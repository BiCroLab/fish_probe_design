# Nexflow Implementation for Probe Design Pipeline

## Purpose

Make the probe_design pipeline more reproducible and robust.

## Already exist

- FISH_probe design pipeline by Quentin 
- Singularity image of it by Zafer
requires few fixes

## Make it into nextflow


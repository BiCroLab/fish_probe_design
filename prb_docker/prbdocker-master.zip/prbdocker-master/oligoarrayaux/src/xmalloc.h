#ifndef XMALLOC_H
#define XMALLOC_H

void* xcalloc(size_t, size_t);
void* xmalloc(size_t);
void* xrealloc(void*, size_t);

#endif

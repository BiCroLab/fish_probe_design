#include "readfa.h"

int main(int argc, char ** argv)
{
    readfa_ut(argc, argv);
    return EXIT_SUCCESS;
}

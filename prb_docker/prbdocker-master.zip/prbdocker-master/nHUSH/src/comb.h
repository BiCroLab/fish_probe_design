/* The purpose of this library is to generate HASH combs for nhush.
 *
 * Ideally the combs should
 * - find all perfect matches, m=0
 * - find all mismatches of length m=1
 * - find all mismatches of length m+1
 *
 * The first approach was to be guided by the explicit calculation
 * of the nCk(L,m) mismatches, and then selecting the comb, tricked
 * by the fewest possible remaining mismatches. (problem 1)
 *
 * After revisiting the problem it is clear that the combs solving problem 1
 * are minimally redundant, and that we could search for combs using the
 * redundancy criterion instead. That is done in v4. (problem 2)
 *
 * It turns out that such combs are 'constant weight codes' also known as
 * 'unbalanced codes'
 * - Constant Weight Codes: An Approach Based on Knuth’s Balancing Method
 *   Vitaly Skachek and Kees A. Schouhamer Immink
 *
 */

#ifndef __comb_h__
#define __comb_h__

#include <errno.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <getopt.h>
#include "util.h"

typedef struct {
    uint8_t * C; /* Row-major storage for combs, one row per comb */
    size_t L; /* length of rows, i.e. sequence length */
    size_t N; /* number of rows, i.e. number of combs */
    size_t Nalloc; /* number of rows allocated */
    int verbose; /* verbosity level */
    int milestone; /* Next radius to conquer */
} comb_t;


/* Create a new comb, free with comb_free */
comb_t * comb_new(int L);
/* Frees up and sets the pointer to NULL */
void comb_free(comb_t ** comb);

/* Dump the combs to a file descriptor */
void comb_fprint(FILE * , comb_t * );

/* Disk operations
 * Only saves/loads C, L, and N
 */
/* Save a comb to disk */
int comb_save(comb_t * comb, char * fname);
/* Load a comb */
comb_t * comb_load(char * fname);


uint8_t * comb_get_v4(comb_t * comb, int H);

// TODO: replace by uint8_t * comb_get_next(comb_t *)
// Get a new hash comb with H elements set to 1
/* suggested version, using gradient-descent like heuristics */
uint8_t * comb_get_v3(comb_t * comb, int H);
// Combining some ideas from 3 and 4, not better than 3
uint8_t * comb_get_v31(comb_t * comb, int H);
/* abandoned heuristics with slow convergence */
uint8_t * comb_get_v2(comb_t * comb, int H);
/* brute force version, really slow but
   probably the best as long as it can cope...
   The caller should not free the return value
   from this one.
*/
uint8_t * comb_get_v1(comb_t * comb, int H);

/* Append a comb generated with comb_get_v... to a comb
* TODO: don't expose
*/
void comb_append(comb_t * comb, const uint8_t * A);

/* See how far we have come
* TODO: don't expose this, integrate where needed
*/
void comb_calculate_milestone(comb_t * comb);

/* Generate mismatches for strings of length L */
uint8_t * genmm(int L, int r, size_t * _Nmm);

/* For the CLI */
/* Also known as N choose k */
size_t binomial(size_t N, size_t k);
double get_detection_p(uint8_t * C, size_t N, size_t L, size_t r,
                       size_t * ncases, size_t * ncovered);
size_t count_remaining_mm(comb_t * comb, size_t r, size_t * ncases);
#endif

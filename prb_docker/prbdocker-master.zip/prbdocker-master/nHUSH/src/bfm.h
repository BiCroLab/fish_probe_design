#ifndef __bfm_h__
#define __bfm_h__

int nhush_bfm(int argc, char ** argv);

/*
 * Brute force matching of a single oligo vs a single chromosome.
 */

#define _GNU_SOURCE
#include <assert.h>
#include <dirent.h>
#include <errno.h>
#include <math.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <getopt.h>
#include <omp.h>

#include "atcg.h"
#include "readfa.h"
#include "util.h"
#include "version.h"
#include "util.h"
#include "bitfield.h"
#include "mindist_gen_mask_lua.h"

typedef struct{
    char * rfile; // Reference file
    char * qfile; // Query file
    char * string; // Query string
    uint8_t * genome_mask;
    char * genome_mask_script;
    float mmin; // Ignore matches < mmin
    float mmax;  // Max mismatches
    int reverse; // reverse complement or not
    int showTable;
    int verbose;
    int colors; /* if you really want... */
    int threads; /* <= 0 -> automatic  */
    int pbinding; /* Evaluate the binding probability */
    /* Create a histogram per chromosome with this bin size */
    int pbinding_bin_size;
    sym_table_t * sym;
    fasta_data_t * fadata;
} bconf_t;

void bconf_show(bconf_t* C);
bconf_t * bconf_new();
void bconf_free(bconf_t * C);

/* Match a single string against the reference */
void bfm_string(bconf_t * C);

/* Match a fa files against the reference */
int bfm_fasta(bconf_t * C);

/** @brief hithist: Hit Histograms
 *
 * For constructing histograms while brute force scanning
 * using a custom bin size.
 */

typedef struct {
    /* Number of tracks reflects the number of records in the reference genome */
    int ntracks;
    /* A double array per track */
    double ** bins;
    /* Size of each track */
    size_t * nbin;
    /* bin size set at creation */
    int bin_size;
    char ** name;
    /*  */
    char * outfolder;
    int folder_already_existed;
} hithist_t;


/** @brief New histogram structure
 *
 * @arg fadata Copies everything that it needs from fadata and does
 * not keep any references to it.
 * @arg bin_size the number of base pairs per bin
 * @param tag will be used to create a new folder 'hithist_tag/'
 *
*/
hithist_t *
hithist_new(const fasta_data_t * fadata,
            int bin_size, const char * tag);

/** @brief Free all memory that was allocated */
void hithist_free(hithist_t *);

/** @brief write to disk
 *
*/
int hithist_write(const hithist_t *);

#endif

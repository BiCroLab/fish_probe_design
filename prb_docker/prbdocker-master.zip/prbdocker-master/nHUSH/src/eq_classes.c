#include "eq_classes.h"
#include "count_sort.h"

/* An obvious optimization which wasn't used is to store a flag
 * for each sequence indicating if the minimal form requires
 * reverse complement or not. At the moment the RC is calculated
 * multiple times per sequence.
 */


/* This determines the size of some buffers later on
 * the program will crash in a nasty way if the number
 * of threads exceeds this value. TODO */
#define MAX_THREADS 1024

seq_info_t * read_eqc(const char * fname, size_t * _N)
{
    *_N = 0;
    FILE * fid = fopen(fname, "r");
    if(fid == NULL)
    {
        printf("Unable to open %s\n", fname);
        return NULL;
    }

    /* get file size */
    fseek(fid, -0L, SEEK_END);
    size_t size = ftell(fid);
    rewind(fid);

    if(size % sizeof(seq_info_t) != 0)
    {
        fprintf(stderr, "Strange file size: %zu not a factor of %zu\n",
                size, sizeof(seq_info_t));
        exit(EXIT_FAILURE);
    }
    size_t N = size / sizeof(seq_info_t);
    printf("%zu sequences described\n", N);

    seq_info_t * seq_info = calloc(N, sizeof(seq_info_t));

    size_t nread = fread(seq_info, sizeof(seq_info_t), N, fid);
    if(nread != N)
    {
        fprintf(stderr, "Failed to read from %s\n", fname);
        fprintf(stderr, "Read %zu / %zu\n", nread, N);
        exit(EXIT_FAILURE);
    }
    fclose(fid);
    *_N = N;
    return seq_info;
}

uint8_t * eqc_gen_ulist(const seq_info_t * eqc, size_t N)
{
    uint8_t * ulist = calloc(N, 1);

#ifndef NDEBUG
    uint32_t max_id = 0;
    for(size_t kk = 0; kk<N; kk++)
    {
        uint32_t id = eqc[kk].class_id;
        max_id < id ? max_id = id : 0;
    }
    printf("max_id=%u\n", max_id);
    assert(max_id <= N);
#endif

    bitfield_t * seen_class = bitfield_new_false(N);
    for(size_t kk = 0; kk < N; kk++)
    {
        size_t class = eqc[kk].class_id;
        if(bitfield_get(seen_class, class) == 0)
        {
            ulist[kk] = 1;
            bitfield_set_true(seen_class, class);
        }
    }
    bitfield_free(seen_class);

    return ulist;
}

/* Read the binary output file and produce some statistics */
int eq_classes_show_stats(char * file)
{
    size_t N = 0;
    seq_info_t * seq_info = read_eqc(file, &N);
    if(N == 0)
    {
        fprintf(stderr, "%s seems empty!\n", file);;
        return EXIT_FAILURE;
    }

    /* Generate a histogram */
    size_t nH = 128; // number of bins
    // for sequences
    size_t * H = calloc(nH, sizeof(size_t));
    // for equivalence classes
    size_t * He = calloc(nH, sizeof(size_t));

    bitfield_t * seen_class = bitfield_new_false(N);

    size_t max_class = 0;
    size_t max_mult = 0;
    size_t n_mult_1 = 0;

    size_t kk = 0;
    pbar_t * pb = pbar_new(&N, &kk);
    pbar_start(pb);

    for(kk = 0; kk < N; kk++)
    {
        size_t class = seq_info[kk].class_id;
        if(class > max_class)
        {
            max_class = class;
        }
        size_t mult = seq_info[kk].class_multiplicity;
        if(mult > max_mult)
        {
            max_mult = mult;
        }
        n_mult_1 += (mult == 1);

        // log4(mult)
        size_t hbin = (size_t) ceil(log2(mult) / 2.0);
        H[hbin]++;
        if(bitfield_get(seen_class, class) == 0)
        {
            He[hbin]++;
            bitfield_set_true(seen_class, class);
        }
    }
    pbar_stop(pb);

    bitfield_free(seen_class);

    printf("%zu equivalence classes\n", max_class+1);
    printf("max multiplicity: %zu\n", max_mult);
    printf("Multiplicity = 1 : %zu (%.2f %%)\n", n_mult_1,
           100.0*(double) n_mult_1 / (double) N);

    printf("Multiplicity,  #sequences, #eq. classes\n");
    for(int kk = 0; kk< (int) nH; kk++)
    {
        if(H[kk] > 0)
        {
            printf("4^%d -- 4^%d-1, %10zu, %10zu\n", kk, kk+1,
                   H[kk], He[kk]);
        }
    }

    free(H);
    free(seq_info);

    return EXIT_SUCCESS;
}

static void
eqc_usage()
{

    printf("Usage: \n");
    printf("nhush eq_classes [OPTIONS]\n");
    printf("\n");
    printf("Required arguments to create equivalence classes:\n");
    printf("--file <file>\n\t specify fasta file to read\n");
    printf("--length <L>\n\t specify the sequence length of interest\n");
    printf("Optional\n");
    printf("--overwrite\n\t Overwrite existing output files\n");
    printf("--out file.fa\n\t"
           "specify the file to write to. Default <file>.L<length>.fa\n");
    printf("--verbose <v>\n\t"
           "Set verbosity level, default 1\n");
    printf("On binary .eqc file:\n");
    printf("--stats file\n\t"
           "Show statistics from the binary file produced by this program\n");
    printf("--export file.eqc\n\t"
           "Export sequences with multiplicity >= low and <= high\n. Combine \n\t"
           "with --out unless you want to write to stdout\n");
    printf("--low t\n\t"
           "min multiplicity for --export\n");
    printf("--high t\n\t"
           "max multiplicity for --export\n");
    printf("\n");
    return;
}


eqc_conf_t *
eqc_conf_new(int argc, char ** argv)
{

    struct option longopts[] = {
        { "export",       required_argument, NULL,   'E' },
        { "low",          required_argument, NULL,   'l' },
        { "high",         required_argument, NULL,   'h' },

        { "file",         required_argument, NULL,   'F' },
        { "length",       required_argument, NULL,   'L' },
        { "overwrite",    no_argument,       NULL,   'o' },
        { "out",          required_argument, NULL,   'O' },

        { "stats",        required_argument, NULL,   'S' },

        { "verbose",      required_argument, NULL,   'V' },
        { NULL,           0,                 NULL,   0   }
    };


    eqc_conf_t * conf = calloc(1, sizeof(eqc_conf_t));
    conf->verbose = 1;
    conf->export_th_low = 10;
    conf->export_th_high = (size_t) -1;

    int ch;
    while((ch = getopt_long(argc, argv,
                            "l:h:E:F:L:oO:S:T:V:",
                            longopts, NULL)) != -1)
    {
        switch(ch)
        {
        case 'E':
            conf->export = 1;
            conf->eqc_name = strdup(optarg);
            break;
        case 'l':
            conf->export_th_low = atol(optarg);
            break;
        case 'h':
            conf->export_th_high = atol(optarg);
            break;
        case 'F':
            conf->fname = strdup(optarg);
            break;
        case 'L':
            conf->seq_len = atoi(optarg);
            break;
        case 'o':
            conf->overwrite = 1;
            break;
        case 'O':
            conf->oname = strdup(optarg);
            break;
        case 'S':
            eq_classes_show_stats(optarg);
            exit(EXIT_SUCCESS);
            break;
        case 'T':
            conf->threshold = atoi(optarg);
            break;
        case 'V':
            conf->verbose = atoi(optarg);
            break;
        }
    }






    if(conf->fname == NULL)
    {
        fprintf(stderr, "--file not specified\n");
        goto fail;
    }

    if(conf->seq_len == 0)
    {
        fprintf(stderr, "--length not specified\n");
        goto fail;
    }

    if(conf->export)
    {
        // No log file used
        return conf;
    }

    if(conf->oname == NULL)
    {
        conf->oname = malloc(strlen(conf->fname) + 128);
        sprintf(conf->oname, "%s.L%zu.eqc", conf->fname, conf->seq_len);
    }

    if(conf->overwrite == 0)
    {
        FILE * fid = fopen(conf->oname, "r");
        if(fid != NULL)
        {
            fprintf(stderr, "%s already exists\n", conf->oname);
            exit(EXIT_FAILURE);
        }
    }

    conf->logname = malloc(strlen(conf->oname) + 16);
    sprintf(conf->logname, "%s.log.txt", conf->oname);

    conf->logfile = fopen(conf->logname, "a");
    if(conf->logfile == NULL)
    {
        fprintf(stderr, "Unable to open %s for writing\n", conf->logname);
    }

    conf->outfile = fopen(conf->oname, "w");
    if(conf->outfile == NULL)
    {
        fprintf(stderr, "Unable to open %s for writing\n", conf->oname);
        exit(EXIT_FAILURE);
    }

    return conf;

 fail:
    eqc_usage();
    exit(EXIT_FAILURE);
}


void
eqc_conf_free(eqc_conf_t * conf)
{
    if(conf == NULL)
    {
        return;
    }

    if(conf->logfile != NULL)
    {
        fclose(conf->logfile);
    }
    if(conf->outfile != NULL)
    {
        fclose(conf->outfile);
    }

    free(conf->logname);

    free(conf->fname);
    free(conf);
}


// Reverse complement
static void
set_rc(uint8_t * r, const uint8_t * f, const size_t L)
{
    for(size_t k = 0; k < L; k++)
    {
        r[L-k-1] = 3-f[k];
    }
    return;
}

typedef struct {
    uint8_t * G;
    uint32_t L;
    uint8_t * buff;
} arg_t;

/* Taking reverse complement into account Verify to yourself that it
 * will not be correct to pick the form with the smallest hash,
 * a full comparison is really needed. */
uint32_t rhashfun8(const uint8_t * A,  const void * _arg)
{
    assert(_arg != NULL);
    arg_t * arg = (arg_t*) _arg;
    const size_t L = arg->L;
    uint8_t * rA = arg->buff + L*omp_get_thread_num();
    set_rc(rA, A, L);

    const uint8_t * M = A; /* Minimal form */
    if(memcmp(rA, A, L) < 0) {
        M = rA; }

    uint32_t hash = 16384*(uint32_t) M[0] + 4096*(uint32_t) M[1] +
        1024*(uint32_t) M[2] + 256*(uint32_t) M[3]
        + 64*(uint32_t) M[4] + 16*(uint32_t) M[5]
        + 4*(uint32_t) M[6] + (uint32_t) M[7];

    return hash;
}
#define rhashfun8_max 65635

static int
rcmpfun(const void * _A, const void * _B, void * _arg)
{

    uint32_t * A = (uint32_t*) _A;
    uint32_t * B = (uint32_t*) _B;

    arg_t * arg = (arg_t*) _arg;
    const size_t L = arg->L;
    uint8_t * s1 = arg->G + *A;
    uint8_t * s2 = arg->G + *B;

    //printf("pos %u vs %u L=%zu\n", *A, *B, L); fflush(stdout);


    /* Quick return without rcomp if possible */
    if(memcmp(s1, s2, L) == 0)
    { return 0; }

    /* Find a buffer region that this thread is allowed to use */
    int thread = omp_get_thread_num();
    if(thread < 1)
    {
        thread = 1;
    }
    assert(thread < MAX_THREADS);
    assert(thread > 0);

    uint8_t * r1 = arg->buff + L*2*thread;
    uint8_t * r2 = arg->buff + L*2*thread + L;

    set_rc(r1, s1, L);
    set_rc(r2, s2, L);
    uint8_t * a = s1;
    uint8_t * b = s2;
    if(memcmp(r1, s1, L) < 0)
    {
        a = r1;
    }
    if(memcmp(r2, s2, L) < 0)
    {
        b = r2;
    }
    return memcmp(a, b, L);
}


static void
eqc_conf_show(FILE * fid, eqc_conf_t * conf)
{
    fprintf(fid, "Reading genome from %s\n", conf->fname);
    fprintf(fid, "Will write to %s\n", conf->oname);
    fprintf(fid, "Overwrite=%d\n", conf->overwrite);
    fprintf(fid, "Sequence length: %zu\n", conf->seq_len);
    fprintf(fid, "Threshold:       %zu\n", conf->threshold);
    fprintf(fid, "Verbosity level: %d\n", conf->verbose);
}

int
export_to_fa(eqc_conf_t * conf)
{

    if(conf->verbose > 0)
    {
        printf("-> export equivalence classes with multiplicity\n");
        if(conf->oname == NULL)
        {
            printf("Will write to stdout\n");
        } else {
            printf("Outfile: %s\n", conf->oname);
        }
        printf("Will export one representative per equivalence class\n");
        printf("when %zu <= multiplicity <= %zu\n",
               conf->export_th_low, conf->export_th_high);
    }

    FILE * fid = stdout;
    if(conf->oname != NULL)
    {
        fid = fopen(conf->oname, "w");
        if(fid == NULL)
        {
            fprintf(stderr, "Unable to open %s for writing\n",
                    conf->oname);
            exit(EXIT_FAILURE);
        }
    }

    uint8_t * rs = malloc(conf->seq_len);

    /* Note: one per sequence, not one per eq class */
    size_t N = 0;
    seq_info_t * seq_info = read_eqc(conf->eqc_name, &N);
    if(N == 0)
    {
        fprintf(stderr, "%s seems empty!\n", conf->eqc_name);;
        return EXIT_FAILURE;
    }

    bitfield_t * seen_class = bitfield_new_false(N);
    for(size_t kk = 0; kk < N; kk++)
    {
        uint32_t class = seq_info[kk].class_id;
        uint32_t mult = seq_info[kk].class_multiplicity;
        if(mult >= conf->export_th_low && mult <= conf->export_th_high)
        {
            if(bitfield_get(seen_class, class) == 0)
            {
                bitfield_set_true(seen_class, class);

                uint8_t * s = conf->G + kk;
                set_rc(rs, s, conf->seq_len);
                uint8_t * ms = s; // Minimal form
                //uint8_t * Ms = rs; // Maximal form
                if(memcmp(rs, s, conf->seq_len) < 0)
                {
                    ms = rs;
                    //                    Ms = s;
                }

                fprintf(fid, "> %u id%u\n", mult, class);
                fprint_seq(fid, ms, conf->seq_len);
                //fprintf(fid, " < ");
                //fprint_seq(fid, Ms, conf->seq_len);
                fprintf(fid, "\n");
            }
        }
    }
    free(rs);
    bitfield_free(seen_class);
    free(seq_info);

    return EXIT_SUCCESS;
}


int
eq_classes(int argc, char ** argv)
{
    eqc_conf_t * conf = eqc_conf_new(argc, argv);

    if(conf->verbose > 1)
    {
        eqc_conf_show(stdout, conf);
    }

    if(conf->logfile != NULL) {
        eqc_conf_show(conf->logfile, conf);
    }

    if(conf->verbose > 0)
    {
        printf("Reading %s\n", conf->fname);
    }

    conf->G = readfa(conf->fname, &conf->nG, &conf->G_records);

    if(conf->G == NULL)
    {
        fprintf(stderr, "Something went wrong when reading %s\n", conf->fname);
        fprintf(stderr, "Unable to continue\n");
        exit(EXIT_FAILURE);
    }

    conf->nseq = conf->nG - conf->seq_len+1;

    if(conf->export == 1)
    {
        return export_to_fa(conf);
    }

    /*
     * Sort sequences
     */
    if(conf->verbose > 0)
    {
        printf("Sorting %zu oligos into equivalence classes\n", conf->nseq);
    }

    /* Set up arguments to the hash function and the comparison
       function */
    arg_t cs_arg;
    cs_arg.L = conf->seq_len;
    cs_arg.G = conf->G;
    cs_arg.buff = (uint8_t *) malloc(MAX_THREADS*cs_arg.L*2);

    count_sort_t * cs =
        count_sort_idx(conf->G,
                       conf->nseq,
                       rcmpfun,
                       rhashfun8,
                       rhashfun8_max,
                       &cs_arg);
    free(cs->bucket_start);

    const uint32_t * GP = cs->buckets;
    free(cs);

    /*
     * Identify the equivalency classes and their sizes
     */
    if(conf->verbose > 0)
    {
        printf("Identifying unique sequences withing the bins\n");;
    }

    // TODO: we don't need to compare over bin boundaries, on the
    // other hand we don't use that many bins so it is ok. But it would be
    // nice to do this in parallel.
    // In parallel we could compare all pairs of adjacent oligos.

    size_t nseq = conf->nseq;

    uint8_t * equal = calloc(nseq, 1);

#pragma omp parallel for shared(equal)
    for(size_t kk = 0 ; kk < nseq-1; kk++)
    {
        if(rcmpfun(&GP[kk], &GP[kk+1], &cs_arg) == 0)
        {
            equal[kk] = 1;
        }
    }

    /* To be written to disk later on*/
    seq_info_t * seq_info = calloc(nseq, sizeof(seq_info_t));

    size_t total_seq = 0;
    size_t first_idx = 0;
    size_t class_id = 0;

    volatile size_t idx = 0;
    pbar_t * pb = pbar_new(&nseq, &idx);

    if(conf->verbose > 0)
    {
        pbar_start(pb);
    }

    for(idx = 0; idx < nseq; idx++)
    {
        int found_more = 0;

        if(idx + 1 == nseq)
        { /* Reached the last seq, can't compare forward */
            found_more = 0;
        } else  {
            if(equal[idx] == 1) {
                found_more = 1;
            }
        }

        if(!found_more)
        {
            size_t neq = idx - first_idx + 1;
            for(size_t ss = first_idx; ss <= idx; ss++)
            {
                size_t i = GP[ss];
                seq_info[i].class_id = class_id;
                seq_info[i].class_multiplicity = neq;
            }
            class_id++;
            total_seq += neq;
            first_idx = idx+1;
        }
    }
    free(equal);
    pbar_stop(pb);

    printf("Found %zu equivalence classes in %zu sequences\n",
           class_id, total_seq);

    printf("Writing binary result to %s\n", conf->oname);

    FILE * fid = fopen(conf->oname, "w");
    if(fid == NULL)
    {
        fprintf(stderr, "Unable to open %s for writing\n", conf->oname);
        exit(EXIT_FAILURE);
    }

    size_t nwritten = fwrite(seq_info, sizeof(seq_info_t), nseq, fid);
    if(nwritten != nseq)
    {
        fprintf(stderr, "ERROR: Could only write %zu / %zu\n", nwritten, nseq);
        fprintf(stderr, "Disk full?\n");
        exit(EXIT_FAILURE);
    }
    fclose(fid);

    free(cs_arg.buff);

    eqc_conf_free(conf);

    return EXIT_SUCCESS;
}

#include "eq_classes.h"


int main(int argc, char ** argv)
{
    return eq_classes(argc, argv);
}

#/bin/env bash
set -e

# The _ut programs should contain self-tests but some also print
# to the screen for manual inspection.

# Spits out some tables that can be manually verified
./atcg_ut

# This one you just have to observe ... takes about 14 s
./pbar_ut

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <time.h>

/* Randomly change an input string to produce a fixed number of
 * differences
*/

static void
usage()
{
  printf("Usage:\n");
  printf("-f min_mm : mismatches, least\n");
  printf("-t max_mm : mismatches, most\n");
  printf("-s ATC... : string\n");
  printf("-c        : disable comment strings in output\n");
  printf("-n nseq   : number of sequences per mismatch\n");
  printf("-r seed   : set a seed for the random number generator\n");
  printf("-p level  : set how much to print to stdout, 0=little, 1=more\n");
  printf("See the man-page for more info\n");
}

static char ntshift(char nt)
{
  switch(nt)
  {
    case 'A':
      return 'T';
    case 'T':
      return 'C';
    case 'C':
      return 'G';
    case 'G':
      return 'A';
    }
  return 'X';
}

static void verify_input_string(char * s)
{
  for(size_t kk = 0; kk<strlen(s); kk++)
  {
    if( !( (s[kk] == 'A') || (s[kk] == 'T') || (s[kk] == 'C') || s[kk] == 'G'))
    {
      printf("Unknown characters used\n");
      exit(1);
    }
  }
}


static int hdist(char * r, char * s)
{
  int N = strlen(r);
  int dist = 0;
  for(int kk = 0; kk<N; kk++)
    if(r[kk] != s[kk])
      dist++;
  return dist;
}

static void printmm(char * r, char * s, int mm)
{

  while(hdist(s, r)<mm)
  {
    int pos = rand() % strlen(s);
    s[pos] = ntshift(s[pos]);
  }

  printf("%s\n", s);

}

int nhush_genmm(int argc, char ** argv)
{

    if(argc == 1)
    {
        usage();
        exit(1);
    }
  char * s = malloc(1024*sizeof(char));
  sprintf(s, "\b");
  char * s2 = malloc(1024*sizeof(char));

  int comments = 1;
  int mm_from = 0;
  int mm_to = 0;
  size_t N = 1;
  int verbose = 0;
  unsigned int r_seed = time(NULL)*getpid();

  int ch;
  while((ch = getopt(argc, argv, "cf:t:m:s:hn:r:p:")) != -1)
  {
    switch(ch) {
      case 'c':
        comments = 0;
        break;
      case 'f':
        mm_from = atoi(optarg);
        break;
      case 't':
        mm_to = atoi(optarg);
        break;
      case 's':
        strcpy(s, optarg);
        break;
      case 'n':
        N = atol(optarg);
        break;
      case 'h':
        usage();
        return(0);
      case 'r':
          r_seed = atol(optarg);
        break;
      case 'p':
        verbose = atoi(optarg);
        break;
      default:
        printf("Unknown option\n");
        return(0);
    }
  }

  if(verbose>0)
  {
    printf("# mm_from: %d\n", mm_from);
    printf("# mm_to: %d\n", mm_to);
    printf("# N: %zu\n", N);
    printf("# S: %s\n", s);
    printf("# r_seed: %u\n", r_seed);
  }

if(strlen(s) == 0)
{
  printf("No string specified.\n");
  exit(1);
}

if(mm_to > (int) strlen(s))
{
  printf("Can't generate sequences with %d mismatches when the sequence length is %zu\n", mm_to, strlen(s));
  exit(1);
}

verify_input_string(s);

  srand(r_seed);

size_t id = 0;
  for(int mm = mm_from; mm<=mm_to; mm++)
  {
    for(size_t nn = 0; nn<N; nn++)
    {
      if(comments)
        printf(">seq %zu, %d mm\n", id++, mm);
      strcpy(s2, s);
      printmm(s, s2, mm);
    }
  }

  return EXIT_SUCCESS;
}

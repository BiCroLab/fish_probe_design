#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>

/*
 * Might fail to produce a string of full length if it hits EOF
 * before all characters have been read.
 *
 * Does not warn if N is outside of the file.
 */

void readrand_usage()
{
    printf("reads N characters 'A'--'z' in a file, starting at a random position\n");
    printf("Usage:\n");
    printf("$ readrand file L N\n");
    printf("L: string length\n");
    printf("N: number of strings to extract\n");
    printf("There is no guarantees that L characters can be found\n");
    printf("Returns 1 on failure\n");
}

static int
print_randseq(FILE * f, size_t fsize, size_t L)
{
    char * seq = malloc(L+1);
    char * buff = malloc(10*L);

    seq[L] = '\0';

    size_t writepos = 0;
    size_t attempt = 0;
    while(writepos != L)
    {
        writepos = 0;
        size_t maxpos = fsize-L;
        size_t pos = rand() % (maxpos+1);
        fseek(f, pos, SEEK_SET);
        if(errno != 0)
        {
            fprintf(stderr, "errno=%d\n", errno);
            exit(EXIT_FAILURE);;
        }
        size_t nread = fread(buff, 1, 10*L, f);

        size_t readpos = 0;
        while( readpos < nread  && writepos < L)
        {
            char u = (char) toupper(buff[readpos++]);
            if( u == 'A'
                || u == 'T'
                || u == 'C'
                || u == 'G')
            {
                seq[writepos++] = u;
            }
        }
        if(attempt++ == 100)
        {
            fprintf(stderr, "Failed to extract a sequence 100 times\n");
            exit(EXIT_FAILURE);
        }
    }

    printf("%s\n", seq);
    free(seq);
    free(buff);
    return 0;
}

int nhush_readrand(int argc, char ** argv)
{
    size_t N = 1; /* Number of sequences to extract */

    if(argc < 3)
    {
        readrand_usage();
        exit(1);
    }
    size_t L = atol(argv[2]);

    if(argc > 3)
    {
        N = atoi(argv[3]);
    }

    FILE * f = fopen(argv[1], "r");

    if(f == NULL)
    {
        fprintf(stderr, "Failed to open %s\n", argv[1]);
        return EXIT_FAILURE;
    }

    fseek(f, 0L, SEEK_END);
    size_t fsize = ftell(f);

    srand(time(NULL)*getpid());

    if(L>fsize)
    {
        fprintf(stderr, "Can't extract %zu characters from a file of %zu bytes\n", L, fsize);
        exit(1);
    }


    if(N == 1)
    {
        print_randseq(f, fsize, L);
        goto done;
    }

    for(size_t kk = 0; kk<N; kk++)
    {
        printf("> %zu/%zu\n", kk+1, N);
        print_randseq(f, fsize, L);
    }

done:
    fclose(f);
    return EXIT_SUCCESS;
}

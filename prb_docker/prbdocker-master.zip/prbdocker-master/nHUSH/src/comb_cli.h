#ifndef comb_cli_h_
#define comb_cli_h_

#include "comb.h"
#include "version.h"

int nhush_comb(int argc, char ** argv);

#endif

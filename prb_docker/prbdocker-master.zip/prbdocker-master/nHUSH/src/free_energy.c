/* https://doi.org/10.1093/nar/gkz071
dAA/dTT 	−0.56 ± 0.03
dAT/dTA 	−0.37 ± 0.03
dTA/dAT 	−0.28 ± 0.03
dCA/dGT 	−0.80 ± 0.04
dGT/dCA 	−0.84 ± 0.03
dCT/dGA 	−0.66 ± 0.05
dGA/dCT 	−0.86 ± 0.03
dCG/dGC 	−1.27 ± 0.05
dGC/dCG 	−1.40 ± 0.05
dGG/dCC 	−1.06 ± 0.04
Initiation GC 	1.33 ± 0.16
Initiation AT 	1.98 ± 0.67
*/

/* https://doi.org/10.1073/pnas.95.4.1460 */
float FE[4][4]; /* Free Energy */
FE[numA][numA] = -1.00;
FE[numT][numT] = -1.00;
FE[numA][numT] = -0.88;
FE[numT][numA] = -0.58;
FE[numC][numA] = -1.45;
FE[numT][numG] = -1.45;
FE[numG][numT] = -1.44;
FE[numC][numA] = -1.44;
FE[numC][numT] = -1.28;
FE[numA][numG] = -1.28;
FE[numG][numA] = -1.30;
FE[numT][numC] = -1.30;
FE[numC][numG] = -2.17;
FE[numG][numC] = -2.24;
FE[numG][numG] = -1.84;
FE[numC][numC] = -1.84;
FE_terminal[numG] = 0.98;
FE_terminal[numC] = 0.98;
FE_terminal[numA] = 1.03;
FE_terminal[numT] = 1.03;

/* dH, dS ...  */


// https://www.sciencedirect.com/topics/agricultural-and-biological-sciences/base-pair-mismatch


/* Related:
 * Secondary structures:
 * 10.1137/060651100
 */

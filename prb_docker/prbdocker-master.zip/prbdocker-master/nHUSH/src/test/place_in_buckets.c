#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdint.h>
#include <assert.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#define uintG_t uint64_t


typedef struct{
    int h;
    uint8_t * ulist;
    size_t nbuckets;
} conf_t;

void cumsum_inplace(uintG_t * restrict B, const size_t n)
{
    size_t sum = 0;
    for(size_t kk = 0; kk < n; kk++)
    {
        sum+=B[kk];
        B[kk]=sum;
    }
    return;
}


static double timespec_diff(struct timespec* end, struct timespec * start)
{
    double elapsed = (end->tv_sec - start->tv_sec);
    elapsed += (end->tv_nsec - start->tv_nsec) / 1000000000.0;
    return elapsed;
}

uintG_t * place_in_buckets(conf_t * conf, uintG_t * restrict B,
                           const uint32_t * restrict chashes,
                           const size_t nchashes)
{
    uintG_t * restrict S = malloc(nchashes*sizeof(uintG_t));
    const uint8_t * ulist = conf->ulist;
    for(size_t kk = 0; kk < nchashes; kk++)
    {
        if(ulist[kk] == 0)
            continue;

        __builtin_prefetch((const void*) &B[chashes[kk + 32]]);
        __builtin_prefetch((const void*) &S[B[chashes[kk + 4]]]);

        S[B[chashes[kk]]++] = kk;
    }
    return S;
}

/* Defunctional options, too see what hurts the performance the most
* The B++ is at most 1% */
uintG_t * place_in_buckets_defun1(conf_t * conf, uintG_t * restrict B,
                           const uint32_t * restrict chashes,
                           const size_t nchashes)
{
    uintG_t * restrict S = malloc(nchashes*sizeof(uintG_t));
    const uint8_t * restrict ulist = conf->ulist;
    for(size_t kk = 0; kk < nchashes; kk++)
    {
        if(ulist[kk] == 0)
            continue;

        __builtin_prefetch((const void*) &B[chashes[kk + 32]], 0, 2);
        __builtin_prefetch((const void*) &S[B[chashes[kk + 4]]], 0, 2);


        S[B[chashes[kk]]++] = kk;
    }
    return S;
}


uintG_t * place_in_buckets_alt(conf_t * conf, uintG_t * restrict B,
                               const uint32_t * restrict chashes,
                               const size_t nchashes)
{
    uintG_t * restrict S = malloc(nchashes*sizeof(uintG_t));
    const uint8_t * ulist = conf->ulist;
#pragma omp parallel shared(S, B, ulist)
    {
        uint32_t tid = omp_get_thread_num();
        int nth = omp_get_max_threads();

        for(size_t kk = 0; kk < nchashes; kk++)
        {
            if(ulist[kk] == 0)
                continue;

            if( (chashes[kk] % nth) == tid)
            {
                S[B[chashes[kk]]++] = kk;
            }
        }
    }

    return S;
}



uintG_t * get_bucket_sizes(conf_t * conf, const uint32_t * restrict chashes, const size_t nchashes)
{
    int h = conf->h;
    uint8_t * ulist = conf->ulist;
    uintG_t * restrict _bsize = calloc(powl(4, h)+2, sizeof(uintG_t));
    if(_bsize == NULL)
    {
        fprintf(stderr, "Allocation failed at line %d\n", __LINE__);
    }
    uintG_t * bsize = _bsize+2; /* NOTE: SHIFTED 2 steps RIGHT */
    for(size_t kk = 0; kk<nchashes; kk++)
    {
        if(ulist[kk] == 1)
        {
            bsize[(size_t) chashes[kk]]++;
        }
    }
    return _bsize;
}

typedef struct {
    uintG_t * S;
    size_t N;
} run_t;

run_t * run(int argc, char ** argv, int method, int nn)
{
    size_t N = 1000*1000000;
//    N = 100;

    if(argc > 1)
    {
        N = atol(argv[1]);
    }

    conf_t * conf = malloc(sizeof(conf_t));
    conf->h = 14;
    conf->nbuckets = pow(4, conf->h);

    if(N > 1000000)
    {
        printf("Using %.1f M elements and %zu buckets\n", (double) N / 1000000.0, conf->nbuckets);
    } else {
        printf("Using %zu elements and %zu buckets\n", N, conf->nbuckets);
    }
    /* use-list, to be set to 1 */
    conf->ulist = malloc(N*sizeof(uint8_t));
    for(size_t kk = 0; kk<N; kk++)
    {
        conf->ulist[kk] = 1;
    }
    /* Buckets */
    uint32_t * chashes = malloc(N*sizeof(uint32_t));
    for(size_t kk = 0; kk<N; kk++)
    {
        chashes[kk] = rand() % conf->nbuckets;
    }
    size_t nchashes = N;
    uintG_t * B = get_bucket_sizes(conf, chashes, nchashes);
    cumsum_inplace(B+1, conf->nbuckets);



    struct timespec t0, t1;
    double dt = 0;
    uintG_t * S = NULL;
    if(method == 0)
    {
        clock_gettime(CLOCK_REALTIME, &t0);
        S = place_in_buckets(conf, B+1, chashes, nchashes);
        clock_gettime(CLOCK_REALTIME, &t1);
        printf("place_in_buckets\n");
        dt =  timespec_diff(&t1, &t0);
        printf("Took %f s\n", dt);
    }

    if(method == 1)
    {

        omp_set_num_threads(nn);
        clock_gettime(CLOCK_REALTIME, &t0);
        S = place_in_buckets_alt(conf, B+1, chashes, nchashes);
        clock_gettime(CLOCK_REALTIME, &t1);
        printf("place_in_buckets_alt, %d threads\n", nn);
        dt =  timespec_diff(&t1, &t0);
        printf("Took %f s\n", dt);

    }

    if(method == 2)
    {

        omp_set_num_threads(nn);
        clock_gettime(CLOCK_REALTIME, &t0);
        S = place_in_buckets_defun1(conf, B+1, chashes, nchashes);
        clock_gettime(CLOCK_REALTIME, &t1);
        printf("place_in_buckets_defun1\n");
        dt =  timespec_diff(&t1, &t0);
        printf("Took %f s\n", dt);

    }





    run_t * ret = malloc(sizeof(run_t));
    free(B);
    ret->N = N;
    ret->S = S;

    return ret;
}


int main(int argc, char ** argv)
{
    unsigned int rseed = 0;
    srand(rseed);
    run_t * B0 = run(argc, argv, 0, 0);
    srand(rseed);
    run_t * Bx = run(argc, argv, 2, 0);
    srand(rseed);
    run_t * B1 = run(argc, argv, 1, 8);
    for(size_t kk = 0 ; kk<B0->N; kk++)
    {
        //printf("%zu -- %lu %lu\n", kk, B0->S[kk], B1->S[kk]);
        if(B0->S[kk] != B1->S[kk])
        {

            printf("Sorted results differ\n");
            return(EXIT_FAILURE);
        }
    }
    free(B0->S);
    free(B1->S);
    free(B0);
    free(B1);
    return(EXIT_SUCCESS);
}

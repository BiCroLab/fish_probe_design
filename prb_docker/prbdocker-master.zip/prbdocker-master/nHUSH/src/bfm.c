#include "bfm.h"


hithist_t * hithist_new(const fasta_data_t * fasta, int bin_size, const char * tag)
{
    hithist_t * H = calloc(1, sizeof(hithist_t));
    H->bin_size = bin_size;
    if(bin_size <= 0)
    {
        fprintf(stderr, "ERROR: The bin size has to be positive\n");
        exit(EXIT_FAILURE);
    }
    H->ntracks = fasta->records->n;
    H->bins = malloc(H->ntracks*sizeof(double*));
    H->name = malloc(H->ntracks*sizeof(char*));
    H->nbin = malloc(H->ntracks*sizeof(size_t*));

    H->outfolder = calloc(strlen(tag)+32, 1);
    sprintf(H->outfolder, "hithist_%s", tag);
    if(H->outfolder[strlen(H->outfolder)-1] != '/')
    {
        H->outfolder[strlen(H->outfolder)] = '/';
    }

    DIR* dir = opendir(H->outfolder);
    if (dir) {
        /* Directory exists. */
        closedir(dir);
        H->folder_already_existed = 1;
    }

    for(int kk = 0; kk<H->ntracks; kk++)
    {
        ldiv_t d = ldiv(fasta->records->len[kk], bin_size);
        size_t nbin = d.quot;
        if(d.rem)
        {
            nbin++;
        }
        H->nbin[kk] = nbin;
        H->bins[kk] = calloc(nbin, sizeof(double));
        H->name[kk] = strdup(fasta->records->name[kk]);
    }

    //printf("new histogram; bin size %d, tag=%s\n", H->bin_size, tag);
    return H;
}

void hithist_free(hithist_t * H)
{
    if(H == NULL)
    {
        return;
    }
    for(int kk = 0; kk<H->ntracks; kk++)
    {
        free(H->bins[kk]);
        free(H->name[kk]);
    }
    free(H->name);
    free(H->bins);
    free(H->nbin);
    free(H->outfolder);
    free(H);
    return;
}

int hithist_write(const hithist_t * H)
{


    if(mkdir(H->outfolder, 0700))
    {
        int err = errno;
        if(err)
        {
            if(err != EEXIST)
            {
                fprintf(stderr, "Unable to create the folder %s\n", H->outfolder);
                exit(EXIT_FAILURE);
            }
        }
    }

    /* Records.tsv file */
    char *rfname = malloc(strlen(H->outfolder) + 128);
    sprintf(rfname, "%srecords.tsv", H->outfolder);
    FILE * rfid = fopen(rfname, "w");
    fprintf(rfid, "file\trecord\n");

    /* metainfo.txt */
    char * mfname = malloc(strlen(H->outfolder) + 128);
    sprintf(mfname, "%smetainfo.txt", H->outfolder);
    FILE * mfid = fopen(mfname, "w");
    fprintf(mfid, "Histogram data with bin size=%d bp\n", H->bin_size);
    fprintf(mfid, "Track names in %s\n", rfname);
    fprintf(mfid, "histogram data saved as double in machine endianness\n");
    fclose(mfid);


    char * fname = malloc(strlen(H->outfolder) + 128);
    for(int kk = 0; kk<H->ntracks; kk++)
    {
        sprintf(fname, "%strack_%03d.double", H->outfolder, kk);
        fprintf(rfid, "%s\t%s\n", fname, H->name[kk]);
        FILE * fid = fopen(fname, "w");
        size_t nwritten = fwrite(H->bins[kk], sizeof(double), H->nbin[kk], fid);
        if(nwritten != H->nbin[kk])
        {
            fprintf(stderr, "Error writing to %s. Wrote %zu / %zu\n",
                    fname, nwritten, H->nbin[kk]);
        }
        fclose(fid);
    }

    free(fname);
    free(rfname);
    fclose(rfid);

    return EXIT_SUCCESS;
}

void bconf_show(bconf_t* C)
{
    printf("rfile=%s\n", C->rfile);
    printf("qfile=%s\n", C->qfile);
    printf("string=%s\n", C->string);
    printf("mmin=%.2f\n", C->mmin);
    printf("mmax=%.2f\n", C->mmax);
    printf("reverse=%d\n", C->reverse);
    printf("showTable=%d\n", C->showTable);
}

bconf_t * bconf_new()
{
    bconf_t * C = calloc(1, sizeof(bconf_t));
    C->mmin = 0;
    C->mmax = 5;
    C->reverse = 1;
    C->showTable = 0;
    C->verbose = 1;
    C->colors = 0;
    C->threads = 0;
    return C;
}

void bconf_free(bconf_t * C)
{
    sym_table_free(C->sym);
    fasta_data_free(C->fadata);
    free(C->rfile);
    free(C->string);
    free(C->qfile);
    free(C->genome_mask);
    free(C->genome_mask_script);
    return;
}

void bfm_usage()
{
    printf("Brute force matching. Genomic sequence vs "
           "reference genome.\n");
    printf("\n");
    printf("Usage:\n");
    printf(" bfm -r reference.fa -s string -v -m -x\n");
    printf("\n");
    printf("OPTIONS:\n");
    printf(" -r [file]"
           "\n\t Specify reference file\n");
    printf(" -s [string]"
           "\n\t Specify query string\n");
    printf(" -q qfile"
           "\n\t Specify a fasta query file."
           "\n\t not to be used with -s"
           "\n\t note: bfm will act as filter and remove any"
           "\n\t matching sequences from the input file\n");
    printf(" -M [number]"
           "\n\t Specify the Hamming radius "
           "\n\t (distance <=M is considered a hit)\n");
    printf(" -y"
           "\n\t Don't scan reverse complement\n");
    printf(" -h"
           "\n\t Show this help message\n");
    printf(" -V, --version"
           "\n\t Show version\n");
    printf(" -t"
           "\n\t show summary table at the end\n");
    printf(" -v v, --verbose v"
           "\n\t set verbose level\n");
    printf(" --threads t"
           "\n\t Set the number of threads to use\n");
    printf(" --colors \n\t use colors in output\n");
    printf(" --probb\n\t Evaluate the binding probability\n");
    printf(" --probb-profiles binsize"
           "\n\t also calculate and store histograms/profiles for all tracks in "
           "\n\t the fasta file and save to a sub folder for plotting\n");
    printf(" --genome-mask file.lua"
           "\n\t specify lua script to mask the genome -- i.e. that will not be "
           "\n\t matched \n");
    printf("\n");
    printf("http://github.com/elgw/nHUSH/\n");
    return;
}

int bfm_hamming(uint8_t * A, uint8_t * B, int N)
{
    int d = N;
    for(int kk = 0; kk<N; kk++)
    {
        d -= (A[kk] == B[kk]);
    }
    return d;
}

static uint8_t hamming_distance(const uint8_t * A, const uint8_t * B, const int L)
{
    int d = 0;
    for(int kk = 0; kk<L; kk++)
    {
        if(A[kk] != B[kk])
        {
            d++;
        }
    }
    return d;
}

/* Hamming distance using a 16x16 elements table */
static float hamming_distance_16x16(const uint8_t * A,
                                    const uint8_t * B, const int L,
                                    const float * distance16x16)
{
    float distance = 0.0;

    for(int kk = 0; kk<L; kk++)
    {
        size_t idx = 16*A[kk]+B[kk];
        assert(idx < 16*16);
        float d = distance16x16[idx];
        distance += d;
    }

    return distance;
}



/** Evaluate
 * \sum 4^{-H(s, g_i)}
 * for the reference string vs all other genomic strings (g_i)
 */
double prob_binding(const bconf_t *C,
                    const fasta_data_t * fadata,
                    const sym_table_t * sym,
                    hithist_t * pb_hist)
{
    double pb = 0;
    char * S = strdup(C->string);
    size_t len = strlen(S);
    sym_replace_str(S, len, sym);
    /* NOTE: RS is not \0 terminated */
    char * RS = sym_reverse_complement(S, len, sym);

    const uint8_t * D = fadata->data;
    size_t nD = fadata->data_size;


    if(pb_hist == NULL)
    {
#pragma omp parallel for reduction(+:pb)
        for(size_t pos = 0; pos < nD - len; pos++)
        {
            if(C->genome_mask)
            {
                if(C->genome_mask[pos] == 0)
                {
                    continue;
                }
            }
            double h1 = hamming_distance_16x16((uint8_t*) S,
                                               (uint8_t*) D+pos,
                                               len, sym->dist);
            double h2 = hamming_distance_16x16((uint8_t*) RS,
                                               (uint8_t*) D+pos,
                                               len, sym->dist);
            double H = h1;
            h2 < h1 ? H = h2 : 0 ;
            pb += pow(4.0,  -H);
        }
    }

    if(pb_hist != NULL)
    {
#pragma omp parallel for reduction(+:pb)
        for(int track = 0; track < fadata->records->n; track++)
        {
            size_t pos0 = fadata->records->pos[track];
            size_t pos1 = pos0 + fadata->records->len[track] - len;
            double * hist = pb_hist->bins[track];
            for(size_t pos = pos0; pos < pos1; pos++)
            {
                if(C->genome_mask)
                {
                    if(C->genome_mask[pos] == 0)
                    {
                        continue;
                    }
                }

                double h1 = hamming_distance_16x16((uint8_t*) S,
                                                   (uint8_t*) D+pos,
                                                   len, sym->dist);
                double h2 = hamming_distance_16x16((uint8_t*) RS,
                                                   (uint8_t*) D+pos,
                                                   len, sym->dist);
                double H = h1;
                h2 < h1 ? H = h2 : 0 ;
                double _pb = pow(4.0,  -H);
                size_t hist_bin = (pos-pos0)/pb_hist->bin_size;
                hist[hist_bin] += _pb;
                pb+=_pb;
            }
        }
    }

    free(RS);
    free(S);
    return pb;
}

/* Remove at most one instance of '\n' at the end of a string.
 * i.e., convert 'ATC\n\0' -> 'ATC\0\0' and return the new length.
 * Used when parsing fasta files
 */
static int char_trimnewline(char * S, int N)
{
    assert(strlen(S) == (size_t) N);
    assert(N>0);

    if(N>0)
    {
        if(S[N-1] == '\n')
        {
            S[N-1] = '\0';
            return N-1;
        }
    }
    return N;
}

/* Populate C->sym and C->fadata */
void bfm_load_genome(bconf_t * C)
{
    /* Read the reference file */
    C->sym = sym_table_new();

    if(C->verbose > 1)
    {
        sym_table_show(C->sym);
    }

    if(C->verbose > 0)
    {
        printf("Loading %s\n", C->rfile);
    }

    int fourbase = 0;
    C->fadata = readfa_sym(C->rfile,
                                       C->sym,
                                       fourbase,
                                       C->verbose);

    if(C->verbose > 1)
    {
        fasta_records_fprint(stdout, C->fadata->records);
    }

    if(C->genome_mask_script != NULL)
    {
        if(C->verbose > 0)
        {
            printf("Applying genome mask from %s\n", C->genome_mask_script);

        }

        FILE * outfile = stdout;
        int close_outfile = 0;

        if(C->verbose < 2)
        {
            outfile = fopen("/dev/null", "w");
            close_outfile = 1;
        }
        C->genome_mask =
            mindist_gen_mask_lua(outfile,
                                 C->genome_mask_script,
                                 C->fadata->records, C->fadata->data_size);
        if(close_outfile)
        {
            fclose(outfile);
        }


        if(C->verbose > 1 ) {
            printf("Press enter to continue\n");
            getchar();
        }
    }
    return;
}

/* Query each sequence in a fasta file against the genome
 * TODO: This is a mess, should only need to call bfm_string for
 * each record ... and should load the fasta file in the same way
 * as we read the genome ...
 *
 * Possibly we can do the parallelization more clever in order to
 * retain some locality.
 */
int bfm_fasta(bconf_t * C)
{

    free(C->string);

    FILE * fquery = fopen(C->qfile, "r");
    if(fquery == NULL)
    {
        printf("Unable to open %s for reading\n", C->qfile);
        exit(EXIT_FAILURE);
    }

    size_t linecap = 1024;
    char * string = malloc(1024+2);
    ssize_t qread = 0;
    size_t seq_nr = 0;
    while( (qread = getline(&string, &linecap, fquery)) != -1)
    {
        // Remove '\n' from the end of R
        qread = char_trimnewline(string, qread);
        if(string[0] < 'A' || string[0] > 'T') // if comment or unrecognized
        {
            continue;
        }
        C->string = string;

        seq_nr++;
        printf("-> Processing seq #%zu : %s\n", seq_nr, string);

        bfm_string(C);
    }

    return 0;
}

void show_version_bfm()
{
    printf("nHUSH-bfm version %s\n", NHUSH_VERSION);
}

void bfm_argparsing(bconf_t * C, int argc, char ** argv)
{
    int gotr = 0; // reference
    int gots = 0; // string
    int gotq = 0; // query file

    struct option longopts[] = {
        {"colors",      no_argument,       NULL, 'c'},
        {"help",        no_argument,       NULL, 'h'},
        {"from",        required_argument, NULL, 'm'},
        {"query",       required_argument, NULL, 'q'},
        {"ref",         required_argument, NULL, 'r'},
        {"string",      required_argument, NULL, 's'},
        {"table",       no_argument,       NULL, 't'},
        {"verbose",     required_argument, NULL, 'v'},
        {"no-reverse",  no_argument,       NULL, 'y'},
        {"genome-mask", required_argument, NULL, 'G'},
        {"to",          required_argument, NULL, 'M'},
        {"probb",       no_argument,       NULL, 'P'},
        {"probb-profiles", required_argument, NULL, 'Q'},
        {"version",     no_argument,       NULL, 'V'},
        {"threads",     required_argument, NULL, 'T'},
        {NULL, 0, NULL, 0}};

    char ch;
    while((ch = getopt_long(argc, argv,
                            "cG:r:s:hvm:M:xytPQ:q:v:VT", longopts, NULL)) != -1)
    {
        switch(ch){
        case 'C':
            C->colors = 1;
            break;
        case 'q':
            C->qfile = malloc(strlen(optarg)+2);
            sprintf(C->qfile, "%s", optarg);
            gotq = 1;
            break;
        case 'c':
            C->verbose = atoi(optarg);;
            break;
        case 'G':
            free(C->genome_mask_script);
            C->genome_mask_script = strdup(optarg);
            assert(C->genome_mask_script != NULL);
            break;
        case 'h':
            bfm_usage();
            exit(1);;
            break;
        case 'P':
            C->pbinding = 1;
            break;
        case 'Q':
            C->pbinding = 1;
            C->pbinding_bin_size = atoi(optarg);
            break;
        case 'V':
            show_version_bfm();
            exit(EXIT_SUCCESS);
        case 'v':
            C->verbose = atoi(optarg);
            break;
        case 'r':
            C->rfile = malloc(strlen(optarg)+2);
            strcpy(C->rfile, optarg);
            gotr = 1;
            break;
        case 's':
            C->string = malloc(strlen(optarg)+2);
            strcpy(C->string, optarg);
            gots = 1;
            break;
        case 'm':
            C->mmin = atof(optarg);
            break;
        case 'M':
            C->mmax = atof(optarg);
            break;
        case 'y':
            C->reverse = 0;
            break;
        case 't':
            C->showTable = 1;
            break;
        case 'T':
            C->threads = atoi(optarg);
            break;
        }
    }

    if(C->verbose > 1)
    {
        bconf_show(C);
    }

    if(gotr == 0)
    {
        printf("--r file : not specified (reference genome)\n");
        bfm_usage();
        exit(1);
    }

    if(gots == 0 && gotq == 0)
    {
        printf("-s string : not specified (query string)\n");
        bfm_usage();
        exit(1);
    }

    if(gots == 1 && gotq == 1)
    {
        printf("Both query string and query file specified!\n");
        bfm_usage();
        exit(1);
    }

    if(C->threads > 0)
    {
        omp_set_num_threads(C->threads);
    }

}

void query_string_numeric(bconf_t * C,
                          fasta_data_t * fadata)
{
    size_t * M = calloc((C->mmax+1), sizeof(size_t));

    int len = strlen(C->string);
    char * R = C->string;
    uint8_t * Rv = malloc(1024*sizeof(char));
    to_digital(Rv, R, strlen(R));
    uint8_t * Rrcv = malloc(strlen(R)*sizeof(uint8_t));
    reverse_complement(Rrcv, Rv, len);

    int delta = 0;
    if(C->verbose > 0)
    {
        printf("Querying ...\n");
    }
    const size_t nD = fadata->data_size;
    const uint8_t * D = fadata->data;
    fasta_records_t * records = fadata->records;
    for(size_t pos = 0; pos < nD - len; pos++)
    {
        if(C->reverse)
        {
            delta = hamming_distance(Rrcv, D + pos, len);
            if( delta > C->mmin && delta <= C->mmax)
            {
                M[delta]++;

                if(C->verbose > 0)
                {
                    //printf("\n%s, (%zu) RC\n", C->rfile, pos);
                    printf("\n");
                    show_match_records(D+pos, pos, records, Rrcv, len, 1, C->colors);
                }
            }
        }

        delta = hamming_distance(Rv, D+pos, len);
        if( delta <= C->mmax)
        {
            M[delta]++;
            if(C->verbose > 0)
            {
                //printf("\n%s (%zu):\n", C->rfile, pos);
                printf("\n");
                show_match_records(D+pos, pos, records, Rv, len, 0, C->colors);
            }
        }
    }

    if(C->showTable)
    {
        printf("\n");
        printf("Hamming distance, number of hits\n");
        for(int kk = C->mmin; kk<= C->mmax; kk++)
        {
            printf("%3d, %zu\n", kk, M[kk]);
        }
        printf("\n");
    }
    return;
}


/** Use the "true" alphabet, i.e. not a numerical representation
 * and do a proper reverse complement
 * Then do a probabilistic Hamming distance ...
 */
void query_string_true(bconf_t * C,
                       fasta_data_t * fadata,
                       sym_table_t * sym)
{
    size_t * M = calloc((C->mmax+1), sizeof(size_t));
    assert(fadata != NULL);

    int len = strlen(C->string);
    assert(len < 200);
    char * S = C->string;

    sym_replace_str(S, len, sym);
    /* NOTE: RS is not \0 terminated */

    char * RS = sym_reverse_complement(S, len, sym);

    if(C->verbose > 0)
    {
        printf("Querying ... radius [%f, %f]\n",
               C->mmin, C->mmax);
    }
    size_t nD = fadata->data_size;

    const uint8_t * D = fadata->data;
    assert(D != NULL);

    fasta_records_t * records = fadata->records;

    /* Forward direction */
#pragma omp parallel for shared(M)
    for(size_t pos = 0; pos < nD - len; pos++)
    {

        float delta =  hamming_distance_16x16((uint8_t*) S,
                                              (uint8_t*) D+pos,
                                              len, sym->dist);

        if( (delta >= (float) C->mmin) && (delta <= (float) C->mmax))
        {
            M[(int) delta]++;
            if(C->verbose > 0)
            {

                if(C->genome_mask)
                {
                    if(C->genome_mask[pos] == 0)
                    {
                        continue;
                    }
                }
#pragma omp critical
                show_match_records_sym((uint8_t*) D+pos,
                                       pos,
                                       records,
                                       (uint8_t*) S,
                                       len, 0,
                                       C->colors, sym);
            }
        }

    }

    if(C->reverse == 0)
    {
        goto done;
    }

    /* Reverse complement */
#pragma omp parallel for shared(M)
    for(size_t pos = 0; pos < nD - len; pos++)
    {
        if(C->genome_mask)
        {
            if(C->genome_mask[pos] == 0)
            {
                continue;
            }
        }

        float delta = hamming_distance_16x16((uint8_t*) RS,
                                             (uint8_t*) D + pos,
                                             len, sym->dist);

        if((delta >= (float) C->mmin) && (delta <= (float) C->mmax))
        {
            M[(int) delta]++;

            if(C->verbose > 0)
            {

#pragma omp critical
                show_match_records_sym(D+pos, pos, records, (uint8_t*) RS,
                                       len, 1, C->colors, sym);
            }
        }
    }

 done: ;

    if(C->showTable)
    {
        printf("\n");
        printf("Hamming distance, number of hits\n");
        for(int kk = C->mmin; kk<= C->mmax; kk++)
        {
            printf("%3d, %zu\n", kk, M[kk]);
        }
        printf("\n");
    }

    free(RS);
    free(M);
    return;
}


/* Entry point when a single string is matched against a genome
 *
 * TODO: Specify output file, stdout makes sense when we only query one
 * file. Should return pb in some cases ...
 */
void bfm_string(bconf_t * C)
{
    assert(C->sym != NULL);
    assert(C->fadata != NULL);

    hithist_t * pb_hist = NULL;
    if(C->pbinding_bin_size > 0)
    {
        if(C->verbose > 1)
        {
            printf("Initializing bins for storing the results\n");
        }
        pb_hist = hithist_new(C->fadata, C->pbinding_bin_size, C->string);
        if(pb_hist->folder_already_existed)
        {
            printf("output folder already exists, will skip this sequence\n");
            hithist_free(pb_hist);
            return;
        }
        // TODO: return if folder already existed
    }

    if( !sym_validate_string(C->sym, C->string, strlen(C->string)) )
    {
        fprintf(stderr, "Please check your input string\n");
        fprintf(stderr, "'%s' is not a valid query\n", C->string);
        exit(EXIT_FAILURE);
    }

    if(C->pbinding)
    {
        double pb = prob_binding(C, C->fadata, C->sym, pb_hist);
        printf("Apb=%f\n", pb);
    } else {
        query_string_true(C, C->fadata, C->sym);
    }


    if(pb_hist)
    {
        hithist_write(pb_hist);
        hithist_free(pb_hist);
    }

    return;
}


int nhush_bfm(int argc, char ** argv)
{
    struct timespec ta, tb;
    clock_gettime(CLOCK_MONOTONIC, &ta);

    bconf_t * C = bconf_new();
    bfm_argparsing(C, argc, argv);

    /* Load genome and apply masking */
    bfm_load_genome(C);

    /* scan a single string against a genome */
    if(C->string != NULL)
    {
        bfm_string(C);
    }

    /* scan vs a fasta file */
    if(C->qfile != NULL)
    {
        bfm_fasta(C);
    }

    int verbose = C->verbose;
    bconf_free(C);
    free(C);

    clock_gettime(CLOCK_MONOTONIC, &tb);
    if(verbose > 1)
    {
        printf("Took: %.1f s\n", clockdiff(&tb, &ta));
    }

    return(EXIT_SUCCESS);
}

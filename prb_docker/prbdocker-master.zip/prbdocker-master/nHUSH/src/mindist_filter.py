#!/bin/python
""" Filter a database by the output of --dump-mindist
mindist_filter.py mindist_file database
it is assumed each line in the mindist file has the format
SEQUENCE\t#
and that each line in the database has the format
sth\t\sth\tsth\SEQUENCE

each line is read in both files
if sequences not match, abort
if sequences the same, export if # > 5
"""

import os
import sys

if __name__ == '__main__':
    print(f'sys.argc: {len(sys.argv)}')

    mdfile = open(sys.argv[1], 'r');
    dbfile = open(sys.argv[2], 'r');

    for l1, l2 in zip(mdfile, dbfile):
        l1_parts = l1.split('\t')
        l2_parts = l2.split('\t')
        seq1 = l1_parts[0]
        seq2 = l2_parts[3].rstrip()
        assert(seq1 == seq2)
        hdist = int(l1_parts[1].rstrip())
        if hdist > 5:
            print(l2.rstrip())

    mdfile.close()
    dbfile.close()

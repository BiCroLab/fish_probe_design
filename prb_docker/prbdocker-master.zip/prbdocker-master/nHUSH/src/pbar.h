/*
 * A Simple Progress "Bar" running in a separate thread.
 * see pbar_ut.c for the intended usage
 *
 * Erik Wernersson 2023
 */

#ifndef pbar_h_
#define pbar_h_

#include <stddef.h>

typedef struct pbar pbar_t;

/* Specify a new progressbar by giving pointers to the total
 * number of items to process, and a pointer to the current
 * in progress.
 * call pbar_start to get it spinning */
pbar_t *
pbar_new(const size_t * total, volatile size_t * current);

int
pbar_start(pbar_t *);

/* Stop a and free all resources */
int
pbar_stop(pbar_t *);


#endif

#pragma once

#define _GNU_SOURCE

#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <math.h>
#include <malloc.h> // memalign
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifndef __APPLE__
#include <sys/mman.h> // madvise
#include <sys/types.h>
#include <sys/sysinfo.h>
#endif
#include <time.h>
#include <unistd.h>
#include <omp.h>

#include <omp.h>

#include "util.h"
#include "readfa.h"
#include "atcg.h"

#include <readline/readline.h>
#include <readline/history.h>

int oracle(int argc, char ** arvg);

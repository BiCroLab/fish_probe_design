#include "comb.h"
#include "version.h"

/* Forward declarations */
static int comb_mm(uint8_t * C, int L, int N, uint8_t * MM, size_t Nmm);


static void nCk_update_state(int * state, int L, int r);


comb_t * comb_new(int L)
{
    comb_t * comb = malloc(sizeof(comb_t));
    comb->N = 0; // number of combs
    comb->Nalloc = 0; // number of allocated combs
    comb->L = L; // string length
    comb->C = NULL; // data
    comb->milestone = 0; // What to cover next
    comb->verbose = 1;
    return comb;
}

void comb_free(comb_t ** _comb)
{
    comb_t * comb = *_comb;
    if(comb->C != NULL)
    {
        free(comb->C);
    }
    free(comb);
    _comb[0] = NULL;
    return;
}

int comb_save(comb_t * comb, char * fname)
{
    if(comb == NULL)
        return EXIT_FAILURE;
    if(comb->C == NULL)
        return EXIT_FAILURE;
    if(comb->N == 0)
        return EXIT_FAILURE;
    if(comb->L == 0)
        return EXIT_FAILURE;
    char * tmpname = malloc(strlen(fname) + 8);
    sprintf(tmpname, "%s.tmp", fname);
    FILE * fid = fopen(tmpname, "w");
    if(fid == NULL)
        return EXIT_FAILURE;
    // printf("L = %zu, N = %zu\n", comb->L, comb->N);
    fwrite(&comb->N, sizeof(size_t), 1, fid);
    fwrite(&comb->L, sizeof(int), 1, fid);
    fwrite(comb->C, 1, comb->N*comb->L, fid);
    fclose(fid);
    int r = rename(tmpname, fname);
    if(r != 0)
    {
        printf("Failed to move %s to %s\n",
               tmpname, fname);
        printf("Error code: %d\n", errno);
        free(tmpname);
        return EXIT_FAILURE;
    }

    free(tmpname);
    return EXIT_SUCCESS;
}

comb_t * comb_load(char *fname)
{
    FILE * fid = fopen(fname, "r");
    if(fid == NULL)
        return NULL;
    int L = 0;
    size_t N = 0;
    size_t r = fread(&N, sizeof(size_t), 1, fid);
    if(r != 1)
        goto fail2;
    r = fread(&L, sizeof(int), 1, fid);
    if(r != 1)
        goto fail2;
    comb_t * comb = comb_new(L);
    comb->C = malloc(L*N);
    r = fread(comb->C, 1, L*N, fid);
    if( r != L*N)
        goto fail1;

    fclose(fid);
    comb->L = L;
    comb->N = N;
    comb->Nalloc = N;
    return comb;
fail1:
    comb_free(&comb);
fail2:
    fclose(fid);
    return NULL;
}

void comb_fprint(FILE * fid, comb_t * comb)
{
    size_t L = comb->L;
    size_t N = comb->N;
    uint8_t * C = comb->C;

    if(N == 0)
    {
        fprintf(fid, "0 hash combs\n");
        fflush(stdout);
        return;
    }
    for(size_t kk = 0; kk<N; kk++)
    {
        int nset = 0;
        fprintf(fid, "#%4zu: ", kk+1);
        uint8_t * c = C + kk*L;
        for(size_t ll = 0; ll < L; ll++)
        {
            switch(c[ll])
            {
            case 0:
                fprintf(fid, " -");
                break;
            case 1:
                fprintf(fid, " #");
                nset++;
                break;
            default:
                fprintf(fid, " ?");
                break;
            }

        }
        fprintf(fid, " %4d\n", nset);
    }
    return;
}

/* Get the number of remaining mismatches given a comb and a radius
 * same as get_remaining_mm, except that this one just counts
 */
size_t count_remaining_mm(comb_t * comb, size_t r, size_t * ncases)
{
    size_t L = comb->L;
    size_t N = comb->N;
    size_t Nmm = binomial(L, r);
    *ncases = Nmm;
    size_t n_remaining_mm = Nmm;
    uint8_t * C = comb->C;

    int state[r];
    for(size_t kk = 0; kk<r; kk++)
    {
        state[kk] = kk;
    }
    for(size_t kk = 0; kk < Nmm; kk++)
    {
        if(kk > 0)
            nCk_update_state(state, L, r);

        int passes = 0;
        for(size_t cc = 0; cc < N; cc++)
        {
            uint8_t * c = C+cc*L;
            int pass = 1;
            for(size_t pp = 0; pp<r; pp++)
            {
                if(c[state[pp]] == 1)
                   pass = 0;
            }
            if(pass)
            {
                passes=1;
                break;
            }
        }

        if(passes)
            n_remaining_mm--;
    }
    return n_remaining_mm;
}

uint8_t * uint8_table_add_row(uint8_t * remaining_mm,
                              const size_t L,
                              size_t * _nset, size_t * _nalloc,
                              const int * state, const size_t r)
{
    uint8_t * rem = remaining_mm;

    /* if table full, increase allocation */
    if(*_nalloc == *_nset)
    {
        size_t new_alloc = *_nalloc * 1.5; // in number of rows
        rem = realloc(remaining_mm, new_alloc*L);
        if(rem == NULL)
        {
            fprintf(stderr, "Memory allocation failed at %s : %d\n",
                    __FILE__, __LINE__);
            exit(EXIT_FAILURE);
        }
        *_nalloc = new_alloc;
    }

    /* insert */
    uint8_t * mm = rem + L * (*_nset);
    memset(mm, 0, L);
    for(size_t rr = 0; rr<r; rr++)
    {
        mm[state[rr]] = 1;
    }

    (*_nset)++;
    /* might be a new address due to realloc */
    return rem;
}

/* More memory efficient version than the previous trio
 * genmm, filter_mm, prune_MM */
static uint8_t * get_remaining_mm(comb_t * comb, size_t r, size_t * ncases)
{
    size_t L = comb->L;
    size_t N = comb->N;
    size_t Nmm = binomial(L, r);
    *ncases = Nmm;

    size_t nalloc = 1024;
    uint8_t * remaining_mm = malloc(nalloc*L);
    size_t n_remaining_mm = 0;

    uint8_t * C = comb->C;

    int state[r];
    for(size_t kk = 0; kk<r; kk++)
    {
        state[kk] = kk;
    }
    for(size_t kk = 0; kk < Nmm; kk++)
    {
        if(kk > 0)
            nCk_update_state(state, L, r);

        /* check all combs and see if it passed any of them */
        int passed = 0;
        for(size_t cc = 0; cc < N; cc++)
        {
            uint8_t * c = C+cc*L;
            int pass = 1;
            for(size_t pp = 0; pp<r; pp++)
            {
                if(c[state[pp]] == 1)
                    pass = 0;
            }
            if(pass == 1)
            {
                passed = 1;
                continue;
            }
        }
        if(passed == 0)
        {
            remaining_mm = uint8_table_add_row(remaining_mm, L,
                                               &n_remaining_mm, &nalloc,
                                               state, r);
        }

    }
    *ncases = n_remaining_mm;
    return remaining_mm;
}

/* Generate next state in a nCk vector
 * Example, r = 3
 * Initial state: [0, 1, 2]
 * Final state: [L-3, L-2, L-1]
 */
static void nCk_update_state(int * state, int L, int r)
{
    // Find first to be updated
    int pos = r-1;
    if(state[pos] == L-1)
    {
        pos--;
        while(state[pos]+1 == state[pos+1])
        {
            pos--;
        }
    }

    // Update that one and all following
    state[pos]++;
    for(int kk = pos+1; kk<r; kk++)
    {
        state[kk] = state[kk-1]+1;
    }
    if(0){
    printf("State = ");
    for(int kk = 0; kk<r; kk++)
        printf("%d ", state[kk]);
    printf("\n");
    }
}

void set_rand(uint8_t * c, int L, int H)
{
    memset(c, 0, L);
    assert(c[0] == 0);
    int nset = 0;
    while(nset < H)
    {
        int pos = rand() % L;
        if(c[pos] == 0)
        {
            c[pos] = 1;
            nset++;
        }
    }
    return;
}

// Generate a binary mask with all L over r combinations
uint8_t * genmm(int L, int r, size_t * _Nmm)
{
    assert(L >= r);
    assert(L > 0);
    assert(r>0);

    size_t Nmm = binomial(L, r);


    _Nmm[0] = Nmm;
    uint8_t * MM = calloc(Nmm*L , 1);
    int state[r];
    for(int kk = 0; kk<r; kk++)
    {
        MM[kk] = 1;
        state[kk] = kk;
    }

    //printf("State reset, L = %d, r = %d\n", L, r);
    for(size_t kk = 1; kk < Nmm; kk++)
    {
        //printf("%zu\n", kk);
        nCk_update_state(state, L, r);
        // Current row
        uint8_t * mm = MM+L*kk;
        for(int ll = 0; ll<r; ll++)
        {
            assert(state[ll] < L);
            mm[state[ll]] = 1;
        }
    }
    return MM;
}

// Generate a binary mask with all L over r combinations
double get_detection_p(uint8_t * C, size_t N, size_t L, size_t r,
                       size_t * ncases, size_t * ncovered)
{
    size_t Nmm = binomial(L, r);

    if(N == 0)
    {
        if(ncases != NULL)
            *ncases = Nmm;
        if(ncovered != NULL)
            *ncovered = 0;
        return 0;
    }

    assert(L >= r);
    assert(L > 0);
    assert(r>0);

    int state[r];
    for(size_t kk = 0; kk < r; kk++)
    {
        state[kk] = kk;
    }

    size_t npasses = 0;
    for(size_t kk = 0; kk < Nmm; kk++)
    {
        int passes = 0;
        for(size_t cc = 0; cc < N; cc++) // For all combs
        {
            uint8_t * c = C + cc*L;

            int sum = 0;
            for(size_t ll = 0; ll<r; ll++)
                sum += c[state[ll]];

            if(sum == 0)
            {
                passes = 1;
                continue;
            }
        }
        if(passes)
            npasses++;
        if(kk + 1 < Nmm)
            nCk_update_state(state, L, r);
    }

    //printf("r = %zu, Nmm: %zu, npasses: %zu\n", r, Nmm, npasses);;
    if(ncases != NULL)
    {
        *ncases = Nmm;
    }
    if(ncovered != NULL)
    {
        *ncovered = npasses;
    }
    return (double) npasses / (double) Nmm;
}

uint8_t * filter_mm(uint8_t * C, int L, int N, uint8_t * MM, size_t Nmm)
{
    //printf("cmm\n");
    uint8_t * mask = calloc(Nmm, 1);

    for(size_t kk = 0; kk < (size_t) N; kk++) // For each comb
    {
        uint8_t * c = C + kk*L; // take one column
        for(size_t ll = 0; ll<Nmm; ll++) // Compare to all mm
        {
            if(mask[ll] == 1)
                continue;

            uint8_t * mm = MM + ll*L;
            size_t sum = 0;
            for(size_t pp = 0; pp < (size_t) L; pp++)
            {
                sum += c[pp]*mm[pp];
            }
            if(sum == 0) // if the comb wasn't tricked by the mm
            {
                mask[ll]=1;
            }
        }
    }

    return mask;
}

int comb_mm(uint8_t * C, int L, int N, uint8_t * MM, size_t Nmm)
{
    //printf("cmm\n");
    uint8_t * mask = calloc(Nmm, 1);

    for(size_t kk = 0; kk < (size_t) N; kk++) // For each comb
    {
        uint8_t * c = C + kk*L; // take one column
        for(size_t ll = 0; ll<Nmm; ll++) // Compare to all mm
        {
            uint8_t * mm = MM + ll*L;
            size_t sum = 0;
            for(size_t pp = 0; pp < (size_t) L; pp++)
            {
                sum += c[pp]*mm[pp];
            }
            if(sum == 0) // if the comb wasn't tricked by the mm
            {
                mask[ll]=1;
            }
        }
    }

    size_t sum = 0;
    for(size_t kk = 0; kk<Nmm; kk++)
    {
        sum += (mask[kk] == 0);
    }
    //printf("sum=%zu\n", sum);
    free(mask);
    return sum;
}

void comb_append(comb_t * comb, const uint8_t * c)
{
    int L = comb->L;

    // If empty, create
    if(comb->N == 0)
    {
        if(comb->C != NULL)
            free(comb->C);

        size_t Nalloc = 50;
        comb->C = calloc(L*Nalloc, 1);
        if(comb->C == 0)
            exit(EXIT_FAILURE);
        comb->N = 0;
        comb->Nalloc = Nalloc;
        goto insert;
    }

    // Increase allocation if full
    if(comb->N == comb->Nalloc)
    {
        int newN = 2*comb->N;
        comb->C = realloc(comb->C, newN*L);
        comb->Nalloc = newN;
        goto insert;
    }

insert:
    ;
    uint8_t * C = comb->C + L*comb->N;
    for(int kk = 0; kk<L; kk++)
    {
        C[kk] = c[kk];
    }
    comb->N++;
    //printf("comb: N = %zu, L = %zu\n", comb->N, comb->L);
    return;
}

void comb_calculate_milestone(comb_t * comb)
{
    // No previous combs
    if(comb->N == 0)
    {
        comb->milestone = 0;
        return;
    }

    // Brute force was used i.e. the zero-comb
    int sum = 0;
    for(size_t kk = 0; kk<comb->L; kk++)
    {
        sum+=comb->C[(comb->N-1)*comb->L + kk];
    }
    if(sum == 0)
    {
        comb->milestone = comb->L+1;
        return;
    }

    int mm = 1;
    while(1)
    {
        size_t ncases;
        //get_detection_p(comb->C, comb->N, comb->L, mm,
        //                           &ncases, &ncovered);
        size_t nrem = count_remaining_mm(comb, mm, &ncases);

        if(comb->verbose > 0)
        {
        if(nrem > 0)
            printf("At %d mm, total cases: %zu, remaining: %zu\n", mm, ncases, nrem);
        }
        if(nrem == 0)
        {
            if(comb->verbose > 1)
            {
                printf("At %d mm, all %zu configurations covered\n", mm, ncases);
            }
            comb->milestone = mm+1;
            mm++;
        } else {
            comb->milestone = mm;
            break;
        }
    }
    return;
}

uint8_t * comb_get_v1(comb_t * comb, int H)
{
    int L = comb->L;

    if(comb->N == 0)
    {
        comb->C = calloc(L*50, 1);
        comb->Nalloc = 50;
        for(int kk = 0; kk<H; kk++)
        {
            comb->C[kk] = 1;
        }
        comb->N = 1;
        comb->milestone = 0;
        return comb->C;
    }

    // Increase allocation if full
    if(comb->N == comb->Nalloc)
    {
        int newN = 2*comb->N;
        comb->C = realloc(comb->C, newN*L);
        comb->Nalloc = newN;
    }

    int r = comb->milestone;
    // We aim to guarantee a radius comb->milestone

    size_t Nmm = 0;
    /* Generate a list where all possible r mismatches can be */
    uint8_t * MM = genmm(L, r, &Nmm);

    int least = Nmm+1;
    char * best = malloc(L);

    /* Better way:
       - Gen MM
       - Filter MM based on C one time
       - Use remaining MM to build next c
       - Add with comb_append at the end
     */
    for(size_t kk = 0; kk<100000; kk++)
    {
        set_rand(comb->C + L*comb->N, L, H);
        int nrem = comb_mm(comb->C, L, comb->N+1, MM, Nmm);
        if(nrem < least)
        {
            least = nrem;
            memcpy(best, comb->C + L*comb->N, L);
        }
    }
    printf("Coverage: %zu/%zu mismatches of length %d\n", Nmm-least, Nmm, r);
    memcpy(comb->C + L*comb->N, best, L);
    free(best);
    free(MM);

    if(least == 0)
    {
        comb->milestone++;
    }

    comb->N++;
    return comb->C + comb->L*(comb->N-1);
}

static int v2_find_filter(uint8_t * c,
                uint8_t * MM, uint8_t * MM_filter, size_t Nmm,
                size_t L, size_t H,
    int th)
{
    assert(L>H);

    // How many are set to 0 already?
    size_t nset = 0;
    for(size_t kk = 0; kk<L; kk++)
    {
        if(c[kk] == 0)
            nset++;
    }

    for(size_t kk = 0; kk<Nmm; kk++)
    {
        if(MM_filter[kk] == 0)
        {
            uint8_t * M = MM+kk*L; // Mismatch pattern no. kk
            /* If c already has something set,
               we prefer to use mm patterns that can re-use some of
               that. */
            int ctn = 1;
            int nsimilar = 0;
            if(nset > 0)
            {
                ctn = 0;
                for(size_t pp = 0; pp<L; pp++)
                {
                    if(M[pp] == 1 && c[pp] == 0)
                    {
                        nsimilar++;
                    }
                }
                if(nsimilar >= th)
                { // some self-matches goes here...
                    ctn = 1;
                }
            }

            if(ctn == 1)
            {
                for(size_t mm = 0; mm < L; mm++)
                {
//                printf("%d ", M[mm]);
                    if(M[mm] == 1)
                    {
                        if(c[mm] == 1 && nset <  L-H)
                        {
                            c[mm] = 0;
                            MM_filter[kk] = 0;
                            nset++;
                        }
                    }
                }
            }
        }
        if(nset == L-H)
            break;
    }
    return (int) nset;
}

uint8_t * comb_get_v2(comb_t * comb, int H)
{
    assert(H > 0);
    assert(comb != NULL);

    size_t L = comb->L;
    size_t N = comb->N;
    // We aim to guarantee a radius of comb->milestone
    int r = comb->milestone;

    if(comb->N > 0)
    {
        if(r == 0)
            r = 1;
    }

    if(comb->verbose > 2)
        printf("v2 optimizing for r = %d\n", r);

    uint8_t * c = malloc(L);

    if(H == 0)
    {
        for(size_t kk = 0 ; kk<L; kk++)
            c[kk] = 0;
        return c;
    }

    for(size_t kk = 0; kk<L; kk++)
        c[kk] = 1;
    int nset = 0; // number of 0s in c;
    if(N == 0)
    {
        /* For the initial HASH comb, it is not so good to have
           a dense arrangement, something like
           [ 0 1 0 0 1 0 1 1 0 0 .... ]
           is better than
           [ 1 1 1 ... 1 1 1 1 0 0 0 ... 0 0 ]
           since the latter tend to pick up more repeated
           sequences. That means more empty buckets and more
           xxl-sized buckets, i.e., slower query speed.
        */

        int nzeros = 0;
        while(nzeros < (int) L-H)
        {
            int pos = rand()%L;
            if(c[pos] == 1)
            {
                c[pos] = 0;
                nzeros++;
            }
        }
        return c;
    }

    size_t Nmm = 0;
    /* Generate a binary mask where all possible r mismatches can be */
    uint8_t * MM = genmm(L, r, &Nmm);
    /* Figure out what mismatch configurations that are not covered */
    uint8_t * MM_filter = filter_mm(comb->C, L, N,
                                    MM, Nmm);

    /* Try to trick as many of the remaining MM configurations
       as possible. In this version we start with the first
       remaining MM configuration, and then add other MM configurations
       with as large overlap as possible. The threshold says how many
       overlapping points that are required for a MM configuration to
       be merged with the comb that is under construction */

    for(int th = r-1; th>=0; th--)
    {
        int nset_last = -1;
        while(nset != nset_last && nset != (int) L-H)
        {
            nset_last = nset;
            nset = v2_find_filter(c, MM, MM_filter, Nmm, L, H, th);
        }
    }

    free(MM);
    free(MM_filter);

    /* If the heuristics above didn't figure out where to place all '0's
       just fill up until the numbers are ok */

    while(nset < (int)  L-H )
    {
        int pos = rand() % L;
        if(c[pos] == 1)
        {
            c[pos] = 0;
            nset++;
        }
    }

    int sum = 0;
    for(size_t kk = 0; kk < L; kk++)
    {
        sum+=c[kk];
    }
    //printf("nset: %d, sum: %d, H: %d\n", nset, sum, H);
    assert(nset == (int) L-H);
    assert(sum == H);

    return c;
}

static size_t uint8_vec_sum(uint8_t * v, size_t n)
{
    size_t sum = 0;
    for(size_t kk = 0; kk<n; kk++)
        sum += v[kk];
    return sum;
}


typedef struct{
    int most_overlap;
    int n_overlap;
} ol_t;

size_t arg_min_ol(ol_t * A, size_t n)
{

    size_t minpos = 0;
    for(size_t kk = 1 ; kk<n; kk++)
    {
        if(A[kk].most_overlap < A[minpos].most_overlap)
        {
            minpos = kk;
        } else if(A[kk].most_overlap <= A[minpos].most_overlap)
        {
            if(A[kk].n_overlap <= A[minpos].n_overlap)
            {
                minpos = kk;
            }
        }
    }
    return minpos;
}


int get_overlap_one_set_by0(uint8_t * c0, uint8_t * cs, size_t L, size_t col)
{
    int ol = 0;
    /* Return the overlap between c0 and cs when cs[col] == 1
     * Overlap defined as the number of shared 0s
     */
    for(size_t kk = 0; kk<L; kk++)
    {
        if(kk != col && c0[kk] == 0 && cs[kk] == 0)
            ol++;
    }
    return ol;
}


int get_overlap_one_set(const uint8_t * c0, const uint8_t * cs, size_t L, size_t col)
{
    int ol = 0;
    /* Return the overlap between c0 and cs when cs[col] == 1
     * Overlap defined as the number of shared 1s
     * Should give identical results as get_overlap_one_set_by0
    */
    for(size_t kk = 0; kk<L; kk++)
    {
        if(kk == col)
        {
            if(c0[kk] == 1)
                ol++;
        }
        if(c0[kk] == 1 && cs[kk] == 1)
            ol++;
    }
    return ol;
}


void int_vec_show(int * v, size_t L)
{
    for(size_t kk = 0; kk<L; kk++)
    {
        if(v[kk] == 10000)
        {
            printf("x ");
        } else {
        printf("%d ", v[kk]);
        }
    } printf("\n");
}

void u8_vec_show(uint8_t * v, size_t L)
{
    for(size_t kk = 0; kk<L; kk++)
    {
        printf("%u ", v[kk]);
    } printf("\n");
}

void ol_vec_show(ol_t * v, size_t L)
{
    for(size_t kk = 0; kk<L; kk++)
    {
        printf("%u ", v[kk].most_overlap);
    } printf("\n");
}



ol_t * most_overlap(const uint8_t * C, size_t N, size_t L, const uint8_t * c)
{
    // ol[kk] : max overlap to any of the other combs when c[kk] == 1
    ol_t * ol = calloc(L, sizeof(ol_t));
    //u8_vec_show(c, L);
    //int_vec_show(ol, L);
    for(size_t row = 0; row<N; row++)
    {
        const uint8_t * Cr = C + L*row;
        for(size_t col = 0; col<L; col++)
        {
            ol[col].n_overlap += Cr[col];
            int v = 10000;
            if(c[col] == 0)
            {
                v = get_overlap_one_set(Cr, c, L, col);
            }
            if(ol[col].most_overlap < v)
            {
                ol[col].most_overlap = v;
            }
        }
    }
    if(0)
    {
    printf("ol: ");
    //int_vec_show(ol, L);
    ol_vec_show(ol, L);
    printf("getchar()\n");
    getchar();
    }
    return ol;
}

uint8_t * comb_get_v4(comb_t * comb, int H)
{
    /*
     * When searching for m mm, any filter with m overlaps or more contains
     * some redundancy
     *
     * We want to maximize the hamming distance between the new comb and
     * all existing given H bits set to 1.
     * Possible improvement: generate up to M more than asked for (sequentially)
     * and return the best.
     *
     */
    assert(H > 0); assert(comb != NULL);
    size_t L = comb->L; size_t N = comb->N;

    printf("v4, L=%zu, N = %zu, H=%d\n", L, N, H);
    if(N == 0)
    {
        /* Random is is the best start */
        uint8_t * c = malloc(L);
        set_rand(c, L, H);
        return c;
    }

    uint8_t * C = comb->C;

    int least_overlap = L+1;

    uint8_t * c = calloc(L, 1);
    int nset = 0;

    while(nset < H)
    {
        ol_t * ol = most_overlap(C, N, L, c);
        size_t p = arg_min_ol(ol, L);

        if(0){
            for(size_t kk = 0; kk<L; kk++)
            {
                printf("%zu : (%d, %d)", kk, ol[kk].most_overlap, ol[kk].n_overlap);
                if(kk == p)
                    printf("*");
                printf("\n");
            }
        }
        assert(c[p] == 0);
        c[p] = 1;
        nset++;
    }

    printf("Overlap for chosen comb: %d\n", least_overlap);
    return c;
}

size_t size_t_argmax(size_t * V, size_t n)
{
    size_t max = 0;
    size_t maxpos = 0;
    for(size_t kk = 0; kk<n; kk++)
    {
        if(V[kk] > max)
        {
            max = V[kk];
            maxpos = kk;
        }
    }
    return maxpos;
}

size_t size_t_n_equal(size_t * V, size_t n, size_t v)
{
    size_t neq = 0;
    for(size_t kk = 0; kk<n; kk++)
    {
        if(V[kk] == v)
            neq++;
    }
    return neq;
}

uint8_t * comb_get_v31(comb_t * comb, int H)
{
    /* Version 3.1
     * Given a comb with N combs of length L
     * Find a new comb with H elements set to 1
     * that is as good as possible
     * This version: gradient descent on one hash position
     * at a time.
     * Compared to version 3: using overlap criterion from v 4 when ties
     * Does not seem better in general.
     *
     */

    assert(H > 0); assert(comb != NULL);
    size_t L = comb->L; size_t N = comb->N;

    /* Corner cases */
    if(H == 0)
    {
        uint8_t * c = malloc(L);
        memset(c, 0, L);
        return c;
    }

    if(N == 0)
    {
        /* Random is is the best start */
        uint8_t * c = malloc(L);
        set_rand(c, L, H);
        return c;
    }

    /* The general case */

    // We aim to guarantee a radius of comb->milestone
    int r = comb->milestone;
    if(N > 0)
    {
        if(r == 0)
            r = 1;
    }

    /* Generate a binary mask where all possible r mismatches can be */
    size_t Nmm = 0;
    uint8_t * MM = get_remaining_mm(comb, r, &Nmm);

    /* This algorithm does a greedy gradient descent:
     *
     * Start with and empty comb, c0.
     * While < H positions are set to 1:
     *    Figure out what position escapes most mismatches
     *    Set that position to 1.
     *
     * The algorithm is not optimal, beaten by
     * brute force in some tests.
     */
    uint8_t * c0 = calloc(L, 1);
    uint8_t * c1 = malloc(L);
    size_t nleft[L];
    for(size_t mm = 0; mm < (size_t) H; mm++)
    {
        for(size_t kk = 0; kk<L; kk++)
        {
            if(c0[kk] == 1)
            {
                nleft[kk] = 0;
                continue;
            }

            memcpy(c1, c0, L);
            c1[kk] = 1;
            uint8_t * MM_filter1 = filter_mm(c1, L, 1,
                                             MM, Nmm);
            nleft[kk] = uint8_vec_sum(MM_filter1, Nmm);
            free(MM_filter1);
        }

        size_t maxpos = size_t_argmax(nleft, L);
        size_t nmax = size_t_n_equal(nleft, L, nleft[maxpos]);
        //printf("maxpos1 = %zu\n", maxpos);
        if(nmax == 1)
        { // if one clear winner -- like v3
            c0[maxpos] = 1;
        } else {
            ol_t * ol = most_overlap(comb->C, N, L, c1);

            for(size_t pp = 0; pp<L; pp++)
            {
                if(nleft[pp] != nleft[maxpos]) // only care about the nmax best pos
                {
                    //printf("No-Option: %zu\n", pp);
                    ol[pp].most_overlap = 10000;
                }
            }
            maxpos = arg_min_ol(ol, L);
            //printf("maxpos2 = %zu\n", maxpos);
            c0[maxpos] = 1;
            free(ol);
        }

        // printf("Getchar\n"); getchar();

    }
    free(c1);
    free(MM);
    //free(MM_filter);
    assert(uint8_vec_sum(c0, L) == (size_t) H);
    return c0;
}

uint8_t * comb_get_v3(comb_t * comb, int H)
{
    /* Given a comb with N combs of length L
     * Find a new comb with H elements set to 1
     * that is as good as possible
     * This version: gradient descent on one hash position
     * at a time.
     */

    assert(H > 0); assert(comb != NULL);
    size_t L = comb->L; size_t N = comb->N;

    /* Corner cases */
    if(H == 0)
    {
        uint8_t * c = malloc(L);
        memset(c, 0, L);
        return c;
    }

    if(N == 0)
    {
        /* Random is is the best start */
        uint8_t * c = malloc(L);
        set_rand(c, L, H);
        return c;
    }

    /* The general case */

    // We aim to guarantee a radius of comb->milestone
    int r = comb->milestone;
    if(N > 0)
    {
        if(r == 0)
            r = 1;
    }

    /* Generate a binary mask where all possible r mismatches can be */
    size_t Nmm = 0;
    uint8_t * MM = get_remaining_mm(comb, r, &Nmm);

    /* This algorithm does a greedy gradient descent:
     *
     * Start with and empty comb, c0.
     * While < H positions are set to 1:
     *    Figure out what position escapes most mismatches
     *    Set that position to 1.
     *
     * The algorithm is not optimal, beaten by
     * brute force in some tests.
     */
    uint8_t * c0 = calloc(L, 1);
    uint8_t * c1 = malloc(L);
    for(size_t mm = 0; mm < (size_t) H; mm++)
    {
    size_t bestpos = 0;
    size_t most = 0;
    for(size_t kk = 0; kk<L; kk++)
    {
        if(c0[kk] == 1)
            continue;

        memcpy(c1, c0, L);
        c1[kk] = 1;
        uint8_t * MM_filter1 = filter_mm(c1, L, 1,
                                    MM, Nmm);
        size_t nleft = uint8_vec_sum(MM_filter1, Nmm);
        if(nleft > most)
        {
            most = nleft;
            bestpos = kk;
        }
        free(MM_filter1);
    }
    //printf("Best pos: %zu\n", bestpos);
    c0[bestpos] = 1;
    }
    free(c1);
    free(MM);
    //free(MM_filter);
    assert(uint8_vec_sum(c0, L) == (size_t) H);
    return c0;
}



static size_t gcd(size_t a, size_t b)
{
    while(b != 0)
    {
        size_t t = b;
        b = a % b;
        a = t;
    }
    return a;
}

size_t binomial(size_t N, size_t k)
{

    size_t A = 1;
    size_t B = 1;
    for(size_t aa = 0; aa < k ; aa++)
    {
        // should use gcd reduction here to avoid overflows...
        A *= N-aa;
        B *= (aa+1);
        size_t g = gcd(A, B);
        A /= g;
        B /= g;
    }
    return A/B;
}

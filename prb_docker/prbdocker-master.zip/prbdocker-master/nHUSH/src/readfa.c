#include "readfa.h"

/* Forward declarations */

/* New */
static fasta_records_t * fasta_records_new(void);
/* Use when all data is read and all fasta headers are parsed
 * to set the len/size of the records */
static void fasta_records_finish(fasta_records_t * fr, size_t last);
/* add one more record */
static void fasta_records_add(fasta_records_t * fr,
                              const char * name, size_t lname,
                              size_t pos, size_t len);


static char num2char(uint8_t n);



/* End of forward declaration */


static fasta_records_t * fasta_records_new(void)
{
    fasta_records_t * fr = malloc(sizeof(fasta_records_t));
    size_t nalloc = 128;
    fr->name = malloc(nalloc*sizeof(char*));
    fr->pos = malloc(nalloc*sizeof(size_t));
    fr->len = malloc(nalloc*sizeof(size_t));
    fr->n = 0;
    fr->nalloc = nalloc;
    return fr;
}

void fasta_records_add(fasta_records_t * fr,
                       const char * name, size_t lname,
                       size_t pos, size_t len)
{
    if(fr->nalloc == fr->n)
    {
        size_t na = fr->nalloc*2;
        fr->name = realloc(fr->name, na*sizeof(char**));
        fr->pos = realloc(fr->pos, na*sizeof(size_t));
        fr->len = realloc(fr->len, na*sizeof(size_t));
        fr->nalloc = na;
    }
    size_t n = fr->n;
    fr->name[n] = strndup(name, lname);
    fr->pos[n] = pos;
    fr->len[n] = len;
    fr->n++;
    return;
}

static void fasta_records_finish(fasta_records_t * fr, size_t last)
{
    if(fr->n == 0)
    {
        fasta_records_add(fr, "ANONYMOUS", strlen("ANONYMOUS"), 0, last);
    } else {
        for(size_t kk = 0; kk+1< fr->n; kk++)
        {
            fr->len[kk] = fr->pos[kk+1]-fr->pos[kk];
        }
    }
    fr->len[fr->n-1] = last-fr->pos[fr->n-1];

}

void fasta_records_fprint(FILE * fid, fasta_records_t * fr)
{
    fprintf(fid, "record\tpos\tlen\tname\n");
    for(size_t kk = 0; kk<fr->n; kk++)
    {
        fprintf(fid, "%zu\t%zu\t%zu\t'%s'\n",
                kk, fr->pos[kk], fr->len[kk],
                fr->name[kk]);
    }
}


void fasta_records_free(fasta_records_t ** _fr)
{
    fasta_records_t * fr = *_fr;
    if(fr->nalloc > 0)
    {
        free(fr->len);
        free(fr->pos);
        for(size_t kk = 0; kk<fr->n; kk++)
        {
            free(fr->name[kk]);
        }
        free(fr->name);
    }
    free(fr);
    *_fr = NULL;
}


fasta_data_t * readfa_sym(const char * fname,
                          const sym_table_t * sym_table,
                          int fourbase,
                          int verbose)
{

/*  Get file size */
    struct stat st;
    int status = stat(fname, &st);
    if(status != 0)
    {
        fprintf(stderr, " readfa_sym: can not open '%s'\n", fname);
        return NULL;
    }

    size_t fsize = st.st_size;
    if(verbose > 1)
    {
        printf("%s is %zu B\n", fname, fsize);
    }
    // Allocate enough memory, possibly more than needed when
    // non-nucleotide characters are filtered out like line endings

    uint8_t * D = malloc(fsize);
    if(D == NULL)
    {
        printf("  ! Memory allocation failed\n");
        return NULL;
    }

    FILE * f = fopen(fname, "r");
    if(f == NULL)
    {
        printf("  ! Could not open %s\n", fname);
        goto fail;
    }

    // read fsize bytes
    size_t bbRead =  fread(D, fsize, 1, f);
    if(bbRead != 1)
    {
        printf("  ! Failed to read from %s\n", fname);
        goto fail;
    }
    fclose(f);

    fasta_records_t * fr = fasta_records_new();

    size_t readpos = 0;
    size_t writepos = 0;

    /* Two state parser: either inside comment or not
     * assuming comments start with '>' and end with '\n'
     * */
    int inComment = 0;
    size_t comment_start = 0;

    uint8_t * subs = NULL;
    if(fourbase)
    {
        subs = sym_table->num4_from_char;
    } else {
        subs = sym_table->num_from_char;
    }

    while(readpos<fsize)
    {
        char symbol = D[readpos++];

        if(inComment == 1)
        {
            if(symbol == '\n')
            {
                inComment = 0;
                fasta_records_add(fr, (char *) D+comment_start,
                                  readpos-1-comment_start,
                                  writepos, 0);
            }
        }
        else
        {
            uint8_t subs_symbol = subs[(uint8_t) symbol];
            if(subs_symbol != SUBS_TABLE_INVALID)
            {
                D[writepos++] = subs_symbol;
            }
            else
            {
                switch(symbol)
                {
                case '>':
                    inComment = 1;
                    comment_start = readpos;
                    break;
                case '\r':
                    ;
                    break;
                case '\n':
                    ;
                    break;
                default:
                    fprintf(stderr, "At pos %zu Read '%c' and don't know what to do with it\n",
                            readpos, symbol);
                    exit(EXIT_FAILURE);
                    break;
                }
            }
        }
    }
    size_t nD = writepos;


    uint8_t * Dr = realloc(D, writepos);
    if(Dr == NULL)
    {
        free(D);
        return NULL;
    }

    /* Set end pos of all sequences */
    fasta_records_finish(fr, writepos);
    //fasta_records_show(fr, Dr);

    fasta_data_t * data = calloc(1, sizeof(fasta_data_t));
    data->records = fr;
    data->data = Dr;
    data->data_size = nD;

    return data;

fail:
    free(D);
    return NULL;
}


uint8_t * readfa(const char * fname,
                 size_t * gsize, fasta_records_t ** _fr)
{
    sym_table_t * sym_table = sym_table_new();
    int verbose = 1;
    int fourbase = 1; /* Convert to restricted 4-bases */
    fasta_data_t * fa_data = readfa_sym(fname, sym_table, fourbase, verbose);
    if(fa_data == NULL)
    {
        sym_table_free(sym_table);
        return NULL;
    }
    *gsize = fa_data->data_size;
    sym_table_free(sym_table);
    uint8_t * data = fa_data->data;
    *_fr = fa_data->records;
    free(fa_data);
    return data;
}

void fasta_data_free(fasta_data_t * fa)
{
    free(fa->data);
    fasta_records_free(&fa->records);
    free(fa);
    return;
}

static char num2char(uint8_t n)
{
    switch(n)
    {
    case 0:
        return 'A';
        break;
    case 1:
        return 'C';
        break;
    case 2:
        return 'G';
        break;
    case 3:
        return 'T';
        break;
    default:
        return '?';
    }
}


void fasta_records_show(fasta_records_t * fr, uint8_t * G)
{

    for(size_t kk = 0; kk<fr->n; kk++)
    {
        printf("'%s'\n", fr->name[kk]);
        printf("start: %zu, len: %zu\n", fr->pos[kk], fr->len[kk]);
        size_t nshow = 60;
        int showdots = 1;
        if(fr->len[kk] < nshow)
        {
            nshow = fr->len[kk];
            showdots = 0;
        }

        for(size_t pp = 0; pp<nshow; pp++)
        {
            printf("%c", num2char(G[fr->pos[kk]+pp]));
        }
        if(showdots)
        {
            printf(" ...");
        }
        printf("\n");
    }
    return;
}


/** @brief Read a fasta file and display some of what it read
 *
 * TODO:
 * - Should add some test files to read.
 * - Read-Write-Read-Compare test
 */
void readfa_ut(int argc, char ** argv)
{
    if(argc == 1)
    {
        printf("Usage: %s file.fa\n", argv[0]);
    }

    if(argc > 1)
    {
        size_t gsize;
        fasta_records_t * fr;
        uint8_t * D = readfa(argv[1], &gsize, &fr);
        if(D == NULL)
        {
            fprintf(stderr, "Could not read from %s\n", argv[1]);
            exit(EXIT_FAILURE);
        }
        fasta_records_show(fr, D);
        char * outname = malloc(100+strlen(argv[1]));
        sprintf(outname, "%s.index.tsv", argv[1]);
        FILE * tsv = fopen(outname, "w");
        free(outname);
        fasta_records_fprint(tsv, fr);
        fclose(tsv);
        fasta_records_free(&fr);
        assert(D != NULL);
        printf("Genome size: %zu\n", gsize);
        free(D);
    }
    return;
}

function d = readfa(file)


fid = fopen(file, 'r');
d = fread(fid, inf, 'uint8');
fclose(fid);
d = uint8(d);

d = d(8:end);
mask = (d >= 65) & (d <= 116);
d = d(mask);
d = upper(d);
unique(d);
d(d == 'a' | d == 'A') = 1;
d(d == 'c' | d == 'C') = 2;
d(d == 'g' | d == 'G') = 3;
d(d == 't' | d == 'T') = 4;
d = d(d<5);
end
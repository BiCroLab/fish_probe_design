/* Purpose:
 * Split a fasta file with L-mers into l<L mers
 * Todo:
 *  - code for merging the result from proprobe
 * Notes:
 * Assumes no surprises in the input.
*/

#include <assert.h>
#include <ctype.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "version.h"

typedef struct {
    char * infile;
    char * outfile;
    int L;
    int l;
} fas_t;

fas_t * fas_new()
{
    fas_t * fas = malloc(sizeof(fas_t));
    fas->infile = NULL;
    fas->outfile = NULL;
    fas->L = -1;
    fas->l = -1;
    return fas;
}

void fas_free(fas_t * fas)
{
    free(fas->infile);
    free(fas->outfile);
    free(fas);
}

static int
isgenomic(char c)
{
    switch(c)
    {
    case 'a':
    case 'b':
    case 'c':
    case 'g':
    case 'A':
    case 'T':
    case 'C':
    case 'G':
        return 1;
    default:
        return 0;
    }
}

/* Write each substring of length l to the out file
 * E.g. for L=80 and l=20, write L-l+1 sub strings of length
 * l.
 */
static void
dumpseq(fas_t * fas, char * line, FILE * out)
{
    // - check that the line is long enough?
    for(int kk = 0; kk<fas->L - fas->l + 1; kk++)
    {
        fprintf(out, "%.*s\n", fas->l, line + kk);
    }
}


static void
fas_split(fas_t * fas)
{
    printf("Opening %s for reading\n", fas->infile);
    FILE * fin = fopen(fas->infile, "r");
    assert(fin != NULL);
    printf("Opening %s for writing\n", fas->outfile);
    FILE * fout = fopen(fas->outfile, "w");
    assert(fout != NULL);

    char * line = NULL;
    size_t n = 0;
    size_t nFound = 0;
    while(getline(&line, &n, fin) > 0)
    {
        char * tline = line;
        /* Remove initial white spaces */
        while(isblank(tline[0]))
        {
            tline++;
        }
        if(isgenomic(tline[0]))
        {
            nFound++;
            dumpseq(fas, tline, fout);
        }
    }
    fclose(fin);
    fclose(fout);
    free(line);
    printf("Spilt %zu sequences\n", nFound);
}

static void
show_version()
{
    printf("nHUSH-fasplit version %s\n", NHUSH_VERSION);
}

static void
show_usage(char ** argv)
{
    printf("Usage:\n");
    printf("%s --length L "
           "--sub-length l "
           "--file file.fa "
           "[--out out.fa] [--help]\n", argv[0]);
    printf("Required arguments:\n");
    printf(" --file file.fa\n\t Specify the fasta file to split.\n");
    printf(" --length L\n\t Specify the string length.\n");
    printf(" --sub-length L\n\t Specify the sub string length.\n");
    printf("Other arguments:\n");
    printf(" --out out.fa\n\t Specify the file to write to.\n");
    printf(" --help\n\t show this message\n");
}

static int
fas_argparsing(int argc, char ** argv, fas_t * fas)
{
        struct option longopts[] = {
        { "file",        required_argument, NULL,   'f' },
        { "help",        no_argument,       NULL,   'h' },
        { "sub-length",  required_argument, NULL,   'l' },
        { "out",         required_argument, NULL,   'o' },
        { "length",      required_argument, NULL,   'L' },
        { "version",     no_argument,       NULL,   'V' },
        { NULL,          0,                 NULL,    0  }
    };

  int ch;
  while((ch = getopt_long(argc, argv, "f:l:o:L:V", longopts, NULL)) != -1)
  {
      switch(ch)
      {
      case 'h':
          show_usage(argv);
          exit(EXIT_SUCCESS);
      case 'f':
          fas->infile = strdup(optarg);
          break;
      case 'o':
          fas->outfile = strdup(optarg);
          break;
      case 'l':
          fas->l = atoi(optarg);
          break;
      case 'L':
          fas->L = atoi(optarg);
          break;
      case 'V':
          show_version();
          exit(EXIT_SUCCESS);
      default:
          printf("see %s --help\n", argv[0]);
          exit(EXIT_FAILURE);
      }
  }

  if(fas->infile == NULL)
  {
      printf("Please provide a --file\n");
      exit(EXIT_FAILURE);
  }
  if(fas->L < 2)
  {
      printf("Please set the string length --L\n");
      exit(EXIT_FAILURE);
  }
  if(fas->l < 1)
  {
      printf("Please set the sun string length --l\n");
      exit(EXIT_FAILURE);
  }

    if(fas->outfile == NULL)
    {
        fas->outfile = malloc(strlen(fas->infile) + 32);
        sprintf(fas->outfile, "%s.%dmers", fas->infile, fas->l);
    }
    return 0;
}

int nhush_fasplit(int argc, char ** argv)
{

    fas_t * fas = fas_new();
    fas_argparsing(argc, argv, fas);

    fas_split(fas);
    fas_free(fas);
    return(EXIT_SUCCESS);
}

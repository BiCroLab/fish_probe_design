#ifndef find_abundant_h_
#define find_abundant_h_

#define _GNU_SOURCE
#include <stdlib.h>
#include <getopt.h>

#include "util.h"
#include "readfa.h"

typedef struct{
    char * fname; /* Input name */
    char * oname; /* Output name */
    char * logname;
    FILE * outfile;
    FILE * logfile;

    uint8_t * G;
    size_t nG; /* genome length */
    size_t nseq; /* number of sequences */
    size_t seq_len;
    size_t threshold; /* Show sequences with this number of repeats or more */
    int verbose;
    fasta_records_t * G_records;
}
abd_conf_t;

int
find_abundant(int argc, char ** argv);

#endif

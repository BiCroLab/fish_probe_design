typedef struct {
    uint32_t genomic_index;
    uint32_t multiplicity;
} hash_table_entry_t;

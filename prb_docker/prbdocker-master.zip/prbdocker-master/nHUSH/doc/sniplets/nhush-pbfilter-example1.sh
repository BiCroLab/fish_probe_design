$ man nhush # get wise
$ cd genome
$ cat *.fa > genome.fa # nhush reads a single fasta file
$ nhush --help # quick recap of command line arguments
$ nhush pbfilter \
  --ref genome.fa \
  --query ~/probe_candidates.fa \
  --out filtered_probes.fa \
  --length 60 \
  --maxpb 0.1

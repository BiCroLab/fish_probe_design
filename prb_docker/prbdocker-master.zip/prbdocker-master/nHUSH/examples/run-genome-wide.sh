#!/bin/bash
set -e

until=4
folder=genome-wide
length=26
file=genome.fa

nhush=`readlink -f ../bin/nhush`

if [ -z "$nhush" ]; then
    nhush=`which nhush`
fi

if [ -z "$nhush" ]; then
    echo "Cound not find nhush -- please compile first!"
    exit 1
fi
echo "Found nhush at: $nhush"


echo "This script demonstrates how to run nHUSH genome-wide"
echo ""
echo "Settings:"
echo "Folder to run in: ${folder}"
echo "Genome file: ${file}"
echo "Sequence length: ${length}"
echo "Run until all matches <= ${until} are found"
echo "initial hash size: Automatic i.e., not set."
echo "Expected run time: < 1 min (On AMD 3700X)"

confirm () {
    read -r -p "Are you sure? [y/N] " response
    response=${response,,}    # tolower
    if [[ "$response" =~ ^(yes|y)$ ]]
    then
        return 1
    else
        return 0
    fi
}

echo "This will delete the folder '${folder}' if it already exist"
#if confirm == 0
#then
#    exit 0
#fi

rm -rf ${folder}
mkdir ${folder}

echo "Entering '${folder}'"
cd ${folder}

echo "Making a link to ../${file}"
ln ../${file} ${file}

echo "---"
echo "Running nHUSH until everything with a match within a Hamming"
echo "distance of $until is found"
echo "---"

cmd="$nhush --file ${file} --length ${length} --until ${until} --threads 8"
echo $cmd >> commands
eval "$cmd"


echo "---"
echo "Dumping the result, left column: sequence, right column: shortest"
echo "Hamming to any location of the reference genome found so far"
echo "Since we used --until $until you can trust that values <= $unil"
echo "are exact."
echo "For values, v > $until the true value can fall anywhere"
echo "in [$until+1, v]"
echo "A high value is expected for the first sequence"
echo "since we used --sfp, i.e. skip first perfect, and that sequence"
echo "exists on the reference genome"
echo "---"

cmd="$nhush dump-mindist ${file} ${file}.nh.L${length}.mindist.uint8 ${length} > result.tsv"
echo "${cmd}" >> commands
eval "${cmd}"

echo "---"
echo "Showing sequences that has a Hamming distance <= ${until}"
echo "---"

cmd="awk '{if (\$2 <= ${until} ){ print \$0 }}' result.tsv"
echo "${cmd}" >> commands
eval "${cmd}"

echo "---"
echo "Done"
echo "See the folder ${folder} for more details"

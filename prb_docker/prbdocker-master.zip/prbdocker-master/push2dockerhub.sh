# after login to dockerhub
# docker login

docker tag prbdocker zaf4/prbdocker:v0.4
docker push zaf4/prbdocker:v0.4
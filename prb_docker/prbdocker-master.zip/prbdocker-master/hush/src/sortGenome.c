/* Sort all substrings of a fixed length NCHAR
 * from a long string (genome) with a fixed alphabet
 * that should be encoded by {0, 1, 2, 3}
 *
 * Method:
 * - Initially bucketsort
 * - Then qsort on each bucket with more than 1 element.
 *
 * Limitations:
 *  - Uses uint32_t for indexing so the largest string size
 *    is 2^32 elements.
 */

#define _GNU_SOURCE // before stdlib is included
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <stdint.h>
#include <math.h>
#include <string.h>

// Number of characters to sort by
#define NCHAR 60
// Number of characters to use in the hash function
// sweet spot 9
#define HCHAR 12-3
// 4^(HCHAR-1)
#define PHCHAR 4194304/(4*4*4)


void showString(uint8_t * s)
{
  for(int pp =0; pp<NCHAR; pp++)
  {
    switch(s[pp])
    {
      case 0:
        printf("A");
        break;
      case 1:
        printf("C");
        break;
      case 2:
        printf("G");
        break;
      case 3:
        printf("T");
        break;
    }
    //printf("%u", s[pp]);
  }
  printf("\n");
}

size_t strhash(uint8_t * restrict S)
{
  size_t h = 0;
  size_t mul = PHCHAR;
  for(size_t kk = 0 ; kk<HCHAR; kk++)
  {
    h += S[kk]*mul;
    mul /= 4;
  }
  if(0){
    for(int kk = 0 ; kk< 4; kk++)
    {
      printf("%u", S[kk]);
    }
    printf(" = %zu\n", h);
  }
  return h;
}


int gcmp(uint8_t * restrict A, uint8_t * restrict B)
{
  return memcmp(A, B, NCHAR*sizeof(uint8_t));
  if(0){
    for(size_t kk = 0; kk<NCHAR; kk++)
    {
      if(A[kk] > B[kk])
      {
        return 1;
      }
    }
    return 0;
  }
}

int gcmp_S_qs(const void * vA, const void * vB, void * vG)
{
  uint32_t * A = (uint32_t *) vA;
  uint32_t * B = (uint32_t *) vB;
  uint8_t * G = (uint8_t *) vG;

  return gcmp(G+A[0],G+B[0]);
}


void gsort(uint32_t * restrict S, uint8_t * restrict G, const size_t N)
{
  size_t nBins = powl(4, HCHAR);
  printf("%zu bins\n", nBins);
  uint32_t * BN = calloc(nBins, sizeof(uint32_t));
  uint32_t * H = malloc(N*sizeof(uint32_t));

  printf("Counting the number of items per bin ...\n");
  // Can be parallelized
  for(size_t kk = 0; kk<N-NCHAR; kk++)
  {
    size_t h = strhash(G+kk);
    // printf("%zu\n", h);
    assert(h<nBins);
    BN[h]++;
    H[kk] = h;
  }

  printf("Integrate the bucket sizes to get start positions ...\n");
  uint32_t * BS = malloc(nBins*sizeof(uint32_t));
  size_t startpos = 0;
  for(size_t kk = 0; kk<nBins; kk++)
  {
    BS[kk] = startpos;
    startpos += BN[kk];
  }

  printf("Placing pointers to substring in corresponding bins ...\n");
  // The speed of this really depends on the amount of cache that the
  // CPU has. the 6700k has 8 MB. S+BS+H=32+32+32=24 bytes suggesting that HCHAR should not be above 9
  // since BS and S are accessed randomly. On the other hand, using a small HCHAR will trigger many qsorts.
  for(size_t kk = 0; kk<N-NCHAR; kk++)
  {
    //size_t h = strhash(G+kk);
    size_t h = H[kk];
    S[BS[h]] = kk;
    BS[h]++;
  }

  printf("The substrings are now sorted up to the %dth letter\n", (int) HCHAR);

  printf("q-sorting bins, sorting up to the first %d letters ... \n", (int) NCHAR);
  // can be parallelized
  for(size_t kk = 0; kk<nBins; kk++)
  {
    if(BN[kk] > 1)
    { // More than one string in bucket BN[kk]
      // that are only sorted up to HCHAR

      uint32_t * Sbin = S + BS[kk] - BN[kk];
      qsort_r(Sbin, BN[kk], sizeof(uint32_t), gcmp_S_qs, (void*) G);

    }
  }

  free(BN);
  free(BS);
  free(H);
  return;

}

int main(int argc, char ** argv)
{
  if(argc != 2)
  {
    printf("Usage: \n $ ./%s N\n where N is the size of the test data\n", argv[0]);
    return -1;
  }

  size_t N = atol(argv[1]);

  if(N<NCHAR)
  {
    printf("Use at least %d characters in the test string\n", (int) NCHAR+1);
    return -1;
  }

  printf("Creating test data\n");
  uint8_t * G = malloc(N*sizeof(uint8_t));
  for(size_t kk = 0; kk<N; kk++)
  {
    size_t r = rand();
    G[kk] = 0+ (uint8_t) (4*r / RAND_MAX);
    if(G[kk] > 3)
      G[kk] = 3;
    assert(G[kk] < 4);
  }

  // List of locations
  uint32_t * S = malloc(N*sizeof(uint32_t));
  printf("Sorting\n");
  gsort(S, G, N);

  if(0){
    printf("Validation\n");
    // Validation
    for(size_t kk = 1; kk<N-NCHAR; kk++)
    {
      showString(G+S[kk]);

      // Validation that hash numbers are correct
      if( strhash(G+S[kk]) < strhash(G + S[kk-1]))
      {
        printf("strhash(G + S[%zu]) < strhash(G + S[%zu]))\n", kk, kk-1);

        return -1;
      }
      if( gcmp(G+S[kk], G+S[kk-1]) < 0)
      {
        printf("( gcmp(G+S[%zu], G+S[%zu]) < 0)\n", kk, kk-1);
      }

    }
  }
  free(S);
  free(G);
}



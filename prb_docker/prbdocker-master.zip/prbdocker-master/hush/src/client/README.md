# HUSH CGI interface

`hush_cgi.c` is a CGI-compatible binary that can be used with Apache, and probably any other CGI-compatible web server.

To get it going on Ubuntu 18.04.03 LTS together with Apache/2.4.29 the following worked:

 1. Enable the Apache CGI module:
  ```
  $ cd /etc/apache2/mods-enabled
  $ sudo ln -s ../mods-available/cgi.load
  $ sudo service apache2 restart
  ```
 2. Restart apache:
  ```
  $ sudo apachectl stop
  $ sudo apachectl start
  ```

 3. Check where the CGI binaries should go
  ```
  $ cat /etc/apache2/conf-available/serve-cgi-bin.conf
  ```
  In my case it was in: `/usr/lib/cgi-bin`

 4. Compile and place the cgi binary:
  ```
  $ make cgi-bin -B
  $ cp cgi-bin/hush.cgi /usr/lib/cgi-bin/
  ```

  5. Place the html interface in the Document Root of the web server
  ```
  cp src/cgi-bin/hush.html /var/www/html/
  ```

If everything is ok, then you should be able to visit:
[http://localhost/hush.html](http://localhost/hush.html)

When entering a sequence in the search bar you will get a message that it could not connect to the server until hushp is started in server mode, with the `-s` flag.

The error log was found in (look in httpd.conf):
`/private/var/log/apache2/error_log`

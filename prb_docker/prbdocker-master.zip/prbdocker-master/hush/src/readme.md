# src

The makefile in this folder is used to build unit tests. To build hush, use the makefile in the parent folder.

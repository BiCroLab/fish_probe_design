# Comparison between HUSH bowtie2 and blast (oligoarray)

## Aim: 

Produce plots of 
 * time per sequence vs k (length of kmers)
 * RAM vs k (length of k-mers)

Also, produce Venn-diagrams showing which sequences are kept using the different tools.

## Setup

### Reference genome:

stored in `hg/`
```
cat *.fa > GRCh37_all.fsa
```


### Oligoarray/BLAST

```
To ensure the specificity of the oligonucleotide for its target, our approach consists first of detection of sequence similarity between the target and other sequences. The masked sequence is compared to all other sequences using the BLAST program (9) specially tuned for this task as follows. The ‘DUST’ filter is inactivated using the –F F option in order to consider all sequences excepted the one previously masked. The –S option is set to 1 to restrict the search to the plus strand only, the one that will produce labeled probes during reverse transcription. The word size for the BLAST search is set to the smaller value allowed (–W 7) to detect a maximum of sequence similarities. The options controlling the output from BLAST are modified to reduce the number of one-line descriptions (–v 5) and to increase the number of reported alignments (–b 10 000). Before starting to process any sequence, OligoArray 2.0 will compute the Expectation value necessary to report alignments longer than 13 nt as a function of the length of the query and the database (see the OligoArray 2.0 web site for more information: http://berry.engin.umich.edu/oligoarray2). Thus, for each sequence to be processed, this parameter (–e) will be set regarding the length of the query to ensure the reporting of short alignments. The BLAST output is parsed and a matrix will keep a record of the possible similarity between each position of the input sequence and other sequences.
```

i.e., 

```
blastn -F F -S 1 -W 7 -v 5 -b 10000
```

translated to new blast

``` 
blastn -dust no -strand plus -word_size 7 -num_descriptions 5 -num_alignments 10000
```





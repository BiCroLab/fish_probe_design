<link rel="stylesheet" href="style.css">

# HUSH

Except for some legacy code this repo contains:

 * [hush](doc/mantxt/hush.1.txt) An exact <b>H</b>amming distance based tool to search for <b>U</b>nique <b>S</b>equences using multiple <b>H</b>ashing. The current active branch is called hushp, which is a parallelized version of hush.

And utilities:
 * [genmm](doc/mantxt/genmm.1.txt) Generation of sequences with specified number of mismatches from a reference sequence.
 * [genrand](doc/mantxt/genrand.1.txt) Generation of random sequences.
 * [cleaner](doc/mantxt/cleaner.1.txt) Clean up the output from hush by removing spurious comments.
 * [bfm](doc/mantxt/bfm.1.txt) Brute force matching.

For usage see the man pages. For documentation see `doc/`. Source code is in the `src/` directory. There are also some examples in `examples/`.

## Installation

To build the tools, use `make`, i.e.,

``` shell
make all -B
```
which will place binaries in `/bin`.

Please note that the HUSH binary is called `hushp` (to be changed in the future).

Consider also to add the following to your `.bashrc` (or similar if you're not using bash), and fix the paths to match your local file structure:
``` shell
export MANPATH="$(man --path):`pwd`/man"
export PATH="$PATH:`pwd`/bin/"
```
The man pages can also be opened "locally", try:
``` shell
man -l man/man1/hush.1
```

## Basic example

``` shell
mkdir test60
cd test60
# Create a "random" chromosome
genrand -l 10000000 -n 1 > chr_rand.fa
# Read a random 60-mer from the fa file
rseq=`readrand chr_rand.fa 60`
# Generate 11 sequences with increasing hamming distance
# from the randomly extracted sequence
genmm -s $rseq -f 0 -t 10 > query.fa
mkdir squery
cd squery
nthreads=8
# Create one input file per thread
split -n l/$nthreads ../query.fa
cd ..
hushp -l 60 -t $nthreads -r chr_rand.fa -q squery -m 5
# Merge the ouputs to a single file
cat squery/*.out > query.fa.out
```
Using these command `cat query.fa.out` will show something like:
``` text
>seq 0, 0 mm
CGGGCACCGTGTCTGGCCAATATGTCAATTTGTACGATTGCAAACGGATGACGTCAACAT
>seq 1, 1 mm
>seq 2, 2 mm
>seq 3, 3 mm
>seq 4, 4 mm
>seq 5, 5 mm
>seq 6, 6 mm
CGGGCACCGTGTGTGGCCAATATGTGAATTTGTACGACTGCAAACGGATGAGATCATCAT
>seq 7, 7 mm
CGGGCTCCGTGTCTGACCAATTTGTCAACTCGTACGACTGGAAACGGATGACGTCAACAT
>seq 8, 8 mm
CGGGCACCGTATCTGGCCAATATATGAATTCGTTCGATCGCAAACGGATGAGGCCAACAT
>seq 9, 9 mm
CGGGGACCGCGTGTAGAGAATATGTCAATTCGTACAATTGCAAACGGATGACGTCAACTT
>seq 10, 10 mm
CAAGCACCGTGTCTGGCGTATATGTCAATTTGTAGGATTGGTAACGAATGACATCAAGAT
```

As shown in the example above, unique matches are ignored (since we often use sequences that should exist somewhere on the genome).

Another option would be to run

``` shell
hushp -l 60 -t $nthreads -r chr_rand.fa -q squery -m 5 -f -0 -C
```

then `cat squery/*.out` will show something like

``` text
$ cat squery/*.out
>seq 0, 0 mm
CGGGCACCGTGTCTGGCCAATATGTCAATTTGTACGATTGCAAACGGATGACGTCAACAT, 1
>seq 1, 1 mm
CGGGCACCGTGTCTGGGCAATATGTCAATTTGTACGATTGCAAACGGATGACGTCAACAT, 1
>seq 2, 2 mm
CGGGCACCGTATCTGGCCAATACGTCAATTTGTACGATTGCAAACGGATGACGTCAACAT, 1
>seq 3, 3 mm
CGGGCACCGTGTCTGGCCAATATATGAATTTGTTCGATTGCAAACGGATGACGTCAACAT, 1
>seq 4, 4 mm
CGGGCTCCGTGTCTGGCCATTATGTCAATTTGTTCGACTGCAAACGGATGACGTCAACAT, 1
>seq 5, 5 mm
GGGACAGCGTGTCTGGCCAATATGTCAATTTGTACGATTGCATACGGATGACATCAACAT, 1
>seq 6, 6 mm
CGGGCACCGTGTGTGGCCAATATGTGAATTTGTACGACTGCAAACGGATGAGATCATCAT, 0
>seq 7, 7 mm
CGGGCTCCGTGTCTGACCAATTTGTCAACTCGTACGACTGGAAACGGATGACGTCAACAT, 0
>seq 8, 8 mm
CGGGCACCGTATCTGGCCAATATATGAATTCGTTCGATCGCAAACGGATGAGGCCAACAT, 0
>seq 9, 9 mm
CGGGGACCGCGTGTAGAGAATATGTCAATTCGTACAATTGCAAACGGATGACGTCAACTT, 0
>seq 10, 10 mm
CAAGCACCGTGTCTGGCGTATATGTCAATTTGTAGGATTGGTAACGAATGACATCAAGAT, 0
```
In that case the number of matches for each of the query strings will be appended after the sequence.

## TODOs:
 - Improve input/output in general, and more specific:
   - Use [zlib](https://zlib.net/) for reading `.gz` files directly.
   - Use a library for more robust handling of fa files, for example: [https://github.com/attractivechaos/klib]()
   - Add a mode to write SAM/BAM files.
   - Get rid of the dependency of GNU/coreutils split since it is not on mac by default.
   - Use better data structure for -C in hushp. Consider also generating the list of unique locations from the seeds before matching the whole sequence.
 - Write a test suite.
   - Tool to extract all sequences from a fa-file.

## Inspiration

 * PDF: [http://arxiv.org/abs/1307.2982](http://arxiv.org/abs/1307.2982)
 * Code: [https://github.com/norouzi/mih](https://github.com/norouzi/mih)
 * See also [ush](src/ush.md) in the `src/` directory where `popcnt` is used to speed up matching.

#!/bin/bash
set -e

NAME="Erik Wernersson"
EMAIL="https://github.com/elgw/escafish/issues"

set -e # exit on error

if [ $EUID = 0 ]; then
    echo "WARNING: You are running as root, please abort!"
    echo "Sleeping for 10 s"
    sleep 10
fi

savedir="$(pwd)"
builddir=$(mktemp -d)
cd $builddir
pkgdir=$(mktemp -d)/escafish
echo "pkgdir=$pkgdir"

ver_major=`sed -rn 's/^#define.*ESCAFISH_VERSION_MAJOR.*([0-9]+).*$/\1/p' < $savedir/src/version.h`
ver_minor=`sed -rn 's/^#define.*ESCAFISH_VERSION_MINOR.*([0-9]+).*$/\1/p' < $savedir/src/version.h`
ver_patch=`sed -rn 's/^#define.*ESCAFISH_VERSION_PATCH.*([0-9]+).*$/\1/p' < $savedir/src/version.h`
pkgver="${ver_major}.${ver_minor}.${ver_patch}"
echo "pkgver=$pkgver"
arch=$(dpkg --print-architecture)
echo "arch=$arch"

echo "Preparing files"
# Copy files to the correct places
# binaries
mkdir -p $pkgdir/usr/local/bin
cp $savedir/bin/escafish $pkgdir/usr/local/bin/escafish

# man pages
mkdir -p $pkgdir/usr/share/man/man1/
cp $savedir/doc/man-page/escafish.1 $pkgdir/usr/share/man/man1/

cd $pkgdir
size=$(du -k usr | tail -n1 | sed 's/usr//')

mkdir $pkgdir/DEBIAN/
cat > $pkgdir/DEBIAN/control << END
Package: escafish
Version: $pkgver
Architecture: $arch
Depends:
Conflicts:
Maintainer: $NAME <$EMAIL>
Installed-Size: $size
Section: custom
Priority: optional
Homepage: https://github.com/elgw/escafish/
Description: ESCAFISH: for creating FISH probes.
END

cd $pkgdir/../
dpkg-deb --build escafish escafish_${pkgver}_${arch}.deb
mv escafish_${pkgver}_${arch}.deb "$savedir"

#ifndef READ_DB_H
#define READ_DB_H

#include <stdio.h>
#include <stdlib.h>
#include "tsv.h"

/* Parse a tsv file with the same format as the provided example
 *
 * Expecting the following columns in the tsv file
 * "oligo_cost", "start", "end", "sequence"
 *
 * - All sequences should have the same length : checked.
 * - All sequences are on the same chromosome : not checked.
 */

typedef struct {
    FILE * log;
    char * tsvfile;
    int verbose;
    int read_seq; /* Read and store sequences or not */
    int ignore_cost;
} read_db_config;

typedef struct {
    uint32_t * start;
    int read_cost; /* Set to 0 to not look for the 'cost' column */
    float * cost;
    int read_seq;
    char ** seq; /* Points to seq_data */
    char * seq_data; /* String buffer for all seq */
    size_t noligos;
    int oligolen;
} oligodb_t;

/* Returns NULL on failure */
oligodb_t * read_db(const read_db_config);

void oligodb_free(oligodb_t*);

#endif

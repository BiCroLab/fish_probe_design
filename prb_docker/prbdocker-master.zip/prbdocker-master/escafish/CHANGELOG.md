# CHANGELOG

## **0.1.3**
- Added some extra checks that files could be opened, and that
  allocations didn't fail.

## **0.1.2**
- Fixed bug in reading tsv files. Does not crash for everything :)

## **0.1.1**
- Added experimental (brute force) black list filtering with `escafish apply_blacklist`.
- Doesn't work for anything else, got a bug solved in 0.1.2.

## **0.1.0**
- Added the `--greedy` option to turn off exact search.

## **0.0.9**
- Sane error message when asking for more probes than available.
- Sane output when asking for just one oligo.
- Refuse to find < 1 oligo.

## **0.0.8**
- Reduced the output at the default verbose level (1) even more.
- Found and fixed a bug: the _opt method could not find probes that
  included the initial oligo.

## **0.0.7**
- Refactoring alot :)
- Testing all available methods and returning whatever was best.
- The **--opt** flag is obsolete and ignored.

## **0.0.6**
- Gives more information when the program fails to build a probe from
  the oligo database.
- More sane output at default verbose level.
- Added the option *--overwrite**
- File name has to be specified when using **--plot**.

## **0.0.5**
- Added script for deb file creation.

## **0.0.4**
- Fixed the oligo length reading which was broken in version 0.0.3

## **0.0.3**
- Looks for a column called **oligo_cost** where the cost of individual
oligos is specified.
- Outputs a svg/png image of the probe.
- In the first pass, for each oligo, abort looking for the next oligo when
the distance term is larger than the smallest cost so far.
- Checks that the start positions of the oligos are sorted.
- Automatically determines of the oligo length, dropped the **--len**
argument.
- Checks that all oligos have the same length.
- Man page
- Renamed from probelet to escafish.


## **0.0.2**
- Writing to a log file.
- Displays info about the probe at the end.
- Fixed an issue causing some oligos beeing ignored.
- The first pass scans until it is guaranteed that no better oligo
can be found, instead of using a constant distance.
- Changed default pair weight to 0.0001
- Changed argument **--pair** to **--pw**

## **0.0.1**
- Initial version.

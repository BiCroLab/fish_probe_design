#!/bin/bash

# Save the docker container to a tar file and send it to the HT HPC server
docker save -o prbdocker.tar prbdocker
scp prbdocker.tar zafer.kosar@hpclogin.fht.org:/group/bienko/containers/
source ~/shell/interactive.sh -m 4 -c 32



prb get_oligos DNA 1
prb run_nHUSH -d DNA -L 40 -l 21 -m 3 -t 40 -i 14 -y
prb reform_hush_combined DNA 40 21 3
prb melt_secs_parallel
prb generate_blacklist -L 40 -c 100
prb build-db_BL -f q_bl -m 32 -i 6 -L 40 -c 100 -d 8 -T 72 -y
prb cycling_query -s DNA -L 40 -m 8 -c 100 -t 40 -g 500 -greedy --
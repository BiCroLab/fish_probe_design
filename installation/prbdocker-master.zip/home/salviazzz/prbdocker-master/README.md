# prbdocker

Docker image building for probe_design and its dependencies..

## Build base

- OS: Ubuntu 22.04
- Python: 3.10
- R base
- Dependencies From apt-get 

## Binary installations

- escafish
- hush
- nHUSH (required lua.pc for ubuntu)
- oligoarrayaux

## Pip installations

- probe_design
- ifpd2q
- oligo-melting

## Docker side

This part is for building and running the docker image

### Building docker image

```shell
bash build.sh
```

### Sending it to HPC
```shell
bash send2server.sh
```

### Opening an interactive shell with the image 

```shell
docker run -it docker
```



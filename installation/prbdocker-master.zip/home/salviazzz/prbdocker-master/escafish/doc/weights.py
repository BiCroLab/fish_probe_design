import matplotlib.pyplot as plt
import numpy as np

x = np.arange(0, 10)
y = 1/(x+1)

plt.plot(x,y)
plt.title('1/(1+m)')
plt.ylabel('Cost')
plt.xlabel('nHUSH output')
plt.show()

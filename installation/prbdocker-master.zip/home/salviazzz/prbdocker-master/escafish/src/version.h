#ifndef escafish_version_h
#define escafish_version_h

#define ESCAFISH_VERSION_MAJOR "0"
#define ESCAFISH_VERSION_MINOR "1"
#define ESCAFISH_VERSION_PATCH "2"

#define escafish_version ESCAFISH_VERSION_MAJOR "."  \
    ESCAFISH_VERSION_MINOR "."                        \
    ESCAFISH_VERSION_PATCH

#endif

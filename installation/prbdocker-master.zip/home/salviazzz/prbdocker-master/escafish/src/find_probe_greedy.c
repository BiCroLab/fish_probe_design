#include "find_probe_greedy.h"

/* Follow onext and calculate the cost of a probe
 * Early abort when the calculated cost is > current_best
 */
static float get_probe_cost(pconf_t * pc, uint32_t pos, float current_best);

static probe_t *  pconf_extract_probe_at(pconf_t * , uint32_t start_position);

/* Starting at position p, find the index of the optimal next neighbor */
static uint32_t get_onext(pconf_t * pc, const uint32_t p);



static uint32_t get_onext(pconf_t * pc, const uint32_t p)
{
    uint32_t N = pc->noligos_db;
    uint32_t q = p+1;
    if(q + 1 >= N)
    {
        return p; /* Nothing after */
    }
    /* Forward until the first valid oligo */
    while( pc->start[q]
           < pc->start[p] + pc->oligolen + pc->mingap
           && q + 1 < N)
    {
        q++;
    }

    if(q + 1 >= N)
    {
        return p; /* Indicates failure */
    }

    uint32_t best_pos = q;
    float cmin = /* cost_single_from_index(pc, p) same for all so we ignore it*/
        cost_single_from_index(pc, q) +
        oligo_cost_from_pair_index(pc, p, q);
    float cost = cmin;
    q++;


    /* Check forward until the pair term is larger than the current
       best guess */
    while( q < N && oligo_cost_from_pair_index(pc, p, q) < cmin)
    {

        cost = cost_single_from_index(pc, q) + oligo_cost_from_pair_index(pc, p, q);
        if(cost < cmin)
        {
            cmin = cost;
            best_pos = q;
        }
        q++;
    }

    // printf("p: %d best_pos: %d cmin: %f\n", p, best_pos, cmin);
    return best_pos;
}


/* For the greedy approach, construct a prove starting at pos
 * just following next onext
 * The function pconf_extract_probe_at will then find this probe again
 * based on the same start position
 * */

static probe_t *  pconf_extract_probe_at(pconf_t * pc, uint32_t pos)
{
    int noligos = pc->noligos;
    const uint32_t * start = pc->start;
    const float * cost = pc->cost;

    probe_t * probe = probe_new(noligos);
    uint32_t * mers = probe->index;
    mers[0] = pos;
    for(int kk = 1; kk<noligos; kk++)
    {
        mers[kk] = pc->onext[mers[kk-1]];
    }

    if(pc->verbose > 1)
    {
        printf("number\trow\tpos\tcost\n");
        for(int kk = 0; kk < noligos; kk++)
        {
            int id = mers[kk];
            printf("%d\t%u\t%u\t%f\n",
                   kk, id, start[id], cost[id]);
        }
        printf("Deltas: ");
        for(int kk = 0; kk+1 < noligos; kk++)
        {
            int p = mers[kk];
            int q = mers[kk+1];
            int delta = start[q] - (start[p]+pc->oligolen);
            printf("%d ", delta);
        }
        if(pc->verbose > 1)
        {
            printf("\n");
        }
    }

    probe->cost = get_probe_cost(pc, pos, INFINITY);
    return probe;
}


static float get_probe_cost(pconf_t * pc, uint32_t pos, float current_best)
{

    float cost = 0;

    cost += cost_single_from_index(pc, pos);

    for(uint32_t kk = 1; kk < (uint32_t) pc->noligos; kk++)
    {
        uint32_t next = pc->onext[pos];
        if(next == pos)
        {
            return INFINITY;
        }
        float ep = oligo_cost_from_pair_index(pc, pos, next);
        assert(ep >= 0);
        cost += ep;
        cost += cost_single_from_index(pc, next);
        pos = next;

        /* Quick abort if this probe can never be the best */
        if(cost > current_best)
        {
            return cost;
        }
    }

    return cost;
}


probe_t * find_probe_greedy(pconf_t * pc)
{
    if(pc->log)
    {
        fprintf(pc->log, "\n-- using find_probe_greedy\n");
    }

    size_t N = pc->noligos_db;



    if(pc->verbose > 1)
    {
        printf("Pass 1 (greedy connection to best next probe) ... ");
        fflush(stdout);
    }
    struct timespec tstart, tend;
    clock_gettime(CLOCK_REALTIME, &tstart);

    /* Pass 1, for each oligo, find the optimal next one */
    for(uint32_t kk = 0; kk<N; kk++)
    {
        pc->onext[kk] = get_onext(pc, kk);
        //printf("%d, %d, delta=%d\n", kk, pc->onext[kk],
        //       (int) (pc->onext[kk] - kk));
    }

    {
        clock_gettime(CLOCK_REALTIME, &tend);
        double deltat = clockdiff(&tend, &tstart);
        if(pc->verbose > 2)
        {
            printf("took: %.1f s\n", deltat);
        }
    }


    if(pc->verbose > 1)
    {
        printf("Pass 2 (greedy probe construction) ... \n");
        fflush(stdout);
    }
    clock_gettime(CLOCK_REALTIME, &tstart);
    /* Pass 2, starting at each oligo, find the best probe */
    double best_cost = INFINITY;
    uint32_t best_pos = 0;
    for(uint32_t kk = 0; kk+1 < N; kk++)
    {
        float cost = get_probe_cost(pc, kk, best_cost);
        //printf("%d, %f\n", kk, cost);
        if(cost < best_cost)
        {
            best_cost = cost;
            best_pos = kk;
        }
    }

    if(best_cost == INFINITY)
    {
        return NULL;
    }

    if(pc->verbose > 1)
    {
        printf("best_pos: %d, best_cost: %f\n", best_pos, best_cost);
    }
    {
        clock_gettime(CLOCK_REALTIME, &tend);
        double deltat = clockdiff(&tend, &tstart);
        if(pc->verbose > 1)
        {
            printf("took: %.1f s\n", deltat);
        }
        if(pc->log != NULL)
        {
            fprintf(pc->log, "Pass 2 took %.1f s\n", deltat);
        }
    }

    if(pc->verbose > 1)
    {
        printf("Found best probe starting with the oligo on "
               "line %d.\n", best_pos);
    }
    if(pc->log != NULL)
    {
        fprintf(pc->log, "Found best probe starting with the oligo on "
                "line %d.\n", best_pos);
    }
    probe_t * probe = pconf_extract_probe_at(pc, best_pos);
    probe->comment = strdup("find_probe_greedy");
    if(probe_update_cost(probe, pc))
    {
        probe_free(probe);
        return NULL;
    }
    return probe;
}

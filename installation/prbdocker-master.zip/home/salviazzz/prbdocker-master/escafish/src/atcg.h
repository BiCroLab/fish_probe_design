/* Things related to processing genomic strings
 * Version 0.0.1 2023-04-13 (buddy with readfa.h)
 */

#ifndef __atcg_h__
#define __atcg_h__

#include <assert.h>
#include <ctype.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "readfa.h"

#ifndef ANSI_COLOR_RED
#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_YELLOW  "\x1b[33m"
#define ANSI_COLOR_BLUE    "\x1b[34m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_CYAN    "\x1b[36m"
#define ANSI_COLOR_RESET   "\x1b[0m"
#endif

#define SUBS_TABLE_INVALID 127

/* Standard numeric representation well suited for reversing */
#define numA 0
#define numC 1
#define numG 2
#define numT 3

/* Actual table defined in atcg.c */
/* https://en.wikipedia.org/wiki/Nucleic_acid_notation */
typedef struct{
    int num; /* Numerical representation */
    char sym; /* Character symbol */
    int A; /* If it can be 'A' */
    int C; /* If it can be 'C' etc ... */
    int G;
    int T;
    int nbase; /* Number of possible bases */
    char complement; /* Complementary bases */
} iupac_t;


float
iupac_dist(iupac_t a, iupac_t b);

/* SLOW lookup from symbol to number, e.g. from 'A' to 0, 'V' to 13 ... */
uint8_t
iupac_sym_to_num(char sym);

/* SLOW lookup from number to symbol */
char
iupac_num_to_sym(uint8_t num);

iupac_t
iupac_from_sym(char sym);

/* A sym_table defines lookup tables (LUTs) to be used
 * to quickly convert from characters to numbers and back
 * also for quick reverse complements and probabilistic
 * Hamming distances.
 *
 */
typedef struct sym_table{
    /* from character to numeric representation LUT */
    uint8_t * num_from_char;
    /* As above but only mapping to 'A', 'T', 'C', 'G' */
    uint8_t * num4_from_char;

    /* from numeric and back to characters */
    uint8_t * char_from_num;
    /* And back */
    uint8_t * char_from_num4;

    /* Hamming and probabilistic Hamming distances */
    float * dist; /* 16x16 distance table */
    float * dist4; /* 4x4 dis. table for data limited to 'A', 'T', 'C', 'G' */

    /* complementary basis LUTs */
    uint8_t * comp_num_from_num;
    uint8_t * comp_char_from_char;
} sym_table_t;


sym_table_t *
sym_table_new(void);

void
sym_table_show(sym_table_t *);

void
sym_table_free(sym_table_t *);


/* See if a string contains known characters */
int
sym_validate_string(sym_table_t * sym,
                        char * str,
                        size_t len);


char *
sym_reverse_complement(char * S,
                              int L,
                              sym_table_t * sym);


/* Single character to numeric value */
uint8_t
map_char_to_val(const char c);

/* String to numeric array */
void
to_digital(uint8_t * restrict y, const char * restrict x, const size_t n);

/* Single number to base */
char
map_num_to_char(const uint8_t c);


/* More general Hamming distance using the full dist4
 * table. */
float
hamming_distance_sym(const uint8_t * A,
                             const uint8_t * B,
                             int L,
                             sym_table_t * S);

/* Print a numerical representation as a string without '\n' */
void
fprint_seq(FILE * fid, const uint8_t * S, const size_t L);

/* calls fprint_seq with stdout as first argument */
void
print_seq(const uint8_t * S, const size_t L);

/* Print two sequences and highlight their matches */
void
show_match(const uint8_t * A, const uint8_t * B, int L);

struct _fasta_records_t;
typedef struct _fasta_records_t fasta_records_t;

/* Show a match and lookup the position in the record */
void
show_match_records(const uint8_t * A, size_t pos, fasta_records_t * rec,
                        const uint8_t * B, int L, int rc, int colors);

void
show_match_records_sym(const uint8_t * A, size_t pos, fasta_records_t * rec,
                            const uint8_t * B, int L, int rc, int colors, sym_table_t * sym);


void
fprint_seq_num(FILE * fid, const uint8_t * A, int L, sym_table_t * T);

/* Print a seq with color information,
 * if color[i] > 0, S[i] will be printed yellow
 * else: default
 */
void
print_seq_color(const uint8_t * S, uint32_t * color, const size_t L);

/* Read S and write reverse complement to R */
void
reverse_complement(uint8_t * restrict R,
                        const uint8_t * restrict S, const int L);

int
atcg_ut(void);

void
sym_replace_str(char * S, int L, sym_table_t * sym);

#endif

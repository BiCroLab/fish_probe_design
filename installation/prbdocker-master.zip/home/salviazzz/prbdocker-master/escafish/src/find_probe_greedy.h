#ifndef FIND_PROBE_GREEDY_H
#define FIND_PROBE_GREEDY_H

#include "escafish.h"


/* Find the best probe, considering all starting positions
 * A two-pass heuristics:
 * 1/ Scan each oligo for the next optimal oligo
 * 2/ Starting at each oligo follow the chain of optimal next oligo
 */

probe_t * find_probe_greedy(pconf_t *);


#endif

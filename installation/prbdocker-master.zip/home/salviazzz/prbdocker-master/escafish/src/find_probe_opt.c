#include "find_probe_opt.h"


#define NOTNULL(x) {                                            \
        if(x == NULL)                                           \
        {                                                       \
            fprintf(stderr,                                     \
                    "Got unexpected NULL pointer in %s%d\n",    \
                    __FILE__, __LINE__);                        \
            fprintf(stderr,                                     \
                    "This is a bug, please report it!\n");      \
            exit(EXIT_FAILURE);                                 \
        }}                                                      \


typedef struct {
    float cost; /* cost of the tail */
    uint32_t pos; /* latest added oligo */
    uint32_t end; /* last oligo of the tail */
} tail_t;


static tail_t
get_tail(pconf_t * pc, const uint32_t p);


static probe_t*
pconf_find_probe_opt_region(pconf_t * pc_full,
                            const uint32_t ofirst, const uint32_t olast);


/* Get the position of the path tail with smallest cost */
static int
get_min_tail(const pconf_t * pc);

probe_t * find_probe_opt(pconf_t * pc)
{
    if(pc->log)
    {
        fprintf(pc->log, "\n-- using find_probe_opt\n");
    }

    size_t N = pc->noligos_db;

    /* We initialize the tail to the oligo cost */
    pc->tail_cost = calloc(N, sizeof(float));
    NOTNULL(pc->tail_cost);
    float * tail_cost = pc->tail_cost;
    pc->tail_end = calloc(N, sizeof(float));
    NOTNULL(pc->tail_end);
    uint32_t * tail_end = pc->tail_end;


    for(size_t kk = 0; kk<N; kk++)
    {
        tail_cost[kk] = pc->cost[kk];
        tail_end[kk] = kk;
    }

    /* For each iteration the tail grows */
    uint32_t ofirst = 0, olast = 0;
    if(pc->verbose > 1)
    {
        printf("\n");
    }
    for(int tt = 1; tt < pc->noligos; tt++)
    {

        fflush(stdout);
        for(uint32_t kk = 0; kk<N; kk++)
        {
            tail_t tail = get_tail(pc, kk);
            pc->tail_cost[kk] = tail.cost; //get_tail_cost(pc, kk);
            pc->tail_end[kk] = tail.end;
        }
        if(pc->verbose > 1) {
            printf("\r                                             ");
            printf("\rPass %d / %d", tt, pc->noligos -1 );
        }
        /* Get start and en pos of the optimal path so far */
        int min_tail = get_min_tail(pc);
        ofirst = min_tail;
        olast = pc->tail_end[min_tail];
        if(pc->tail_cost[min_tail] == INFINITY)
        {
            if(pc->verbose > 0){
                printf("\n");
            }
            printf("escafish/find_probe_opt: Failed to find a probe longer than %d oligos\n", tt);
            goto fail;
        }
        if(pc->verbose > 1)
        {
            printf(" Min cost: %f at pos %u--%u",
                   pc->tail_cost[min_tail],
                   min_tail,
                   pc->tail_end[min_tail]);
        }


        fflush(stdout);
    }
    if(pc->verbose > 1)
    {
        printf("\n");
    }

    free(pc->tail_end);
    free(pc->tail_cost);
    /* To do: find the actual probe ...  the first oligo can be found
       at ofirst and the last at olast. Hence we have a local problem
       and might be able to store all trails.
    */

    probe_t * probe = pconf_find_probe_opt_region(pc, ofirst, olast);
    if(probe_update_cost(probe, pc))
    {
        probe_free(probe);
        return NULL;
    }
    probe->comment = strdup("find_probe_opt");
    return probe;

fail:
    free(pc->tail_end);
    free(pc->tail_cost);
    return NULL;
}


/* Find the optimal tail cost
 * returns a tail with end==-1 on failure
 */
static tail_t get_tail(pconf_t * pc, const uint32_t p)
{
    uint32_t N = pc->noligos_db;

    tail_t tail = {};
    tail.cost = INFINITY;
    tail.end = -1;

    if(p + 1 >= N)
    {
        return tail; /* Nothing after */
    }

    uint32_t q = p+1;

    /* Forward until the first valid oligo
     * i.e. not overlapping */
    while( pc->start[q] < pc->start[p] + pc->oligolen + pc->mingap -1 && q + 1 < N)
    {
        q++;
    }

    if(q >= N)
    {
        return tail; /* Indicates failure */
    }

    uint32_t best_pos = q;
    float cmin = /* cost_single_from_index(pc, p) same for all so we ignore it*/
        //cost_single_from_index(pc, q) +
        pc->tail_cost[q] +
        oligo_cost_from_pair_index(pc, p, q);
    float cost = cmin;


    q++;
    /* Check forward until the pair term is larger than the current
       best guess */
    while( q < N && oligo_cost_from_pair_index(pc, p, q) < cmin)
    {
        double tail_cost = pc->tail_cost[q];
        cost = tail_cost + oligo_cost_from_pair_index(pc, p, q);
        if(cost < cmin)
        {
            cmin = cost;
            best_pos = q;
        }
        q++;
    }

    tail.cost = cmin + cost_single_from_index(pc, p);
    if(tail.cost < INFINITY)
    {
        tail.pos = best_pos;
        tail.end = pc->tail_end[best_pos];
    }
    return tail;
}


int get_min_tail(const pconf_t * pc)
{
    uint32_t min_pos = 0;
    double min_cost = pc->tail_cost[0];

    for(size_t kk = 0; kk<pc->noligos_db; kk++)
    {
        if(pc->tail_cost[kk] < min_cost)
        {
            min_cost = pc->tail_cost[kk];
            min_pos = kk;
        }
    }
    return min_pos;
}

/* This is like pconf_fint_opt_probe but also tracks the optimal path */
static probe_t * pconf_find_probe_opt_region(pconf_t * pc_full,
                                             const uint32_t ofirst, const uint32_t olast)
{
    NOTNULL(pc_full);
    if(pc_full->verbose > 1)
    {
        printf("Finding optimal path... in [%u, %d]\n", ofirst, olast);
    }
    fflush(stdout);
    pconf_t * pc = calloc(1, sizeof(pconf_t)); /* free before return */
    NOTNULL(pc);
    pc->verbose = pc_full->verbose;
    pc->noligos_db = olast - ofirst + 2;
    int N = pc->noligos_db;
    pc->noligos = pc_full->noligos;
    pc->cost = pc_full->cost + ofirst; /* No copy */
    pc->start = pc_full->start + ofirst; /* No copy */
    pc->mingap = pc_full->mingap;
    pc->oligolen = pc_full->oligolen;
    int n = pc->noligos;
    pc->pair_weight = pc_full->pair_weight;
    assert(N>0); // TODO
    pc->tail_end = calloc(N, sizeof(uint32_t)); /* free before return */
    NOTNULL(pc->tail_end);

    pc->tail_cost = calloc(N, sizeof(float)); /* free before return */
    NOTNULL(pc->tail_cost);

    if(pc->verbose > 1)
    {
        printf("N=%d, n=%d\n", N, n); fflush(stdout);
    }
    float * cost = pc->cost;
    float * tail_cost = pc->tail_cost;
    /* a table with the tail_paths */
    uint32_t * tail_path = calloc(N*n, sizeof(uint32_t));
    NOTNULL(tail_path);
    uint32_t * tail_end = pc->tail_end;
    for(int kk = 0; kk<N; kk++)
    {
        tail_cost[kk] = cost[kk];
        tail_path[kk + 0*n] = kk;
        tail_end[kk] = kk;
    }


    for(int tt = 1; tt<n; tt++)
    {

        fflush(stdout);
        for(int kk = 0; kk<N; kk++)
        {
            tail_t tail = get_tail(pc, kk);

            tail_cost[kk] = tail.cost;
            tail_path[kk + (tt-1)*N] = tail.pos;
            //printf("Step %d, oligo %d, the optimal path continues at %d\n",tt, kk, tail.pos);
        }
        if(pc->verbose > 1)
        {
            printf("\r                                                     ");
            printf("\rPass %d / %d", tt, pc->noligos -1 );
            fflush(stdout);
        }
    }
    if(pc->verbose > 1)
    {
        printf("\n");
    }
    if(0){ // show the table
        for(int tt = 1; tt<n; tt++)
        {
            for(int kk = 0; kk<N; kk++)
            {
                printf("%u ", tail_path[kk + (tt-1)*N]);
            }
            printf("\n");
        }
    }
    probe_t * probe = probe_new(n);
    probe->n = n;
    if(pc->verbose > 1)
    {
        printf("ofirst = %u, olast = %u, n=%d\n", ofirst, olast, n); fflush(stdout);
    }
    probe->index[0] = 0; /* According to assumptions the path starts
                            at the first oligo */
    // printf("%d: %d\n", 0, probe->index[0]); /* show the path */
    for(int kk = 1; kk<n; kk++)
    {

        probe->index[kk] = tail_path[probe->index[kk-1] + N*(n-kk-1)];
        // printf("%d: %d\n", kk, probe->index[kk]); /* show the path */
    }
    for(int kk = 0; kk<n; kk++)
    {
        probe->index[kk] += ofirst;
    }
    free(pc->tail_end);
    free(pc->tail_cost);
    free(tail_path);
    free(pc);
    return probe;
}

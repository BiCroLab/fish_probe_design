#include "read_db.h"

#define NOTNULL(x) {                                            \
        if(x == NULL)                                           \
        {                                                       \
            fprintf(stderr,                                     \
                    "Got unexpected NULL pointer in %s%d\n",    \
                    __FILE__, __LINE__);                        \
            fprintf(stderr,                                     \
                    "This is a bug, please report it!\n");      \
            exit(EXIT_FAILURE);                                 \
        }}                                                      \


typedef struct {
    int start;
    int end;
    float cost;
    char seq[512];
} row_data_t;

void
oligodb_free(oligodb_t * db)
{
    if(!db)
        return;
    free(db->start);
    free(db->cost);
    free(db->seq);
    free(db->seq_data);
    free(db);
    return;
}

/* Count the number of newlines in a file,
 * used to guess how much memory to allocate for the db
 */

static size_t count_newlines(const char * fname);

/* Set the cost for including a single oligo
 * based on one line from the tsv-database.
 * If cost_row >= 0 the oligo costs will be read from that row */
static row_data_t get_row_data(oligodb_t * db,
                               const char * line,
                               const int start_col,
                               const int end_col,
                               const int cost_col,
                               const int seq_col,
                               char * buffer,
                               size_t buffer_size,
    int verbose);



oligodb_t * read_db(const read_db_config config)
{
    FILE * log = config.log;
    const char * filename = config.tsvfile;
    const int verbose = config.verbose;

    size_t N = count_newlines(filename);
    N++;

    if(verbose > 1)
    {
        printf("%s contains %zu lines\n", filename, N);
    }
    if(log != NULL)
    {
        fprintf(log, "%s contains %zu lines\n", filename, N);
    }

    oligodb_t * db = calloc(1, sizeof(oligodb_t));
    NOTNULL(db);
    db->read_cost = 1;

    if(config.ignore_cost)
    {
        db->read_cost = 0;
    }

    db->start = malloc(N*sizeof(uint32_t));
    NOTNULL(db->start);

    if(db->read_cost)
    {
        db->cost = malloc(N*sizeof(float));
        NOTNULL(db->cost);
    }
    db->oligolen = -1; /* Indicates undiscovered */

    if(config.read_seq)
    {
        db->read_seq = 1;
        db->seq = malloc(N*sizeof(char*));
        NOTNULL(db->seq);
    }

    FILE * fp;
    char * line = NULL;
    size_t len = 0;
    ssize_t read;

    fp = fopen(filename, "r");
    if (fp == NULL)
    {
        fprintf(stderr, "Unable to open %s\n", filename);
        goto fail1;
    }

    /* Read header line */
    read = getline(&line, &len, fp);
    if(read == -1)
    {
        fprintf(stderr,
                "Failed to read from %s when looking for the header row\n",
                filename);
        goto fail1;
    }
    while(line[0] == '#') // TODO: skip blank lines?
    {
        read = getline(&line, &len, fp);
        if(read == -1)
        {
            fprintf(stderr,
                    "Failed to read from %s when looking for the header row\n",
                    filename);
            goto fail1;
        }
    }

    /* -1 No row labelled oligo_cost is present
       >= 0 : oligo_cost is at cost_row */

    int ln = strlen(line);
    if(line[ln-1] == '\n')
    {
        line[ln-1] = '\0';
    }

    int cost_col = tsv_get_col_number(line, "oligo_cost");
    int start_col = tsv_get_col_number(line, "start");
    int end_col = tsv_get_col_number(line, "end");
    int seq_col = tsv_get_col_number(line, "sequence");
    if(verbose > 2)
    {
        printf("cost_col: %d, start_col: %d, end_col: %d, seq_col: %d\n",
               cost_col, start_col, end_col, seq_col);
    }

    int ok = 1;
    if(cost_col < 0 && db->read_cost)
    {
        printf("ERROR: Could not find any 'oligo_cost' column\n");
        ok = 0;
    }
    if(start_col < 0)
    {
        printf("ERROR: Could not find any 'start' column\n");
        ok = 0;
    }
    if(end_col < 0)
    {
        printf("ERROR: Could not find any 'end' column\n");
        ok = 0;
    }

    if(config.read_seq && seq_col < 0)
    {
        printf("ERROR: could not find any 'sequence' column\n");
        ok = 0;
    }

    if(ok == 0)
    {
        fprintf(stderr, "ERROR: could not find all required columns\n");
        fprintf(stderr, "first line: '%s'\n", line);
        exit(EXIT_FAILURE);
    }

    size_t buffer_size = 6400;
    char * buffer = calloc(buffer_size, 1);
    NOTNULL(buffer);

    size_t n = 0;
    while ((read = getline(&line, &len, fp)) != -1) {
        if(strlen(line) > 0 && line[0] != '#')
        {
            int ln = strlen(line);
            if(line[ln-1] == '\n')
            {
                line[ln-1] = '\0';
            }

            row_data_t rd =
                get_row_data(db, line,
                             start_col,
                             end_col,
                             cost_col,
                             seq_col,
                             buffer,
                             buffer_size,
                    verbose);
            if(rd.start < 0)
            {
                goto fail2;
            }
            db->start[n] = rd.start;
            if(db->read_cost)
            {
                db->cost[n] = rd.cost;
            }
            if(db->read_seq)
            {
                if(n == 0)
                {
                    db->seq_data = malloc(N*(strlen(rd.seq)+1));
                    NOTNULL(db->seq_data);
                }
                db->seq[n] = db->seq_data + n*(db->oligolen+1);
                sprintf(db->seq[n], "%s", rd.seq);
            }
            n++;
        }
    }

    free(buffer);

    fclose(fp);

    free(line);

    db->noligos = n;

    /* Ensure that start positions are sorted */
    for(size_t kk = 0; kk+1<n; kk++)
    {
        if(db->start[kk] >= db->start[kk+1])
        {
            if(db->start[kk] == db->start[kk+1])
            {
                fprintf(stderr,
                        "escafish ERROR: the input data contains duplicate start values\n");
            } else {
                fprintf(stderr,
                        "escafish ERROR: the input data is not sorted by the start column\n");
            }
            goto fail1;
        }
    }

    /* Oligos might be overlapping. All oligos have length pc->oligolen */

    return db;

fail2:
    free(buffer);
    fclose(fp);
    free(line);

fail1:
    free(db->start);
    free(db->cost);
    free(db);
    return NULL;
}


/* Count the number of newlines in a file */
static size_t count_newlines(const char * fname)
{
    FILE * fid = fopen(fname, "r");
    assert(fid != NULL);
    size_t N = 0;
    char c = EOF;
    while( (c = fgetc(fid) ) != EOF )
    {
        if( c == '\n')
        {
            N++;
        }
    }
    fclose(fid);
    return N;
}

/* Parse a single line from a tsv file */
static row_data_t get_row_data(oligodb_t * db,
                               const char * line,
                               const int start_col,
                               const int end_col,
                               const int cost_col,
                               const int seq_col,
                               char * buffer,
                               size_t buffer_size,
    int verbose)
{

    row_data_t rd;
    rd.start = -1;
    rd.end = -1;
    rd.cost = -1;

    char * sequence = buffer;

    int ok = tsv_get_int_col(line, start_col, &rd.start);
    ok += tsv_get_int_col(line, end_col, &rd.end);
    ok += tsv_get_float_col(line, cost_col, &rd.cost);
    ok += tsv_get_string_col(line, seq_col, sequence, buffer_size);

    int seq_len = strlen(sequence);
    if(db->oligolen == -1)
    {
        if(verbose > 2)
        {
            printf("First sequence: '%s' (%d bases)\n", sequence, seq_len);
        }

        db->oligolen = seq_len;
    } else {
        if(db->oligolen != seq_len)
        {
            fprintf(stderr, "escafish: Mix of oligo lengths found, both %d and %d\n",
                    db->oligolen, seq_len);
            rd.start = -1;
            return rd;
        }
    }
    if(ok != 0)
    {
        fprintf(stderr, "Failed to parse this line:\n%s\n Quitting\n", line);
        rd.start = -1;
        return rd;
    }

    if(db->read_seq)
    {
        sprintf(rd.seq, "%s", sequence);
    }

    return rd;
}

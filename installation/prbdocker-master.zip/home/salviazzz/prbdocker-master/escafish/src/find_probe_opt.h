#ifndef FIND_PROBE_OPT_H
#define FIND_PROBE_OPT_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "escafish.h"

probe_t * find_probe_opt(pconf_t * pc);

#endif

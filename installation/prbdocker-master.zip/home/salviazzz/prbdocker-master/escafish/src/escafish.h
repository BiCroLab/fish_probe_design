#ifndef __escafish_h__
#define __escafish_h__

#define _GNU_SOURCE
#include <assert.h>
#include <getopt.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include "version.h"

#include <cairo.h>
#include <cairo-svg.h>

#include "util.h"
#include "tsv.h"
#include "apply_blacklist.h"

/* TODO: factor into program settings / algorithm settings */
typedef struct {
    /* TSV database file */
    char * dbfile;
    /* Data, after loaded from the TSV file */
    size_t noligos_db; /* number of available oligos */
    uint32_t * start; /* Start of oligo */
    float * cost; /* cost of oligo (lower is better) */
    uint32_t * onext; /* Optimal next oligo# */
    /* Configuration */
    int noligos; /* Number of oligos in a probe */
    int oligolen; /* Length of each oligo */
    int mingap; /* Minimum of base pairs before the next oligo */
    /* Configuration -- minimization */
    float pair_weight; /* coefficient before Quadratic distance */
    /* Output */
    char * outfile;
    char * logfile;
    FILE * log;
    int verbose; /* 1=default, 0=quiet, > 1 chatty */
    int overwrite;
    int greedy; /* Set to 1 to disable the exact search */

/* TODO: remove, specific to find_probe_opt */
    float * tail_cost; /* Optimal cost of the tail ... */
    uint32_t * tail_end; /* Last oligo of the tail */

    int plot; /* Produce svg/png plot or not */
    char * plotfile;

    int argc;
    char ** argv;
} pconf_t;

typedef struct {
    int gap_min;
    double gap_avg;
    int gap_max;
    double cost_min;
    double cost_avg;
    double cost_max;
    double cost_oligos;
    double cost_gaps;
    int size;
    int noligos;
    char * method;
} probe_info_t;

probe_info_t * probe_info_new(void);
void probe_info_free(probe_info_t * pi);

typedef struct {
    uint32_t * index;
    int n;
    double cost; /* Set by? */
    char * comment;
} probe_t;


pconf_t * pconf_new();
void pconf_free(pconf_t*);
/* Parse command line arguments, exit if not valid */
void pconf_argparse(int argc, char ** argv, pconf_t * pconf);
/* Print the settings to a file, does nothing if fid == NULL */
void pconf_print(FILE * fid, pconf_t * pc);


probe_t * probe_new(int nOligos);
void probe_free(probe_t*);

/* Update probe->cost returns 0 on success and 1 on failure.
 * Failure indicates that the cost was INFINITE or that
 * the oligos overlap or are in the wrong order
 */
int probe_update_cost(probe_t * probe, pconf_t * pc);

/* Populate p->info */
probe_info_t * probe_get_info(const probe_t * p, const pconf_t * pc);

/* Print probe info to file */
void probe_info_print(FILE * fid, probe_info_t * i);

/*  */
void probe_to_svg(char * fname, const probe_t * t, const pconf_t * pc);

/* Dump the tsv file corresponding to a probe to a FILE* */
void pconf_probe_print(pconf_t *, probe_t *);

probe_t * probe_keep_best(probe_t * P1, probe_t * P2);

/* Cost calculations.
 * For each probe the cost is calculated as
 * C(probe) = sum_{i=1}^{i=n} cost_single(o_i) + \sum_{i=1}^{i=n-1} cost_pair(o_i, o_{i+1})
 */


/* Cost for a single oligo */
float cost_single_from_index(const pconf_t * pc, int pos);

/* The cost of placing two oligos next to each other,
 * only the distance term */
float oligo_cost_from_pair_index(const pconf_t * pc, int posA, int posB);


void show_help(int argc, char ** argv);


#endif

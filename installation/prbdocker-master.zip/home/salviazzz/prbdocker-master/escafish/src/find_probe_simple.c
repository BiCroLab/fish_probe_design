#include "find_probe_simple.h"


#define NOTNULL(x) {                                            \
        if(x == NULL)                                           \
        {                                                       \
            fprintf(stderr,                                     \
                    "Got unexpected NULL pointer in %s%d\n",    \
                    __FILE__, __LINE__);                        \
            fprintf(stderr,                                     \
                    "This is a bug, please report it!\n");      \
            exit(EXIT_FAILURE);                                 \
        }}                                                      \



probe_t * find_probe_simple_uniform(pconf_t * pc)
{


    probe_t * probe = probe_new(pc->noligos);
    int noligos = pc->noligos;


    /* Somewhat uniform distribution */
    for(int kk = 0; kk < noligos; kk++)
    {
        long int idx = round(
            (double) kk * (double) pc->noligos_db / (double) noligos);
        //printf("idx=%ld\n", idx);
        probe->index[kk] = idx;

        if(kk > 0)
        {
            if(probe->index[kk] <= probe->index[kk-1])
            {
                printf("%d %d\n", probe->index[kk], probe->index[kk-1]);
                goto fail;
            }
        }
    }

    probe->comment = strdup("find_probe_simple/uniform");

    if(probe_update_cost(probe, pc))
    {
        probe_free(probe);
        return NULL;
    }

    return probe;

fail:
    probe_free(probe);
    return NULL;
}

int find_best_idx(float * cost, uint8_t * index, size_t N)
{
    float min = INFINITY;
    long int best_idx = -1;
    for(size_t kk = 0; kk<N ; kk++)
    {
        if(index[kk] == 0)
        {
            if(cost[kk] < min)
            {
                min = cost[kk];
                best_idx = kk;
            }
        }
    }
    return best_idx;
}

void update_index(uint8_t * index, size_t best_idx, pconf_t * pc)
{
    index[best_idx] = 1;


    long int last_to_block = pc->start[best_idx]
        + pc->oligolen + pc->mingap - 1;
    long int first_to_block = (long int) pc->start[best_idx]
        - pc->oligolen - pc->mingap + 1;
    if(0)
    {
    printf("blocking pos: %ld to %ld, +%d/-%d\n", first_to_block, last_to_block,
           (int) last_to_block - (int) pc->start[best_idx],
           (int) first_to_block - (int) pc->start[best_idx]);
    }

    // Forward scan
    long int pos = best_idx+1;
    while((size_t) pos < pc->noligos_db)
    {

        if(pc->start[pos] <= last_to_block)
        {
            if(index[pos] == 1)
            {
                printf("ERROR index[%ld]==1 (pos == %u)\n", pos, pc->start[pos]);
                assert(0);
            }
            index[pos] = 2;
        } else {
            break;
        }
        pos++;
    }

    // Backward scan

    pos = best_idx-1;
    while(pos >= 0)
    {

        if(pc->start[pos] >= first_to_block)
        {
            if(index[pos] == 1)
            {
                printf("ERROR index[%ld]==1 (pos == %u)\n", pos, pc->start[pos]);
                assert(0);
            }
            index[pos] = 2;
        } else {
            break;
        }
        pos--;
    }

    if(0){
        for(size_t kk = 0; kk<pc->noligos_db; kk++)
        {
            printf("index[%zu] = %u\n", kk, index[kk]);
        }
        getchar();
    }
    return;
}


/* Pick the best available oligo until we have enough
 * or there is nothing to select */
probe_t * find_probe_simple_best_oligo(pconf_t * pc)
{


    /*
     * 0=unused/available
     * 1=used
     * 2=blocked (by overlap) */
    uint8_t * index = calloc(pc->noligos_db, 1);
    NOTNULL(index);

    for(int oo = 0; oo < pc->noligos; oo++)
    {
        int best_idx = find_best_idx(pc->cost, index, pc->noligos_db);
        if(0)
        {
        printf("best_idx = %d, pos=%d cost=%f\n",
               best_idx, pc->start[best_idx], pc->cost[best_idx]);
        }
        if(best_idx == -1)
        {
            goto fail;
        }
        update_index(index, best_idx, pc);
    }

    /* Create probe and extract the 1es from the index */
    probe_t * probe = probe_new(pc->noligos);
    size_t oligo_number = 0;
    for(size_t kk = 0; kk<pc->noligos_db; kk++)
    {
        if(index[kk] == 1)
        {
            probe->index[oligo_number++] = kk;
        }
    }

    if(oligo_number != (size_t) pc->noligos)
    {
        printf("oligo_number = %zu\n", oligo_number);
        printf("pc->noligos = %d\n", pc->noligos);
        assert(0);
    }

    free(index);
    probe->comment = strdup("find_probe_simple/best oligo");
    return probe;

fail:
    free(index);
    return NULL;
}

probe_t * find_probe_simple(pconf_t * pc)
{
    if(pc->log)
    {
        fprintf(pc->log, "\n-- using find_probe_simple\n");
    }

    probe_t * P1 = find_probe_simple_uniform(pc);
    if(probe_update_cost(P1, pc))
    {
        fprintf(stderr, "find_probe_simple_uniform return an invalid probe\n");
        probe_free(P1);
        P1 = NULL;
    }

    probe_t * P2 = find_probe_simple_best_oligo(pc);
    if(probe_update_cost(P2, pc))
    {
        fprintf(stderr, "find_probe_simple_best_oligo return an invalid probe\n");
        probe_free(P2);
        P2 = NULL;
    }

    probe_t * P = probe_keep_best(P1, P2);

    return P;

}

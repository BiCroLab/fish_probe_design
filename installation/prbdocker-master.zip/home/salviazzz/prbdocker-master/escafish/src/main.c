#include "escafish.h"

#include "find_probe_greedy.h"
#include "find_probe_opt.h"
#include "find_probe_simple.h"
#include "read_db.h"

pconf_t * pconf_new(void)
{
    pconf_t * pc = calloc(1, sizeof(pconf_t));

    pc->dbfile = NULL;
    pc->noligos_db = 0;
    pc->start = NULL;
    pc->cost = NULL;
    pc->noligos = 20;
    pc->oligolen = -1;
    pc->pair_weight = 0.0001;
    pc->mingap = 5;

    pc->outfile = NULL;
    pc->logfile = NULL;
    pc->log = NULL;
    pc->verbose = 1;
    //pc->oligolen = -1;

    pc->overwrite = 0;
    pc->tail_cost = NULL;
    pc->tail_end = NULL;
    pc->plot = 0;

    return pc;
}

void pconf_free(pconf_t * pc)
{
    free(pc->dbfile);
    free(pc->start);
    free(pc->cost);
    free(pc->logfile);
    free(pc->outfile);
    free(pc->onext);
    if(pc->log != NULL)
    {
        fclose(pc->log);
    }
    free(pc->plotfile);

    free(pc);
}


void probe_to_svg(char * fname, const probe_t * p, const pconf_t * pc)
{

    /* TODO: Seems to crash for large number of oligos, why? */

    /* Set up FOV */
    double x0 = pc->start[p->index[0]];
    double x1 = pc->start[p->index[pc->noligos-1]]+pc->oligolen-1;
    double w = x1-x0;
    x0 -= 1e-3*w;
    x1 += 1e-3*w;
    w = x1-x0;

    probe_info_t * i = probe_get_info(p, pc);

    double width = 1024;
    double height = 128;

    cairo_surface_t *surface =
        cairo_svg_surface_create(fname, width, height);
    assert(surface != NULL);
    cairo_t *cr =
        cairo_create (surface);
    assert(cr != NULL);
    cairo_set_source_rgb (cr, 1.0, 1.0, 1.0); /* white */
    cairo_paint (cr);

    cairo_set_line_width(cr, height/2);
    for(int kk = 0; kk < pc->noligos; kk++)
    {
        int idx = p->index[kk];
        double cost_min = 0.012;
        double cost_max = 0.074;

        // double cost_min = i->cost_min;
        // double cost_max = i->cost_max;
        double rel_cost = (pc->cost[idx] - cost_min)/(cost_max-cost_min);
        rel_cost < 0 ? rel_cost = 0 : 0;
        rel_cost > 1 ? rel_cost = 1 : 0;
        cairo_set_source_rgb (cr, rel_cost, 0.2, 0.2);


        double start = pc->start[idx];
        double end = start + pc->oligolen - 1;

        start = (start-x0)/w*width;
        end = (end-x0)/w*width;

        cairo_move_to(cr, start, height / 2.0);
        cairo_line_to(cr, end, height / 2.0);
        cairo_stroke(cr);
    }

    cairo_surface_write_to_png (surface, "temp.png");
    cairo_surface_finish(surface);
    free(i);
}

void pconf_print(FILE * fid, pconf_t * pc)
{
    if(fid == NULL)
    {
        return;
    }
    fprintf(fid, "\n-- Settings\n");
    fprintf(fid, "CMD: ");
    for(int kk = 0; kk < pc->argc; kk++)
    {
        fprintf(fid, "\"%s\" ", pc->argv[kk]);
    }
    fprintf(fid, "\n");
    fprintf(fid, "dbfile: %s\n", pc->dbfile);
    fprintf(fid, "Oligos per probe: %d\n", pc->noligos);
    // fprintf(fid, "# Oligo length: %d\n", pc->oligolen);
    fprintf(fid, "Mingap: %d\n", pc->mingap);
    fprintf(fid, "Pair coefficient: %.2e\n", pc->pair_weight);
    if(pc->outfile == NULL)
    {
        fprintf(fid, "WARNING: no output file specified please use\n"
                "           '--out file.tsv' to save the result\n");
    } else {
        fprintf(fid, "Output file: %s\n", pc->outfile);
    }
    if(pc->log != NULL)
    {
        fprintf(fid, "Log file: %s\n", pc->logfile);
    }

}

probe_t * probe_new(int n)
{
    probe_t * p = malloc(sizeof(probe_t));
    p->n = n;
    p->index = malloc(n*sizeof(uint32_t));
    p->comment = NULL;
    return p;
}

void probe_free(probe_t * p)
{
    if(p == NULL)
    {
        return;
    }
    free(p->index);
    free(p->comment);
    free(p);
    return;
}

probe_info_t * probe_info_new(void)
{
    probe_info_t * i = calloc(1, sizeof(probe_info_t));
    i->gap_min = 2147483647;
    i->gap_max = 0;
    i->gap_avg = 0;
    i->cost_min = INFINITY;
    i->cost_max = 0;
    i->cost_avg = 0;
    i->cost_oligos = 0;
    i->cost_gaps = 0;

    return i;
}

void probe_info_print(FILE * fid, probe_info_t * i)
{
    fprintf(fid, "Probe size: %d bases\n", i->size);
    fprintf(fid, "Probe cost: %f (oligos: %f, gaps: %f)\n",
            i->cost_oligos + i->cost_gaps, i->cost_oligos, i->cost_gaps);
    if(i->noligos > 1)
    {
    fprintf(fid, "min/avg/max gap size: %d, %.1f, %d\n",
            i->gap_min, i->gap_avg, i->gap_max);
    }
    fprintf(fid, "min/avg/max oligo cost: %.3f, %.3f, %.3f\n",
            i->cost_min, i->cost_avg, i->cost_max);
    fprintf(fid, "method: %s\n", i->method);
}

probe_info_t * probe_get_info(const probe_t * p, const pconf_t * pc)
{
    probe_info_t * i = probe_info_new();
    i->noligos = p->n;
    /* If the region is too small or the pairwise weight was too small
     * it is not always possible to construct an oligo, specifically
     * a next oligo is not always found */
    for(int kk = 0; kk + 1 < p->n; kk++)
    {
        if(p->index[kk] >= p->index[kk+1])
        {
            fprintf(stderr, "ERROR: Invalid probe\n");
            fprintf(stderr, "       %s %s at %d\n",
                    __FILE__, __FUNCTION__, __LINE__);
            return NULL;
        }
    }

    {
        int first = pc->start[p->index[0]];
        int last = pc->start[p->index[pc->noligos-1]] + pc->oligolen-1;
        i->size = last - first + 1;
    }

    /* For single oligos */
    for(int kk = 0; kk < pc->noligos; kk++)
    {
        int P = (int) p->index[kk]; /* Current oligo */
        double c = pc->cost[P];
        c > i->cost_max ? i->cost_max = c : 0 ;
        c < i->cost_min ? i->cost_min = c : 0 ;
        i->cost_avg += c;
        i->cost_oligos += c;
    }
    i->cost_avg /= (double) pc->noligos;

    int ngaps = pc->noligos-1.0;
    if(ngaps == 0)
    {
        i->gap_min = 0;
        i->gap_max = 0;
        i->gap_avg = 0;
    }

    /* For oligo pairs */
    for(int kk = 0; kk+1 < pc->noligos; kk++)
    {
        int P = (int) p->index[kk]; /* Current oligo  */
        int Q = (int) p->index[kk+1]; /* Next oligo */

        int gap = (int) pc->start[Q] -
            ((int) pc->start[P]+(int) pc->oligolen-1) -1;

        if(gap < pc->mingap)
        {
            fprintf(stderr, "ERROR: mindist not respected. This is a bug!\n");
            fprintf(stderr, "Found a gap=%d, while mingap was set to %d\n",
                    gap, pc->mingap);
            exit(EXIT_FAILURE);
        }

        gap > i->gap_max ? i->gap_max = gap : 0;
        gap < i->gap_min ? i->gap_min = gap : 0;
        i->gap_avg += gap;
        i->cost_gaps += oligo_cost_from_pair_index(pc, P, Q);
    }

    if(ngaps > 0)
    {
        i->gap_avg /= (double) ngaps;
    }

    if(p->comment)
    {
        i->method = strdup(p->comment);
    }
    return i;
}


void pconf_probe_print(pconf_t * pc, probe_t * p)
{
    FILE * fout = stdout;
    if(pc->outfile != NULL)
    {
        fout = fopen(pc->outfile, "w");
        if(fout == NULL)
        {
            printf("Error: Unable to open %s for writing\n", pc->outfile);
            exit(EXIT_FAILURE);
        }
    }
    FILE * fid = fopen(pc->dbfile, "r");
    char * line = NULL;
    size_t len = 0;
    int read = getline(&line, &len, fid);
    if(read == EOF)
    {
        printf("ERROR: Reached unexpected EOF while reading %s\n",
               pc->dbfile);
        printf("Empty file?");
        exit(EXIT_FAILURE);
    }
    fprintf(fout, "%s", line);

    int start_row_number = tsv_get_col_number(line,
                           "start");


    for(int kk = 0; kk <p->n; kk++)
    {
        int start = pc->start[p->index[kk]];
        /* row 3 */
        int done = 0;
        do{
            read = getline(&line, &len, fid);
            assert(read != EOF);
            int tstart = -1;
            int ok = tsv_get_int_col(line, start_row_number, &tstart);
            //printf("kk = %d, start = %d, tstart = %d\n", kk, start, tstart);
            if(ok != EXIT_SUCCESS || tstart == -1)
            {
                printf("Unexpected error in print_probe\n");
                exit(EXIT_FAILURE);
            }

            if(tstart == start)
            {
                fprintf(fout, "%s", line);
                done = 1;
            }
        } while (done == 0);
    }
    free(line);
    fclose(fid);
    /* Close the output file if it wasn't stdout */
    if(pc->outfile != NULL)
    {
        fclose(fout);
    }
    return;
}

void show_help(int argc, char ** argv)
{
    pconf_t * pc0 = pconf_new();
    if(argc == 0)
        return;

    printf("Usage:\n");
    printf("%s --db db.tsv --len l --noligos n --out out.tsv [OPTIONS]\n",
           argv[0]);
    printf("Required arguments:\n");
    printf("--db database\n\t"
           "specify tsv file/database to use\n");
    printf("Optional arguments:\n");
    printf("--help\n\t"
           "show this help message\n");
    printf("--mingap\n\t"
           "specify the minimal gap allowed between oligos, "
           "default=%d\n", pc0->mingap);
    printf("--noligos n\n\t"
           "number of oligos per probe\n");
    printf("--out out.tsv\n\t"
           "specify where to write the output,\n\t"
           "uses stdout if not specified\n");
    printf("--pw value\n\t"
           "Set the Pair Weight i.e., specify the weight for \n\t"
           "oligos to close to each other in the least squares sense, default=%.2e\n",
           pc0->pair_weight);
    printf("--plot filename.svg\n\t"
           "Plot the probe to filename.svg\n");
    printf("--overwrite\n\t"
           "Overwrite output file if it already exist\n");
    printf("--verbose l\n\t"
           "set the verbosity level, default=%d\n",
           pc0->verbose);
    printf("--version\n\t"
           " show version (=%s)\n", escafish_version);
    printf("--greedy\n\t"
           "Disable the extact search\n");
    printf("See the man page for more details\n");
    printf("Web page: http://www.github.com/elgw/escafish/\n");
    pconf_free(pc0);
    return;
}
void pconf_argparse(int argc, char ** argv, pconf_t * pc)
{
    pc->argc = argc;
    pc->argv = argv;

    struct option longopts[] = {
        { "db",     required_argument, NULL, 'd' },
        { "greedy", no_argument, NULL, 'g' },
        { "help",   no_argument, NULL, 'h' },
        { "mingap", required_argument, NULL, 'm' },
        { "noligos",required_argument, NULL, 'n' },
        { "out", required_argument, NULL, 'o'},
        { "plot", required_argument, NULL, 'P'},
        { "pw", required_argument, NULL, 'p'},
        { "version", no_argument, NULL, 'V'},
        { "verbose", required_argument, NULL, 'v'},
        { "overwrite", no_argument, NULL, 'w'},
        { NULL, 0, NULL, 0 }
    };
    int ch;

    while((ch = getopt_long(argc, argv, "d:hm::n:p:PVv:wo:", longopts, NULL)) != -1)
    {
        switch(ch) {
        case 'd':
            pc->dbfile = strdup(optarg);
            break;
        case 'g':
            pc->greedy = 1;
            break;
        case 'h':
            show_help(argc, argv);
            exit(EXIT_SUCCESS);
            break;
        case 'n':
            pc->noligos = atoi(optarg);
            break;
        case 'm':
            pc->mingap = atoi(optarg);
            break;
        case 'o':
            pc->outfile = strdup(optarg);
            break;
        case 'p':
            pc->pair_weight = atof(optarg);
            break;
        case 'P':
            pc->plot = 1;
            pc->plotfile = strdup(optarg);
            break;
        case 'V':
            printf("%s version %s\n", argv[0], escafish_version);
            exit(EXIT_SUCCESS);
            break;
        case 'v':
            pc->verbose = atoi(optarg);
            break;
        case 'w':
            pc->overwrite = 1;
            break;
        default:
            exit(EXIT_FAILURE);
        }
    }

    if(pc->noligos < 1)
    {
        fprintf(stderr, "ERROR: --noligos %d is not valid, ask for at least one oligo\n",
                pc->noligos);
        exit(EXIT_FAILURE);
    }

    if(pc->pair_weight < 1e-9)
    {
        fprintf(stderr, "ERROR: --pw value, %e, is too small\n", pc->pair_weight);
        exit(EXIT_FAILURE);

    }

    if(pc->dbfile == NULL)
    {
        fprintf(stderr, "ERROR: DBfile not provided\n");
        show_help(argc, argv);
        exit(EXIT_FAILURE);
    }

    {
        FILE * fid = fopen(pc->dbfile, "r");
        if(fid == NULL)
        {
            fprintf(stderr, "ERROR: Can't open db-file %s\n", pc->dbfile);
            exit(EXIT_FAILURE);
        }
        fclose(fid);
    }

    /* Check that the outfile does not exist */
    if(pc->outfile != NULL && pc->overwrite == 0)
    {
        FILE * fid = fopen(pc->outfile, "r");
        if(fid != NULL)
        {
            fprintf(stderr, "ERROR: '%s' does already exist\n", pc->outfile);
            fprintf(stderr, "       Please delete it and try again\n");
            fprintf(stderr, "       or use the --overwrite flag\n");
            exit(EXIT_FAILURE);
        }
    }
    /* Open the log file */
    if(pc->outfile != NULL)
    {
        pc->logfile = malloc(strlen(pc->outfile)+10);
        sprintf(pc->logfile, "%s.log.txt", pc->outfile);
        pc->log = fopen(pc->logfile, "w");
        if(pc->log == NULL)
        {
            fprintf(stderr, "ERROR: Unable to open %s for writing\n", pc->logfile);
            fprintf(stderr, "       Please check permissions and make sure that the "
                            "disk is not full\n");
            exit(EXIT_FAILURE);
        }
    }
}

/* Cost for a single oligo */
float cost_single_from_index(const pconf_t * pc, int pos)
{
    return pc->cost[pos];
}

/* Cost for a pair, only the pair term */
float oligo_cost_from_pair_index(const pconf_t * pc, int posA, int posB)
{

    if(posA >= posB)
    {
        /* It is the responsibility of the algorithm finding probes to
           make sure that they are sorted */
        printf("ERROR %s The oligos are in the wrong order! This is due to an upstream error\n",
               __FUNCTION__);
        printf("      %s, line %d\n", __FILE__, __LINE__);
        // TODO longjmp
        exit(EXIT_FAILURE);
    }
    int startA = pc->start[posA];
    int startB = pc->start[posB];

    double ideal = pc->oligolen + pc->mingap;
    double actual = startB - startA;
    if(0){
        printf("posA: %d, posB: %d\n", posA, posB);
        printf("dbg: startA: %d startB: %d\n", startA, startB);
        printf("dbg, actual = %f, ideal = %f\n", actual, ideal);
    }
    if(actual<ideal)
    {
        return INFINITY;
    }
    else {
        return pc->pair_weight*pow(ideal - actual, 2);
    }
}


int probe_update_cost(probe_t * probe, pconf_t * pc)
{
    if(probe == NULL)
    {
        return EXIT_FAILURE;
    }

    double cost = 0;
    for(int kk = 0; kk < probe->n ; kk++)
    {
        cost = cost +
            (double) cost_single_from_index(pc, probe->index[kk]);
        // printf("DBG: %s prob->cost = %f\n", probe->comment, cost);
    }

    for(int kk = 0; kk + 1< probe->n ; kk++)
    {
        cost = cost +
            (double) oligo_cost_from_pair_index(pc,
                                                probe->index[kk],
                                                probe->index[kk+1]);
        // printf("DBG: p %s prob->cost = %f\n", probe->comment, cost);
    }
    probe->cost = cost;

    //printf("DBG: %s prob->cost = %f\n", probe->comment, probe->cost);
    if(probe->cost == INFINITY)
    {
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}




/* Return the best probe and free the other
 * returns NULL of both are NULL */
probe_t * probe_keep_best(probe_t * P1, probe_t * P2)
{
    if(P1 == NULL && P2 == NULL)
    {
        return NULL;
    }

    if(P1 == NULL)
    {
        return P2;
    }

    if(P2 == NULL)
    {
        return P1;
    }

    if(P2->cost < P1->cost)
    {
        probe_free(P1);
        return P2;
    } else {
        probe_free(P2);
        return P1;
    }

    return NULL;
}

void probe_info_free(probe_info_t * pi)
{
    free(pi->method);
    free(pi);
    return;
}

int
pconf_read_db(pconf_t * pc)
{
    read_db_config conf = {};
    conf.log = pc->log;
    conf.tsvfile = pc->dbfile;
    conf.verbose = pc->verbose;

    oligodb_t * db = read_db(conf);
    if(db == NULL)
    {
        fprintf(stderr, "escafish: fatal error. Could not read %s\n",
                pc->dbfile);
        return EXIT_FAILURE;
    }
    assert(db->start != NULL);
    pc->start = db->start;
    assert(db->cost != NULL);
    pc->cost = db->cost;
    pc->noligos_db = db->noligos;
    pc->oligolen = db->oligolen;
    pc->onext = calloc(pc->noligos_db, sizeof(float));
    free(db);

    return EXIT_SUCCESS;
}

int main(int argc, char ** argv)
{
    if(argc > 1)
    {
        if(strcmp(argv[1], "apply_blacklist") == 0)
            return(apply_blacklist(argc-1, argv+1));
    }
    /* Set up and parse command line arguments */
    pconf_t * pc = pconf_new();
    pconf_argparse(argc, argv, pc);
    if(pc->verbose > 1)
    {
        pconf_print(stdout, pc);
    }

    if(pc->log)
    {
        fprintf(pc->log, "-- escafish v%s\n", escafish_version);
        show_time(pc->log);
    }

    pconf_print(pc->log, pc);

    /* Run */
    if(pc->verbose > 1)
    {
        printf("Reading %s\n", pc->dbfile);
    }

    if(pconf_read_db(pc))
    {
        return EXIT_FAILURE;
    }

    if((long int) pc->noligos > (long int) pc->noligos_db)
    {
        fprintf(stderr, "ERROR asking for more oligos (%d) than available in the database (%zu)\n",
                pc->noligos, pc->noligos_db);

        return EXIT_FAILURE;
    }

    probe_t * probe = NULL;

    probe_t * P1 = NULL;

    if(!pc->greedy)
    {
        P1 = find_probe_opt(pc);
        if(P1) { assert(P1->comment); }
    }

    probe_t * P2 = find_probe_greedy(pc);
    if(P2) { assert(P2->comment); }
    probe = probe_keep_best(P1, P2);
    probe_t * P3 = find_probe_simple(pc);
    if(P3) { assert(P3->comment); }

    probe = probe_keep_best(probe, P3);
    if(probe) { assert(probe->comment);}
    if(probe == NULL)
    {
        fprintf(stderr, "FAILED to find a probe\n");
        exit(EXIT_FAILURE);
    }

    probe_info_t * i = probe_get_info(probe, pc);
    assert(i->method);
    if(i == NULL)
    {
        fprintf(stderr, "ERROR: Failed to get information about he probe\n");
        fprintf(stderr, "Error occured at File: %s, Line: %d\n",
                __FILE__, __LINE__);
        exit(EXIT_FAILURE);
    }

    if(pc->verbose > 0)
    {
        probe_info_print(stdout, i);
    }
    if(pc->log != NULL)
    {
        fprintf(pc->log, "\n-- Results\n");
        probe_info_print(pc->log, i);
    }
    probe_info_free(i);

    if(pc->verbose > 1)
    {
        printf("Probe index %u -- %u\n",
               probe->index[0], probe->index[pc->noligos-1]);
    }
    pconf_probe_print(pc, probe);


    if(pc->plot)
    {
        printf("Plotting to %s\n", pc->plotfile);
        probe_to_svg(pc->plotfile, probe, pc);
    }

    /* Clean up */
    probe_free(probe);
    size_t peakmem = get_peakMemoryKB();
    if(pc->log != NULL)
    {
        fprintf(pc->log, "Peak memory: %zu kb\n", peakmem);
    }
    if(pc->verbose > 1)
    {
        fprintf(stdout, "Peak memory: %zu kb\n", peakmem);
    }
    pconf_free(pc);

    exit(EXIT_SUCCESS);
}

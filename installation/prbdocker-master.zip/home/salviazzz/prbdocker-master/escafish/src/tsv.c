#include "tsv.h"

int tsv_get_float_col(const char * line, int col, float * value)
{
    char * l = strdup(line);

    char * f = strtok(l, "\t");
    if(f == NULL)
    {
        return EXIT_FAILURE;
    }
    if(col == 0)
    {
        *value = atof(f);
        free(l);
        return EXIT_SUCCESS;
    }
    for(int kk = 0; kk<col; kk++)
    {
        f = strtok(NULL, "\t");
        if(f == NULL)
        {
            return EXIT_FAILURE;
        }
    }
    *value = atof(f);
    free(l);
    return EXIT_SUCCESS;
}

int tsv_get_string_col(const char * line, int col, char * string, int max_len)
{
    char * l = strdup(line);

    char * f = strtok(l, "\t");
    if(f == NULL)
    {
        return EXIT_FAILURE;
    }
    if(col == 0)
    {
        snprintf(string, max_len, "%s", f);
        free(l);
        return EXIT_SUCCESS;
    }
    for(int kk = 0; kk<col; kk++)
    {
        f = strtok(NULL, "\t");
        if(f == NULL)
        {
            return EXIT_FAILURE;
        }
    }
    snprintf(string, max_len, "%s", f);
    free(l);
    return EXIT_SUCCESS;
}


int tsv_get_int_col(const char * line, int col, int * value)
{
    char * l = strdup(line);

    char * f = strtok(l, "\t");
    if(f == NULL)
    {
        free(l);
        return EXIT_FAILURE;
    }
    if(col == 0)
    {
        *value = atoi(f);
        free(l);
        return EXIT_SUCCESS;
    }
    for(int kk = 0; kk<col; kk++)
    {
        f = strtok(NULL, "\t");
        if(f == NULL)
        {
            return EXIT_FAILURE;
        }
    }
    *value = atoi(f);
    free(l);
    return EXIT_SUCCESS;
}


int tsv_get_col_number(const char * line, const char * col_name)
{

    int found_col = -1;
    int nfound = 0;

    if(strlen(line) == 0)
    {
        return -1;
    }

    if(strlen(col_name) == 0)
    {
        return -1;
    }

    int col = 0;
    char * l = strdup(line);
    char * f = strtok(l, "\t");
    if(strcmp(f, col_name) == 0 )
    {
        found_col = col;
        nfound++;
    }

    while( (f=strtok(NULL, "\t")) != NULL)
    {
        col++;
            if(strcmp(f, col_name) == 0)
            {
                found_col = col;
            }
    }
    if(nfound > 1)
    {
        fprintf(stderr, "More than one column named '%s' found\n", col_name);
        exit(EXIT_FAILURE);
    }
    free(l);
    free(f);
    return found_col;
}

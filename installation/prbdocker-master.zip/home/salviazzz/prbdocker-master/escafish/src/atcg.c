#include "atcg.h"


#define NOTNULL(x) {                                            \
        if(x == NULL)                                           \
        {                                                       \
            fprintf(stderr,                                     \
                    "Got unexpected NULL pointer in %s%d\n",    \
                    __FILE__, __LINE__);                        \
            fprintf(stderr,                                     \
                    "This is a bug, please report it!\n");      \
            exit(EXIT_FAILURE);                                 \
        }}                                                      \


iupac_t iupac_symbols[] = {
    // 1-base
    //       A  C  G  T  #   RC
    {0, 'A', 1, 0, 0, 0, 1, 'T'},
    {1, 'C', 0, 1, 0, 0, 1, 'G'},
    {2, 'G', 0, 0, 1, 0, 1, 'C'},
    {3, 'T', 0, 0, 0, 1, 1, 'A'},
    // 2-base
    {4, 'W', 1, 0, 0, 1, 2, 'W'},
    {5, 'S', 0, 1, 1, 0, 2, 'S'},
    {6, 'M', 1, 1, 0, 0, 2, 'K'},
    {7, 'K', 0, 0, 1, 1, 2, 'M'},
    {8, 'R', 1, 0, 1, 0, 2, 'Y'},
    {9, 'Y', 0, 1, 0, 1, 2, 'R'},
    // 3-base
    {10, 'B', 0, 1, 1, 1, 3, 'V'},
    {11, 'D', 1, 0, 1, 1, 3, 'H'},
    {12, 'H', 1, 1, 0, 1, 3, 'D'},
    {13, 'V', 1, 1, 1, 0, 3, 'B'},
    // 4-base
    {14, 'N', 1, 1, 1, 1, 4, 'N'}
};

const int n_iupac_symbols = 15;

static void gen_sym_table_distances(sym_table_t * T);

uint8_t iupac_sym_to_num(char sym)
{
    sym = toupper(sym);
    for(int kk = 0; kk<n_iupac_symbols; kk++)
    {
        if(iupac_symbols[kk].sym == sym)
        {
            return iupac_symbols[kk].num;
        }
    }
    return SUBS_TABLE_INVALID;
}

iupac_t iupac_from_sym(char sym)
{
    sym = toupper(sym);
    for(int kk = 0; kk<n_iupac_symbols; kk++)
    {
        if(iupac_symbols[kk].sym == sym)
        {
            return iupac_symbols[kk];
        }
    }
    assert(0);
    fprintf(stderr, "Could not find a symbol matching '%c'\n", sym);
    exit(EXIT_FAILURE);
    return iupac_symbols[0];
}

char iupac_num_to_sym(uint8_t num)
{
    for(int kk = 0; kk<n_iupac_symbols; kk++)
    {
        if(iupac_symbols[kk].num == num)
        {
            return iupac_symbols[kk].sym;
        }
    }
    return '?';
}

int sym_validate_string(sym_table_t * sym, char * str, size_t len)
{
    for(size_t kk = 0; kk<len; kk++)
    {
        if(sym->num_from_char[(uint8_t) str[kk]] == SUBS_TABLE_INVALID)
        {
            fprintf(stderr, "Invalid character '%c' detected.\n", str[kk]);
            return 0;
        }
    }
    return 1;
}

float iupac_dist(iupac_t a, iupac_t b)
{
    float wa = 1.0 / (float) a.nbase;
    float wb = 1.0 / (float) b.nbase;

    float d =
        a.A*b.A +
        a.C*b.C +
        a.G*b.G +
        a.T*b.T;
    return  1.0 - wa*wb*( (float) d);
}

static void gen_sym_table_distances(sym_table_t * T)
{
    NOTNULL(T);
    float * dist = malloc(16*16*sizeof(float));
    NOTNULL(dist);
    float * dist4 = malloc(4*4*sizeof(float));
    NOTNULL(dist4);

    for(int kk = 0; kk<16*16; kk++)
    {
        dist[kk] = 1;
    }

    int nsymbols =n_iupac_symbols;
    for(int kk = 0; kk<nsymbols; kk++)
    {
        iupac_t a = iupac_symbols[kk];
        for(int ll = kk; ll<nsymbols; ll++)
        {
            iupac_t b = iupac_symbols[ll];
            float d = iupac_dist(a, b);
            //printf("%c vs %c d = %f\n", a.sym, b.sym, d);
            dist[(size_t) (a.num*16 + b.num)] = d;
            dist[(size_t) (b.num*16 + a.num)] = d;
        }
    }

    for(int kk = 0 ; kk<4; kk++)
    {
        iupac_t a = iupac_symbols[kk];
        for(int ll = 0 ; ll<4; ll++)
        {
            iupac_t b = iupac_symbols[ll];
            float d = iupac_dist(a, b);
            dist4[kk*4+ll] = d;
            dist4[ll*4+kk] = d;
        }
    }

    T->dist = dist;
    T->dist4 = dist4;
}

static uint8_t * gen_sym_table_complement()
{
    uint8_t * num_comp = calloc(256, 1);
    NOTNULL(num_comp);
    for(int kk = 0 ; kk<n_iupac_symbols; kk++)
    {
        iupac_t base = iupac_symbols[kk];
        num_comp[(uint8_t) base.sym] = (uint8_t) base.complement;
    }
    return num_comp;
}

void gen_sym_table_num_comp(sym_table_t * T)
{
    T->comp_num_from_num = calloc(256, 1);
    NOTNULL(T->comp_num_from_num);
    memset(T->comp_num_from_num, 127, 256);
    for(int kk = 0; kk<n_iupac_symbols; kk++)
    {
        T->comp_num_from_num[kk] = iupac_sym_to_num(iupac_symbols[kk].complement);
    }
    return;
}

sym_table_t * sym_table_new()
{
    /* Initially all letters are invalid */
    uint8_t * num_from_char = calloc(256, 1);
    NOTNULL(num_from_char);
    uint8_t * num4_from_char = calloc(256, 1);
    NOTNULL(num4_from_char);
    for(int kk = 0 ; kk<256; kk++)
    {
        num_from_char[kk] = SUBS_TABLE_INVALID;
        num4_from_char[kk] = SUBS_TABLE_INVALID;
    }

    int nsymbols = n_iupac_symbols;
    char * valid = calloc(nsymbols, 1);
    NOTNULL(valid);
    for(int kk = 0; kk < nsymbols; kk++)
    {
        valid[kk] = iupac_symbols[kk].sym;
    }
    for(int kk = 0 ; kk < nsymbols; kk++)
    {
        uint8_t sym = (uint8_t) valid[kk];
        uint8_t lsym = tolower((int) sym);
        num_from_char[sym] = kk;
        num_from_char[lsym] = kk;
    }
    free(valid);

    iupac_t iupac_A = iupac_from_sym('A');
    iupac_t iupac_C = iupac_from_sym('C');
    iupac_t iupac_G = iupac_from_sym('G');
    iupac_t iupac_T = iupac_from_sym('T');

    for(int kk = 0; kk < nsymbols; kk++)
    {
        iupac_t sym = iupac_symbols[kk];
        int lsym = tolower(sym.sym);
        if(sym.C)
        {
            num4_from_char[(uint8_t) sym.sym] = iupac_C.num;
            num4_from_char[lsym] = iupac_C.num;
        }
        if(sym.G)
        {
            num4_from_char[(uint8_t) sym.sym] = iupac_G.num;
            num4_from_char[lsym] = iupac_G.num;
        }
        if(sym.T)
        {
            num4_from_char[(uint8_t) sym.sym] = iupac_T.num;
            num4_from_char[lsym] = iupac_T.num;
        }
        if(sym.A)
        {
            num4_from_char[(uint8_t) sym.sym] = iupac_A.num;
            num4_from_char[lsym] = iupac_A.num;
        }
    }

    sym_table_t * T = calloc(1, sizeof(sym_table_t));
    NOTNULL(T);
    T->num_from_char = num_from_char;
    T->num4_from_char = num4_from_char;
    gen_sym_table_distances(T);
    T->comp_char_from_char = gen_sym_table_complement();
    gen_sym_table_num_comp(T);
    assert(T->comp_num_from_num != NULL);
    T->char_from_num = calloc(256, 1);
    NOTNULL(T->char_from_num);
    for(size_t kk = 0; kk<256; kk++)
    {
        T->char_from_num[kk] = '?';
    }
    for(int kk =0 ; kk<15; kk++)
    {
        T->char_from_num[kk] = iupac_symbols[kk].sym;
    }
    assert(T->char_from_num != NULL);
    return T;
}

void sym_table_free(sym_table_t * s)
{
    free(s->num_from_char);
    free(s->dist);
    free(s->dist4);
    free(s->comp_char_from_char);
    free(s->num4_from_char);
    free(s->comp_num_from_num);
    free(s->char_from_num);
    free(s);
}

static void show_color(const uint8_t * seq, const uint8_t * color, int L)
{
    for(int kk = 0; kk<L; kk++)
    {
        char c = map_num_to_char(seq[kk]);
        switch(color[kk])
        {
        case 0:
            printf(ANSI_COLOR_RED);
            break;
        case 1:
            printf(ANSI_COLOR_GREEN);
            break;
        default:
            ;
        }
        printf("%c", c);
        printf(ANSI_COLOR_RESET);
    }
}

char map_num_to_char(const uint8_t c)
{
    switch(c)
    {
    case numA:
        return 'A';
        break;
    case numC:
        return 'C';
        break;
    case numG:
        return 'G';
        break;
    case numT:
        return 'T';
        break;
    default:
        return '?';
        break;
    }
}

void print_seq_color(const uint8_t * S, uint32_t * color, const size_t L)
{
    for(size_t kk = 0; kk<L; kk++)
    {
        if(color[kk] > 0)
            printf(ANSI_COLOR_YELLOW);

        printf("%c", map_num_to_char(S[kk]));

        if(color[kk] > 0)
            printf(ANSI_COLOR_RESET);
    }
    printf("\n");
    return;
}


void fprint_seq(FILE * fid, const uint8_t * S, const size_t L)
{
    for(size_t kk = 0; kk<L; kk++)
    {
        fprintf(fid, "%c", map_num_to_char(S[kk]));
    }
    return;
}

void fprint_seq_char(FILE * fid, const uint8_t * S, const size_t L)
{
    for(size_t kk = 0; kk<L; kk++)
    {
        fprintf(fid, "%c", S[kk]);
    }
    return;
}


void print_seq(const uint8_t * S, const size_t L)
{
    fprint_seq(stdout, S, L);
}

void print_seq_char(const uint8_t * S, const size_t L)
{
    fprint_seq_char(stdout, S, L);
}


#if 0
static uint8_t hamming_distance(const uint8_t * A, const uint8_t * B, const int L)
{
    int d = 0;
    for(int kk = 0; kk<L; kk++)
    {
        if(A[kk] != B[kk])
        {
            d++;
        }
    }
    return d;
}
#endif

float hamming_distance_sym(const uint8_t * A,
                           const uint8_t * B, const int L,
                           sym_table_t * sym)
{
    float distance = 0.0;
    for(int kk = 0; kk<L; kk++)
    {
        size_t idx = 16*A[kk]+B[kk];
        assert(idx < 16*16);
        float d = sym->dist[idx];
        distance += d;

    }
    return distance;
}


void show_match(const uint8_t * A, const uint8_t * B, int L)
{
    uint8_t * mask = calloc(L, 1);
    NOTNULL(mask);
    for(int kk = 0; kk<L; kk++)
    {
        if(A[kk] == B[kk])
        {
            mask[kk] = 1;
        }
    }
    show_color(A, mask, L);
    for(int kk = 0; kk<L; kk++)
    {
        if(mask[kk] == 0)
        {
            printf(" ");
        } else {
            printf("|");
        }
    }
    printf("\n");
    show_color(B, mask, L);
    free(mask);
}

void show_match_records(const uint8_t * A, size_t pos, fasta_records_t * rec,
                        const uint8_t * B, int L, int rc, int colors)
{



    uint8_t * mask = calloc(L, 1);
    NOTNULL(mask);
    for(int kk = 0; kk<L; kk++)
    {
        if(A[kk] == B[kk])
        {
            mask[kk] = 1;
        }
    }

    if(colors)
    {
        show_color(A, mask, L);
    } else {
        print_seq(A, L);
    }

    for(size_t kk = 0; kk<rec->n; kk++)
    {
        if(pos > rec->pos[kk] && pos + L < rec->pos[kk] + rec->len[kk])
        {
            printf(" %s:%zu:%zu", rec->name[kk],
                   pos - rec->pos[kk], pos - rec->pos[kk]+L);
        }
    }
    printf("\n");
    int neq = 0;
    for(int kk = 0; kk<L; kk++)
    {
        if(mask[kk] == 0)
        {
            printf(" ");
        } else {
            printf("|");
            neq++;
        }
    }

    printf(" %d/%d, hd=%d\n", neq, L, L-neq);
    if(colors)
    {
        show_color(B, mask, L);
    } else {
        print_seq(B, L);
    }

    printf(" query");
    if(rc)
    {
        printf(", RC");
    }
    printf("\n");
    free(mask);
}

void fprint_seq_num(FILE * fid, const uint8_t * A, int L, sym_table_t * T)
{
    for(int kk = 0; kk<L; kk++)
    {
        fprintf(fid, "%c", T->char_from_num[A[kk]]);
    }
}

void show_match_records_sym(const uint8_t * A, size_t pos, fasta_records_t * rec,
                            const uint8_t * B, int L, int rc, int colors, sym_table_t * sym)
{
    printf("\n");
    float * mask = calloc(L, sizeof(float));
    NOTNULL(mask);
    for(int kk = 0; kk<L; kk++)
    {
        float w = sym->dist[16*A[kk] + B[kk]];
        mask[kk] = w;
    }

    if(colors)
    {
        // show_color(A, mask, L); // TODO
    } else {
        fprint_seq_num(stdout, A, L, sym);
    }

    for(size_t kk = 0; kk<rec->n; kk++)
    {
        if(pos > rec->pos[kk] && pos + L < rec->pos[kk] + rec->len[kk])
        {
            printf(" %s:%zu:%zu", rec->name[kk],
                   pos - rec->pos[kk], pos - rec->pos[kk]+L);
        }
    }
    printf("\n");

    for(int kk = 0; kk<L; kk++)
    {
        if(mask[kk] == 0)
        {
            printf("|");
        } else if(mask[kk] == 1){
            printf(" ");
        } else {
            printf(".");
        }
    }
    float fuzzy_hamming = hamming_distance_sym(A, B, L, sym);
    printf(" fHD=%.2f, match=%.0f%%\n", fuzzy_hamming,
           100.0*((float) L - fuzzy_hamming)/(float) L);
    if(colors)
    {
        // show_color(B, mask, L); TODO
    } else {
        fprint_seq_num(stdout, B, L, sym);
    }

    printf(" query");
    if(rc)
    {
        printf(", RC");
    }
    printf("\n");
    free(mask);
}




void reverse_complement(uint8_t * restrict R,
                        const uint8_t * restrict S, const int L)
{

    // Reverse
    for(int kk = 0; kk<L; kk++)
    {
        R[kk] = S[L-kk-1];
    }
    // Complement
    for(int kk = 0; kk<L; kk++)
    {
        R[kk] = 3 - R[kk];
    }
    return;
}




void to_digital(uint8_t * restrict y, const char * restrict x, const size_t n)
{
    for(size_t kk=0; kk<n; kk++)
    {
        //    printf("%c=%u ", x[kk], (uint8_t) x[kk]); fflush(stdout);
        y[kk] = map_char_to_val(x[kk]);
    }
    //  printf("\n");
    return;
}

uint8_t map_char_to_val(const char c)
{
    switch(c) {
    case 'a':
        return numA;
        break;
    case 'A':
        return numA;
        break;
    case 'c':
        return numC;
        break;
    case 'C':
        return numC;
        break;
    case 'g':
        return numG;
        break;
    case 'G':
        return numG;
        break;
    case 't':
        return numT;
        break;
    case 'T':
        return numT;
        break;
    default:
        /* invalid letter */
        assert(0);
        return 255;
    }
}

void sym_table_show(sym_table_t * S)
{
    printf("-- Accepted symbols (full)\n");
    for(int kk = 0; kk<256; kk++)
    {
        if(S->num_from_char[kk] != SUBS_TABLE_INVALID)
        {
            printf("%c", (char) kk);
        }
    }
    printf("\n");
    printf("-- Accepted symbols (4-base)\n");
    for(int kk = 0; kk<256; kk++)
    {
        if(S->num4_from_char[kk] != SUBS_TABLE_INVALID)
        {
            printf("%c", (char) kk);
        }
    }
    printf("\n");


    printf("-- Probability weighted Hamming distances\n");
    printf("    ");
    for(int kk = 0; kk<n_iupac_symbols; kk++)
    {
        printf("   %c  ", iupac_symbols[kk].sym);
    }
    printf("\n");
    for(int kk = 0; kk<n_iupac_symbols; kk++)
    {
        uint8_t sA = iupac_symbols[kk].num;
        for(int ll = 0; ll<n_iupac_symbols; ll++)
        {
            uint8_t sB = iupac_symbols[ll].num;
            if(ll == 0)
            {
                printf(" %c ", iupac_symbols[kk].sym);
            }
            printf(" %.2f ", S->dist[16*sA + sB]);
            assert(fabs(S->dist[16*sA + sB] - S->dist[16*sB + sA]) < 1e-6);
        }
        printf("\n");
    }
    printf("dist4:\n");
    printf("    ");
    for(int kk = 0; kk<4; kk++)
    {
        printf("   %c  ", iupac_symbols[kk].sym);
    }
    printf("\n");
    for(int kk = 0; kk<4; kk++)
    {
        uint8_t sA = iupac_symbols[kk].num;
        for(int ll = 0; ll<4; ll++)
        {
            uint8_t sB = iupac_symbols[ll].num;
            if(ll == 0)
            {
                printf(" %c ", iupac_symbols[kk].sym);
            }
            float d = S->dist4[4*sA + sB];
            printf(" %.2f ", d);

            assert(fabs(S->dist4[4*sA + sB] - S->dist4[4*sB + sA]) < 1e-6);
        }
        printf("\n");
    }


    printf("-- Translation table (full)\n");
    int col = 0;
    for(int kk = 0 ; kk<127; kk++)
    {
        if(S->num_from_char[kk] != SUBS_TABLE_INVALID && S->num_from_char[kk] != kk)
        {
            printf("%c -> %2d", kk, S->num_from_char[kk]);

            if(col == 4)
            {
                printf("\n");
                col = 0;
            } else {
                printf("  ");
                col++;
            }
        }
    }

    printf("-- Translation table (4-base)\n");
    col = 0;
    for(int kk = 0 ; kk<127; kk++)
    {
        if(S->num4_from_char[kk] != SUBS_TABLE_INVALID && S->num4_from_char[kk] != kk)
        {
            printf("%c -> %2d", kk, S->num4_from_char[kk]);

            if(col == 4)
            {
                printf("\n");
                col = 0;
            } else {
                printf("  ");
                col++;
            }
        }
    }
    printf("\n");

    if(S->comp_char_from_char != 0)
    {
        printf("-- Complementary bases:\n");
        int col = 0;
        for(int kk = 0; kk<256; kk++)
        {
            if(S->comp_char_from_char[kk] != 0)
            {
                char ckk = (char) S->comp_char_from_char[kk];
                char cckk = (char) S->comp_char_from_char[(uint8_t) ckk];
                printf("%c -> %c -> %c", (char) kk,
                       ckk, cckk);

                assert(S->comp_char_from_char[S->comp_char_from_char[kk]] == kk);
                if(col == 4)
                {
                    printf("\n");
                    col = 0;
                } else {
                    printf("  ");
                    col++;
                }
            }
        }
    }
    printf("\n");
}

int atcg_ut()
{

    printf("-> sym_table_new_full()\n");
    sym_table_t * S = sym_table_new();
    sym_table_show(S);
    sym_table_free(S);

    return EXIT_SUCCESS;
}


char * sym_reverse_complement(char * S, int L, sym_table_t * sym)
{
    char * R = malloc(L);
    NOTNULL(R);
    //printf("Input  : %.*s\n", L, S);
    // Reverse
    for(int kk = 0; kk<L; kk++)
    {
        R[kk] = S[L-kk-1];
    }
    //printf("Reverse: %.*s\n", L, R);
    // Complement
    for(int kk = 0; kk<L; kk++)
    {
        R[kk] = sym->comp_num_from_num[(uint8_t) R[kk]];
    }
    //printf("Complem: %.*s\n", L, R);
    return R;
}


void sym_replace_str(char * S, int L, sym_table_t * sym)
{
    for(int kk = 0; kk<L; kk++)
    {
        S[kk] = (char) sym->num_from_char[(uint8_t) S[kk]];
    }
}

#ifndef __tsv_h__
#define __tsv_h__

#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

/* Version 1, 2023-03-28 */

/* Get row numbers from the header line of a tsv file
*/
int tsv_get_col_number(const char * line,
                       const char * row_name);


/* Functions to get data out of a single row
* these functions return EXIT_SUCCESS or EXIT_FAILURE
*/

int tsv_get_float_col(const char * line,
                      int row, float * value);

int tsv_get_int_col(const char * line,
                    int row, int * value);

/* Write at most max_len characters to str, i.e. max_len should be smaller
 * than the size of the allocation */
int tsv_get_string_col(const char * line,
                       int row, char * str, int max_len);

#endif

/* For reading fasta-files
 * Version 0.0.1 2023-04-13 (buddy with atcg.h)
 */

/* Usage:
 * Reads all records of a fasta file (.fa) into a continuous piece of memory
 *
 */

#ifndef __readfa_h__
#define __readfa_h__

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include "atcg.h"

/* Structure for the names of the structures in the
 * the fasta file */

typedef struct _fasta_records_t {
    /* Array of all record names */
    char ** name;
    /* Length of each record */
    size_t * len;
    /* Start position in the genome */
    size_t * pos;
    /* Number of records */
    size_t n;
    /* Number of records allocated */
    size_t nalloc;
} fasta_records_t;

typedef struct {
    /* Genomic data converted to numeric representation */
    uint8_t * data;
    /* Number of basepairs */
    size_t data_size;
    fasta_records_t * records;
} fasta_data_t;

/* Defined in atcg.h */
struct sym_table;
typedef struct sym_table sym_table_t;


/* Read a fasta file.  If fourbase is set all symbols are converted to
 * ACGT.  The sym_table_t is defined in atcg.h and contains a Lookup
 * table for Nucleic Acid Codes. The non-unique are mapped to a single
 * alternative For example N is mapped to A but could be mapped to T,
 * C or G. M is mapped to A (or could be to C) ...  Unknown letters
 * are left untouched
 */

fasta_data_t * readfa_sym(const char * fname,
                          sym_table_t * T,
                          int fourbase,
                          int verbose);


/* Simpler interface with no substitution
   Read fa and return *gsize bytes.
 *fr will be set. */
uint8_t * readfa(const char * fname,
                 size_t * gsize, fasta_records_t ** fr);


void fasta_data_free(fasta_data_t * fa);



/* Read fasta file and return *gsize bytes */
uint8_t * readfa_basic(const char * fname, size_t * gsize);

/* Print the content of fr in tab delimited format.
 * suitable for direct writing to a tsv file */
void fasta_records_fprint(FILE * fid, fasta_records_t * fr);

/* free */
void fasta_records_free(fasta_records_t ** _fr);

void fasta_data_free(fasta_data_t * fa);

/* Remove at most one instance of '\n' at the end of a string.
 * i.e., convert 'ATC\n\0' -> 'ATC\0\0' and return the new length.
 * Used when parsing fasta files
 */
int char_trimnewline(char * S, int N);

void readfa_ut(int argc, char ** argv);
#endif

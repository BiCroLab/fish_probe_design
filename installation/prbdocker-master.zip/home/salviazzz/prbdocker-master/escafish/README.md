# FISH probe design with escafish

**escafish** is used to design Fluorescent In-Situ Hybridization
(FISH) probes from a set of candidate oligos. With some terminology we
can formulate it as an optimization problem. An **oligo** is a short
genomic sequence, for example **TCATCTATGAAAACAATCAGTGAACTC** and a
**probe** an ordered set of multiple oligos that are close to each
other on the linear genome but not overlapping. The input **database**
typically consists of a large number of candidate oligos, which are
allowed to be overlapping, on one chromosome.

Ideally we would like to minimize a penalty (or error) function of the form
<img src="https://render.githubusercontent.com/render/math?math=E=\sum_{i=1}^{n}f(o_i)%2B\sum_{i=2}^{n}g(o_i, o_{i-1})">

where
 - **n** is the number of oligos per probe,
 - **o** denotes a single oligo
 - **f** determines the cost for including a single oligo.
 - **g** is the additional cost of linking two oligos together and has the form
 <img src="https://render.githubusercontent.com/render/math?math=g(o_i, o_j) = wd(o_i, o_j)^2">

where **w** is a weigh factor and **d** is the linear distance between the oligos
i.e. the difference between the end position of the first oligo and the start
position of the second oligo.

Doing this we take into account the goodness/badness of each oligo and also
indicate how important it is that the probe is small by tuning the **c**
parameter.

Here is an illustration of an probe with six oligos (in practice there
would be more). The short horizontal lines represent oligos in the
database while the thick black lines are the oligos selected as the
probe. The green arrows indicate how oligos are connected to form the
probe. See the see the [full documentation](doc/manual/escafish.pdf).


![probe](doc/figures/probe.png)

## Algorithm
**escafish** contains two algorithms to minimize the cost function
described shortly above.

 1. A heuristic algorithm, being ultra fast and memory efficient. This
    is the default for the moment.

 2. An optimal algorithm, that find the global minimum of the cost
    function. This is enabled by the **--opt** command line argument
    and will be the default once it is more polished and tested.

For the details, see the [full documentation](doc/manual/escafish.pdf).

## Installation
On Ubuntu:

``` bash
apt-get install libcairo-dev # if not already installed
sudo make install
```
remove by

``` bash
sudo make uninstall
```

## Example usage
For help:
``` bash
escafish --help # list of command line arguments
man escafish    # actual usage guidelines
```

To run with the supplied test data, first we need to assign a cost to
each oligo. The script **escafish_score.py** provides one suggestion
for this. Please modify it to fit your taste.


``` bash
cd testdata
cat db.roi_1.GC35to85_Reference.tsv | ../utils/escafish_score.py gg_nhush > scored_gg_nhush.tsv
```

To find a probe with 4 oligos, this is enough

``` bash
escafish --db scored_gg_nhush.tsv --noligos 4
```

for saving the results to a file, plotting, other parameters etc, see
the [man page](doc/man-page/escafish.txt).


## Things to do
In priority order:

- [ ] Validation and improved documentation.
- [ ] Make it run on MacOS as well.
- [ ] Multiple probes in the same region. Could be done the greedy way,
  i.e. after extracting each probe, all oligos in that region are
  black-listed.
- [ ] Ignore blank lines and lines starting with a comment character
       (what would that be?)
-[ ] [https://build.opensuse.org/] for this and everything else?

## Will not happen

- The algoritm(s) are single core. Have a look at [GNU
  Parallel](https://www.gnu.org/software/parallel/) to use all your
  cores.

See the [CHANGELOG](CHANGELOG.md) for what has been done.

#!/bin/bash

mkdir -p -m 770 data/candidates data/melt data/secs data/db data/db_tsv data/logfiles HUSH
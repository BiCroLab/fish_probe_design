# FISH-QC

Verification of FISH probe specificity.

## Purpose and limitations

Given a Fluorescent In-Sity Hybridization (FISH) probe consisting of
multiple oligos, **fish-qc** tells how specific the probe is and
reveals if and where the off-targets accumulate.

This tool will not miss any alignment, since it use brute force, and
every position in the reference genome will be considered as a hit,
although the importance of off-targets vanish quickly according to the
$`A_{bp}`$ statistic which is described further down.

Limitations:
- **Low throughput** -- use other tools for initial probe
design. **fish-qc** can scan about 3600 oligos per hour on a 8-core
AMD 3700X. On a Raspberry pi 5, the processing speed was about 600
oligos per hour. The RAM usage is less than 2 GB on the T2T reference
genome.
- **Insertions and deletions** (indels) are not considered -- extra
  checks might be required for long oligos.
- **basic alphabet** -- only handle the symbols A, T, C and G.
- **not complete QC** -- secondary structures, termodynamic
  properties, etc has be to checked using other software [^1]. It
  might also make sense to check that the probe does not cross TAD
  boundaries etc.

## Output

An $`A_{bp}`$ profile will be generated for each oligo in the
probe. The most basic analysis is to simply average and then plot the
profiles, which will reveal the signal (value in the designated
region) over noise (highest value outside of the designated region).

Below is an example from a probe consisting of 5996 oligos of length
25 -- 35 distribute on the T2T genome. The probe was designed for Chr
17 and the scanning was done with bin size 50,000 bp using
$`\beta=4`$. In the screenshot the average of the tracks is plotted.

![example result](doc/screenshot001.png)

In this case it could be concluded that the probe works as intended as
the SNR is close to 1000.

## Accumulated binding probability

The accumulated binding probability, $`A_{bp}`$, as used on the y-axis
in the plots above, is a concept that was introduced in
[nHUSH](https://github.com/elgw/nHUSH/) to summarize all full and
partial alignments of an oligo with respect to a genome into a single
statistic (floating point value).  **fish-qc** calculates $`A_{bp}`$
with higher granularity, i.e. breaks it down into bins of variable
size.

An oligo $`s`$ is represented by a continuous stretch of DNA with
length $`|s|`$, e.g., if $s$='GTCAGTAAGT' then $|s|$=10. An oligo is
_specific_ (to a designated position in the genome) if it binds at
that position with high probability and anywhere else with a very low
probability.

How well an oligo binds somewhere on the genome is a complicated
question, which depends on biochemical properties of DNA and
experimental conditions. Here we take a practical approach to
approximate this binding probability so that it can be computed
efficiently.

The Hamming distance between two oligos of the same length, $`d(p,
q)`$ measures how many base pairs that are dissimilar:

``` math
d(p, q) = \sum_{i=1}^{i=|p|} p(i) \neq q(i)
```

If an oligo $`s`$ is equivalent to a stretch of DNA starting at index
$`t`$ in a reference genome then, by definition, it binds perfect
there, i.e. the binding probability is $`1`$. An oligo $`s`$ could
bind also to other positions on the genome, if we only care about the
Hamming distance at those location, what is the best proxy for binding
probability?

We simply define the accumulated binding probability for a sequence
$`s`$ versus a genome $`G`$ as

``` math
A_{pb}(s) = \mbox{forward}\, A_{pb}(s) + \mbox{backward}\, A_{pb}(s)
```

where,

``` math
\mbox{forward}\, A_{bp}(s) = \sum_{i=1}^{|G|-|s|+1} \beta^{-d(s, G(i)}
```

and, where $`\hat{s}`$ denotes the reverse complement of $`s`$,

``` math
\mbox{backward}\, A_{bp}(\hat{s}) = \sum_{i=1}^{|G|-|\hat{s}|+1} \beta^{-d(\hat{s}, G(i)}
```

The parameter $`\beta`$ determines how fast the binding probability
drops with an increasing Hamming distance. At the moment we use
$`\beta=4`$ by default (you can change it with the **\--beta**
parameter). If you believe that any other value is better.

## Usage
Typical usage with default settings could be:

``` shell
fish-qc \
    --genome GCF_009914755.1_T2T-CHM13v2.0_genomic.fna \
    --query sequences.fa \
    --outdir sequences_qc
```

Which will scan all oligos in `sequences.fa` against the reference
genome. All results will be saved in the folder `sequences_qc`, which
will be created.

When the scan is done, it is up to you to make sense of it, for plotting, try

``` shell
fish-qc-plot.py --data sequences_qc
```

which will generate an image like in the screenshot above. The script
can be found in the `scripts/` folder.

For more details, use the **--help** argument or check the [man
page](doc/fish-qc.txt).

## Installation

Build from the source code:

``` shell
# Ubuntu 22.04
sudo apt-get install libcjson-dev
make
```

Then to install, either create a deb file

``` shell
# To install
./makedeb-ubuntu_2204
sudo apt-get install ./fish-qc_X.Y.Z_amd64.deb
```

or just place the binary and the man page wherever it suits you
(possibly with `sudo make install`).

### Files and file formats
Each output folder will have a `records.json` which specifies how to
interpret the binary data, in version 0.1.0 it looks something like:

``` json
{
	"genome":	"/path/to/GCF_009914755.1_T2T-CHM13v2.0_genomic.fna",
	"bin_size":	50000,
	"records":	[{
			"name":	"NC_060925.1 Homo sapiens isolate CHM13 chromosome 1, alternate assembly T2T-CHM13v2.0",
			"first_pos":	0,
			"last_pos":	248387247,
			"first_bin":	0,
			"last_bin":	4967
...
        	}],
	"cmd":	"./fish-qc --genome /path/to/GCF_009914755.1_T2T-CHM13v2.0_genomic.fna --query sequences.fa --outdir sequences_qc"
}
```

This file is read by the `plot_hist.py` script.


## Implementation details

The genome is read and represented in a compact form with 2 base pairs
(bp) per byte. This enables fast calculations of Hamming distances
using hardware instructions (`popcount` on x86_64), with up to 16
basepairs per instruction.

In order for this to work, only the basic alphabet is supported,
i.e. only A, T, C and G. The program will complain if the reference
genome, or the query sequence contain any other values.

Open MP is used to parallelize the code which implies that some of the
behavior can be controlled from command line. The most useful option
is to specify the number of threads to use (the default is typically
one per core):

``` shell
OMP_NUM_THREADS=2 fish-qc ...
```

Please note that it is often a bad idea to use more threads than
physical cores.

## References
[^1]:
    [ggirelli/oligo-melting](https://github.com/ggirelli/oligo-melting)
    for melting temperature calculation of oligonucleotides
    hybridization and secondary structures.

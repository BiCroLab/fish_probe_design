## 2023-12-12, v 0.1.3
- Handles windows line endings `\r\n` in query files.
- Allowing 'n' and 'N' in the reference genome. These will not match
  anything (they should match 1/4 with A, T, C and G).

## 2023-12-08, v 0.1.2

- Added the **\--beta** command line argument.
- Added `example/`

## 2023-12-07, v 0.1.1
- Added a man page.
- Added an example script to plot the output.

## 2023-12-06, v 0.1.0
- Hello world version. Worked on one computer with one dataset.
- It is still not perfectly clear if this tool will be useful and how
  it should be used.

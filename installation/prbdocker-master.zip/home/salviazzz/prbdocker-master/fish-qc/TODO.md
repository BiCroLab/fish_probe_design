## To do:

- Integrate plotting to produce a report without any auxiliary
    scripts. Options:
    - [https://github.com/sciapp/gr], [https://gr-framework.org/c.html]
    - Just pipe to gnuplot.
    - Use libcariro

- Update the plotting script
 - Some options, especially the target region.
 - Don't hard code the number of records!

- Produce a bigger variety of quality metrics, distribution of
  lengths, melting temperature etc.

- Suggest if removal of oligos increase the SNR, that requres
  awareness of the target region?

- Refuse to write to existing **--outdir** unless it contains a
  **records.json** with matching genome file and bin size.
- Use the same tsv reader as escafish.

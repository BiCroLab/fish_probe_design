#!/bin/env python

# TODO:
# Add a bottle/http interface for interactive explorations

def find_common_prefix(strs):
    """ Find a common prefix in a list of strings
    """
    prefix = strs[0]
    for s in strs:
        n = min(len(prefix), len(s))
        neq = 0
        while (neq < n) and (prefix[neq] == s[neq]):
            neq = neq + 1;
        if neq == 0:
            return ''
        prefix = prefix[0:neq]
    return prefix


def find_common_postfix(strs):
    """ Find a commin postfix in a list of strings """
    postfix = strs[0]
    for s in strs:
        n = min(len(postfix), len(s))
        neq = 0
        while (neq < n) and (postfix[-neq-1] == s[-neq-1]):
            neq = neq + 1;
        if neq == 0:
            return ''
        postfix = postfix[-neq:]
    return postfix

def guess_chromosome(name):
    """ Guess chromosome name based on T2T record name

    Uses the regexp 'ome (..?),'
    and returns a short name like 'chr 11' on success.

    returns name unmodified if it does not match the regexp

    """
    match = re.search('ome (..?),', name)
    if not match:
        return name

    return "chr " + match.groups()[0] #name[match.span()[0]+4:match.span()[1]-1]

def get_metadata(filename):
    """ Figure out the name of the metadata file associated to
    filename, which is either a f32 file or a folder name.
    Loads the json metadata dn returns it.
    """

    if os.path.isdir(filename):
        metafile = os.path.join(filename, 'records.json')
        print(f"dirname: {filename} metafile: {metafile}")
    else:
        metafile = os.path.join(os.path.split(filename)[0], "records.json");
        print(f"filename: {filename} metafile: {metafile}")


    with open(metafile, "r") as fid:
        mdata = json.load(fid)

    names = []
    for rec in mdata['records']:
        names.append(rec['name'])

    # prefix = find_common_prefix(names)
    # print(f"prefix: {prefix}")
    # postfix = find_common_postfix(names)
    # print(f"postfix: {postfix}")

    for rec in mdata['records']:
        rec['name'] = guess_chromosome(rec['name'])
        # rec['name'] = rec['name'][len(prefix):-len(postfix)]

    return mdata



def plot_linear(data, metadata, noligo=1):
    y0 = np.min(data)
    y1 = np.max(data)
    d = y1-y0;
    y0 = y0 - 1e-2*d;
    y1 = y1 + 1e-2*d;

    for rec in metadata['records']:
        x = rec['first_bin'] - 0.5
        plt.plot([x, x], [y0, y1], 'k--')


    print(data.shape)
    plt.title(filename)
    plt.xlabel('Bin id')
    plt.ylabel('Abp')
    plt.step(np.arange(len(data))-0.5, data)
    plt.show()


def plot_per_record_plotly(data, metadata, noligo=1):
    from plotly.subplots import make_subplots
    import plotly.graph_objects as go
    import plotly.express as px

    bs = metadata['bin_size']
    max_data = max(data)

    data = data/max_data

    fig = make_subplots(
        rows=5, cols=5)
        # layout_yaxis_range=[1e-8, 1.0])
    row = 1
    col = 1
    for rec in metadata['records']:
        first = rec['first_bin']
        last = rec['last_bin']
        subdata = data[first:last]
        fig.add_trace(go.Scatter(
            x=np.linspace(0, len(subdata)*bs, len(subdata)),
            y=subdata, line=dict(color="#000000"), name=rec['name']),
                      row=row, col=col)

        fig.update_yaxes({'type': 'log',
                          'range': [math.log10(1e-9), math.log10(1.0)],
                          'showexponent': 'all',
                          'exponentformat': 'e'})

        col = col + 1
        if(col > 5):
            col = 1
            row = row + 1


    ttext = cli_args.data[0]
    if noligo > 1:
        ttext = cli_args.data[0] + f"n={noligo}"

    fig.update_layout(title_text=ttext)

    fig.show()

def plot_per_record(data, metadata, noligo=1):
    # breakpoint()
    min_ylim = cli_args.minabp[0]
    bs = metadata['bin_size']
    max_data = max(data)

    data = data/max_data

    nrow = 5
    ncol = 5
    # TODO: subplot
    rec_id = 1
    for rec in metadata['records']:
        ax = plt.subplot(nrow, ncol, rec_id)
        first = rec['first_bin']
        last = rec['last_bin']
        subdata = data[first:last]
        plt.title(rec['name'])
        # plt.xlabel('record position')
        plt.plot([0, len(subdata)*bs], [0.01, 0.01], 'r--')

        if rec_id == 1:
            plt.ylabel('Abp')

        if rec_id == len(metadata['records']):
            plt.xlabel('position')

        plt.yscale('log')

        plt.ylim(min_ylim, 1)
        ax.step(np.arange(len(subdata))*bs, subdata)

        rec_id = rec_id + 1

    # plt.tight_layout()
    if noligo > 1:
        plt.suptitle(cli_args.data[0] + f"n={noligo}")
    else:
        plt.suptitle(cli_args.data[0])

    plt.show()


def get_SNR(fdata):
    """Return the SNR value for a hit track.

    We define it as the number of hits in the most populated bin vs
    the second most populated bin

    """
    k = 2
    top = np.sort(np.argpartition(fdata, len(fdata) - k)[-k:])
    # breakpoint()
    top_values = np.sort( [fdata[top[0]], fdata[top[1]]] )
    SNR = top_values[1] /top_values[0]
    # print(f"{fdata[top[1]]} / {fdata[top[0]]} = {SNR}")
    return SNR


def plot_file(metadata, filename):
    """ Plot a single .f32 file """
    data = np.fromfile(filename, np.dtype('float32'))
    # plot_linear(data, metadata)
    print(f"SNR = {get_SNR(data)}")
    plot_per_record_plotly(data, metadata)
    #plot_per_record(data, metadata)

def seq_from_file(filename):
    """ parse sequence from .f32 file name"""
    match = re.search('/?([ATCG]+)_', filename)
    if not match:
        return filename

    return match.groups()[0]


def plot_folder(metadata, folder):
    """ Plot all .f32 files in a folder

    Note that we can't really give an SNR for the whole probe
    since the script is unaware of the target region.
    """
    files = glob.glob(folder + "*.f32")
    # breakpoint()

    data = [];
    print(f"Loading {len(files)} results")
    datasets = [];
    for fname in files:
        fdata = np.fromfile(fname, np.dtype('float32'))
        if len(fdata) == 0:
            print(f"got no data from {fname}")
            exit(1)
        SNR=get_SNR(fdata)
        Abp=np.sum(fdata)

        special = np.sum(fdata[(58023+105):(58023+146)])

        # 0.5->5822 special = np.max(fdata[(58023+105):(58023+146)])
        #if special > 0.5:
        #    continue

        datasets.append({'file': fname,
                         'snr': SNR,
                         'Abp': Abp ,
                         'special': special})

        #print(f"{fname} SNR={SNR}")
        if len(data) == 0:
            data = fdata
        else:
            data = data + fdata

    datasets = sorted(datasets, key=lambda d: d['snr'])
    #for d in datasets:
    #    if d['snr'] < 100:
    #        print(f"{d['file']} snr: {d['snr']}")
    # plot_linear(data, metadata)

    if cli_args.out_table:
        with open(cli_args.out_table[0], "w") as fid:
            fid.write("seq, Abp, SNR\n")
            for d in datasets:
                fid.write(f'{seq_from_file(d["file"])}, {d["Abp"]}, {d["snr"]}\n')

    # Check that the special region is correct
    # data[(58023+105):(58023+145)] = len(datasets)
    plot_per_record_plotly(data, metadata, noligo=len(datasets))

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Summarize the data from fish-qc.')
    parser.add_argument('--minabp', nargs=1, type=float, default=[1e-5],
                        help='Specify the min value of the y-axis in the plots')
    parser.add_argument('--data', nargs=1,
                        help='Specify file or folder to load', required=True)
    parser.add_argument('--out-table', nargs=1,
                        help='Write a summary to this file', required=False)
    parser.add_argument('--no-plot', action='store_true',
                        help="Don't plot anything", required=False)

    cli_args = parser.parse_args()


    import numpy as np
    import matplotlib.pyplot as plt
    import sys
    import os
    import json
    import re
    import glob
    import math

    filename = cli_args.data[0]

    metadata = get_metadata(filename)

    if os.path.isdir(filename):
        plot_folder(metadata, filename)
    else:
        plot_file(metadata, filename)

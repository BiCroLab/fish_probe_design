% FISH-QC(1) version ABCDE
% Erik Wernersson
% 2023

# NAME
**fish-qc** Quality Control for FISH probes.

# SYNOPSIS

**fish-qc** [\--version] [\--help] [\--verbose \<v\>] [\--self-test]
[\--beta \<b\>] [\--genome \<file\>] [--query \<file\>] [--outdir \<dir\>] [\--binsize \<bs\>]

# DESCRIPTION
**fish-qc** can be used to brute force scan oligos agains a reference
genome and eventually produce a quality report for a FISH probe.

# OPTIONS

**\--genome genome.fa**
: Specify the fasta file containing the reference genome.

**\--query probe.fa**
: Specify the fasta file with oligos to test. Can't be combined with
  **\--string**.

**\--outdir folder_name**
: Specify the name of a folder to be created to store the results.

**\--string ATAG...**
: Just query one oligo and then quit. Can't be combined with **\--query**.

**\--binsize n**
: Set the size of the bins in basepairs. Default could be 50,000 bp,
  specify it yourself to be sure. This does only affect how the
  results are binned together, i.e. all hits should be found
  regardless of the bin size. Obviously the bin size has to be at
  least 1.

**\--beta b**
: Set the beta value that determines how alignments are accumulated. Default 4.

**\--verbose v**
: Specify the verbosity level. Default = 1. Quiet = 0.

**\--version**
: Show version information and quit.

**\--self-test**
: Perform some self testing.

**\--help**
: Show a short help message and quit.

# Input files
The oligos in the query file, or after **\--string** are only allowed
to contain the letters 'a', 'A', 't', 'T', 'c', 'C', 'g', 'G',
i.e. not 'n' or 'N'. The program does not make any distinction between
upper case and lower case.

The reference genome is allowed to contain 'n' and 'N' which will be
ignored in all queries. I.e. the Hamming distance, $d('N', L)=0$ for any
genomic letter L.

The parser for the **\--query** file will treat each line as a query
string unless it starts with a '>'. It does not support oligos that
are broken into multiple lines.

No bin will contain matches from more than one chromosome since each
record in the reference genome will be started at a bin boundary.

# Output files
All output files will be placed in the **\--outdir** folder. Hence the
following command

``` shell
$ fish-qc --outdir roi_12 --genome ...
```
will produce the following files
``` shell
└── roi_12
    ├── AAAAACAAAAAGTGAGCTGAGTGTGATGGCAAGCATGTGC_50000.f32
    ├── AAAAACACAATCATAAACCAGTCAAGATTCAAGGGGTGAA_50000.f32
...
    └── records.json
```

with one `.f32` file per sequence in the **\--query** file. The `.f32`
files are 32-bit floating point numbers, written in machine format,
hence they are not portable across machines with different
endianness. In this case the part `_50000` indicates that the bin size
was 50 kbp. The `records.json` file contains meta data to map genomic
coordinates to bins.

For ideas of how to use the output files see `scripts/fish-qc-plot.py`.

# PERFORMANCE

Expect a throughput of about 1 oligo per second on a 8-core AMD 3700X
using 8 threads. The RAM memory usage should be around 0.5x of the
reference genome.

## Number of threads

Open MP is used to parallelize the code which implies that some of the
behavior can be controlled from command line. The most useful option
is to specify the number of threads to use (the default is typically
one per core):

``` shell
$ OMP_NUM_THREADS=2 fish-qc ...
```

Please note that it is often a bad idea to use more threads than
physical cores.


# WEB PAGE
[https://github.com/elgw/fish-qc/](https://github.com/elgw/fish-qc/)


# REPORTING BUGS
Please report bugs at
[https://github.com/elgw/fish-qc/issues/](https://github.com/elgw/fish-qc/issues/)

#define _GNU_SOURCE
#define  _XOPEN_SOURCE

#include <assert.h>
#include <errno.h>
#include <getopt.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <omp.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cjson/cJSON.h>

#include "version.h"
#include "halfbyte.h"

/** TODO:
 *
 * - Grab the normal fasta reader and inject here or read directly as 4-base ...
 * possibly align each new chromosome to a histogram boundary.
 * - Combine with some plotting.
 * - :)
 */

#define SUBS_TABLE_INVALID 255
#define alignval 16


typedef uint8_t u8;


typedef struct
{
    size_t first_pos;
    size_t last_pos;
    char * name;
} fasta_record_t;


typedef struct
{
    uint8_t * genome_data;
    size_t n_bp;
    /* For named sequences */
    size_t n_record;
    fasta_record_t * record;
} fasta_data_t;


static void fadata_free(fasta_data_t * F)
{
    for(size_t kk = 0; kk<F->n_record; kk++)
    {
        free(F->record[kk].name);
    }
    free(F->record);
    free(F);
}


static void strip_newline(char * str)
{
    size_t n = strlen(str);
    if(n == 0)
    {
        return;
    }

    if(str[n-1] == '\n')
    {
        str[n-1] = '\0';
    }
    return;
}

static void show_version(FILE * fid)
{
    fprintf(fid, "fish-qc version %d.%d.%d\n",
            FQ_VERSION_MAJOR, FQ_VERSION_MINOR, FQ_VERSION_PATCH);
    fprintf(fid, "web page: https://www.github.com/elgw/fish-qc/\n");
    return;
}

/** Starting to collect some of the settings for the program
 */
typedef struct {
    /** fasta file containing the genome */
    char * genome_file;
    /** fasta file containing the query sequences */
    char * query_file;
    /** If a single string is to be queried*/
    char * query_string;
    /** Where to write the metadata in json format */
    char * mdata_file;
    /** Where all results will be stored */
    char * outdir;
    /** The command line will be saved to the meta data */
    char * commandline;
    /** Number of base pairs in the genome. TODO: Including padding? */
    size_t genome_size_bp;
    /* Genome as one byte per character. TODO: Used? */
    uint8_t * genome_bytes;
    /* Genome compressed to two base pairs per byte */
    uint8_t * genome_halfbyte;
    /** Number of base pairs per bin */
    size_t bin_size;
    /** Verbosity level */
    int verbose;
    /** For weighting together hits*/
    float beta;
} popscan_t;

/** @brief Free up ps everything it points to */
static void popscan_free(popscan_t * ps)
{
    free(ps->outdir);
    free(ps->genome_bytes);
    free(ps->genome_halfbyte);
    free(ps->query_string);
    free(ps->query_file);
    free(ps->genome_file);
    free(ps->mdata_file);
    free(ps->commandline);
    free(ps);
}

/** @brief new with default values */
static popscan_t * popscan_new()
{
    popscan_t * ps = calloc(1, sizeof(popscan_t));
    ps->bin_size = 50000;
    ps->verbose = 1;
    ps->beta = 4;
    return ps;
}

/** @brief stream read a fasta file in half bytes
 */
fasta_data_t * readfa4(const char * fname, const size_t bin_size, int verbose)
{
    /*  Get file size */
    struct stat st;
    int status = stat(fname, &st);
    if(status != 0)
    {
        fprintf(stderr, "Can not open %s\n", fname);
        return NULL;
    }
    size_t fsize = st.st_size;
    if(verbose > 1)
    {
        printf("file size: %zu (%s)\n", fsize, fname);
    }
    size_t nbytes_alloc = fsize/2 + 16 + 23*bin_size;
    uint8_t * D4 = calloc(nbytes_alloc, 1);
    assert(D4 != NULL);

    FILE * fid = fopen(fname, "r");
    if(fid == NULL)
    {
        fprintf(stderr, "Can not open %s\n", fname);
        goto fail;
    }

    size_t readpos = 0;
    size_t writepos = 0;


    /* Set up a substitution table with all valid characters */
    char subs[256];
    memset(subs, SUBS_TABLE_INVALID, 256);
    subs['a'] = hb_A;
    subs['A'] = hb_A;
    subs['t'] = hb_T;
    subs['T'] = hb_T;
    subs['c'] = hb_C;
    subs['C'] = hb_C;
    subs['g'] = hb_G;
    subs['G'] = hb_G;

    // Possibly only enable this with a switch
    subs['n'] = hb_ignore;
    subs['N'] = hb_ignore;


    size_t record_id = 0;
    size_t record_alloc = 4;
    fasta_record_t * records = calloc(record_alloc,
                                     sizeof(fasta_record_t));


    int symbol;
    while( (symbol = fgetc(fid)) != EOF )
    {

        readpos++;

        uint8_t subs_symbol = subs[(uint8_t) symbol];
        if(subs_symbol != SUBS_TABLE_INVALID)
        {
            /* Write as half byte */
            if(writepos % 2 == 0)
            {
                size_t idx = writepos / 2;
                D4[idx] = 16*subs_symbol;
            } else {
                size_t idx = writepos / 2;
                D4[idx] += subs_symbol;
            }
            writepos++;
            continue;
        }


        switch(symbol)
        {

        case '>':
            /* If we hit a comment, consume until the end of the line */
            if(record_id > 0)
            {
                records[record_id-1].last_pos = writepos-1;
            }
            if( writepos % bin_size > 0)
            {
                /** add padding so that the next chromosome starts with a fresh bin */
                size_t d = writepos/bin_size;
                //printf("Advancing writepos from %zu ", writepos);
                writepos = (d+1)*bin_size;
                //printf("to %zu\n", writepos);
            }
            assert(writepos % bin_size == 0);
            memset(&records[record_id], 0, sizeof(fasta_record_t));
            records[record_id].first_pos = writepos;
            size_t n = 0;
            ssize_t nread = getline(&records[record_id].name, &n, fid);
            assert(nread >= 0);
            if(nread > 0)
            {
                strip_newline(records[record_id].name);
            }

            /* Increase the size of the record? */
            record_id++;
            if(record_id == record_alloc)
            {
                record_alloc*=1.5;
                records = realloc(records, record_alloc*sizeof(fasta_record_t));
            }

            break;
        case '\r':
            ;
            break;
        case '\n':
            ;
            break;
        case ' ':
            ;
            break;
        default:
            fprintf(stderr, "ERROR in readfa4\n"
                    "Read '%c' at pos %zu in %s and don't know what to do with it\n",
                    symbol, readpos, fname);
            exit(EXIT_FAILURE);
            break;
        }

    }

    if(writepos == 0)
    {
        fprintf(stderr, "Failed to read anything from %s\n", fname);
        exit(EXIT_FAILURE);
    }

    if(record_id > 0)
    {
        records[record_id-1].last_pos = writepos-1;
    }

    if((writepos+1)/2 + 15 >= nbytes_alloc)
    {
        fprintf(stderr,
                "ERROR: The programmer was lazy and didn't bother to "
                "implement this corner case. Please file a bug report\n");
        exit(EXIT_FAILURE);
    }

    //    halfbyte_print_substring(stdout, D4, 0, 100);
    // printf("\n");

    fasta_data_t * fadata = calloc(1, sizeof(fasta_data_t));
    fadata->record = records;
    fadata->n_record = record_id;
    fadata->genome_data = D4;
    fadata->n_bp = writepos;
    return fadata;

fail:
    free(D4);
    return NULL;
}

/** @brief time delta in s */
static double dt(const struct timespec* finish,
                 const struct timespec* start)
{
    double elapsed = (finish->tv_sec - start->tv_sec);
    elapsed += (finish->tv_nsec - start->tv_nsec) / 1000000000.0;
    return elapsed;
}

/** @brief Number of matching basepairs in two sequences
 *
 * Note that both R and Q needs to have at least nQ uint64_t for comparison
 * - hb_query_new_from_bytes solves is on the query side.
 * - pack_8bit_to_4bit or readfa4 should add enough padding on the genome side.
 *
 * The cost increase with nQ, i.e. once per 16 base pairs.
 *
 * @param R, Q Input sequences to compare.
 * @param nQ Number of u64 to compare.
 */
static int
compare4(const uint64_t * R, const uint64_t * Q, const size_t nQ)
{
    int neq = 0;
    for(size_t kk = 0; kk< nQ; kk++)
    {
        uint64_t delta = (R[kk] & Q[kk]);
        neq +=  __builtin_popcountll(delta);
    }
    return neq;
}


static void popscan_usage(void)
{
    printf("--genome file.fa"
           "\n\t specify fasta file with genome\n");
    printf("--query query.fa"
           "\n\t specify file containing sequences to scan\n");
    printf("--outdir folder"
           "\n\t direct output to this folder (will be created)\n");
    printf("--string ATCG..."
           "\n\t Only scan one sequences and then quit\n");
    printf("--binsize b"
           "\n\t Specify the bin size b (has to be even)\n");
    printf("--verbose v"
           "\n\t set verbosity level v, default =1\n");
    printf("--self-test"
           "\n\t perform self-tests and quit\n");
    printf("--beta"
           "\n\t set the base of the weighting function (default 4.0)\n");
    printf("--help"
           "\n\t show this help message\n");
    printf("\n");
    show_version(stdout);
    return;

}

static void dup_cmdline(char ** _target, int argc, char ** argv)
{
    size_t nchar = 0;
    for(size_t kk = 0; kk < (size_t) argc; kk++)
    {
        nchar += 3+strlen(argv[kk]);
    }
    _target[0] = malloc(nchar+1);
    char * target = _target[0];
    target[0] = '\0';

    for(size_t kk = 0; kk < (size_t) argc; kk++)
    {
        if(kk > 0) {
            target = strcat(target, " ");
        }

        target = strcat(target, argv[kk]);
    }
    return;
}


/** Parse command line arguments etc */
static popscan_t * popscan_from_cli(int argc, char ** argv)
{
    popscan_t * ps = popscan_new();

    dup_cmdline(&ps->commandline, argc, argv);

    struct option longopts[] = {
        { "binsize",    required_argument, NULL, 'b' },
        { "beta",       required_argument, NULL, 'B' },
        { "genome",     required_argument, NULL, 'g' },
        { "help",       no_argument,       NULL, 'h' },
        { "outdir",     required_argument, NULL, 'o' },
        { "query",      required_argument, NULL, 'q' },
        { "string",     required_argument, NULL, 's' },
        { "self-test",  no_argument,       NULL, 't' },
        { "verbose",    required_argument, NULL, 'v' },
        { "version",    no_argument,       NULL, 'V' },
        { NULL,         0,                 NULL,  0  }
    };
    int ch;
    while((ch = getopt_long(argc, argv,
                            "b:B:g:ho:q:s:v:V",
                            longopts, NULL)) != -1)
    {
        switch(ch) {
        case 'b':
            ps->bin_size = atol(optarg);
            break;
        case 'B':
            ps->beta = atof(optarg);
            break;
        case 'g':
            free(ps->genome_file);
            ps->genome_file = strdup(optarg);
            break;
        case 'h':
            popscan_usage();
            exit(EXIT_SUCCESS);
        case 's':
            free(ps->query_string);
            ps->query_string = strdup(optarg);
            break;
        case 'o':
            free(ps->outdir);
            ps->outdir = strdup(optarg);
            break;
        case 'q':
            free(ps->query_file);
            ps->query_file = strdup(optarg);
            break;
        case 't':
            popscan_free(ps);
            exit(halfbyte_ut());
            break;
        case 'v':
            ps->verbose = atoi(optarg);
            break;
        case 'V':
            show_version(stdout);
            exit(EXIT_SUCCESS);
        }
    }

    int leave = 0;

    if( (ps->beta > 1024) | (ps->beta < 2) )
    {
        fprintf(stderr, " ! bad beta value, please use the range [2, 1024]\n");
        leave = 1;
    }

    if(ps->bin_size > 10000000)
    {
        printf(" warning: the bin size value: %zu seems very high\n",
               ps->bin_size);
    }

    if(ps->bin_size < 2)
    {
        printf(" ! the bin size has to be at least 2\n");
        leave = 1;
    }

    if(ps->bin_size %2 == 1)
    {
        printf(" ! the bin size must be even\n");
        leave = 1;
    }

    if(ps->genome_file == NULL)
    {
        printf(" ! no --genome specified\n");
        leave = 1;
    }

    if( (ps->outdir == NULL) & (ps->query_string == NULL) )
    {
        printf(" ! neither --outdir or --string specified\n");
        leave = 1;
    }

    if( (ps->outdir != NULL) & (ps->query_string != NULL) )
    {
        printf(" ! both --outdir or --string specified\n");
        leave = 1;
    }

    if( ((ps->query_string == NULL) && (ps->query_file == NULL)) ||
        ((ps->query_string != NULL) && (ps->query_file != NULL)) )
    {
        printf(" ! please specify either --query or --string\n");
        leave = 1;
    }

    if(leave)
    {
        fprintf(stderr, "\n");
        fprintf(stderr,
                "Unable to continue, please correct you command "
                "line arguments (see --help).\n");
        exit(EXIT_FAILURE);
    }

    if(ps->query_file)
    {
        FILE * fid = fopen(ps->query_file, "r");
        if(fid == NULL)
        {
            fprintf(stderr, "Unable to open %s for reading\n", ps->query_file);
            exit(EXIT_FAILURE);
        }
        fclose(fid);
    }

    if(ps->outdir)
    {
        if(mkdir(ps->outdir, 0700))
        {
            int err = errno;
            if(err)
            {
                if(err != EEXIST)
                {
                    fprintf(stderr, "Unable to create the folder %s\n",
                            ps->outdir);
                    exit(EXIT_FAILURE);
                }
            }
        }
        ps->mdata_file = malloc(256+strlen(ps->outdir));
        sprintf(ps->mdata_file, "%s/records.json", ps->outdir);
    }



    return ps;
}

static int ps_write_records_json(popscan_t * ps, fasta_data_t * fadata)
{

    int retvalue = EXIT_SUCCESS;

    cJSON * metadata = cJSON_CreateObject();

    /* Program settings */
    cJSON * jstring = cJSON_CreateString(ps->genome_file);
    cJSON_AddItemToObject(metadata, "genome", jstring);

    cJSON * jbs = cJSON_CreateNumber((double) ps->bin_size);
    cJSON_AddItemToObject(metadata, "bin_size", jbs);

    cJSON * jbeta = cJSON_CreateNumber(ps->beta);
    cJSON_AddItemToObject(metadata, "beta", jbeta);

    cJSON * jcmdline = cJSON_CreateString(ps->commandline);
    cJSON_AddItemToObject(metadata, "cmd", jcmdline);

    /* The records from the genome */
    cJSON * jrecords = cJSON_CreateArray();
    cJSON_AddItemToObject(metadata, "records", jrecords);

    for(size_t kk = 0; kk<fadata->n_record; kk++)
    {
        cJSON * rec = cJSON_CreateObject();
        cJSON_AddItemToArray(jrecords, rec);

        cJSON * j_rec_name = cJSON_CreateString(fadata->record[kk].name);
        cJSON_AddItemToObject(rec, "name", j_rec_name);

        cJSON * j_first_pos =
            cJSON_CreateNumber(fadata->record[kk].first_pos);
        cJSON_AddItemToObject(rec, "first_pos", j_first_pos);

        cJSON * j_last_pos =
            cJSON_CreateNumber(fadata->record[kk].last_pos);
        cJSON_AddItemToObject(rec, "last_pos", j_last_pos);

        cJSON * j_first_bin =
            cJSON_CreateNumber(fadata->record[kk].first_pos / ps->bin_size);
        cJSON_AddItemToObject(rec, "first_bin", j_first_bin);

        cJSON * j_last_bin =
            cJSON_CreateNumber(fadata->record[kk].last_pos / ps->bin_size);
        cJSON_AddItemToObject(rec, "last_bin", j_last_bin);
    }

    /* Write/overwrite records.json in the outdir folder */
    FILE * fid = fopen(ps->mdata_file, "w");
    if(fid == NULL)
    {
        fprintf(stderr, "Unable to write to %s\n", ps->mdata_file);
        retvalue = EXIT_FAILURE;
        cJSON_Delete(metadata);
        goto done;
    }

    char * json_string = cJSON_Print(metadata);
    cJSON_Delete(metadata);
    fprintf(fid, "%s", json_string);
    fclose(fid);
    free(json_string);

 done: ;

    return retvalue;
}


void ps_write_records(popscan_t * ps, fasta_data_t * fadata)
{
    if(ps->mdata_file == NULL)
    {
        return;
    }
    // TODO: Check if ps->mdata_file already exists and take action
    ps_write_records_json(ps, fadata);
    return;
}

/** or just create some dummy data */
static void popscan_load_genome(popscan_t * ps)
{
    if(ps->genome_file == NULL)
    {
        fprintf(stderr, "No --genome specified\n");
        exit(EXIT_FAILURE);
    }

    if(ps->verbose > 0)
    {
        printf("Loading %s\n", ps->genome_file);
    }
    fasta_data_t * fadata = readfa4(ps->genome_file, ps->bin_size, ps->verbose);
    if(fadata == NULL)
    {
        fprintf(stderr, "Sorry, can't continue\n");
        exit(EXIT_FAILURE);
    }
    if(ps->verbose > 1)
    {
        printf("Genome size: %zu\n", fadata->n_bp);
    }
    ps_write_records(ps, fadata);

    ps->genome_halfbyte = fadata->genome_data;
    fadata->genome_data = NULL; /* Steal the pointer */
    ps->genome_size_bp = fadata->n_bp;

    fadata_free(fadata);

    return;
}

/** Create a dummy query */
hb_query_t * gen_rand_query(size_t n_bp)
{
    /* needle/query */
    printf("Needle size: %zu\n", n_bp);
    u8 * Needle = aligned_alloc(alignval, n_bp);
    assert(Needle != NULL);
    for(size_t kk = 0; kk < n_bp; kk++)
    {
        Needle[kk] = pow(2, kk % 4);
        halfbyte_print_basepair(stdout, Needle[kk]);
    }
    printf("\n");

    /* Convert to 4-bit representations,
       later on we could read the genome directly to 4bit :) */

    //u8 * Needle4 = pack_8bit_to_4bit(NULL, Needle, n_bp);
    hb_query_t * query = hb_query_new_from_bytes(Needle, n_bp);
    free(Needle);
    return query;
}


typedef struct {
    float * counts;
    size_t nbin;
    size_t bin_size;
} hist_t;

static hist_t * hist_new(size_t domain_size, size_t bin_size)
{
    hist_t * H = calloc(1, sizeof(hist_t));
    H->bin_size = bin_size;
    H->nbin = (domain_size + bin_size - 1) / bin_size;
    assert(H->nbin != 0);
    H->counts = calloc(H->nbin, sizeof(float));
    return H;
}

static double hist_sum(const hist_t * H)
{
    double sum = 0;
#pragma omp parallel for reduction(+:sum)
    for(size_t bb = 0; bb<H->nbin; bb++)
    {
        sum += H->counts[bb];
    }
    return sum;
}

static void hist_free(hist_t * H)
{
    free(H->counts);
    free(H);
    return;
}

static int hist_write(hist_t * H, const char * fname)
{
    FILE * fid = fopen(fname, "w");
    if(fid == NULL)
    {
        printf("Unable to open %s for writing\n", fname);
        return EXIT_FAILURE;
    }
    size_t nwritten = fwrite(H->counts, sizeof(float), H->nbin, fid);
    fclose(fid);
    if(nwritten != H->nbin)
    {
        printf("Failed to write to %s\n", fname);
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}

void popscan_scan(popscan_t * ps, hb_query_t * query)
{
    /* Prof[kk] += cost[match]
     * then later on care about splitting the profile into
     * separate chromosomes.
     */

    char * outname = NULL;
    if(ps->outdir)
    {
        outname = calloc(strlen(ps->outdir) + strlen(query->human_readable) + 256, 1);
        sprintf(outname, "%s/%s_%zu.f32", ps->outdir, query->human_readable, ps->bin_size);
    } else {
        outname = calloc(strlen(query->human_readable) + 256, 1);
        sprintf(outname, "%s_%zu.f32", query->human_readable, ps->bin_size);
    }

    FILE * fid = fopen(outname, "r");
    if(fid != NULL)
    {
        printf("%s already exists, skipping this oligo\n", outname);
        fclose(fid);
        free(outname);
        return;
    }

    hist_t * hist = hist_new(ps->genome_size_bp, ps->bin_size);

    struct timespec tstart, tend;
    clock_gettime(CLOCK_MONOTONIC, &tstart);

    size_t nH = ps->genome_size_bp;

    size_t nN = query->n_bp;
    //printf("query->n_bp = %zu\n", query->n_bp);
    uint8_t * H4 = ps->genome_halfbyte;

    float * cost = calloc(query->n_bp+1, sizeof(float));
    for(size_t kk = 0; kk <= query->n_bp; kk++)
    {
        cost[kk] = powf(ps->beta, -((float) query->n_bp - (float) kk));
    }

    assert(cost[query->n_bp] == 1);
    assert(cost[query->n_bp-1] == 1.0/4.0);
    assert(ps->bin_size %2 == 0);

    //printf("hist->nbin=%zu\n", hist->nbin);
    //printf("nH: %zu\n", nH);

    /** Please note that the index, kk below is over the bytes of the genome,
     * not the coordinates */
#pragma omp parallel for
    for(size_t bb = 0; bb < hist->nbin; bb++)
    {
        size_t pos0 = bb*ps->bin_size/2;
        size_t pos1 = pos0 + ps->bin_size/2;
        size_t lastpos = (nH - nN)/2;
        pos1 > lastpos ? pos1 = lastpos : 0;
        //printf("bb=%zu pos0: %zu, pos1: %zu\n", bb, pos0, pos1);
        for(size_t kk = pos0; kk < pos1; kk++)
        {

            /* On even genomic pos 2*kk */
            hist->counts[bb] += cost[compare4((uint64_t*) (H4+kk),
                                              query->even, query->n_even)];
            hist->counts[bb] += cost[compare4((uint64_t*) (H4+kk),
                                              query->r_even, query->n_even)];


            /* On odd genomic pos 2*kk + 1 */
            hist->counts[bb] += cost[compare4((uint64_t*) (H4+kk),
                                              query->odd,  query->n_odd)];
            hist->counts[bb] += cost[compare4((uint64_t*) (H4+kk),
                                              query->r_odd,  query->n_odd)];
        }

    }

    free(cost);

    // Sum up the matches from the histogram
    double total_matches = hist_sum(hist);

    clock_gettime(CLOCK_MONOTONIC, &tend);
    printf("Took %.2f s Abp=%f \n", dt(&tend, &tstart), total_matches);

    hist_write(hist, outname);
    free(outname);

    hist_free(hist);

    return;
}

static void popscan_show(popscan_t * ps)
{
    if(ps->verbose <= 1) {
        return;
    }

    printf("ps->genome_size = %zu bp\n", ps->genome_size_bp);
    return;
}


static void
query_single_string(popscan_t * ps)
{
    /* Encode to numeric representation 1 byte each */
    uint8_t * encoded_query =
        halfbyte_encode_string(ps->query_string,
                               strlen(ps->query_string));
    /* Generate the query */
    hb_query_t * query =
        hb_query_new_from_bytes(encoded_query,
                                strlen(ps->query_string));
    free(encoded_query);
    /* Repeat for multiple queries ...  */
    popscan_scan(ps, query);

    hb_query_free(query);
    return;
}

static void
query_from_file(popscan_t * ps)
{
    FILE * fid = fopen(ps->query_file, "r");
    char * line = NULL;
    size_t n = 0;
    size_t seq_id = 0;
    ssize_t len;
    while( (len = getline(&line, &n, fid) ) != -1)
    {
        if(n == 0) {
            continue;
        }

        if(line[0] == '>') {
            continue;
        }
        /* Remove line break */
        if((line[len-1] == '\n') | (line[len-1] == '\r')) {
            line[len-1] = '\0';
            len--;
        }

        if( (line[len-1] == '\n') | (line[len-1] == '\r')) {
            line[len-1] = '\0';
            len--;
        }

        free(ps->query_string);
        ps->query_string = strdup(line);
        printf("querying #%zu '%s'\n", ++seq_id, line);
        query_single_string(ps);
    }
    free(line);
    return;
}


int popscan(int argc, char ** argv)
{
    popscan_t * ps = popscan_from_cli(argc, argv);

    popscan_load_genome(ps);
    popscan_show(ps);

    if(ps->query_string != NULL)
    {
        query_single_string(ps);
    }

    if(ps->query_file != NULL)
    {
        query_from_file(ps);
    }

    popscan_free(ps);

    return EXIT_SUCCESS;
}

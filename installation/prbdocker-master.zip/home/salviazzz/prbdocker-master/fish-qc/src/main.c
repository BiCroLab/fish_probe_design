#include "popscan.h"
#include "version.h"


int main(int argc, char ** argv)
{
    return popscan(argc, argv);
}

#include "halfbyte.h"

/**
 * TODO: be more consistent and careful with the naming with regards
 * to input/output so that it is clear when half bytes vs bytes are used.
 */

/* Pack the number 8-bit numbers in the range 0-15
 * Into an array of 4-bit numbers.
 */
unsigned char *
pack_8bit_to_4bit(unsigned char * B,
                  const unsigned char * A, size_t nA)
{
    size_t nB = (nA+1)/2;
    assert(nB*2 >= nA);
    nB += 16; /* Extra padding for the popcount stuff, i.e. at least 8 bytes */
    if(B == NULL)
    {
        B = calloc(nB, 1);
        if(B == NULL)
        {
            return B;
        }
    }

    for(size_t kk = 0; kk+1 < nA; kk+=2)
    {
        assert(A[kk]<16);
        assert(A[kk+1]<16);
        B[kk/2] = 16*A[kk] + A[kk+1];
    }
    if(nA % 2 == 1)
    {
        size_t kk = nA-1;
        B[kk/2] = 16*A[kk];
    }
    //printf("%u\n", B[0]);
    return B;
}

unsigned char *
unpack_4bit_to_8bit(unsigned char * A, const unsigned char * B, size_t nA)
{
    if(A == NULL)
    {
        A = calloc(nA, 1);
        if(A == NULL)
        {
            return A;
        }
    }

    for(size_t kk = 0; kk+1 < nA; kk+=2)
    {
        A[kk] = (B[kk/2] & (unsigned char) 0xF0) >> 4;
        A[kk+1] = B[kk/2] & 0x0f;
    }
    if(nA % 2 == 1)
    {
        size_t kk = nA-1;
        A[kk] = (B[kk/2] & 0xF0) >> 4;
    }
    return A;
}



uint8_t rc_u8(uint8_t base)
{
    switch(base)
    {
    case hb_A:
        return hb_T;
    case hb_T:
        return hb_A;
    case hb_C:
        return hb_G;
    case hb_G:
        return hb_C;
    }
    fprintf(stderr, "Unexpected genomic encoding\n");
    exit(EXIT_FAILURE);
}

/** shift the n first bytes right inserting a 0 at the beginning
 * Examples:
 * [1] -> [0 1] (n = 1)
 * [1 2] -> [0, 1, 2] (n = 2)
 */

static void shift_bytes_right(uint8_t * B, size_t n)
{
    for(size_t kk = n; kk>0; kk--)
    {
        B[kk] = B[kk-1];
    }
    B[0] = 0;
}

hb_query_t * hb_query_new_from_bytes(uint8_t * representation,
                                     size_t n)
{
    hb_query_t * q = calloc(1, sizeof(hb_query_t));
    assert(q != NULL);
    q->n_bp = n;
    q->n_even = (n + 15)/16;
    q->n_odd = (n + 16)/16;
    //printf("n=%zu, n_even=%zu\n", n, q->n_even);
    //printf("n=%zu, n_odd=%zu\n", n, q->n_odd);
    assert(q->n_even > 0);
    assert(q->n_odd > 0);
    assert(q->n_even * 16 >= n);
    assert(q->n_odd * 16 >= (n+1));

    q->even = calloc(q->n_even, sizeof(uint64_t));
    assert(q->even != NULL);
    pack_8bit_to_4bit( (uint8_t*) q->even, representation, n);
    //printf("input: %s\n",
    //       halfbyte_decode_bytes(representation, n));

    uint8_t * shifted_representation = calloc(n+1, 1);
    memcpy(shifted_representation, representation, n);
    shift_bytes_right(shifted_representation, n);
    q->odd = calloc(q->n_odd, sizeof(uint64_t));
    assert(q->odd != NULL);
    //printf("input shifted: %s\n",
    //       halfbyte_decode_bytes(shifted_representation, n+1));
    pack_8bit_to_4bit( ((uint8_t*) q->odd), shifted_representation, n+1);


#ifndef DNDEBUG
    for(size_t kk = 0; kk<n; kk++)
    {
        assert(representation[kk] == shifted_representation[kk+1]);
    }
#endif

    q->human_readable = calloc(n+1, 1);
    q->human_readable[n] = '\0';
    for(size_t kk = 0; kk<n; kk++)
    {
        char decoded = '?';
        switch(representation[kk]) {
        case hb_A:
            decoded = 'A';
            break;
        case hb_T:
            decoded = 'T';
            break;
        case hb_C:
            decoded = 'C';
            break;
        case hb_G:
            decoded = 'G';
            break;
        }
        q->human_readable[kk] = decoded;
    }



    /* Reverse complement */
    uint8_t * reverse = calloc(n+1, 1);
    memset(reverse, 0, n+1);
    for(size_t kk = 0; kk < n; kk++)
    {
        reverse[kk] = rc_u8(representation[n-kk-1]);
    }


    //printf("rc   : %s\n",
    //       halfbyte_decode_bytes(reverse, n));


    q->r_even = calloc(q->n_even, sizeof(uint64_t));
    assert(q->r_even != NULL);
    pack_8bit_to_4bit( ((uint8_t*) q->r_even), reverse, n);

    // Shift right
    uint8_t * reverse_shifted = calloc(n+1, 1);
    memcpy(reverse_shifted, reverse, n);
    shift_bytes_right(reverse_shifted, n);

    //printf("rc sh: %s\n",
    //       halfbyte_decode_bytes(reverse_shifted, n+1));

    q->r_odd = calloc(q->n_odd, sizeof(uint64_t));
    assert(q->r_odd != NULL);
    pack_8bit_to_4bit( ((uint8_t*) q->r_odd), reverse_shifted, n+1);
    free(shifted_representation);
    free(reverse);
    free(reverse_shifted);
    return q;
}
void hb_query_free(hb_query_t * q)
{
    free(q->even);
    free(q->odd);
    free(q->r_even);
    free(q->r_odd);
    free(q->human_readable);
    free(q);
    return;
}

#define always_assert(cond) cond ? (void)0 : die_now(#cond, __FILE__, __LINE__)
static void die_now(char *cond_str, const char *file, int line) {
    fprintf(stderr, "Assertion failed (%s)\n", cond_str);
    fprintf(stderr, "In %s, line %d\n", file, line);
    exit(EXIT_FAILURE);
}




void
halfbyte_print_substring(FILE * fid,
                         const uint8_t * bytes,
                         size_t from, size_t to)
{
    for(size_t kk = from; kk < to; kk++)
    {
        if(kk%2 == 0)
        {
            size_t idx = kk/2;
            //if(kk == 0) {printf("<v=%d>", bytes[idx]);}
            int v = bytes[idx]/16;
            halfbyte_print_basepair(fid, v);
        } else {
            size_t idx = kk/2;
            int v = (bytes[idx] & (uint8_t) 0x0f);
            halfbyte_print_basepair(fid, v);
        }
    }
    return;
}


/** @brief From numeric back to human readable
 *
 * @return A \0 terminated char.
 */

char *
halfbyte_decode_bytes(const uint8_t * encoded,
                      size_t str_len)
{
    char * decoded = calloc(str_len+1, 1);
    decoded[str_len] = '\0';

    for(size_t kk = 0; kk < str_len; kk++)
    {
        switch(encoded[kk])
        {
        case hb_A:
            decoded[kk] = 'A';
            break;
        case hb_T:
            decoded[kk] = 'T';
            break;
        case hb_C:
            decoded[kk] = 'C';
            break;
        case hb_G:
            decoded[kk] = 'G';
            break;
        case hb_ignore:
            decoded[kk] = 'i';
            break;
        default:
            decoded[kk] = '-';
        }
    }
    return decoded;
}

// TODO: some DRY here please
void halfbyte_print_basepair(FILE * fid, uint8_t byte)
{
    switch(byte)
    {
    case hb_A:
        fprintf(fid, "A");
        break;
    case hb_T:
        fprintf(fid, "T");
        break;
    case hb_C:
        fprintf(fid, "C");
        break;
    case hb_G:
        fprintf(fid, "G");
        break;
    default:
        fprintf(fid, "?");
    }
    return;
}


/** @brief From genomic string to numeric representation
 *
 * Accepted letter are aAtTcCgGnN but please note that nN will be
 * converted to hb_ignore, i.e. will not return a matching basepair
 * for any comparison.
 *
 * Example: 'ATCG' -> [hb_A, hb_T, hb_C, hb_G]
 *
 * @return an array of size str_len which the caller is responsible to
 * free.
 **/
uint8_t *
halfbyte_encode_string(const char * str,
                       size_t str_len)
{
    uint8_t * encoded = calloc(str_len, 1);
    for(size_t kk = 0; kk < str_len; kk++)
    {
        switch(str[kk])
        {
        case 'a':
        case 'A':
            encoded[kk] = hb_A;
            break;
        case 't':
        case 'T':
            encoded[kk] = hb_T;
            break;
        case 'c':
        case 'C':
            encoded[kk] = hb_C;
            break;
        case 'g':
        case 'G':
            encoded[kk] = hb_G;
            break;
        case 'n':
        case 'N':
            encoded[kk] = hb_ignore;
            break;
        default:
            fprintf(stderr, "Invalid character: '%c' can't be encoded\n", str[kk]);
            exit(EXIT_FAILURE);
        }
    }
    return encoded;
}

static void ut_encode_decode(void)
{
    /* Encode and decode */
    char * str = strdup("ATCGAATTCCGG");
    uint8_t * e_str = halfbyte_encode_string(str, strlen(str));
    char * str2 = halfbyte_decode_bytes(e_str, strlen(str));
    always_assert(strlen(str) == strlen(str2));
    for(size_t kk = 0; kk < strlen(str); kk++)
    {
        always_assert(str[kk] == str2[kk]);
    }
    free(str);
    free(e_str);
    free(str2);
}

static void ut_pack_unpack(void)
{
    /* Packing and unpacking */
    size_t nValues = 5;
    unsigned char * eight = calloc(nValues, 1);
    eight[0] = 12;
    eight[1] = 3;
    eight[2] = 0;
    eight[3] = 15;
    eight[4] = 12;

    unsigned char * four = pack_8bit_to_4bit(NULL, eight, nValues);
    unsigned char * eight2 = unpack_4bit_to_8bit(NULL, four, nValues);

    for(size_t kk = 0; kk < nValues; kk++)
    {
        //printf("#%zu, %u, %u\n", kk, eight[kk], eight2[kk]);
        always_assert(eight[kk] == eight2[kk]);
    }
    free(eight);
    free(four);
    free(eight2);
}

static void ut_reverse_complement(void)
{
    /* Test reverse complement  */
    always_assert( rc_u8(hb_A) == hb_T );
    always_assert( rc_u8(hb_C) == hb_G );
    always_assert( rc_u8(rc_u8(hb_A)) == hb_A );
    always_assert( rc_u8(rc_u8(hb_T)) == hb_T );
    always_assert( rc_u8(rc_u8(hb_C)) == hb_C );
    always_assert( rc_u8(rc_u8(hb_G)) == hb_G );
}

int halfbyte_ut(void)
{
    printf("-> encode and decode\n");
    ut_encode_decode();
    printf("-> pack and unpack\n");
    ut_pack_unpack();
    printf("-> reverse complement\n");

    ut_reverse_complement();

    return EXIT_SUCCESS;
}

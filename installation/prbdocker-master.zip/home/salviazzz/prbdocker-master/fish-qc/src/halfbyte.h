#pragma once
#include <assert.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

/** Convert between bytes and half bytes
 *
 * If a byte array contain numbers up to 16 i.e. only use
 * four out of the eight bits we only need half the number of bytes to
 * represent it.
 *
 * Example: (pack)
 * [0x02, 0x0f, 0x01, 0x05] -> [0x2f, 0x15]
 *
 * Example: (unpack)
 * [0x2f, 0x15] -> [0x02, 0x0f, 0x01, 0x05]
 *
 * Obviously a convention is needed when an odd number of elements are
 * to be decoded/encoded. Or we need to know how many number that are encoded,
 * not just the number of bytes that it was squeezed into.
 *
 * Examples:
 *
 * n=5
 * [0x02, 0x0f, 0x01, 0x05, 0x07] -> [0x2f, 0x15, 0x70]
 *
 * n=5 (but three bytes)
 * [0x2f, 0x15, 0x70] -> [0x02, 0x0f, 0x01, 0x05, 0x07]
 *
 * n=6 (but three bytes)
 * [0x2f, 0x15, 0x70] -> [0x02, 0x0f, 0x01, 0x05, 0x07, 0x00]
 *
 */


/* What basepair that is associated to what number is arbitrary
 * as long as we stick to the same conventions everywhere.
 * and as long as we only use the numbers 1, 2, 4, 8 and nothing else.
 */

#define hb_ignore 0
#define hb_A 1
#define hb_T 2
#define hb_C 4
#define hb_G 8

/** @brief For querying on 4-bit data
 *
 * The query string is packed in units of 16 half bytes.
 *
 * There is one form for querying on even start positions
 * and one form for querying on odd starting positions.
 *
 * The odd query is shifted 4 bits.
 *
 *
*/
typedef struct {
    uint64_t * even;
    uint64_t n_even;
    uint64_t * odd;
    uint64_t n_odd;
    /* The r_ means reverse complement */
    uint64_t * r_even; // same size as even
    uint64_t * r_odd; // same size as odd
    uint64_t n_bp; /* Number of base pairs in the query string*/
    char * human_readable; /* Optional in plain text*/
} hb_query_t;


/** @brief Generate a query from an encoded representation */
hb_query_t *
hb_query_new_from_bytes(uint8_t * byte_representation,
                        size_t n_elements);


/** @brief byte to half-byte conversion */
unsigned char *
pack_8bit_to_4bit(unsigned char * hb_target,
                  const unsigned char * byte_source,
                  size_t nElements);


/** @brief half-byte to byte conversion */
unsigned char *
unpack_4bit_to_8bit(unsigned char * byte_target,
                    const unsigned char * hb_source,
                    size_t n_elements);



void
hb_query_free(hb_query_t * q);


void halfbyte_print_basepair(FILE * fid, uint8_t byte);

void halfbyte_print_substring(FILE * fid,
                              const uint8_t * bytes,
                              size_t from, size_t to);

/** Between full bytes and chars */
uint8_t *
halfbyte_encode_string(const char * str,
                       size_t str_len);

char *
halfbyte_decode_bytes(const uint8_t * encoded,
                      size_t str_len);

/** @brief Perform some self-tests */
int halfbyte_ut(void);

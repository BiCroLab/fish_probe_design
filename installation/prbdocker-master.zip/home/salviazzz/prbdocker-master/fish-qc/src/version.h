#pragma once

#define FQ_VERSION_MAJOR 0
#define FQ_VERSION_MINOR 1
#define FQ_VERSION_PATCH 3

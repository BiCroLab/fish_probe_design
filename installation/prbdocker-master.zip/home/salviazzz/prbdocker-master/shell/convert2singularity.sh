#!/bin/bash

# Convert the docker container to a singularity container
module load singularity
cd /group/bienko/containers
rm -f prb.sif
singularity build prb.sif docker-archive://prbdocker.tar
#!/bin/bash

# Run the docker container interactively on your local machine 
# with the current directory mounted as the working directory
docker run -it --volume $HOME:$HOME --workdir $PWD prbdocker
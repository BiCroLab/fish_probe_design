# Log of changes

## 0.1.0
- Added an experimental interactive interface `nhush interactive`
  which has limited use at the moment.
- A few of the commands can now use binary filters which can be
  specified by small lua scripts.
- Requires lua and readline to build.

## 0.0.9
- Updated output when using `nhush bfm -r ... -s ... --probb`.

## 0.0.8
- **nhush-bfm** is now baked into the **nhush** binary using the command **bfm**.
- Added the flag `--probb` to **bfm** to calculate the Hamming based
  binding probability (see documentation).
- Fixed that **bfm** did not show matches at distance 0 for the
  reverse complement.

- Documentation progressing ...

## 0.0.7
- calculating bucket sizes in parallel. Time reduced from 100 to 35 s
  on a 4-core computer.
- Bucket initialization slightly faster.
- added the sub command `find-abundant` to find sequences that appear
  multiple times. It might make sense to match against that list (with
  a high Hamming radius).

## 0.0.6
- Brute force matching **nhush-bfm** can handle the whole set of possible
  letters used.
- Progress bar made more stable.
- Cosmetic changes in code.
- Using 2 Mb pages as default, does not seem to make a difference to
  speed.

## 0.0.4
- Exits gracefully when fasta files does not exist.
- Updated documentation and examples.

## 0.0.3
- re-organized source files.
- changing the name of the output files when `--external` is used
  so that the output files inherit the name of the query file.

## 0.0.2
- nhush-fasplit ignores initial blank characters
- installing bfm-comb by default.
- added the `--until` switch to nhush for automatic stopping.
- Improved documentation and consistency when using the binaries.

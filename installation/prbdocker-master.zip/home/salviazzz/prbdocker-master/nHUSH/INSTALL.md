# Alternative install procedure using Meson

For non-Ubuntu distributions this might work better than the standard
way to install nHUSH as described in the [README](README.md).

``` shell
sudo apt install meson
meson setup builddir --buildtype release
cd builddir
meson compile
meson install # Note: meson needs to be install by sudo
```
and to uninstall:

``` shell
sudo ninja -C builddir uninstall
```

To make a **deb** package:

``` shell
dh_make --createorig -p nhush_0.0.4
dh_auto_configure --buildsystem=meson
dpkg-buildpackage -rfakeroot -us -uc -b
```
the *deb* file will end up in the parent directory.

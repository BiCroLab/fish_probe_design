#include "find_abundant.h"
#include "eq_classes.h"
#include "bfm.h"
#include "version.h"
#include "comb_cli.h"
#include "lua_interface.h"
#include "oracle.h"

int nhush_fasplit(int argc, char ** argv);
int nhush_genrand(int argc, char ** argv);
int nhush_genmm(int argc, char ** argv);
int nhush_readrand(int argc, char ** argv);
int nhush_mindist(int argc, char ** argv);

static int
show_usage()
{
    printf("nHUSH v%s\n", NHUSH_VERSION);
    printf("\n");
    printf("Major commands:\n");
    printf("\tmindist -- "
           "find minimal Hamming distance between oligos\n");
    printf("\tbfm -- "
           "\tBrute force matching of oligo(s) vs genome\n");
    printf("\tinteractive --"
           "\tStart a Real-Eval-Print loop (lua based)\n");
    printf("Minor commands:\n");
    printf("\tcomb -- "
           "inspect/generate HASH combs\n");
    printf("\tfind-abundant -- "
           "find sequences appearing in more than one place on the genome\n");
    printf("\teq_classes -- "
           "find equivalence classes in a genome\n");
    printf("\treadrand -- "
           "read a random oligo from a genome\n");
    printf("\tgenrand -- "
           "generate a random string of genomic letters\n");
    printf("\tgenmm -- "
           "permute a string to have a specific Hamming distance\n");
    printf("\n");
    printf("Web page: https://www.github.com/elgw/nHUSH/\n");
    return EXIT_SUCCESS;
}


int main(int argc, char ** argv)
{
    if(argc < 2) {
        return show_usage();
    }
    if(strcasecmp(argv[1], "help") == 0)
    {
        return show_usage();
    }
    if(strcasecmp(argv[1], "--help") == 0)
    {
        return show_usage();
    }
    if(strcasecmp(argv[1], "-h") == 0)
    {
        return show_usage();
    }

    if(strcasecmp(argv[1], "interactive") == 0)
    {
        return nhush_lua_repl(argc-1, argv+1);
    }

    if(strcasecmp(argv[1], "probb") == 0)
    {
        return nhush_mindist(argc-1, argv+1);
    }

    if(strcasecmp(argv[1], "bfm") == 0)
    {
        return nhush_bfm(argc-1, argv+1);
    }
    if(strcasecmp(argv[1], "comb") == 0)
    {
        return nhush_comb(argc-1, argv+1);
    }
    if(strcasecmp(argv[1], "eq_classes") == 0)
    {
        return eq_classes(argc-1, argv+1);
    }
    if(strcasecmp(argv[1], "fasplit") == 0)
    {
        return nhush_fasplit(argc-1, argv+1);
    }
    if(strcasecmp(argv[1], "find-abundant") == 0)
    {
        return find_abundant(argc-1, argv+1);
    }
    if(strcasecmp(argv[1], "genrand") == 0)
    {
        return nhush_genrand(argc-1, argv+1);
    }
    if(strcasecmp(argv[1], "genmm") == 0)
    {
        return nhush_genmm(argc-1, argv+1);
    }
    if(strcasecmp(argv[1], "mindist") == 0)
    {
        return nhush_mindist(argc-1, argv+1);
    }
    if(strcasecmp(argv[1], "readrand") == 0)
    {
        return nhush_readrand(argc-1, argv+1);
    }

    if(strcasecmp(argv[1], "oracle") == 0)
    {
        return oracle(argc-1, argv+1);
    }

    return nhush_mindist(argc, argv);
}

#include <assert.h>
#include <stdio.h>
#include <cairo.h>
#include <cairo-svg.h>
#include <math.h>
#include <stdlib.h>

#include "comb.h"

static void
rounded_rectangle (cairo_t *cr,
                   double x, double y,
                   double w, double h, double r)
{
    cairo_new_sub_path (cr);
    cairo_arc (cr, x + r, y + r, r, M_PI, 3 * M_PI / 2.0);
    cairo_arc (cr, x + w - r, y + r, r, 3.0 *M_PI / 2.0, 2.0 * M_PI);
    cairo_arc (cr, x + w - r, y + h - r, r, 0.0, M_PI / 2.0);
    cairo_arc (cr, x + r, y + h - r, r, M_PI / 2.0, M_PI);
    cairo_close_path (cr);
}


void draw_pattern(uint8_t * P, size_t L, size_t N, int mm, const char * file)
{
    double width = 20;
    double height = 20;
    int image_width = L*width;
    int image_height = N*height;

    cairo_surface_t *surface =
        cairo_svg_surface_create (file, image_width, image_height);
    assert(surface != NULL);
    cairo_t *cr =
        cairo_create (surface);
    assert(cr != NULL);


    double radius = 4;
    /* Paint background white, then draw in black. */
    cairo_set_source_rgb (cr, 1.0, 1.0, 1.0); /* white */
    cairo_paint (cr);
    cairo_set_source_rgb (cr, 0.2, 0.2, 0.2); /* dark gray */
    //cairo_set_fill_rule (cr, CAIRO_FILL_RULE_EVEN_ODD);
    for(size_t rr = 0; rr<N; rr++)
    {
        double y = width*(double) rr;
        for(size_t cc = 0; cc < L; cc++)
        {
            double x = height*(double) cc;
            if(P[cc + rr*L] == 1)
            {
                rounded_rectangle (cr, x, y, width*0.9, height*0.9, radius);
            }
        }
    }

    cairo_fill (cr);
    cairo_surface_finish(surface);
}


int main(int argc, char ** argv)
{
    size_t L = 20;
    size_t N = 0;
    int r = 2;

    if(argc == 3)
    {
        L = atol(argv[1]);
        r = atoi(argv[2]);
    }

    char * outfile = strdup("temp.svg");

    printf("Using L = %zu, mm = %d\n", L, r);
    printf("Will write to %s\n", outfile);
    uint8_t * P = genmm(L, r, &N);

    draw_pattern(P, L, N, r, outfile);
    free(P);
    free(outfile);
    return EXIT_SUCCESS;

}

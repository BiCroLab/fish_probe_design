#ifndef count_sort_h_
#define count_sort_h_

#define _GNU_SOURCE

#include <assert.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#include <omp.h>

#define COUNT_SORT_VERSION_MAJOR "0"
#define COUNT_SORT_VERSION_MINOR "1"
#define COUNT_SORT_VERSION_PATCH "1"
#define COUNT_SORT_VERSION COUNT_SORT_VERSION_MAJOR "."     \
    COUNT_SORT_VERSION_MINOR "."                          \
    COUNT_SORT_VERSION_PATCH
#define COUNT_SORT_DATE "2023-04-20"

/* Compare A vs B */
typedef int (*cs_compare_t)(const void * B,
                            const void * A,
                            void * arg);

/* Calculate hash for A  */
typedef uint32_t (*cs_hash_t)(const uint8_t * A,
                      const void * arg);

typedef struct {
    uint32_t * buckets;
    uint32_t * bucket_start;
    uint32_t nbuckets;
} count_sort_t;

void count_sort_free(count_sort_t * );

/* Sort the references in idx, which are indexes to data
 * using the supplied hash function.
 * if cmp is supplied the elements in each bin is sorted
 * hash_max is the max value that the hash function can generate
 * i.e. the number of buckets-1
 * sorting only makes sense if H(A) < H(B) implies cmp(A)<cmp(B)
 */
count_sort_t * count_sort_idx(uint8_t * data,
                   size_t nmemb,
                   cs_compare_t cmp,
                   cs_hash_t hash,
                   size_t hash_max,
                   void * arg);

#endif

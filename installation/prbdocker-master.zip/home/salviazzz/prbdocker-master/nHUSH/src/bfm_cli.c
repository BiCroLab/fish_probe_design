#include "bfm.h"

int main(int argc, char ** argv)
{
    return nhush_bfm(argc, argv);
}

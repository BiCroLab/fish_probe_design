function read_proprobe(fname)
%% Example on how to read a mindist file produced by proprobe

wip = 0;

%fname = 'hg19/chr17.fa.out.L30.uint8';
%fname = 'hg19.fa.out.L20.uint8';
%fname = 'hg19.fa.out.L40.uint8';
%fname = 'hg19.fa.out.L30.uint8'; wip = 17;
fname = 'R64-1-1/all.dna.chromosome.fa.out.L30.uint8'; wip = 30
%fname = 'R64-1-1/all.dna.chromosome.fa.out.L20.uint8'; wip = 30
%fname = 'R64-1-1/all.dna.chromosome.fa.out.L25.uint8'; wip = 30
%fname = 'minimal.fa.out.L20.uint8'
tsvname = 'hg19.fa.index.tsv';
%per_chromosome(fname, tsvname);
H = get_histogram(fname);

fprintf('# Sequences: %d\n', sum(H(:)));
fprintf('# Sequences without match: %d (mindist value = 255)\n', double(H(256)));

plot_histogram(fname, H, wip);

%keyboard      

end

function per_chromosome(fname, tsvname)
index = tdfread(tsvname)
fid = fopen(fname, 'r');

for kk = 8    
    fseek(fid, index.pos(kk), 'bof')
    d = fread(fid, index.len(kk));
    d = d>7;
    d = convn(d, ones(10001,1), 'same');
    plot(1:10000:numel(d), d(1:10000:end));
    title([index.name(kk,:) ' 10k per bin']);
    legend('Number of unique sequences')
    %imagesc(d(1:10000:end))
end


fclose(fid);
keyboard
end

function HG = get_histogram(fname)
%% Read the mindist file in chunks and create a histogram on the go

chunk_size = 1e7;

fid = fopen(fname, 'r');
HG = zeros([65536,1], 'uint32'); % Empty histogram
mindist_chunk = 1;
while (numel(mindist_chunk) > 0)
    mindist_chunk = fread(fid, chunk_size, 'uint8');    
    hg = df_histo16(uint16(mindist_chunk(:)));
    HG = HG+hg;    
end 
fclose(fid);
end


function plot_histogram(fname, HG, wip)
%% Plot the histogram

maxpos = find(HG > 0);
maxpos = maxpos(end);
if(wip > maxpos)
    wip = maxpos+1;
end

%keyboard
fig = figure;
for kk = 1:2
sp = subplot(1,2,kk)
bar(0:wip-1, HG(1:wip), 'FaceColor', [0, .6, 0])
hold on
bar(wip, HG(wip+1), 'b')
b = bar(wip+1:maxpos, HG(wip+2:maxpos+1), 'FaceColor', [1, .4, 0])
legend({'Final', 'Can grow', 'Not final'})
sp.XTick = 0:maxpos
if kk == 2
set(gca, 'YScale', 'log')
a = axis();
a(3) = 1-1e-5;
axis(a)

end
title(fname)
ylabel('#')
xlabel('Smallest distance')
end
if 0
    fig = figure;
    subplot(1,2,1)
    bar(0:maxpos, HG(1:maxpos+1))
    title(fname)
    ylabel('#')
    xlabel('Smallest distance')
    subplot(1,2,2)
    bar(0:maxpos, HG(1:maxpos+1))
    title(fname)
    ylabel('#')
    xlabel('Smallest distance')
    set(gca, 'YScale', 'log')
end

f = 1.2;
w = f*25;
h = f*10;
set(fig,'Units','centimeters',...
    'PaperUnits', 'centimeters', ...
    'PaperSize',[w h], ...
    'PaperPosition', [0,0,w,h], ...
    'PaperPositionMode', 'Manual')
drawnow()
img_name = [fname '_histogram.png'];
fprintf('Saving image to %s\n', img_name);
print('-dpng', img_name)
end
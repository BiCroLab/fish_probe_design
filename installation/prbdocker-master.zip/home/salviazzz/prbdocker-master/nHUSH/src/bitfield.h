#ifndef bitfield_h_
#define bitfield_h_

#include <assert.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>

// Set to 1 to enable some assert
#define bitfield_h_assert_ 0

typedef struct
{
    uint8_t * data;
    size_t N;
} bitfield_t;


bitfield_t *
bitfield_new_false(size_t N);

bitfield_t *
bitfield_new_true(size_t N);

void
bitfield_free(bitfield_t * F);

void
bitfield_set_false(bitfield_t * F, size_t N);

void
bitfield_set_true(bitfield_t * F, size_t N);

int
bitfield_get(const bitfield_t * F, size_t N);

#endif

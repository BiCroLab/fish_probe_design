function gen_scheme()
L = 20; % Sequence length
H = 15; % Initial hash length

C1 = [ones(1, H) zeros(1, L-H)];
C = C1;
k = 1
while max(min(C, [], 1)) == 1
    C = cat(1, C, circshift(C1, k*(L-H)));
    k = k+1;
end

% Garantees that all mismatches within distance 1 are found
assert( max(min(C, [], 1)) == 0 )

assert(captures_all(C, 1))

% For L=20, 49 is the best so far... using 15-mers
% worst is in theory infinite ...
% For L=12, and extending with 12-mers: 19 (in total)


M = genmm(L, 2);
for kk = 1:size(C,1)
    M = filtermm(M, C(kk,:));
end
%figure, imagesc(M), axis image


while captures_all(C, 2) == 0
    c = tricks_most(M, H);
    M = filtermm(M, c);
    C = cat(1, C, c);
end
size(C,1)

% This is a test to see that up to 2 mm passes?
P = ones(size(C,2));
for a = 1:size(C,1)
    for b = a+1:size(C,1)
        P = min(P, C(a,:)'*C(b,:));
    end
end

keyboard

template = [ones(1, 12), zeros(1, L-12)];
C1 = C;
best = 49;
for kk = 1:100000000
    C = C1;
    % random strategy
    while(captures_all(C, 2) == 0 && size(C,1) < best)        
        C = cat(1, C, template(randperm(L)) );
    end
    if(size(C,1) < best)
        best = size(C,1);
        best_C = C;
        disp(C)
        fprintf('Number of rows: %d\n', size(C,1));        
    end
end
 
fprintf('Best: Number of rows: %d\n', size(best_C,1));
keyboard
end

function y = captures_all(C, d)
y = 0;
if d == 1
    y = (max(min(C, [], 1)) == 0);
    return;
end

N = size(C,1);
L = size(C,2);

if d == 2    
    for kk = 1:L
        for ll = kk+1:L
            % Is there a good row?
            y = 0;
            for rr = 1:N
                if(C(rr, kk) == 0 && C(rr, ll) == 0)
                    y = 1;                    
                end
            end
            if y == 0
                return;
            end               
        end
    end
end

y = 1;
return;
end

function MM = genmm(L, n)
MM = [];
if n == 2
    for kk = 1:L
        for ll = kk+1:L
            M = zeros(1, L);
            M(kk) = 1;
            M(ll) = 1;
            MM = cat(1, MM, M);
        end
    end
end
end

function M = filtermm(M, c)
%keyboard
% M position of mismatches
% c: a hash comb, 1=using that position, 0=don't care
%figure, subplot(1,2,1), imagesc(M), axis image
tricked = c*M';
M = M(tricked ~= 0, :);
%subplot(1,2,2), imagesc(M), axis image

%keyboard

end

function best_c = tricks_most(M, H)
%keyboard
L = size(M,2);
c = [ones(1, H), zeros(1, L-H)];
best = size(filtermm(M, c), 1);
best_c = c;

for kk = 1:100000
    c = c(randperm(numel(c)));
    v = size(filtermm(M, c), 1);
    if v < best
        best = v;
        best_c = c;
    end
end
fprintf('best = %d reduction: %d\n', best, size(M,1)-best);

end


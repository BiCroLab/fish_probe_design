#ifndef __util_h__
#define __util_h__

#include <assert.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include "version.h"

double clockdiff(struct timespec* start, struct timespec * finish);

#define tictoc struct timespec tictoc_start, tictoc_end;
#define tic clock_gettime(CLOCK_REALTIME, &tictoc_start);
#define toc(X) {clock_gettime(CLOCK_REALTIME, &tictoc_end); printf(#X); printf(" %f s\n", clockdiff(&tictoc_end, &tictoc_start)); fflush(stdout);};

/* Get peak memory usage from /proc/PID/status */
size_t get_peakMemoryKB(void);

/* Print out peak memory usage */
void fprint_peakMemory(FILE * fout);



/* Print ISO time with a message  */
void print_time(FILE * f, char * msg);

/* Print out the nHUSH version to stdout */
void show_version();

/* Get the size of an open file, rewinds to beginning */
size_t FILE_size(FILE * fid);

/* Filter to keep only unique elements, use qsort first
 * returns the number of unique elements items beyond that
 * are undefined */
size_t unique(void * data, size_t nmemb, size_t size,
              int (*)(const void *, const void*));

#endif

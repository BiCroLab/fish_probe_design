#ifndef __mindist_stats_h__
#define __mindist_stats_h__

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Load and print out statistics from a mindist file */
int mindists_stats(int argc, char ** argv);

/* To be moved to a common file ... */
uint8_t * md_read(const char * file, size_t * fsize);

#endif

#include "mindist_gen_mask_lua.h"

typedef struct{
    FILE * outfile; /* For redirecting stdout to something else */
    fasta_records_t * records;
    size_t genome_size;
    uint8_t * mask;
} gen_mask_data_t;


static int cb_select_all(lua_State * L)
{
    lua_getglobal(L, "gen_mask_config");
    gen_mask_data_t * config = (gen_mask_data_t *) lua_touserdata(L, -1);
    assert(config != NULL);
    memset(config->mask, 1, config->genome_size);
    return 0;
}

static int cb_unselect_all(lua_State * L)
{
    lua_getglobal(L, "gen_mask_config");
    gen_mask_data_t * config = (gen_mask_data_t *) lua_touserdata(L, -1);
    assert(config != NULL);
    memset(config->mask, 0, config->genome_size);
    return 0;
}

static int set_region(lua_State * L, uint8_t mask_value)
{
    lua_getglobal(L, "gen_mask_config");
    gen_mask_data_t * conf = (gen_mask_data_t *) lua_touserdata(L, -1);
    assert(conf != NULL);

    const char * record = lua_tostring(L, 1);
    if(record == NULL)
    {
        printf("chromosome/record not specified\n");
        exit(EXIT_FAILURE);
        return 0;
    }

    const char * startpos_str = lua_tostring(L, 2);
    if(startpos_str == NULL)
    {
        printf("start position not specified\n");
        exit(EXIT_FAILURE);
        return 0;
    }

    const char * endpos_str = lua_tostring(L, 3);
    if(endpos_str == NULL)
    {
        printf("start position not specified\n");
        exit(EXIT_FAILURE);
        return 0;
    }

    long int startpos = atol(startpos_str);
    long int endpos = atol(endpos_str);


    if(startpos > endpos)
    {
        printf("The start position can not be after then end position\n");
        return 0;
    }

    if(startpos < 0)
    {
        printf("The start position has to be positive\n");
        return 0;
    }

    fprintf(conf->outfile, "Selecting %s [%ld -- %ld] \n", record, startpos, endpos);

    // Find ONE matching record or fail
    int match = -1;
    int nmatch = 0;
    for(size_t kk = 0; kk<conf->records->n; kk++)
    {
        if(strcasestr( conf->records->name[kk], record))
        {
            match = kk;
            nmatch++;
        }
    }

    if(nmatch < 1)
    {
        printf("Could not find any record that match '%s'\n", record);
        return 0;
    }

    if(nmatch > 1)
    {
        printf("Found %d matches for '%s', please be more specific!\n", nmatch, record);
        return 0;
    }

    fprintf(conf->outfile, "Matching record: '%s'\n", conf->records->name[match]);

    if((size_t) endpos >= conf->records->len[match])
    {
        fprintf(stderr, "The end pos (%ld) >= the size of the chromosome (%ld)\n",
               endpos, conf->records->len[match]);
        exit(EXIT_FAILURE);
        return 0;
    }

    size_t global_first = conf->records->pos[match] + startpos;
    size_t global_end = global_first + endpos - startpos;
    fprintf(conf->outfile, "Will set pos [%zu, %zu] to 1\n", global_first, global_end);
    for(size_t kk = global_first; kk <= global_end; kk++)
    {
        conf->mask[kk] = mask_value;
    }
    fprintf(conf->outfile, "done\n");

    return 0;
}

static int cb_select_region(lua_State * L)
{
    return set_region(L, 1);
}

static int cb_unselect_region(lua_State * L)
{
    return set_region(L, 0);
}

uint8_t *
mindist_gen_mask_lua(FILE * outfile,
                     const char * script_file,
                     fasta_records_t * records,
                     size_t genome_size)
{
    gen_mask_data_t conf = {};
    conf.outfile = outfile;
    conf.records = records;
    conf.mask = calloc(genome_size, 1);
    conf.genome_size = genome_size;

    lua_State * L = luaL_newstate();
    lua_pushlightuserdata(L, &conf);
    lua_setglobal(L, "gen_mask_config");

    lua_register(L, "mask_all", cb_unselect_all);
    lua_register(L, "unmask_all", cb_select_all);
    lua_register(L, "mask_region", cb_unselect_region);
    lua_register(L, "unmask_region", cb_select_region);
    int ret = luaL_dofile(L, script_file);
    if(ret)
    {
        fprintf(stderr, "Failed to parse %s\n", script_file);
        fprintf(stderr, "Error: %s", lua_tostring(L, -1));
        exit(EXIT_FAILURE);
    }
    lua_close(L);

    return conf.mask;
}

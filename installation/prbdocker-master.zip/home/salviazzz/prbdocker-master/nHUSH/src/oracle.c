#include "oracle.h"

/** TODO:
 * Read/write to table
 * See if there is any correlation to Abp (no just on a low Abp dataset)
 * If full RC: correction factor 1/2
 */

typedef struct {
    char * genome_file;
    uint8_t * genome_data;
    size_t genome_size;
    char * out_file;
    char * table_file;
    char * query_file;
    /* Length of sequences in table */
    size_t length;
    /* Tables of size 4^length */
    uint32_t * counts;
    float * prob;
    int verbose;
    size_t sum;
    int argc;
    char ** argv;
} oracle_t;

static oracle_t * oracle_new(void)
{
    oracle_t * conf = calloc(1, sizeof(oracle_t));
    conf->verbose = 1;
    conf->length = 8;
    return conf;
}

static void oracle_free(oracle_t * conf)
{
    free(conf->genome_data);
    free(conf->genome_file);
    free(conf->counts);
    free(conf->table_file);
    free(conf->query_file);
    free(conf);
}

static void oracle_help(void)
{
    printf("The nHUSH oracle\n");
    printf("--genome <file>"
           "\n\t fasta file with genome\n");
    printf("--length l"
           "\n\t length of sub sequences in probability table. Default=8\n"
           "\n\t recommended=16 which will generate a 16 GB database for T2T\n");
    printf("--out <file>"
           "\n\t file to write to\n");
    printf("--query <file>"
           "\n\t fasta file with query sequences\n");
    return;
}

static oracle_t * oracle_new_from_cli(int argc, char ** argv)
{
    oracle_t * conf = oracle_new();
    conf->argc = argc;
    conf->argv = argv;

    struct option longopts[] = {
        { "genome",       required_argument, NULL,   'G' },
        { "help",         no_argument,       NULL,   'H' },
        { "length",       required_argument, NULL,   'L' },
        { "out",          required_argument, NULL,   'O' },
        { "query",        required_argument, NULL,   'Q' },
        { "verbose",      required_argument, NULL,   'v' },
        { "version",      no_argument,       NULL,   'V' },

        { NULL,           0,                 NULL,   0   }
    };
    int ch;
    while((ch = getopt_long(argc, argv,
                            "G:HL:O:Q:Vv:",
                            longopts, NULL)) != -1)
    {
        switch(ch)
        {
        case 'G':
            free(conf->genome_file);
            conf->genome_file = strdup(optarg);
            break;
        case 'H':
            oracle_help();
            exit(EXIT_SUCCESS);
            break;
        case 'L':
            conf->length = atoi(optarg);
            break;
        case 'O':
            free(conf->out_file);
            conf->out_file = strdup(optarg);
            break;
        case 'Q':
            free(conf->query_file);
            conf->query_file = strdup(optarg);
            break;
        case 'v':
            conf->verbose = atoi(optarg);
            break;
        case 'V':
            show_version();
            break;
        case '?':
            fprintf(stderr, "Unknown argument used\n");
            exit(EXIT_FAILURE);
        }
    }

    /** Validate input arguments */
    int arguments_ok = 1;
    if(conf->genome_file == NULL)
    {
        printf(" ! --genome missing\n");
        arguments_ok = 0;
    }

    if(! arguments_ok)
    {
        printf("Error: Required arguments missing\n");
        exit(EXIT_FAILURE);
    }

    conf->table_file = calloc(256, 1);
    sprintf(conf->table_file, "oracle_table_%zu.u32", conf->length);

    return conf;
}

static size_t oracle_hash_encoded(size_t length, const uint8_t * encoded_str)
{
    size_t hash = 0;
    size_t multiplier = 1;
    for(size_t ll = 0; ll < length; ll++)
    {
        hash += multiplier*encoded_str[ll];
        multiplier *= 4;
    }
    return hash;
}

static size_t oracle_hash_encoded_rc(size_t length, const uint8_t * encoded_str)
{
    size_t hash = 0;
    size_t multiplier = 1;
    for(size_t ll = 0; ll < length; ll++)
    {
        hash += multiplier*(3-encoded_str[length-ll-1]);
        multiplier *= 4;
    }
    return hash;
}

static size_t oracle_hash_raw(size_t length, const char * str)
{
    size_t hash = 0;
    size_t multiplier = 1;
    for(size_t ll = 0; ll < length; ll++)
    {
        uint8_t val = map_char_to_val(str[ll]);
        hash += multiplier*val;
        multiplier *= 4;
    }
    return hash;
}


static void oracle_gen_table(oracle_t * conf)
{
    size_t table_size = powl(4, conf->length);
    conf->counts = calloc(table_size, sizeof(uint32_t));

    for(size_t kk = 0; kk<conf->genome_size - conf->length; kk++)
    {
        size_t hash = oracle_hash_encoded(conf->length, conf->genome_data+kk);
        conf->counts[hash]++;
        hash = oracle_hash_encoded_rc(conf->length, conf->genome_data+kk);
        conf->counts[hash]++;
    }
    return;
}

static void print_seq_from_hash(size_t h, size_t l)
{
    size_t denom = powl(4, l-1);
    for(int kk = 0; kk < (int) l; kk++)
    {
        int n = h/denom;
        switch(n)
        {
        case numA:
            printf("A");
            break;
        case numT:
            printf("T");
            break;
        case numC:
            printf("C");
            break;
        case numG:
            printf("G");
            break;
        default:
            printf("?");
        }
        h = h - denom*n;
        denom/=4;
    }
}

static void oracle_show_table(oracle_t * conf)
{
    size_t sum = 0;
    size_t table_size = powl(4, conf->length);
    size_t first = 0;
    size_t min = conf->counts[0];
    size_t max = conf->counts[0];

    for(size_t kk = 0; kk<table_size; kk++)
    {
        sum+=conf->counts[kk];
        conf->counts[kk] < min ? min = conf->counts[kk] : 0;
        conf->counts[kk] > max ? max = conf->counts[kk] : 0;
    }
    conf->sum = sum;
    if(conf->out_file)
    {
        return;
    }

    if(table_size > 80)
    {
        first = table_size - 80;
    }
    if(first > 0)
    {
        printf("...\n");
    }


    for(size_t kk = first; kk<table_size; kk++)
    {
        print_seq_from_hash(kk, conf->length);
        printf("[%zu] = %9u, p=%e\n", kk, conf->counts[kk],
               (double) conf->counts[kk] / (double) sum);
    }
    printf("sum=%zu (min=%zu, max=%zu)\n", sum, min, max);

    return;
}

static void oracle_save_table(oracle_t * conf)
{

    FILE * fid = fopen(conf->table_file, "w");
    if(fid == NULL)
    {
        printf("Unable to open %s for writing\n", conf->table_file);
    }
    size_t nelements = powl(4, conf->length);
    size_t nwritten = fwrite(conf->counts, sizeof(uint32_t), nelements, fid);
    if(conf->verbose > 0)
    {
        printf("Wrote %zu u32 to %s\n", nwritten, conf->table_file);
    }
    if(nwritten != nelements)
    {
        fprintf(stderr, "Expected to write %zu elements, wrote %zu\n",
                nelements, nwritten);
        exit(EXIT_FAILURE);
    }
    return;
}

static int oracle_load_table(oracle_t * conf)
{
    FILE * fid = fopen(conf->table_file, "r");
    if(fid == NULL)
    {
        return EXIT_FAILURE;
    }
    size_t fsize = FILE_size(fid);
    conf->counts = calloc(fsize, 1);
    size_t nelements = powl(4, conf->length);
    size_t nread = fread(conf->counts, sizeof(uint32_t), nelements, fid);
    if(nread != nelements)
    {
        fprintf(stderr, "Read %zu elements, expected %zu\n", nread, nelements);
        exit(EXIT_FAILURE);
    }
    return EXIT_SUCCESS;
}

static double oracle_lookup_full(oracle_t * conf, const char * str)
{
    size_t h = oracle_hash_raw(conf->length, str);
    //printf("T[%zu] = %u, sum= %zu\n", h, conf->counts[h], conf->sum);
    return (double) conf->counts[h]/ (double) conf->sum;
}

static double oracle_lookup_conditional(oracle_t * conf, const char * str)
{
    size_t h = oracle_hash_raw(conf->length, str);
    size_t base_hash = (h/4)*4;

    size_t n = conf->counts[h];
    size_t ndiv = 0;
    for(size_t kk = 0; kk<4; kk++)
    {
        ndiv += conf->counts[base_hash+kk];
    }
    if(ndiv == 0)
    {
        return 0;
    }
    return (double) n / (double) ndiv;
}

static void reverse_complement_raw(char * str)
{
    size_t len = strlen(str);
    for(size_t kk = 0; kk < len/2; kk++)
    {
        char t = str[kk];
        str[kk] = str[len-kk-1];
        str[len-kk-1] = t;
    }
    for(size_t kk = 0; kk<len; kk++)
    {
        char c = toupper(str[kk]);
        switch(c)
        {
        case 'A':
            str[kk] = 'T';
            break;
        case 'T':
            str[kk] = 'A';
            break;
        case 'C':
            str[kk] = 'G';
            break;
        case 'G':
            str[kk] = 'C';
            break;
        default:
            str[kk] = '?';
            break;
        }
    }
    return;
}

static double oracle_predict(oracle_t * conf, const char * prompt)
{
    size_t n = strlen(prompt);

    if(n < conf->length)
    {
        return -1;
    }

    /* Lookup the first conf->length letters */
    double p = oracle_lookup_full(conf, prompt);
    for(size_t kk = 1; kk+conf->length <= n; kk++)
    {
        p*=oracle_lookup_conditional(conf, prompt+kk);
    }
    return p;
}

static void oracle_scan_query(oracle_t * conf)
{
    FILE * out = stdout;
    FILE * log = NULL;
    if(conf->out_file)
    {
        out = fopen(conf->out_file, "w");
        if(out == NULL)
        {
            fprintf(stdout, "Unable to open %s for writing\n", conf->out_file);
        }
        char * logfile = malloc(strlen(conf->out_file) + 16);
        sprintf(logfile, "%s.log.txt", conf->out_file);
        log = fopen(logfile, "w");
        fprintf(log, "log file for %s\n", conf->out_file);
        fprintf(log, "generated with nHUSH oracle v%s.%s.%s\n",
                NHUSH_VERSION_MAJOR, NHUSH_VERSION_MINOR, NHUSH_VERSION_PATCH);
        fprintf(log, "cmd: ");
        for(int kk = 0; kk<conf->argc; kk++)
        {
            fprintf(log, "'%s' ", conf->argv[kk]);
        }
        fprintf(log, "\n");
        fclose(log);
        free(logfile);
    }
    FILE * fid = fopen(conf->query_file, "r");
    char * line = NULL;
    size_t n = 0;
    ssize_t len;


    while( (len = getline(&line, &n, fid) ) != -1)
    {
        if(len == 0) {
            continue;
        }

        /* Remove line break */
        if((line[len-1] == '\n') | (line[len-1] == '\r')) {
            line[len-1] = '\0';
            len--;
        }

        if( (line[len-1] == '\n') | (line[len-1] == '\r')) {
            line[len-1] = '\0';
            len--;
        }
        #if 0
        int pos = 0;
        while(line[pos] != 0)
        {
            printf("%03u ", line[pos]);
            pos++;
        }
        printf("'%s'\n\n", line);
        fflush(stdout);
#endif
        if(line[0] == '>') {
            fprintf(out, "%s, ", line);
            continue;
        }

        double p1 = oracle_predict(conf, line);
        char * rc_line = strdup(line);
        reverse_complement_raw(rc_line);

        // This is good to have :)
        double p2 = oracle_predict(conf, rc_line);
        //printf("%e %e %e\n", p1, p2, p1-p2);
        p2 > p1 ? p1 = p2 : 0;

        double n_on_genome = p1 * (double) conf->sum;
        fprintf(out, "%s, %e\n", line, n_on_genome);
        free(rc_line);
    }

    free(line);

    if(out != stdout)
    {
        fclose(out);
    }
    fclose(fid);
    return;
}

int oracle(int argc, char ** argv)
{
    oracle_t * conf = oracle_new_from_cli(argc, argv);

    printf("Retrieving probabilities\n");

    if(oracle_load_table(conf))
    {
        printf("Reading genome\n");
        fasta_records_t * records = NULL;
        conf->genome_data = readfa(conf->genome_file, &conf->genome_size, &records);
        fasta_records_free(&records);

        if(conf->genome_data == NULL)
        {
            printf("Unable to read %s\n", conf->genome_file);
            exit(EXIT_FAILURE);
        }

        if(conf->verbose > 0)
        {
            printf("Read genome of size %zu\n", conf->genome_size);
        }
        printf("Calculating probabilites\n");
        oracle_gen_table(conf);
        oracle_save_table(conf);
    }

    oracle_show_table(conf);

    if(conf->query_file) {
        struct timespec t0, t1;
        clock_gettime(CLOCK_REALTIME, &t0);
        oracle_scan_query(conf);
        clock_gettime(CLOCK_REALTIME, &t1);

        if(conf->verbose > 0)
        {
            printf("Scanning took %f s\n", clockdiff(&t1, &t0));
        }
        goto done;
    }

    using_history();    /* initialize history */
    char * prompt = NULL;
    while( (prompt = readline("FISH-O> ")) )
    {
        if(strlen(prompt) == 0)
            continue;

        add_history(prompt);

        printf("'%s' : ", prompt);
        double p1 = oracle_predict(conf, prompt);
        printf("p=%e (random genome: %e)\n",
               p1,
               (double) 1.0 / (double) powl(4, strlen(prompt)) );
        reverse_complement_raw(prompt);
        printf("'%s' : ", prompt);

        double p2 = oracle_predict(conf, prompt);
        printf("p=%e (random genome: %e)\n",
               p2,
               (double) 1.0 / (double) powl(4, strlen(prompt)) );
        p2 > p1 ? p1 = p2 : 0;
        printf("-> %e or %f on this genome\n",
               p1,
               p1 * (double) conf->sum);
        free(prompt);
    }

    // TODO history_free ?

 done: ;

    oracle_free(conf);
    return EXIT_SUCCESS;
}

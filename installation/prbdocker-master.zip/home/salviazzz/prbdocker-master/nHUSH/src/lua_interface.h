#pragma once
#define _GNU_SOURCE

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>
#include <readline/readline.h>
#include <readline/history.h>

#include "eq_classes.h"
#include "count_sort.h"

int nhush_lua_repl(int argc, char ** argv);

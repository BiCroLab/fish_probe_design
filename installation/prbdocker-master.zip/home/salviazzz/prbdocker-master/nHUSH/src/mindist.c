#include "mindist.h"

/* PROBB TODO:
 * - How to organize data on hits?
 * - Only write matches < some relevant radius*multiplicity
 *   if pb > 1/N ? (That is HD 16!)
 *   Something larger seems better... say 1e-5.
 *   make it minpb
 *   i.e. if(pb > minpb) { write/store contact }.
 *   data storage will be too large if genome vs genome is scanned,
 *   start with the case with fasta file vs genome.
 */

static uint8_t
hamming_distance(const uint8_t * A, const uint8_t * B, const int L)
{
    int d = 0;
    for(int kk = 0; kk<L; kk++)
    {
        if(A[kk] != B[kk])
        {
            d++;
        }
    }
    return d;
}

/* This was used for testing and can be removed */
static uint8_t *  gen_hash_filter(size_t L, size_t h)
{
    /* Generate a binary mask of size L
       where h elements are set to 1,
       remaining set to 0*/

    assert(L != 0);
    uint8_t * A = calloc(L, 1);

    size_t sum = 0;
    while(sum != h)
    {
        uint32_t pos = rand() % L;
        if(A[pos] == 0)
        {
            A[pos] = 1;
            sum++;
        }
    }
    return A;
}

int cmp_match_record(const void * _A, const void *_B)
{
    match_record_t * A = (match_record_t*) _A;
    match_record_t * B = (match_record_t*) _B;


    if(A->seq_id < B->seq_id)
    {
        return -1;
    }
    if(A->seq_id > B->seq_id)
    {
        return 1;
    }
    // A->seq_id == B->seq_id
    if(A->target_id < B->target_id)
    {
        return -1;
    }
    if(A->target_id > B->target_id)
    {
        return 1;
    }
    if(A->pb < B->pb)
    {
        return -1;
    }
    if(A->pb > B->pb)
    {
        return 1;
    }
    return 0;
}

match_record_t * match_record_read(const char * fname, size_t * _N)
{
    match_record_t * match_records = NULL;
    FILE * fid = fopen(fname, "r");
    assert(fid != NULL);
    size_t file_size = FILE_size(fid);
    size_t N = file_size / sizeof(match_record_t);
    match_records = malloc(file_size);
    size_t nread = fread(match_records, sizeof(match_record_t), N, fid);
    if(nread != N)
    {
        fprintf(stderr, "Failed to read from %s\n", fname);
        fprintf(stderr, "Got %zu, expected %zu\n", nread, N);
        fclose(fid);
        free(match_records);
        return NULL;
    }
    *_N = N;
    return match_records;
}

int match_record_write(const match_record_t * match_records, const char * match_file, const size_t N)
{
    FILE * fid = fopen(match_file, "w");
    if(fid == NULL)
    {
        fprintf(stderr, "Unable to open %s for writing\n", match_file);
        exit(EXIT_FAILURE);
    }
    size_t nwritten = fwrite(match_records, sizeof(match_record_t), N, fid);
    if(nwritten != N)
    {
        fprintf(stderr, "Unable to write to %s\n", match_file);
        fclose(fid);
        exit(EXIT_FAILURE);
    }

    fclose(fid);
    return EXIT_SUCCESS;
}

/* Was used for testing and can be removed */
uint8_t * gen_hash_filter_debug(size_t L, size_t h)
{
    uint8_t * hash_filter = malloc(L);
    for(size_t kk = 0; kk < h; kk++)
    {
        hash_filter[kk] = 1;
    }
    for(size_t kk = h; kk < L; kk++)
    {
        hash_filter[kk] = 0;
    }
    return hash_filter;
}

uint32_t chash(const uint8_t * restrict S, /* sequence mapped to 0,1,2,3 */
               const uint32_t * restrict C, /* hash Comb */
               const size_t L) /* Length of sequence */
{
    size_t h = 0;
    for(size_t kk = 0; kk<L; kk++)
    {
        h += (uint32_t) S[kk] * C[kk];
    }
    return h;
}

uint8_t * genome_random(const size_t genome_size)
{
    uint8_t * genome = malloc(genome_size);
    for(size_t kk = 0; kk<genome_size; kk++)
    {
        genome[kk] = rand() % 4;
    }

    return genome;
}

uint32_t * chash_gen_comb(const uint8_t * hash_filter, size_t L, int h)
{
    const int show = 0;
    uint32_t v = powl(4, h-1);
    uint32_t * C = calloc(L, sizeof(uint32_t));
    if(show){
        printf("Comb=");
    }
    for(size_t kk = 0; kk<L; kk++)
    {
        if(hash_filter[kk] == 1)
        {
            C[kk] = v;
            v/=4;
        }
        if(show){
            printf("%u ", C[kk]);
        }
    }
    if(show)
    {
        printf("\n");
    }
    return C;
}

/** HASH all sequences of interest on the genome
 *
 * @param[out] _nchashes number of hashed sequences
 * @out an array with hash values
 */
uintG_t * chash_hash_genome(const uint8_t * genome, const size_t genome_size,
                            const uintG_t * restrict hash_comb, const size_t L,
                            size_t * _nchashes)
{
    size_t nchashes = (genome_size-L+1);
    uint32_t * chashes = malloc(nchashes*sizeof(uint32_t));

#pragma omp parallel for
    for(size_t gg = 0; gg < nchashes; gg++)
    {
        chashes[gg] = chash(genome+gg, hash_comb, L);
    }

    _nchashes[0] = nchashes;
    return chashes;
}


uintG_t * get_bucket_sizes(conf_t * conf,
                           const uint32_t * restrict chashes,
                           const size_t nchashes)
{
    int h = conf->h;
    uint8_t * ulist = conf->ulist;
    uintG_t * restrict _bsize = calloc(powl(4, h)+2, sizeof(uintG_t));
    if(_bsize == NULL)
    {
        fprintf(stderr, "Allocation failed at line %d\n", __LINE__);
        exit(EXIT_FAILURE);
    }
    //tictoc;

    uintG_t * bsize = _bsize+2; /* NOTE: SHIFTED 2 steps RIGHT */
    //tic;


#pragma omp parallel for shared(bsize)
    for(size_t kk = 0; kk<nchashes; kk++)
    {
        if(ulist[kk] == 1)
        {
#pragma omp atomic
            bsize[(size_t) chashes[kk]]++;
        }
    }
    //toc("gen_bucket_sizes");
    return _bsize;
}


/* See test/cumsum_inplace.c for slower alternative */
void cumsum_inplace(uintG_t * restrict B, const size_t n)
{
    size_t sum = 0;
    for(size_t kk = 0; kk < n; kk++)
    {
        sum+=B[kk];
        B[kk]=sum;
    }
    return;
}

/* This function is called after certain Hamming distances are reached
 * to remove sequences with low multiplicity that does not add up to
 * the accumulated binding probability (abp) any more. */
void abp_reduce_ulist(conf_t * conf, size_t minmult)
{
    for(size_t kk = 0; kk<conf->nG; kk++)
    {
        if(conf->multiplicity[kk] < minmult)
        {
            conf->ulist[kk] = 0;
        }
    }
    return;
}

uintG_t * place_in_buckets(conf_t * conf, uintG_t * restrict B,
                           const uint32_t * restrict chashes,
                           const size_t nchashes)
{
    /* Returns pointers to the genome so that it is sorted in the
       buckets
       NOTE: This alters B so that B[i] is no longer the start position
       of bucket B, rather the end position.*/

    uintG_t * restrict S = malloc(nchashes*sizeof(uintG_t));
    /* Can this be faster with explicit pre-fetching?
       https://gcc.gnu.org/onlinedocs/gcc/Other-Builtins.html
       __builtin_prefetch(const void * addr, rw, loc)
       rw:  Read or write? 0 = read, 1 = write, default: 0
       loc: Locality, default: 3
    */


    //    struct timespec tstart, tend; clock_gettime(CLOCK_REALTIME, &tstart);

    const uint8_t * ulist = conf->ulist;

    // TODO: figure out how to parallelise in a meaningful way

    for(size_t kk = 0; kk < nchashes; kk++)
    {
        if(ulist[kk] == 0)
            continue;
        /* Hand tuned optimizations:
         *  - 100 M entries and 4^14 buckets, from 3.4 to 2.8 s
         * Unfortunately it seems problem size dependent, for
         *  - 1 G entries and 4^14 buckets, from to 68 s to 66 s
         * see https://gcc.gnu.org/onlinedocs/gcc/Other-Builtins.html
         */
        __builtin_prefetch((const void*) &B[chashes[kk + 32]], 0, 2);
        __builtin_prefetch((const void*) &S[B[chashes[kk + 4]]], 0, 2);
        S[B[chashes[kk]]++] = kk;
    }

    return S;
}

uintG_t * place_in_buckets_parallel(conf_t * conf, uintG_t * restrict B,
                                    const uint32_t * restrict chashes,
                                    const size_t nchashes)
{
    /* Returns pointers to the genome so that it is sorted in the
       buckets
       NOTE: This alters B so that B[i] is no longer the start position
       of bucket B, rather the end position.*/

    uintG_t * restrict S = malloc(nchashes*sizeof(uintG_t));

    const uint8_t * ulist = conf->ulist;

    /* TODO: figure out how to do this more efficient only 30% faster
     * than the single threaded version on a 4-cores machine This
     * version avoids the mod operator (%) but is affected by the
     * skewed distribution of the underlying hash values in the sense
     * that a few threads lack behind after all the other have finished
     *
     */

#pragma omp parallel
    {
        const size_t th_num = omp_get_thread_num();
        const size_t th_tot = omp_get_num_threads();

        /* Decide what hash values this thread should handle */
        size_t lower = th_num * conf->nbuckets / th_tot;
        size_t upper = (th_num+1) * conf->nbuckets / th_tot;

        // avoid mod, divide B into th_tot regions instead

        for(size_t kk = 0; kk < nchashes; kk++)
        {
            if(ulist[kk] == 0)
                continue;

            uintG_t hash = chashes[kk];
            if(hash >= lower)
            {
                if(hash < upper)
                {
                    S[B[hash]++] = kk;
                }
            }
        }
    }

    return S;
}


conf_t * conf_new()
{
    conf_t * conf = calloc(1, sizeof(conf_t));
    conf->G = NULL;
    conf->nG = 0;
    conf->L = 40;
    conf->verbose = 1;
    conf->ask = 0;
    conf->fname = NULL;
    conf->outname = NULL;
    conf->n_rounds = 10000;
    conf->until_mm = 10000;
    conf->d_discard = 1;
#ifdef __APPLE__
    conf->nthreads = 1;
#else
    conf->nthreads = get_nprocs();
#endif
    conf->srand = 1;
    conf->fname_embraced = NULL;
    conf->fname_log = NULL;
    conf->ulist = NULL;

    conf->comb = NULL;
    conf->G_records = NULL;
    conf->mode = MODE_FULL;
    conf->query_mode = QUERY_GENOME;

    conf->Q = NULL;
    conf->nseq_query = 0;
    conf->qfname = NULL;
    conf->skip_first_perfect = 0;

    conf->abp_max = 5;

    /* More initialization after conf_argparse */
    return conf;
}

void nfree(void * p)
{
    if(p != NULL)
    {
        free(p);
    }
}

void conf_free(conf_t ** _conf)
{
    conf_t * conf = _conf[0];
    nfree(conf->G);
    nfree(conf->fname);
    nfree(conf->outname);
    nfree(conf->fname_embraced);
    nfree(conf->ulist);
    free(conf->qfname);

    if(conf->log != NULL)
    {
        fclose(conf->log);
    }
    nfree(conf->fname_log);
    nfree(conf->fname_comb);
    comb_free(&conf->comb);
    if(conf->G_records != NULL)
    {
        fasta_records_free(&conf->G_records);
    }
    free(conf->abp);
    free(conf->multiplicity);

    free(conf->genome_mask);
    free(conf->genome_mask_script);
    free(conf->query_mask);
    free(conf->query_mask_script);

    free(conf);
    _conf[0] = NULL;
}

void conf_show(FILE * f, conf_t * conf)
{
    fprintf(f, "-> Configuration:\n");
    fprintf(f, "   L=%zu\t sequence length\n", conf->L);
    fprintf(f, "   n_rounds=%d\n", conf->n_rounds);
    fprintf(f, "   verbose=%d\n", conf->verbose);
    fprintf(f, "   T = %d number of threads\n", conf->nthreads);
    if(conf->fname != NULL)
    {
        fprintf(f, "   Genome: %s\n", conf->fname);
    }
    if(conf->qfname != NULL && conf->query_mode == QUERY_EXTERNAL)
    {
        fprintf(f, "   Query file: %s\n", conf->qfname);
    }
    if(conf->outname != NULL)
    {
        fprintf(f, "   Outfile: %s\n", conf->outname);
    }
    if(conf->srand == 1)
    {
        fprintf(f, "   Random seed: time\n");
    } else {
        fprintf(f, "   random seed: 0\n");
    }
    fprintf(f, "   H=%zu\t initial HASH length\n", conf->h);

    fprintf(f, "   %zu\t initial number of buckets\n", conf->nbuckets);

    if(conf->mode == MODE_DISCARD)
    {
        fprintf(f, "   mode: DISCARD\n");
        fprintf(f, "   D=%d Hamming discard radius\n", conf->d_discard);
    }
    if(conf->mode == MODE_FULL)
    {
        fprintf(f, "   mode: FULL / EXHAUSTIVE\n");
    }
    if(conf->query_mode == QUERY_GENOME)
    {
        fprintf(f, "   query mode: Genome vs self\n");
    }
    if(conf->query_mode == QUERY_EXTERNAL)
    {
        fprintf(f, "   query mode: External list vs genome\n");
    }
    if(conf->until_mm >= 0)
    {
        fprintf(f, "   Until all matches <= %d are found\n", conf->until_mm);
    }
    if(conf->skip_first_perfect)
    {
        fprintf(f, "   skipping the first perfect match\n");
    } else {
        fprintf(f, "   NOT skipping perfect matches\n");
    }
    fprintf(f, "   comb strategy: v 3.0\n");
    if(conf->comb != NULL)
    {
        if(conf->comb->N > 0)
        {
            fprintf(f, "   Hash combs used so far:\n");
            comb_fprint(f, conf->comb);
        } else {
            fprintf(f, "   No combs used yet\n");
        }
    }
}

int mindist_write(conf_t * conf, uint8_t * mindist)
{
    return write_uint8(conf->outname,
                       mindist,
                       conf->nseq_query);
}

void query_seq_bucket(conf_t * conf,
                      const uint8_t * _seq,
                      const uint32_t seq_id,
                      uint8_t * seq_reverse, /* buffer */
                      const uint32_t * restrict hash_comb,
                      const uint32_t * restrict B,
                      const uint32_t * restrict B_genome,
                      uint8_t * mindist,
                      const size_t kk,
                      const int RC,
                      FILE * pb_outfile)
{
    /* Query one sequence against all other in the same bucket */
    const uint8_t * seq = _seq;
    const size_t L = conf->L;

    conf->min_pb = 1e-6; // TODO place earlier and make command line argument

    if(RC == 1)
    {
        reverse_complement(seq_reverse, _seq, L);
        seq = seq_reverse;
    }

    const uint32_t h = chash(seq, hash_comb, L);
    assert(B[0] == 0);
    const uintG_t bucket_start = B[h];
    const uintG_t bucket_end = B[h+1];
    const int HR = conf->d_discard; /* Hamming Radius */
    const int query_mode = conf->query_mode;
    const int skip_first_perfect = conf->skip_first_perfect;

    size_t n_perfect = 0; /* Number of perfect matches */

    for(size_t ll = bucket_start; ll<bucket_end; ll++)
    {
        if(conf->mode != MODE_PROBB)
        {
            if(mindist[kk] <= HR)
            {
                break; /* break ll-loop */
            }
        }

        size_t n_seq_id = B_genome[ll];
        uint8_t * n_seq = conf->G + n_seq_id;

        /* TODO: benchmark prefetching here */
        // __builtin_prefetch((const void*) &conf->G + B_genome[ll+1]);

        int hd = hamming_distance(seq, n_seq, L);

        if(query_mode == QUERY_EXTERNAL)
        {
            /* Set to zero only if more than one perfect match
             *  this works since all perfect matches will be in the
             *  same bin */
            if(conf->mode == MODE_PROBB) // #PB_WRITE
            {
                /* Write to disk if pb is low enough */
                double pb = pow(4.0,-(double) hd)
                    *(double) conf->multiplicity[n_seq_id];
                if(pb > conf->min_pb)
                {
                    match_record_t mr;
                    mr.seq_id = seq_id;
                    mr.target_id = n_seq_id;
                    mr.pb = pb;
                    fwrite(&mr, 1, sizeof(match_record_t), pb_outfile);
                    //printf("%u to %u hd=%d pb = %f\n", mr.seq_id, mr.target_id, hd, pb);
                }
                // array_append(seq specific array,  [seq_id, n_seq_id, pb] )

            } else {
                if( skip_first_perfect == 1)
                {
                    if(hd == 0)
                    {
                        n_perfect++;
                        if(n_perfect > 1)
                        {
                            mindist[kk] = 0;
                        }
                    } else {
                        mindist[kk] = hd;
                    }
                } else {
                    if(hd <= mindist[kk])
                    {
                        mindist[kk] = hd;
                    }
                }
            }
        }


        if(query_mode == QUERY_GENOME)
        {
            if(conf->mode == MODE_PROBB)
            {
                // TODO -- write to disk
            } else {
                if(n_seq != _seq) /* No self-compares */
                {
                    if(hd <= mindist[kk])
                    {
                        mindist[kk] = hd;
                    }
                }
            }
            /* Check that the neighbor seq is in the same bucket */
            assert(h == chash(n_seq, hash_comb, L));
        }
    }

    return;
}


void * filter_matches_thread(void * _tdata)
{

    filter_matches_t * tdata = (filter_matches_t*) _tdata;
    conf_t * conf = tdata->conf;
    assert(conf->abp != NULL);

    // Set file name for thread,
    char * match_file = calloc(strlen(conf->qfname) + 32, 1);
    assert(match_file != NULL);
    sprintf(match_file, "%s.match%03d", conf->qfname, tdata->thread);
    // extract and sort for each probe
    size_t NM = 0;
    match_record_t * match_records = match_record_read(match_file, &NM);
    if(match_records == NULL)
    {
        exit(EXIT_FAILURE);
    }
    assert(match_records != NULL);

    qsort(match_records, NM, sizeof(match_record_t), cmp_match_record);

    //size_t uNM = NM;
    size_t uNM = unique(match_records, NM, sizeof(match_record_t), cmp_match_record);

    /* First reset all sequences that this thread controls */

    for(size_t kk = 0; kk < uNM; kk++)
    {
        uint32_t seq_id = match_records[kk].seq_id;
        // TODO BUG XXX does this write out of bounds?
        // is abp per query sequence or per sequence in the reference genome?
        conf->abp[seq_id] = 0;
    }

    /* Then count again */
    for(size_t kk = 0; kk < uNM; kk++)
    {
        uint32_t seq_id = match_records[kk].seq_id;
        double pb = match_records[kk].pb;
        assert(pb > 0); /* Or it should not have been written */
        conf->abp[seq_id] += pb;
    }

    if(uNM < NM)
    {
        if(match_record_write(match_records, match_file, uNM))
        {
            fprintf(stderr, "whoopsie! Something went wrong");
            exit(EXIT_FAILURE);
        }
    }
    free(match_records);
    free(match_file);
    return NULL;
}

void filter_matches_pthreads(conf_t * conf)
{
    assert(conf->abp != NULL);
    pthread_t * threads = calloc(conf->nthreads, sizeof(pthread_t));


    assert(threads != NULL);

    //filter_matches_t * threaddata = calloc(
    //    conf->nthreads, sizeof(filter_matches_t));
    filter_matches_t * threaddata = aligned_alloc(CACHE_LINESIZE,
                                                  conf->nthreads*sizeof(filter_matches_t));
    assert(threaddata != NULL);

    for (int tt = 0; tt < conf->nthreads; tt++)
    {
        threaddata[tt].thread = tt;
        threaddata[tt].conf = conf;
        assert(threaddata[tt].conf->abp != NULL);
        pthread_create(threads+tt, NULL,
                       filter_matches_thread, threaddata+tt);
    }

    for(int tt = 0; tt < conf->nthreads; tt++)
    {
        pthread_join(threads[tt], NULL);
    }
    assert(conf->abp != NULL);
    free(threaddata);
    free(threads);

    return;
}

void query_genome_threads(conf_t * conf,
                          uint8_t * mindist, uint32_t * hash_comb,
                          uintG_t * B, uintG_t * B_genome)
{
    if(conf->nthreads == 1)
    {
        query_genome_thread(conf,
                            mindist, hash_comb,
                            B, B_genome,
                            0);
        return;
    }

    pthread_t * threads = malloc(conf->nthreads*sizeof(pthread_t));
    q_threaddata_t * threaddata = malloc(
                                         conf->nthreads*sizeof(q_threaddata_t));

    for(int tt = 0; tt < conf->nthreads; tt++)
    {
        threaddata[tt].conf = conf;
        threaddata[tt].mindist = mindist;
        threaddata[tt].hash_comb = hash_comb;
        threaddata[tt].B = B;
        threaddata[tt].B_genome = B_genome;
        threaddata[tt].thread = tt;
        pthread_create(threads+tt, NULL,
                       query_genome_pthread, threaddata+tt);
    }

    for(int tt = 0; tt < conf->nthreads; tt++)
    {
        pthread_join(threads[tt], NULL);
    }
    free(threaddata);
    free(threads);

    return;
}


void * query_genome_pthread(void * threaddata)
{
    q_threaddata_t * td = (q_threaddata_t *) threaddata;
    query_genome_thread(td->conf,
                        td->mindist, td->hash_comb,
                        td->B, td->B_genome,
                        td->thread);
    return NULL;
}

void query_genome_thread(conf_t * conf,
                         uint8_t * mindist, uint32_t * hash_comb,
                         uintG_t * B, uintG_t * B_genome,
                         size_t thread)
{
    FILE * th_match_file = NULL;
    if(conf->mode == MODE_PROBB)
    {
        char * match_file = malloc(strlen(conf->qfname) + 32);
        sprintf(match_file, "%s.match%03zu", conf->qfname, thread);
        th_match_file = fopen(match_file, "a");
        if(th_match_file == NULL)
        {
            fprintf(stderr, "Unable to open %s for appending\n", match_file);
            fprintf(stderr, "Out of disk space?\n");
            exit(EXIT_FAILURE);
        }
        free(match_file);
    }

    uint8_t * seq_buffer = malloc(conf->L);
    //const size_t nseq = conf->nseq;
    const size_t nseq_query = conf->nseq_query;

    const size_t nthreads = conf->nthreads;
    int d_discard = conf->d_discard;

    if(conf->mode == MODE_PROBB)
    {
        d_discard = (int) conf->L;
    }

    size_t kk = thread;
    pbar_t * pbar = NULL;
    if(conf->verbose > 0 && thread == 0)
    {
        pbar = pbar_new(&nseq_query, &kk);
        pbar_start(pbar);
    }

    /* TODO: More memory efficient to process one chunk per thread? */
    //for(size_t kk = pos0; kk<pos1; kk++)
    size_t nfinal = 0;
    for( ; kk < nseq_query; kk+=nthreads)
    {
        if(conf->query_mask)
        {
            if(conf->query_mask[kk] == 0)
            {
                continue;
            }
        }
        if(conf->mode != MODE_PROBB) {
            if(mindist[kk] <= d_discard) {
                continue;
            }
        }

        if(conf->mode == MODE_PROBB) {
            if(conf->abp[kk] > conf->abp_max)
            {
                nfinal++;
                continue;
            }
        }

        /* Get a pointer to the query string */
        uint8_t * seq = NULL;
        if(conf->query_mode == QUERY_GENOME)
        {
            seq = conf->G + kk;
        }
        if(conf->query_mode == QUERY_EXTERNAL)
        {
            seq = conf->Q + conf->L*kk;
        }
        assert(seq != NULL);

        /* Normal forward scan, updates mindist */
        query_seq_bucket(conf, seq, kk,
                         NULL,
                         hash_comb,
                         B, B_genome,
                         mindist, kk, 0,
                         th_match_file);

        if(conf->mode != MODE_PROBB) {
            if(mindist[kk] <= d_discard) {
                continue;
            }
        }

        /* Reverse complement scan */
        query_seq_bucket(conf, seq, kk,
                         seq_buffer,
                         hash_comb,
                         B, B_genome,
                         mindist, kk, 1,
                         th_match_file);
    }

    free(seq_buffer);
    if(thread == 0)
    {
        kk = nseq_query;
        pbar_stop(pbar);
        if(pbar != NULL)
            free(pbar);
    }

    if(conf->mode == MODE_PROBB)
    {
        fclose(th_match_file);
        //printf("thread %zd: %zu sequences are final (abp > %f)\n",
        //       thread, nfinal, conf->abp_max);
    }

    return;
}

void hash_filter_fprint(FILE * fid, const uint8_t * v, int n)
{
    fprintf(fid, "#=");
    for(int kk = 0; kk<n; kk++)
    {
        fprintf(fid, "%u ", v[kk]);
    }
    fprintf(fid, "\n");
    return;
}

void nhush(conf_t * conf, uint8_t * mindist)
{
    struct timespec t_pre_start, t_pre_end;
    struct timespec t_query_start, t_query_end;
    clock_gettime(CLOCK_REALTIME, &t_pre_start);

    if(conf->h == 0)
    {
        printf("TODO: more efficient brute force match when h = 0\n");
    }

    printf("Calculating the HASH comb to use ...\n");
    fflush(stdout);
    /* Generate a list of the positions to use for the hash */
    uint8_t * hash_filter = NULL;
    if(conf->h > 0)
    {
        hash_filter = comb_get_v3(conf->comb, conf->h);
    } else {
        /* Brute force, an empy hash filter/comb will place all sequences
         * in the same bin*/
        hash_filter = calloc(conf->L, 1);
    }

    comb_append(conf->comb, hash_filter);
    /* don't save until it has been used... */

    hash_filter_fprint(stdout, hash_filter, conf->L);
    hash_filter_fprint(conf->log, hash_filter, conf->L);

    comb_fprint(conf->log, conf->comb);

    //uint8_t * hash_filter = gen_hash_filter_debug(conf->L, conf->h); // first h set to 1

    /* Pre-calculate the hash weights */
    uint32_t * hash_comb = chash_gen_comb(hash_filter, conf->L, conf->h);

    if(conf->verbose > 3)
    {
        printf("Filter, Comb:\n");
        for(size_t kk = 0; kk<conf->L; kk++)
        {
            printf("%zu: %u, %u\n", kk, hash_filter[kk], hash_comb[kk]);
        }
    }
    free(hash_filter);


    /* calculate hashes for all sequences using the current comb */
    size_t nchashes = 0;
    printf("Calculating HASH values\n");

    uint32_t * chashes = chash_hash_genome(conf->G, conf->nG,
                                           hash_comb, conf->L, &nchashes);

    /* Determine bucket geometry
     * B[i] : number of sequences that has chash i-1
     * i.e. B[1] : number of buckets with chash 0 */
    printf("Calculating bucket sizes\n"); fflush(stdout);

    uintG_t * B = get_bucket_sizes(conf, chashes, nchashes);
    if(conf->dump_bin_sizes)
    {
        char * outfile = strdup("bin_sizes.uint32");
        printf("Dumping bin sizes to %s ... ", outfile);
        fflush(stdout);
        FILE * fid = fopen(outfile, "w");
        fwrite(B, sizeof(uintG_t), conf->nbuckets, fid);
        fclose(fid);
        free(outfile);
        printf("done.\n");
    }
    if(0)
    {
        double nexp = (double) nchashes / (double) conf->nbuckets;
        size_t nx = (size_t) nexp;
        size_t nempty = 0;
        size_t nlarge = 0;
        size_t nxlarge = 0;
        for(size_t kk = 2; kk < conf->nbuckets+2; kk++)
        {
            if(kk < 100)
                printf("B[%zu] = %u\n", kk, B[kk]);
            if(conf->nbuckets - kk < 100)
                printf("B[%zu] = %u\n", kk, B[kk]);
            uintG_t bsize = B[kk];
            if(bsize == 0)
                nempty++;
            if(bsize >= nx*10)
                nlarge++;
            if(bsize >= nx*1000)
                nxlarge++;
        }
        printf("Expected per bucket: %f\n", nexp);
        printf("nchashes: %zu\n", nchashes);
        printf("%zu buckets\n", conf->nbuckets);
        printf("%zu empty buckets\n", nempty);
        printf("%zu large buckets\n", nlarge);
        printf("%zu xlarge buckets\n", nxlarge);
        FILE * tf = fopen("dump.uint32", "w");
        fwrite(chashes, sizeof(uintG_t), nchashes, tf);
        fclose(tf);
        exit(EXIT_FAILURE);
    }

    //toc("get_bucket_sizes");
    if(conf->verbose > 1)
    {
        for(int kk = 0; kk<10; kk++)
        {
            printf("Bucket %d: %u", kk, B[kk]);
            if(kk == 2)
                printf(" <- first");

            printf("\n");
        }
    }

    /*Integrate bucket sizes to get start and end positions
     * Bucket i starts at B[i] and is B[i+1]-B[i] elements big */

    cumsum_inplace(B+1, conf->nbuckets);
    //toc("integrate_bucket_sizes");

    if(conf->verbose > 1)
    {
        printf("After integration:\n");
        for(int kk = 0; kk<10; kk++)
        {
            printf("Bucket %d: [%u, %u]", kk, B[kk], B[kk+1]);
            if(kk == 1)
                printf(" <- first");

            printf("\n");
        }
    }

    /* Place the hashes in the correct buckets */
    printf("Initializing buckets\n");

#ifdef _OPENMP
    uintG_t * B_genome = place_in_buckets_parallel(conf, B+1, chashes, nchashes);
#else
    uintG_t * B_genome = place_in_buckets(conf, B+1, chashes, nchashes);
#endif

    free(chashes);

    if(conf->verbose > 1)
    {
        for(int kk = 0; kk<10; kk++)
        {
            printf("Bucket %d: [%u, %u]", kk, B[kk], B[kk+1]);
            if(kk == 0)
                printf(" <- first");
            printf("\n");
        }
    }

    if(conf->verbose > 2)
    {
        /* show bucket b */
        size_t b = 0;
        size_t bstart = B[b];
        size_t bend = B[b+1];
        printf("Size of bucket 0 = %zu\n", bstart);
        printf("Size of bucket 1 = %zu\n", bend-bstart);

        for(size_t kk = bstart; kk<bend; kk++)
        {
            print_seq_color(conf->G + B_genome[kk], hash_comb, conf->L);
        }
    }

    clock_gettime(CLOCK_REALTIME, &t_pre_end);
    clock_gettime(CLOCK_REALTIME, &t_query_start);


    /* Start querying */
    printf("Querying ... \n"); fflush(stdout);
    query_genome_threads(conf,
                         mindist, hash_comb,
                         B, B_genome);

    free(hash_comb);
    free(B);
    free(B_genome);

    clock_gettime(CLOCK_REALTIME, &t_query_end);

    double t_query = clockdiff(&t_query_end, &t_query_start);
    double t_pre = clockdiff(&t_pre_end, &t_pre_start);

    fprintf(conf->log, "t_pre = %.1f s\n", t_pre);
    fprintf(conf->log, "t_query = %.1f s\n", t_query);


    /* Reduce the hash size if the preparations takes most time  */
    if(t_pre+1 > t_query)
    {
        if(conf->h != 0)
        {
            conf->h--;
            conf->nbuckets = powl(4, conf->h);
            printf(ANSI_COLOR_GREEN
                   "Reducing h to %zu\n"
                   ANSI_COLOR_RESET, conf->h);
            fprintf(conf->log, "Reducing h to %zu\n", conf->h);
        }
    }

    if(conf->mode == MODE_PROBB)
    {
        /* Filter out duplicates and flag query strings as final
         * if they have too high abp (accumulated binding probability) */
        if(conf->verbose > 1)
        {
            fprintf(stdout, "filter_matches_pthreads ... "); fflush(stdout);
        }
        filter_matches_pthreads(conf);
        if(conf->verbose > 1)
        {
            fprintf(stdout, "ok \n"); fflush(stdout);
        }
    }

    fflush(conf->log);
    return;
}

size_t showstats(const conf_t * conf, const uint8_t * mindist)
{
    size_t n_discard = 0;
    size_t n_keep = 0;

    for(size_t kk = 0; kk<conf->nseq_query; kk++)
    {
        if(mindist[kk] > conf->d_discard)
        {
            n_keep++;
        } else {
            n_discard++;
        }
    }

    printf(ANSI_COLOR_CYAN);
    printf("Active:  %10zu sequences, %6.2f%%", n_keep,
           100.0 * (float) n_keep / (float) (n_keep+n_discard) );
    printf(", where d >  %d\n", conf->d_discard);
    printf("Final:   %10zu sequences, %6.2f%%", n_discard,
           100.0 * (float) n_discard / (float) (n_keep+n_discard) );
    printf(", where d <= %d\n", conf->d_discard);
    printf("Current goal: capture everything <= %d mm\n",
           conf->comb->milestone);
    printf(ANSI_COLOR_RESET);

    /* And print it to the log file */
    fprintf(conf->log, "Active:  %10zu sequences, %6.2f%%", n_keep,
            100.0 * (float) n_keep / (float) (n_keep+n_discard) );
    fprintf(conf->log, ", where d >  %d\n", conf->d_discard);
    fprintf(conf->log, "Final:   %10zu sequences, %6.2f%%", n_discard,
            100.0 * (float) n_discard / (float) (n_keep+n_discard) );
    fprintf(conf->log, ", where d <= %d\n", conf->d_discard);
    fprintf(conf->log, "Current goal: capture everything <= %d mm\n",
            conf->comb->milestone);

    return n_keep;
}


void _xassert(int t, int line, char * file)
{
    if(t != 1)
    {
        fprintf(stderr, "Sadly the program failed in file %s, line %d\n", file, line);
        fprintf(stderr, "Please file a bug report\n");
        exit(EXIT_FAILURE);
    }
}

void safety_test()
{

    /* These structs are read-only so this isn't really needed. */
    assert(sizeof(filter_matches_t) == 64);
    assert(sizeof(q_threaddata_t)==64);

    /* Test that the encoding allows fast reverse complements */
    xassert(3-numA == numT);
    xassert(3-numC == numG);

    /* gen_hash_filter */
    for(int L = 1; L<20; L++)
    {
        for(int H = 0; H<=L; H++)
        {
            uint8_t * hash_filter = gen_hash_filter(L, H);
            int sum = 0;
            for(int kk = 0; kk<L; kk++)
                sum += hash_filter[kk];
            if(sum != H)
            {
                printf("L = %d, H = %d\n", L, H);
                for(int kk = 0; kk<L; kk++)
                {
                    printf("%u ", hash_filter[kk]);
                }
                printf("\n");
                xassert(0);
            }
            free(hash_filter);
        }
    }

    /* chash_gen_comb */

    for(int L = 0; L<20; L++)
    {
        int Lmax = L;
        if(Lmax > 16)
            Lmax = 16;
        for(int H = 1; H<=Lmax; H++)
        {
            uint8_t * hash_filter = gen_hash_filter(L, H);
            uint32_t * comb = chash_gen_comb(hash_filter, L, H);

            int sum = 0;
            for(int kk = 0; kk<L; kk++)
                sum += comb[kk] > 0;
            xassert(sum == H);
            uint32_t min = -1; uint32_t max = 0;
            for(int kk = 0; kk<L; kk++)
            {
                if(comb[kk] > 0)
                {
                    if(comb[kk] < min)
                        min = comb[kk];
                    if(comb[kk] > max)
                        max = comb[kk];
                }
            }
            xassert(min == 1);
            xassert(max == powl(4, H-1));

            free(comb);
            free(hash_filter);
        }
    }
    uint8_t str[] = {0, 0, 0};
    uint8_t * hf = gen_hash_filter(3,3);
    uint32_t * cm = chash_gen_comb(hf, 3, 3);
    uint32_t ch = chash((uint8_t*) str, cm, 3);

    xassert(ch == 0);
    free(cm);
    free(hf);

    return;
}

uint8_t * mindist_read(char * file, size_t size)
{
    uint8_t * mindist = malloc(size*sizeof(uint8_t));
    xassert(mindist != NULL);

    /* Try to load from file */
    FILE * fid = fopen(file, "r");
    if(fid == NULL)
    {
        free(mindist);
        return NULL;
    }
    if(0)
    {
        printf("Reading mindist from: %s ... ", file);
    }
    fflush(stdout);
    size_t nread = fread(mindist, 1, size, fid);
    if(nread != size)
    {
        printf("\n"
               ANSI_COLOR_RED "ERROR:" ANSI_COLOR_RESET
               "When reading %s, I expected %zu B but could only read %zu B.",
               file, size, nread);
        printf("This indicates that the file was not properly written last time (aborted?)\n");
        printf("I don't know how to continue!\n");
    }

    xassert(nread == size);
    fclose(fid);
    return mindist;
}

uint8_t * mindist_get(conf_t * conf)
{
    /* Try to read from disk */
    uint8_t * mindist = mindist_read(conf->outname, conf->nseq_query);
    if(mindist != NULL)
    {
        return mindist;
    }

    /* If not loaded... initialize */
    mindist = malloc(conf->nseq_query*sizeof(uint8_t));
    for(size_t kk = 0; kk < conf->nseq_query; kk++)
    {
        mindist[kk] = 255;
    }

    return mindist;
}

void init_comb(conf_t * conf)
{
    /* Initialization of combs */
    conf->nbuckets = powl(4, conf->h);
    conf->comb = comb_load(conf->fname_comb);
    if(conf->comb == NULL)
    {
        fprintf(conf->log, "Could not read comb: %s\n", conf->fname_comb);
        fprintf(conf->log, "Starting from blank\n");
        conf->comb = comb_new(conf->L);
    } else {
        printf("Read combs from %s\n", conf->fname_comb);
    }

    conf->comb->verbose = conf->verbose;
    if(conf->verbose > 0)
    {
        printf("Calculating number of mismatches already covered...\n");
    }

    comb_calculate_milestone(conf->comb);

    if(conf->verbose > 0)
    {
        printf("Next target for the hash comb: %d mismatches\n", conf->comb->milestone);
    }

    if(conf->mode == MODE_FULL)
    {
        conf->d_discard = conf->comb->milestone;
    } else {
        /* Nothing. */
    }

    comb_fprint(conf->log, conf->comb);
}

void show_usage(__attribute__((unused)) int argc, char ** argv)
{
    printf("Purpose:\n");
    printf("Process all sub-sequences of length L in a fasta file "
           "and discard/filter out all sequences, S, where another "
           "sequence Q can be found such that the Hamming distance "
           "between them is less or equal to h, i.e,. hd(S,Q)<=h. "
           "As an example, if h is set to 0 "
           "only strictly non-unique sequences will be filtered out\n");
    printf("\n");
    printf("Usage:\n");
    printf("%s [--verbose v] [--version] [--hash H] [--length L] [--discard d] "
           "[--nrounds n] [--threads T] [--help] [--no-srand] "
           "[--embraced f] [--external file.seq] [--genome-mask gmask.lua] "
           "[--query-mask qmask.lua] "
           "--file file.fa\n", argv[0]);
    printf("--file ref.fa\n\t Set the reference geneome\n");
    printf("--verbose v\n\t Set verbosity level\n");
    printf("--hash h\n\t Set initial hash length\n");
    printf("--length L\n\t Set string lenght\n");
    printf("--discard d\n\t Set discarding Hamming radius d.\n");
    printf("\n\t Sequences with a mismatch <= d will not be "
           "furter investigated.\n");
    printf("--external file.seq\n\t Query sequences in file.seq vs the genome");
    printf("--probb\n\t"
           "Calculate accumulated binding probability for each sequences\n");
    printf("--out\n\t"
           "specify fasta file to write to\n");
    printf("--nrounds n\n\t Number of rounds to run\n");
    printf("--until mm\n\t Run until it can be guaranteed that all hits "
           "<= mm are found\n");
    printf("--threads T\n\t Set number of threads to T\n");
    printf("--no-srand\n\t Don't use a randomized random seed\n");
    printf("--embraced file\n\t Write embraced sequences to file\n");
    printf("--sfp\n\t Skip the first perfect match (only with --external)\n");
    printf("\n\t Useful when the query sequences are on the genome.\n");
    printf("--help\n\t Show this message\n");
    printf("--version\n\t Show version\n");
    printf("--genome-mask gmask.lua\n\t"
           "set script to mask the genome -- i.e. do hide parts of it\n");
    printf("--query-mask qmask.lua\n\t"
           "set script to mask the query (as part of the genome)\n");
    printf("Alternative use:\n");
    printf("%s dump-mindist query.fa query.fa.nh.L$(L).mindist.uint8 $(L)\n",
           argv[0]);
    return;
}


void conf_argparsing(conf_t * conf, int argc, char ** argv)
{

    struct option longopts[] = {
        { "ask",          no_argument,       NULL,   'A' },
        { "discard",      required_argument, NULL,   'D' },
        { "embraced",     required_argument, NULL,   'E' },
        { "genome-mask",  required_argument, NULL,   'G' },
        { "hash",         required_argument, NULL,   'H' },
        { "length",       required_argument, NULL,   'L' },
        { "out",          required_argument, NULL,   'O' },
        { "probb",        no_argument,       NULL,   'P' },
        { "query-mask",   required_argument, NULL,   'Q',},
        { "threads",      required_argument, NULL,   'T' },
        { "version",      no_argument,       NULL,   'V' },
        { "dump-bin-sizes", no_argument,     NULL,   'b' },
        { "file",         required_argument, NULL,   'f' },
        { "help",         no_argument,       NULL,   'h' },
        { "nrounds",      required_argument, NULL,   'n' },
        { "no-srand",     no_argument,       NULL,   'r' },
        { "sfp",          no_argument,       NULL,   's' },
        { "until",        required_argument, NULL,   'u' },
        { "verbose",      required_argument, NULL,   'v' },
        { "external",     required_argument, NULL,   'x' },

        { NULL,           0,                 NULL,   0   }
    };

    int gotL = 0;

    int ch;
    while((ch = getopt_long(argc, argv,
                            "Abv:VG:H:L:D:f:n:O:shT:rE:u:PQ:",
                            longopts, NULL)) != -1)
    {
        switch(ch)
        {
        case 'A':
            conf->ask = 1;
            break;
        case 'b':
            conf->dump_bin_sizes = 1;
            break;
        case 'D':
            conf->mode = MODE_DISCARD;
            conf->d_discard = atoi(optarg);
            break;
        case 'E':
            conf->fname_embraced = strdup(optarg);
            break;
        case 'G':
            free(conf->genome_mask_script);
            conf->genome_mask_script = strdup(optarg);
            assert(conf->genome_mask_script != NULL);
            break;
        case 'H':
            conf->h = atoi(optarg);
            break;
        case 'L':
            conf->L = atoi(optarg);
            gotL = 1;
            break;
        case 'O':
            conf->fasta_out = strdup(optarg);
            break;
        case 'T':
            conf->nthreads = atoi(optarg);
            break;
        case 'V':
            show_version();
            exit(EXIT_SUCCESS);
        case 'f':
            conf->fname = strdup(optarg);
            break;
        case 'h':
            show_usage(argc, argv);
            exit(EXIT_SUCCESS);
            break;
        case 'n':
            conf->n_rounds = atoi(optarg);
            break;
        case 'r':
            conf->srand = 0;
            break;
        case 's':
            conf->skip_first_perfect = 1;
            break;
        case 'u':
            conf->until_mm = atoi(optarg);
            break;
        case 'v':
            conf->verbose = atoi(optarg);
            break;
        case 'x':
            conf->qfname = strdup(optarg);
            conf->query_mode = QUERY_EXTERNAL;
            break;
        case 'P':
            conf->mode = MODE_PROBB;
            break;
        case 'Q':
            free(conf->query_mask_script);
            conf->query_mask_script = strdup(optarg);
            assert(conf->query_mask_script != NULL);
            break;
        default:
            printf("see %s --help\n", argv[0]);
            exit(EXIT_FAILURE);
        }
    }

    if(conf->query_mode == QUERY_EXTERNAL)
    {
        FILE * fid = fopen(conf->qfname, "r");
        if(fid == NULL)
        {
            fprintf(stderr, "Unable to open %s\n", conf->qfname);
            exit(EXIT_FAILURE);
        }
        fclose(fid);
    }

    if(optind < argc)
    {
        fprintf(stderr, "ERROR: I don't know what do do about the following:\n");
        for(int k = optind; k < argc; k++)
        {
            fprintf(stderr, "'%s'\n", argv[k]);
        }
        exit(EXIT_FAILURE);
    }

    if(conf->h > 16)
    {
        printf("The hash length can't be above 16\n");
        exit(EXIT_FAILURE);
    }


    if(conf->fname == NULL)
    {
        printf("No input file provided\n");
        exit(EXIT_FAILURE);
    }

    if(gotL == 0)
    {
        printf("Please set the sequence length with -L or --length\n");
        exit(EXIT_FAILURE);
    }

    if(conf->L < 5)
    {
        printf("A sequence length of %ld does not make sense\n", conf->L);
        exit(EXIT_FAILURE);
    }

    if(conf->mode == MODE_PROBB)
    {
        if(conf->fasta_out == NULL)
        {
            printf("No output file is specified! Set with -O or --out\n");
            exit(EXIT_FAILURE);
        }
    }


    /* Seed for the random number generator */
    if(conf->srand == 1)
    {
        srand(time(NULL));
    } else {
        srand(0);
    }


    /* Set output file names */

    /* base name/prefix */
    char * bname = NULL;
    if(conf->query_mode == QUERY_EXTERNAL)
    {
        bname = malloc(strlen(conf->qfname)+100);
        sprintf(bname, "%s.nh.L%ld",
                conf->qfname, conf->L);
    } else {
        bname = malloc(strlen(conf->fname)+100);
        sprintf(bname, "%s.nh.L%ld",
                conf->fname, conf->L);
    }

    conf->outname = malloc(strlen(bname) + 100);
    xassert(conf->outname != NULL);
    sprintf(conf->outname, "%s.mindist.uint8", bname);

    conf->fname_log = malloc(strlen(bname) + 20);
    sprintf(conf->fname_log, "%s.log.txt", bname);

    conf->log = fopen(conf->fname_log, "a");
    if(conf->log == NULL)
    {
        printf("Failed to open log file: %s\n",
               conf->fname_log);
        exit(EXIT_FAILURE);
    }

    conf->fname_comb = malloc(strlen(bname) + 100);
    sprintf(conf->fname_comb, "%s.comb",
            bname);


    free(bname);

    /* Write to log, command line */
    for(int kk = 0; kk<argc; kk++)
    {
        fprintf(conf->log, "%s ", argv[kk]);
    }
    fprintf(conf->log, "\n");

    print_time(conf->log, "Started");


    /*  Write settings to log */
    conf_show(conf->log, conf);


    if(conf->verbose > 0)
        conf_show(stdout, conf);
    if(conf->ask)
    {
        printf("Press enter to continue\n");
        getchar();
    }

    return;
}

void export_embraced(conf_t * conf, uint8_t * mindist)
{
    /* Export embraced/remaining sequences, somewhat interactive,
       will show a histogram and ask for a threshold */

    uint32_t * H = calloc(256, sizeof(uint32_t));
    for(size_t kk = 0; kk<conf->nseq_query; kk++)
    {
        H[mindist[kk]]++;
    }

    int last = 0;
    for(int kk = 0; kk<256; kk++)
    {
        if(H[kk] > 0)
            last = kk;
    }
    for(int kk = 0; kk<=last; kk++)
    {
        printf("hd=%d: %u\n", kk, H[kk]);
    }
    free(H);

    printf("Will export sequences where the Hamming Distance it at least...");
    printf("Hamming distance to use:\n");
    printf("> ");
    char *line = NULL;
    size_t size;
    if (getline(&line, &size, stdin) == -1)
    {
        printf("Don't know what hamming distance to use\n");
        return;
    }

    int hdist = atoi(line);
    if(line != NULL)
    {
        free(line);
    }

    if(hdist > 255)
        hdist = 255;
    if(hdist < 0)
        hdist = 0;
    size_t nexport = 0;
    for(int kk = hdist; kk<256; kk++)
        nexport += H[kk];
    printf("Will export %zu sequences to %s\n", nexport,
           conf->fname_embraced);

    free(H);

    FILE * fid = fopen(conf->fname_embraced, "w");
    if(fid == NULL)
    {
        printf("Could not open %s for writing\n",
               conf->fname_embraced);
        return;
    }
    for(size_t kk = 0; kk<conf->nseq_query; kk++)
    {
        if(mindist[kk] >= hdist)
        {
            fprintf(fid, "> pos:%zu, mindist:%u\n", kk, mindist[kk]);
            fprint_seq(fid, conf->G + kk, conf->L);
        }
    }
    fclose(fid);
    return;
}

typedef struct {
    size_t L; /* String length */
    uint8_t * G; /* Pointer to genome */
} seqcmp_t;

int cmp_seq(const void * _s1, const void *_s2, void * _d)
{
    uint32_t * s1 = (uint32_t *) _s1;
    uint32_t * s2 = (uint32_t *) _s2;
    seqcmp_t * d = (seqcmp_t*) _d;
    uint8_t * G = (uint8_t *) d->G;
    return memcmp(G+ *s1, G+ *s2, d->L);
}

int ulist_get(conf_t * conf)
{
    char * eqcfile = malloc(strlen(conf->fname) + 128);
    sprintf(eqcfile, "%s.L%zu.eqc", conf->fname, conf->L);
    if(conf->verbose > 0)
    {
        printf("Reading multiplicity/equivalence classes from %s\n", eqcfile);
    }
    size_t Neqc = 0;
    seq_info_t * eqc = read_eqc(eqcfile, &Neqc);

    if(conf->nseq != Neqc)
    {
        fprintf(stderr, "%s and %s does not match\n", conf->fname, eqcfile);
        fprintf(stderr, "%s suggests %zu seqences (%zu - %zu + 1)\n",
                conf->fname, conf->nseq,
                conf->nG, conf->L);
        fprintf(stderr, "%s loaded info about %zu sequences\n", eqcfile, Neqc);
        fprintf(stderr, "Did you forget to run 'nhush eq_classes --file %s --length %zu'?\n",
                conf->fname, conf->L);
        fprintf(stderr, "Can't continue, exiting\n");
        exit(EXIT_FAILURE);
    }

    conf->ulist = eqc_gen_ulist(eqc, Neqc);
    conf->multiplicity = malloc(Neqc*sizeof(uint32_t));
    for(size_t kk = 0; kk<Neqc; kk++)
    {
        conf->multiplicity[kk] = eqc[kk].class_multiplicity;
    }

    free(eqcfile);
    free(eqc);

    return EXIT_SUCCESS;
}


int write_uint8(char * fname, uint8_t * D,
                size_t N)
{
    if(fname != NULL)
    {
        char * tmpname = malloc(strlen(fname) + 8);
        sprintf(tmpname, "%s.tmp", fname);

        FILE * fout = fopen(tmpname, "w");
        size_t nwritten = fwrite(D, 1, N, fout);
        if(nwritten != N)
        {
            printf("ERROR: failed to write to %s\n", tmpname);
            exit(EXIT_FAILURE);
        }
        fclose(fout);

        int r = rename(tmpname, fname);
        if(r != 0)
        {
            printf("Failed to move %s to %s\n", tmpname, fname);
            printf("Error code: %d\n", errno);
            exit(EXIT_FAILURE);
        }

        free(tmpname);

    } else {
        printf("ERROR: file name not set\n");
        xassert(0);
    }
    return EXIT_SUCCESS;
}

/* Just initialize the ulist and set it to 1. */
void ulist_init_ones(conf_t * conf)
{
    size_t nseq = conf->nseq;
    conf->ulist = malloc(nseq);
    uint8_t * ulist = conf->ulist;
    memset(ulist, 1, nseq);
    return;
}

void comb_write(conf_t * conf)
{
    fprintf(stdout,
            "Writing combs to %s\n", conf->fname_comb);
    fprintf(conf->log,
            "Writing combs to %s\n", conf->fname_comb);
    int r = comb_save(conf->comb, conf->fname_comb);
    if(r != EXIT_SUCCESS)
    {
        printf("ERROR: Could not save to %s\n", conf->fname_comb);
        exit(EXIT_FAILURE);
    }
    return;
}

int export_mindist(int argc, char ** argv)
{
    /* ./nhush dump-mindist query mindist */
    if(argc != 5)
    {
        printf("Usage: %s %s query mindist seq-length\n",
               argv[0], argv[1]);
        return(EXIT_FAILURE);
    }

    /* sequence length */
    size_t L = atol(argv[4]);
    if(L<1)
    {
        printf("The seq-length has be > 0\n");
        return(EXIT_FAILURE);
    }

    /* Read query sequences */
    printf("# Reading fasta file: %s\n", argv[2]);
    size_t xsize = 0;
    fasta_records_t * q_records = NULL;
    uint8_t * Q = readfa(argv[2], &xsize, &q_records);
    if(Q == NULL)
    {
        printf("Unable to continue\n");
        return(EXIT_FAILURE);
    }
    fasta_records_free(&q_records);
    printf("# Read %zu bytes\n", xsize);


    /* Read mindist */
    size_t nseq = xsize/L;
    uint8_t * mindist = mindist_read(argv[3], nseq);

    if(mindist == 0)
    {
        printf("Failed to read %s\n", argv[3]);
        return(EXIT_FAILURE);
    }

    /* Write to stdout */
    for(size_t kk = 0; kk<nseq; kk++)
    {
        print_seq(Q + kk*L, L);
        printf("\t%u\n", mindist[kk]);
    }

    free(mindist);
    return EXIT_SUCCESS;
}

void main_loop_probb(conf_t * conf)
{
    printf("################# MODE: PROBB/ABP -- EXPERIMENTAL ################\n");

    assert(conf->mode == MODE_PROBB);
    if(conf->query_mode != QUERY_EXTERNAL)
    {
        fprintf(stderr, "ERROR: --probb have to be combined with --external\n");
        exit(EXIT_FAILURE);
    }

    int n_hzero = 0;
    for(int kk = 0; kk < conf->n_rounds; kk++)
    {
        if(conf->verbose > 0)
            printf("-> Iteration %d/%d H = %zu\n",
                   kk+1, conf->n_rounds, conf->h);
        fprintf(conf->log, "Iteration %d/%d, H = %zu\n",
                kk+1, conf->n_rounds, conf->h);
        fflush(conf->log);

        if(n_hzero == 0)
        {
            n_hzero++;
        }

        if(n_hzero > 1)
        { /* No need to scan using brute force more than once */
            break;
        }

        /* See query_genome_thread
         * matches handled at #PB_WRITE
         */
        nhush(conf, NULL);

        comb_write(conf);

        comb_calculate_milestone(conf->comb);

        if( conf->comb->milestone > conf->until_mm)
        {
            printf("Reached the --until %d target\n", conf->until_mm);
            fprintf(conf->log, "Reached the --until %d target\n", conf->until_mm);
            kk = conf->n_rounds;
            break;
        }

        /*
         * Fun part: take away some sequences that won't contribute to
         * the abp any more!
         */
        if(conf->comb->milestone > 4)
        {
            size_t minmult = pow(4, conf->comb->milestone - 5);
            abp_reduce_ulist(conf, minmult);
        }

        /* TODO: stop criterion
         */

        print_time(conf->log, "End of iteration");
        fprintf(conf->log, "\n");

        if(conf->verbose > 0)
        {
            print_time(stdout, "End of iteration");
            printf("\n");
        }

        fflush(conf->log);
    }

    if(conf->fasta_out != NULL)
    {
        printf("Will write results to %s\n", conf->fasta_out);
    }
    size_t xsize = 0;
    fasta_records_t * q_records = NULL;
    uint8_t * Q = readfa(conf->qfname, &xsize, &q_records);
    FILE * outfile = stdout;
    if(conf->fasta_out != NULL)
    {
        outfile = fopen(conf->fasta_out, "w");
        if(outfile == NULL)
        {
            fprintf(stderr, "Sorry, can't open %s for writing\n", conf->outname);
            outfile = stdout;
        }

    } else {
        printf("--out not specified, writing to your terminal\n");
    }
    for(size_t kk = 0; kk < (size_t) q_records->n; kk++)
    {
        double abp = conf->abp[kk];
        fprintf(outfile, "> %s, apb=%e", q_records->name[kk], abp);
        if(abp > conf->abp_max)
        {
            fprintf(outfile, " (or higher)");
        }
        fprintf(outfile, "\n");
        fprint_seq(outfile, Q+q_records->pos[kk], conf->L);
        fprintf(outfile, "\n");
        //printf("%*s\n", conf->L, Q+q_records->pos[kk]);
    }
    free(Q);
    fasta_records_free(&q_records);

    return;
}


static uint8_t * mask_from_script(conf_t * conf, const char * script_file)
{
    // We only need: mask_all, unmask_all, mask_region, unmask_region
    // And the function only needs to be aware of fasta_records_t *,
    // and the total size of the genome

    return mindist_gen_mask_lua(conf->log, script_file, conf->G_records, conf->nG);
}

/** Mask the genome based on a lua config script
 *
 * Sets conf->genome_mask if conf->genome_mask_script is set.
 */
static void
mask_genome(conf_t * conf)
{
    if(conf->genome_mask_script)
    {
        conf->genome_mask = mask_from_script(conf, conf->genome_mask_script);
    }
    return;
}

/** Mask the genome based on a lua config script
 *
 * Sets conf->query_mask if conf->query_mask_script is set.
 */
static void
mask_query(conf_t * conf)
{
    if(conf->query_mask_script)
    {
        conf->query_mask = mask_from_script(conf, conf->query_mask_script);
    }
    return;
}

int nhush_mindist(int argc, char ** argv)
{
    uint8_t * mindist = NULL;

    if(argc > 1)
    {
        if(strcasecmp(argv[1], "dump-mindist") == 0)
        {
            /* export query sequences and their mindists */
            return(export_mindist(argc, argv));
        }
    }
    /* Some quick unit tests */
    safety_test();

    conf_t * conf = conf_new();
    /* Argument parsing AND Initialization */
    conf_argparsing(conf, argc, argv);

    /* Get the input data */
    if(conf->verbose > 0)
        printf("Reading genome from %s\n", conf->fname);
    conf->G = readfa(conf->fname, &conf->nG, &conf->G_records);
    if(conf->G == NULL)
    {
        printf("Unable to continue\n");
        exit(EXIT_FAILURE);
    }
    assert(conf->G != NULL);
    if(conf->verbose > 0)
        printf("Genome size: %zu\n", conf->nG);
    fprintf(conf->log, "Genome size: %zu\n", conf->nG);

    mask_genome(conf);
    mask_query(conf);

    if(conf->h == 0)
    {
        conf->h = floor(log2(conf->nG/2)/2);
        conf->h == 0 ? conf->h = 1 : 0;
        conf->h > 16 ? conf->h = 16 : 0 ;
    }

    if(conf->verbose > 0)
    {
        printf("Initial hash length: %zu letters\n", conf->h);
        printf("%.1f sequences per bucket (average)\n",
               (double) conf->nG / (double) pow(4, conf->h));
    }

    init_comb(conf);


    /* Number of sequences to consider */
    conf->nseq = conf->nG-conf->L+1;
    conf->nseq_query = conf->nseq; /* Update when separate query data */

    /* If query sequences are specified, load them
     * (if not it is all vs all on the whole genome) */
    if(conf->query_mode == QUERY_EXTERNAL)
    {
        if(conf->verbose > 0)
            printf("Reading sequences from %s\n", conf->qfname);
        /*  Read the file with sequences to query */
        size_t xsize = 0;
        fasta_records_t * q_records = NULL;
        conf->Q = readfa(conf->qfname, &xsize, &q_records);
        if(conf->verbose > 1 )
        {
            printf("%zu records in %s\n", q_records->n, conf->qfname);
        }

        conf->nseq_query = xsize/conf->L;

        if(conf->nseq_query != q_records->n)
        {
            printf("WARNING: %s seems to contain %zu sequences but only %zu records\n",
                   conf->qfname, conf->nseq_query, q_records->n);
            printf("         I.e. comment lines missing before sequences.\n");
            printf("         This might work...\n");
        }
        fasta_records_free(&q_records);


        if(conf->nseq_query*conf->L != xsize)
        {
            printf("Read %zu bytes from %s\n", xsize, conf->fname);
            printf("Expected %zu = %zu x %zu (length x number of oligos)\n",
                   conf->L*conf->nseq_query,
                   conf->L,
                   conf->nseq_query);
            printf("What you can do:\n");
            printf(" - Verify that --length is set correctly.\n");
            printf(" - Verify that the file is formatted correctly.\n");
            printf(" - If this error still persists, please file a bug report\n");
            exit(EXIT_FAILURE);
        }


        if(conf->verbose > 0)
        {
            fprintf(stdout, "Read %zu sequences of length %zu b\n", xsize/conf->L, conf->L);
        }

        /* Accumulated binding probability, allocate for each query sequence */
        conf->abp = calloc(conf->nseq_query, sizeof(double));
        assert(conf->abp != NULL);
    }


    /* Read/use multiplicity and only one representative per sequence? */
    if(conf->mode == MODE_PROBB)
    {
        if(ulist_get(conf) == EXIT_FAILURE)
        {
            printf(
                   "No information about unique sequences and multiplicty could be "
                   "loaded. Assuming that all sequences are unique (i.e. mult 1)\n");
            printf("Generate this input with `nhush eq-classes -L %zu --file %s`",
                   conf->L, conf->fname);
            exit(EXIT_FAILURE);
        }
    } else {

        if(conf->genome_mask)
        {
            if(conf->verbose > 0)
            {
                printf("Applying the genome mask (as ulist)\n");
            }
            conf->ulist = conf->genome_mask;
            conf->genome_mask = NULL;
        } else {
            if(conf->verbose > 0)
            {
                printf("All sequences are used with multiplicity 1\n");
            }
            ulist_init_ones(conf); // All set to 1
        }

    }

    if(conf->verbose > 0)
        printf("\n");
    fprintf(conf->log, "\n");

    if(conf->mode == MODE_PROBB)
    {
        main_loop_probb(conf);
        goto leave;
    }

    /* mindist: smallest distance to any other sequence
     * starts at 255 and will be decreased
     * only consider sequences for the next iteration when mindist < ...
     * this will read an existing file or create a new if not found
     */
    mindist = mindist_get(conf);

    if(conf->fname_embraced != NULL)
    {
        export_embraced(conf, mindist);
        goto leave;
    }

    if( showstats(conf, mindist) == 0)
    {
        printf("Nothing more to do!\n");
        goto leave;
    }

    /* Normal mindist mode */
    for(int kk = 0; kk < conf->n_rounds; kk++)
    {
        if(conf->verbose > 0)
            printf("-> Iteration %d/%d H = %zu\n",
                   kk+1, conf->n_rounds, conf->h);
        fprintf(conf->log, "Iteration %d/%d, H = %zu\n",
                kk+1, conf->n_rounds, conf->h);
        fflush(conf->log);

        nhush(conf, mindist);

        mindist_write(conf, mindist);
        comb_write(conf);

        /* When we have used the comb, we can update the discard
           distance if the milestone changed. */
        comb_calculate_milestone(conf->comb);
        if(conf->mode == MODE_FULL)
        {
            if(conf->comb->milestone > conf->d_discard)
            {
                conf->d_discard = conf->comb->milestone;
                printf(ANSI_COLOR_GREEN
                       "Updating d_discard to %d"
                       ANSI_COLOR_RESET "\n", conf->d_discard);
                fprintf(conf->log, "Updating d_discard to %d\n",
                        conf->d_discard);
            }
        }
        if(conf->mode == MODE_DISCARD)
        {
            if(conf->comb->milestone > conf->d_discard)
            {
                printf("The comb guarantees that we've discarded "
                       "all sequences with d <= %d. "
                       "We are done!\n",
                       conf->d_discard);
                kk = conf->n_rounds;
            }
        }

        if( conf->d_discard > conf->until_mm)
        {
            printf("Reached the --until %d target\n", conf->until_mm);
            fprintf(conf->log, "Reached the --until %d target\n", conf->until_mm);
            kk = conf->n_rounds;
            break;
        }

        if( showstats(conf, mindist) == 0)
        {
            printf("No need to continue\n");
            fprintf(conf->log, "No need to continue\n");
            kk = conf->n_rounds;
            break;
        }

        print_time(conf->log, "End of iteration");
        fprintf(conf->log, "\n");

        if(conf->verbose > 0)
        {
            print_time(stdout, "End of iteration");
            printf("\n");
        }

        fflush(conf->log);
    }




 leave:
#ifndef __APPLE__
    fprint_peakMemory(stdout);
    fprint_peakMemory(conf->log);
#endif
    print_time(conf->log, "Freeing memory and leaving");
    if(conf->verbose > 0)
        print_time(stdout, "Freeing memory and leaving");

    if(conf->mode != MODE_PROBB)
    {
        free(mindist);
    }
    conf_free(&conf);
    return EXIT_SUCCESS;
}

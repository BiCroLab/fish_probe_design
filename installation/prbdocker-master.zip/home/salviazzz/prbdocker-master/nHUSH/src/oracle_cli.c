#include "oracle.h"

int main(int argc, char ** argv)
{
    return oracle(argc, argv);
}

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdint.h>
#include <assert.h>
#include <string.h>

#define uintG_t uint64_t

static double timespec_diff(struct timespec* end, struct timespec * start)
{
    double elapsed = (end->tv_sec - start->tv_sec);
    elapsed += (end->tv_nsec - start->tv_nsec) / 1000000000.0;
    return elapsed;
}

void cumsum_inplace_alt(uintG_t * restrict B, const size_t n)
{
    size_t sum = 0;
    for(size_t kk = 0; kk < n; kk++)
    {
        sum+=B[kk];
        B[kk]=sum;
    }
    return;
}


void cumsum_inplace(uintG_t * B, const size_t n)
{
    for(size_t kk = 1; kk < n; kk++)
    {
        B[kk]+=B[kk-1];
    }
    return;
}


int main(int argc, char ** argv)
{
    size_t N = 100000000;
    size_t M = 100;
    if(argc > 1)
    {
        N = atol(argv[1]);
    }
    if(argc > 2)
    {
        M = atol(argv[1]);
    }

    printf("Using %zu elements, repeats %zu times\n", N, M);

    struct timespec t0, t1;
    double torg = 0, tnew = 0;

    uintG_t * B = malloc(N*sizeof(uintG_t));
    for(size_t kk = 0 ; kk<N; kk++)
    {
        B[kk] = rand() % 10;
    }
    uintG_t * B1 = malloc(N*sizeof(uintG_t));
    memcpy(B1, B, N*sizeof(uintG_t));
    cumsum_inplace(B, N);
    cumsum_inplace_alt(B1, N);
    for(size_t kk = 0; kk<N; kk++)
    {
        if(B[kk] != B1[kk])
        {
            printf("Results from cumsum_inplace and cumsum_inplace_alt"
                   "differs at pos %zu\n", kk);
        }
    }
    free(B1);
    printf("Results are identical\n");

    for(size_t kk = 0; kk<M; kk++)
    {
        clock_gettime(CLOCK_REALTIME, &t0);
        cumsum_inplace(B, N);
        clock_gettime(CLOCK_REALTIME, &t1);
        if(kk>1)
        {
            torg += timespec_diff(&t1, &t0);
        }

        clock_gettime(CLOCK_REALTIME, &t0);
        cumsum_inplace_alt(B, N);
        clock_gettime(CLOCK_REALTIME, &t1);
        if(kk>1)
        {
            tnew += timespec_diff(&t1, &t0);
        }
    }

    printf("torg: %f s\n", torg);

    printf("tnew: %f s\n", tnew);
    if(torg < tnew)
    {
        printf("torg was faster\n");
    } else {
        printf("tnew was faster\n");
    }
    free(B);
    return(EXIT_SUCCESS);
}

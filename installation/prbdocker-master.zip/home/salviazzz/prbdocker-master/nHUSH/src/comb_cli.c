#include "comb_cli.h"

static void show_version_comb()
{
    printf("nHUSH version %s\n", NHUSH_VERSION);
}


static int * col_sum(uint8_t * C, size_t N, size_t L)
{
    int * sum = calloc(L, sizeof(int));
    for(size_t nn = 0; nn < N; nn++)
    {
        for(size_t pp = 0; pp<L; pp++)
        {
            sum[pp] += C[L*nn+pp];
        }
    }
    return sum;
}

void comb_show(char * fname)
{
    comb_t * comb = comb_load(fname);
    if(comb == NULL)
    {
        printf("Create a new comb...\n");
        char * line = NULL;
        size_t n = 0;
        printf("L="); fflush(stdout);

        if(getline(&line, &n, stdin) < 1)
        {
            fprintf(stderr, "Could not figure out L\n");
            exit(EXIT_FAILURE);
        }
        int L = atoi(line);
        comb = comb_new(L);
        free(line);
    }
    comb_fprint(stdout, comb);
    // comb_calculate_milestone(comb);

    char * line = NULL;
    size_t n = 0;
    while(1)
    {
        printf("H= "); fflush(stdout);
        if(getline(&line, &n, stdin) < 1)
            break;
        if(line[0] == 'p')
        {
            printf("Detection probabilities:\n");
            for(int rr = 1; rr<8; rr++)
            {
                size_t ncases, ncovered;
                double p = get_detection_p(comb->C, comb->N, comb->L, rr,
                                           &ncases, &ncovered);
                printf("%d mm, %*.2f%%, %zu/%zu\n",
                       rr, 7, 100.0*p,
                       ncovered, ncases);
            }
        }
        else if(line[0] == 'P')
        {
            printf("Detection probabilities until crash...\n");
            for(int rr = 1; ; rr++)
            {
                size_t ncases, ncovered;
                double p = get_detection_p(comb->C, comb->N, comb->L, rr,
                                           &ncases, &ncovered);
                printf("%d mm, %*.2f%%, %zu/%zu\n",
                       rr, 7, 100.0*p,
                       ncovered, ncases);
            }
        }
        else if (line[0] == 's')
        {
            int * sum = col_sum(comb->C, comb->L, comb->N);
            for(size_t kk = 0; kk<comb->L; kk++)
            {
                printf("%d ", sum[kk]);
            }
            printf("\n");
            free(sum);
        }
        else if (line[0] == 'q')
        {
            break;
        } else {
            int h = atoi(line);
            printf("Finding the next hash comb for H=%d\n", h);
            uint8_t * c = comb_get_v3(comb, h);
            comb_append(comb, c);// needed for v2 and up
            comb_fprint(stdout, comb);
            comb_calculate_milestone(comb);
        }
    }
    free(line);
    comb_free(&comb);
    printf("\n");
}

void quicktest(int version)
{
    int L = 40;
    comb_t * comb = comb_new(L);
    int ncombs = 14;
    for(int kk = 0; kk<ncombs; kk++)
    {
        uint8_t * c = NULL;
        switch(version)
        {
        case 31:
            c = comb_get_v31(comb, 14);
            break;
        case 3:
            c = comb_get_v3(comb, 14);
            break;
        case 4:
            c = comb_get_v4(comb, 14);
            break;
        default:
            printf("Version %d not supported\n", version);
            exit(EXIT_FAILURE);
        }
        comb_append(comb, c);
        comb_fprint(stdout, comb);
        free(c);
        comb_calculate_milestone(comb);
        if(kk+1 < ncombs)
            continue;
        comb_fprint(stdout, comb);
        printf("Detection probabilities:\n");
        for(int rr = 1; rr<8; rr++)
        {
            size_t ncases, ncovered;
            double p = get_detection_p(comb->C, comb->N, comb->L, rr,
                                       &ncases, &ncovered);
            printf("%d mm, %*.2f%%, %zu/%zu\n",
                   rr, 7, 100.0*p,
                   ncovered, ncases);
            size_t nrem = count_remaining_mm(comb, rr, &ncases);
            printf("count_remaining_mm = %zu, or %zu/%zu covered\n",
                   nrem, ncases-nrem, ncases);
            if(kk == 7 && rr == 3)
            {
                //assert(p > 0.97);
            }
        }
    }
    comb_free(&comb);
}

void unit_tests()
{
    printf("Testing nCk\n");
    for(size_t N = 1; N<60; N++)
        for(size_t k = 1; k<=N; k++)
        {
            printf("(%zu,%zu)=%zu\n", N, k, binomial(N,k));
        }
    printf("\n");
    return;
}

static void usage()
{
    printf("Usage:\n");
    printf("  ./comb --show file.comb\n");
    printf("if file.comb does not exist, it will let you play around\n");
    printf("\n");
    printf("In the program:\n");
    printf("L=\n\t Enter the length of each query sequence and press <ENTER>\n");
    printf("H= \n\t Enter the number of bases to use in the next hash function"
           ", end by <ENTER>\n");
    printf("\n");
    printf("See the man page for more details.\n");
}


void argparsing(int argc, char ** argv)
{

    struct option longopts[] = {
        { "help",      no_argument,       NULL, 'h'},
        { "show",      required_argument, NULL, 'S'},
        { "quicktest", required_argument, NULL, 'T'},
        { "unittest",  no_argument,       NULL, 'U'},
        { "version",   no_argument,       NULL, 'V'},
        { NULL,           0,              NULL,  0 }
    };

    int v = 0;

    int ch;
    while((ch = getopt_long(argc, argv, "hS:T:U", longopts, NULL)) != -1)
    {
        switch(ch)
        {
        case 'h':
            usage();
            exit(EXIT_SUCCESS);
        case 'U':
            unit_tests();
            exit(EXIT_SUCCESS);
            break;
        case 'S':
            comb_show(optarg);
            exit(EXIT_SUCCESS);
            break;
        case 'T':
            v = atoi(optarg);
            quicktest(v);
            exit(EXIT_SUCCESS);
            break;
        case 'V':
            show_version_comb();
            exit(EXIT_SUCCESS);
        }
    }
    return;
}


int nhush_comb(int argc, char ** argv)
{
    if(argc == 1)
    {
        usage();
        exit(EXIT_SUCCESS);
    }
    tictoc;
    tic;
    argparsing(argc, argv);

    assert(binomial(52, 5) == 2598960);

    int L = 20;
    int H = 14;
    if(argc > 1)
    {
        L = atoi(argv[1]);
    }
    if(argc > 2)
    {
        H = atoi(argv[2]);
    }

    int ncomb = 10;
    if(argc > 3)
    {
        ncomb = atoi(argv[3]);
    }
    printf("Testing for L = %d, H = %d\n", L, H);

    comb_t * comb1 = comb_new(L);
    comb_t * comb2 = comb_new(L);

    for(int kk = 0; kk<ncomb; kk++)
    {
        printf("------ %d ", kk);
        printf("captures everything <= %d:\n", comb2->milestone-1);
        comb_fprint(stdout, comb2);

        uint8_t * c2 = comb_get_v2(comb2, H);
        comb_append(comb2, c2);
        comb_calculate_milestone(comb2);
        free(c2);
    }
    //printf("getchar()\n");
    //getchar();
    for(int kk = 0; kk<2; kk++)
    {
        printf("------ %d \n", kk);
        printf("Comb1, milestone: %d\n", comb1->milestone);
        comb_fprint(stdout, comb1);
        comb_get_v1(comb1, H);
    }

    comb_free(&comb2);

    comb_t * comb = comb1;
    printf("Saving ...\n");
    printf("L = %zu, N = %zu\n", comb->L, comb->N);
    comb_save(comb, "test.comb");
    comb_free(&comb);
    comb = comb_load("test.comb");
    printf("Read again...");
    printf("L = %zu, N = %zu\n", comb->L, comb->N);
    comb_free(&comb);
    toc("total time");
    return EXIT_SUCCESS;
}

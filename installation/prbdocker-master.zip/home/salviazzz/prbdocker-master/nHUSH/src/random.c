#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

int main(int argc, char ** argv)
{
    time_t now;
    time(&now);
    char buf[128];
    strftime(buf, sizeof buf, "%FT%TZ", localtime(&now));
    printf("%s\n", buf);

    time_t t = time(NULL);
    struct tm  * tt = localtime(&t);
    printf("%04d-%02d-%02d, %02d:%02d:%02d\n",
           tt->tm_year+1900, tt->tm_mon+1, tt->tm_mday,
           tt->tm_hour, tt->tm_min, tt->tm_sec);
    return EXIT_SUCCESS;
}

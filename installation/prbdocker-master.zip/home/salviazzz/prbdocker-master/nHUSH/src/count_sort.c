#include "count_sort.h"


void count_sort_free(count_sort_t * cs)
{
    if(cs == NULL)
        return;
    free(cs->bucket_start);
    free(cs->buckets);
    free(cs);
}
static uint32_t *
get_bucket_sizes(const uint32_t * restrict hash_values,
                 const size_t nbuckets,
                 size_t N)
{

    uint32_t * Bsize = calloc(nbuckets+2, sizeof(uint32_t));
    uint32_t * _Bsize = Bsize+2;

#pragma omp parallel for shared(Bsize)
    for(size_t kk = 0; kk < N; kk++)
    {
#pragma omp atomic
        _Bsize[(size_t) hash_values[kk]]++;
    }

    return Bsize;
}


static void
cumsum_inplace(uint32_t * restrict B, const size_t n)
{
    size_t sum = 0;
    for(size_t kk = 0; kk < n; kk++)
    {
        sum+=B[kk];
        B[kk]=sum;
    }
    return;
}


static uint32_t *
place_in_buckets(const uint32_t * restrict hash_values,
                 uint32_t * restrict bucket_start,
                 const size_t nbuckets,
                 const size_t N)
{
    /* Returns pointers to the genome so that it is sorted in the
       buckets NOTE: This alters bucket_start so that bucket_start[i]
       is no longer the start position of bucket i, rather the end
       position.*/
    //printf("nbuckets=%u, N=%u\n", nbuckets, N);

    uint32_t * restrict S = calloc(N, sizeof(uint32_t));
    if(S == NULL)
    {
        fprintf(stderr, "ERROR: Unable to allocate memory on line %d\n",
                __LINE__);
        exit(EXIT_FAILURE);
    }

#pragma omp parallel
    {
        const size_t th_num = omp_get_thread_num();
        const size_t th_tot = omp_get_num_threads();

        /* Decide what hash values this thread should handle */
        size_t lower = th_num * nbuckets / th_tot;
        size_t upper = (th_num+1) * nbuckets / th_tot;

        // avoid mod, divide B into th_tot regions instead

        for(size_t kk = 0; kk < N; kk++)
        {
            uint32_t hash = hash_values[kk];
            if(hash >= lower)
            {
                if(hash < upper)
                {
                    assert(hash < nbuckets);
                    S[bucket_start[hash]++] = kk;
                }
            }
        }
    }

    return S;
}

static uint32_t *
get_hash_values(const uint8_t * data,
                const size_t nmemb,
                cs_hash_t hash, void * arg)
{
    if(arg == NULL)
    {
        printf("%s arg==NULL\n", __FUNCTION__);
    }
    uint32_t * hash_values = calloc(nmemb, sizeof(uint32_t));
    if(hash_values == NULL)
    {
        fprintf(stderr, "Allocation failed at line %d\n", __LINE__);
        exit(EXIT_FAILURE);
    }

#pragma omp parallel for
    for(size_t k = 0; k < nmemb; k++)
    {
        hash_values[k] = hash(data+k, arg);
        //printf("#%zu=%u\n", k, hash_values[k]);
    }

    return hash_values;
}

static void
sort_buckets(uint32_t * buckets,
             const uint32_t * restrict bucket_start,
             const size_t nbuckets,
             cs_compare_t cmp,
             void * arg)
{
    //size_t nel = 0;
    /* Dynamic schedule probably faster when we use RC and the bins
     * are less uniformly populated */
#pragma omp parallel for schedule(dynamic)
    for(size_t b = 0; b<nbuckets; b++)
    {
        size_t first = bucket_start[b];
        size_t n = bucket_start[b+1]-first;
        //printf("Sorting bucket %zu, [%zu, %zu]\n", b, first, first+n-1);
        if(n > 1)
        {
            qsort_r(&buckets[first], n, sizeof(uint32_t),
                    cmp, arg);
        }
//#pragma omp atomic
        //      nel+=n;
    }
    //printf("%zu elements were sorted with countsort\n", nel);
    return;
}

count_sort_t * count_sort_idx(uint8_t * data,
                              size_t nmemb,
                              cs_compare_t cmp,
                              cs_hash_t hash,
                              size_t hash_max,
                              void * arg)
{
    size_t nbuckets = hash_max+1;

    uint32_t * hash_values =
        get_hash_values(data, nmemb, hash, arg);

    /* Offset by 2, first index is nbuckets[2] */
    uint32_t * bucket_size =
        get_bucket_sizes(hash_values, nbuckets, nmemb);

    /* re-uses bucket_size, size: hash_max+1 */
    cumsum_inplace(bucket_size, nbuckets+2);
    uint32_t * bucket_start = bucket_size;
    bucket_size = NULL;

    assert(bucket_start[0] == 0);
    assert(bucket_start[1] == 0);

    uint32_t * buckets =
        place_in_buckets(hash_values, bucket_start+1, nbuckets, nmemb);
    free(hash_values);

    assert(bucket_start[0] == 0);

    count_sort_t * result = calloc(1, sizeof(count_sort_t));
    result->buckets = buckets;
    result->bucket_start = bucket_start;
    result->nbuckets = hash_max;

    if(cmp == NULL)
    {
        return result;
    }

    /* Sort each bucket according to the cmp function */
    sort_buckets(buckets, bucket_start, nbuckets, cmp, arg);

    return result;
}

#include "util.h"

double clockdiff(struct timespec* finish, struct timespec * start)
{
    double elapsed = (finish->tv_sec - start->tv_sec);
    elapsed += (finish->tv_nsec - start->tv_nsec) / 1000000000.0;
    return elapsed;
}

size_t get_peakMemoryKB(void)
{
    char * statfile = malloc(100*sizeof(char));
    sprintf(statfile, "/proc/%d/status", getpid());
    FILE * sf = fopen(statfile, "r");
    if(sf == NULL)
    {
        fprintf(stderr, "Failed to open %s\n", statfile);
        free(statfile);
        return 0;
    }

    char * peakline = NULL;

    char * line = NULL;
    size_t len = 0;

    while( getline(&line, &len, sf) > 0)
    {
        if(strlen(line) > 6)
        {
            if(strncmp(line, "VmPeak", 6) == 0)
            {
                peakline = strdup(line);
            }
        }
    }
    free(line);
    fclose(sf);
    free(statfile);

    /* Parse the line starting with "VmPeak"
     * Seems like it is always in kB
     * (reference: fs/proc/task_mmu.c)
     * actually in kiB i.e., 1024 bytes
     * since the last three characters are ' kb' we can skip them and parse in between */
    size_t peakMemoryKB = 0;
    if(strlen(peakline) > 11)
    {
        peakline[strlen(peakline) -4] = '\0';
        peakMemoryKB = (size_t) atol(peakline+7);
    }

    free(peakline);
    return peakMemoryKB;
}


void fprint_peakMemory(FILE * fout)
{
    size_t pm = get_peakMemoryKB();

    if(fout == NULL) fout = stdout;
    fprintf(fout, "peakMemory: %zu kiB\n", pm);

    return;
}

void print_time(FILE * f, char * msg)
{
    time_t t = time(NULL);
    struct tm  * tt = localtime(&t);
    fprintf(f, "%04d-%02d-%02d %02d:%02d:%02d : %s\n",
            tt->tm_year+1900, tt->tm_mon+1, tt->tm_mday,
            tt->tm_hour, tt->tm_min, tt->tm_sec,
            msg);
    return;
}

void show_version()
{
    printf("nHUSH version %s\n", NHUSH_VERSION);
}

size_t FILE_size(FILE * fid)
{
    fseek(fid, -0L, SEEK_END);
    size_t size = ftell(fid);
    rewind(fid);
    return size;
}

size_t
unique(void * _data,
       size_t nmemb,
       size_t size,
       int (*cmp)(const void *, const void*))
{
    char * data = (char*) _data;
    if(nmemb == 0)
        return 0;

    size_t writepos = 1;
    for(size_t readpos = 1; readpos<nmemb; readpos++)
    {
        if(cmp(data+size*readpos,
                  data+size*(writepos-1)) != 0)
        {
            /* different from the last, write it unless it is already in
             * the correct position */
            if(writepos != readpos)
            {
                assert(writepos < readpos);
                memcpy(data + writepos*size,
                       data + readpos*size,
                       size);
            }
            writepos++;
        }
    }
    /* Number of written unique elements */
    return writepos;
}

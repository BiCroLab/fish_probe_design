#!/bin/python

if __name__ == '__main__':
    import sys

    if len(sys.argv) != 2:
        #print(f'Usage: {argv[0]} file.mindist')
        print('hello')
        sys.exit(1)

    mdfile = sys.argv[1]

    import numpy as np
    mindist = np.fromfile(mdfile, dtype=np.uint8)
    values = np.unique(mindist)
    print(f'{mindist.size} sequences')
    for v in values:
        print(f'{v}, {np.sum(mindist==v)}')

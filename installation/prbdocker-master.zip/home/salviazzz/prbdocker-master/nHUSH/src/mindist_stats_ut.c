#include "mindist_stats.h"

int main(int argc, char ** argv)
{
    return mindists_stats(argc, argv);
}

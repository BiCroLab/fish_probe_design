#include "pbar.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char ** argv)
{

    if(argc > 0)
    {
        printf("%s\n", argv[0]);
    }
    size_t N = 127;
    size_t kk = 0;

    pbar_t * pbar = pbar_new(&N, &kk);

    pbar_start(pbar);
    for(kk = 0; kk <= N ; kk++)
    {
        usleep(80000 + rand() % 60000);
    }
    pbar_stop(pbar);


    free(pbar);
    return 0;
}

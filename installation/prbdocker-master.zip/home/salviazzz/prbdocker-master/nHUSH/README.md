# nHUSH

**nHUSH** is a tool for calculating Hamming distances between large sets
of genomic sequences. The indented use case is as a
filter (among others) for ruling out sequences that are not suitable
for FISH experiments. In some sense it is an *anti-*aligner.

If a FISH probe design pipeline starts with:
1. Select a region of interest.
2. Extract k-mers
3. Do fast linear filters, e.g. for GC contents, melting temperature, etc

Then nHUSH would come in as the 4th step.

More formally, given a genome _G_ we would like to find unique sequences
_s_ of some length _L_. In this setting, a sequence is unique if there does
not exist any other sequence on the genome with a Hammind distance below some
threshold, _r_.

nHUSH takes an iterative approach to filter out what is not unique. Since it
is based on the Hamming distance, it does not handle insertions or deletions
(indels).

nHUSH shares some features with
[HUSH](http://github.com/elgw/unique_seq_hamming/)
but is better in terms of speed and flexibility. However nHUSH is not
designed to count the number of matches, just find the shortest distance
to any of the other sequences.

The main algorithm is iterative and at each step:
- A HASH pattern (or comb) is generated.
- The genome is sorted into bins according to the comb.
- All query sequences are matched against the reference sequences
in the corresponding HASH bins.

The first iterations is guaranteed to find all perfect matches (_r_=0),
and by introducing more combs, nHUSH can guarantee that
all matches withing _r_=1 mm, 2 mm, ... are found.

To give some idea of what the algorithm does, it uses:
- Multiple HASHing.
- Variable length HASHing, i.e. it is not limited to a fixed size as old-HUSH
would be.
- Dynamic HASHing, i.e., the size of the HASH is optimized on the go,
as a trade of between the time it takes to index and to scan the reference
genome.
For more details, see the `doc/` folder.

## Binaries

- **nhush** Query genome vs genome or sequences vs genome [man page](man/nhush.txt)
- **nhush-bfm** Brute force matching of a single string against a genome. Slow but hopefully reliable [man page](man/nhush-bfm.txt)
- **nhush-fasplit** Split long oligos into sub-strings [man page](man/nhush-fasplit.txt)


## Installation
nHUSH is tested on Linux, and has no special dependencies. To build the
binaries, first download/clone this repository then
``` shell
make
./makedeb
sudo apt install ./nhush_*_amd64.deb
# uninstall with sudo apt remove nhush
```

if you don't have root access you can simply do (replace
`~/nHUSH/bin/` with the corresponding folder on you system


``` shell
echo 'export PATH=$PATH:~/nHUSH/bin/' >> ~/.bashrc
source ~/.bashrc
```
Alternative install instruction with [INSTALL.md](meson).


## Usage

nHUSH can be run either [Genome wide](#genome-wide), i.e., determine minimal
Hamming distances between all sequences of a genome or used for
[Sequences of interest](#sequences-of-interest), i.e., to calculate minimal
Hamming distance between sequences provided in a fasta file and a genome
specified as a fasta file.

In the folder `examples` there are two scripts that demonstrate how
nHUSH can be used. Please note that the examples use very tiny input files,
while nHUSH scales very well to larger sizes.


## Reading fasta files / Alphabet
nHUSH has a very basic support for reading fasta files (code in **readfa.c**).
- Letters are converted to integers for faster hashing. 'a' and 'A'
is mapped to 0, 't' and 'T' is mapped to 3, 'c' and 'C' is
converted to 1, 'g' and 'G' is converted to 2.
- 'n' and 'N' is mapped to 0 (same as 'a' and 'A'). Unless you want
to query repeated sequences containing many 'A's this should not be
a problem.
- Lines starting with '>' are ignored.
- Any other characters are ignored (will cause a crash unless
compiled with `-DNDEBUG`).

## Output
For the example, the following files are generated:

The output is split into several files

- `commands` shows all commands that were run by the example script

- `query.fa.nh.L40.log.txt`

A log, containing the command line and progress for nHUSH.

- `query.fa.bh.L40.mindist.uint8`

Here comes the real output, encoded as unsigned 8-bit unsigned integers.

- `query.fa.out.L40.ulist`

For book keeping. Flags sequences (by the start positions) to be indexed or
not. Initially nHUSH might scan for duplicate sequences and exclude them for
further indexing.

- `query.fa.nh.L40.comb`

For book keeping/resuming aborted jobs. The combs/hash functions used so far.
The next hash function can be deducted from this. Not expected to be used
except for debugging, can be inspected with

```
nhush-comb --show query.fa.nh.L40.comb
```

## Long Sequences of Interest
For long oligos (L > 60 or even shorter depending on the Hamming radius)
nHUSH will not be able to find all alignments due to the complexity of the
problem.

It might be useful to pose questions like:
- Is there any L-mer such that all of its sub strings have
a Hamming distance at least r to any other sequence of length l
on the genome?

Here is a concrete example on how to find 80-mers with "good" sub strings.
First all sub strings of length l=21 are written down to a new fasta file:

``` shell
nhush fasplit -L 80 -l 21 --file regions.GC35to85_Reference.hpolValid.fa
```
Then **nhush** is run for those sequences:
``` shell
nhush --hash 14 --length 21 --discard 0 --threads 8         ...
    --external regions.GC35to85_Reference.hpolValid.fa.21mers  ...
    --file hg19.fa --sfp
```
in this case it is suggested that the output distances are merged by the min
operator (i.e., each group of 21 values is replaced by their min).

## Questions and Answers

- _Can nHUSH be aborted and resumed?_

Short answer: Yes. Files are saved to disk at the end of each iteration.
It should be safe to abort any time after a new iteration has started,
until the querying is done.

- _Why are some `mindist` values still 255 after one or several iterations?_

During one each iteration each q is placed in a bucket. If this
bucket does not contain any other sequence no comparison is
performed and mindist is not updated. The reverse complement is also
scanned against G, so for the value to still be 255 after an iteration,
`qr` did point to an empty bucket. This typically happens when the number of
buckets is high, i.e., the hash length is high.

- _How much RAM is needed?_

For hg19 (about 3 GB) nHUSH uses about 39 GB of RAM, so approximately 13x
genome size.


- _Is nHUSH useful for really short sequences?_

For sufficiently small _L_ nothing will be unique. In that case it makes sense
to count the number of non-self matches for the sequences and to use sequences
with only relatively few matches as probes. A normal aligner or
[HUSH](http://www.github.com/elgw/hush) might be a better alternative.

- _nHUSH?_

HUSH used to stand for: exact **H**amming distance based tool to
search for **U**nique **S**equences using multiple **H**ashing. The
initial 'n' can be interpreted as 'new' or 'next' since this is the
second incarnation of HUSH.

- _How long time does it take?_

I don't have much figure at the moment but for hg19, querying all sub sequences
of length _L=40_ against the whole hg19 using an 8-core AMD Ryzen 3800x:

- First round, that finds all perfect matches (and make upper bounds for most
sequences) took about 4 h. 23% of the sequences were found to have perfect
matches and could be discarded. The speed was approximately 200,000
sequences / second.

- Second round, everything up to 1 mm is found.

- 5th round, everything up to 2 mm is found and can be discarded from further
queries.

- _What is the development status?_

See the separate [TODO](TODO.md) list and the [issue tracking](https://github.com/elgw/nHUSH/issues).

## References and Related
- [simhash-cpp](https://github.com/seomoz/simhash-cpp) Using multiple hashing
for fingerprint detection.
- [Improved Hamming Distance Search using Variable Length Hashing](https://openaccess.thecvf.com/content_cvpr_2016/papers/Ong_Improved_Hamming_Distance_CVPR_2016_paper.pdf)
- [Very efficient balanced codes](dx.doi.org/10.1109/JSAC.2010.100207) could be relevant to the comb generation.

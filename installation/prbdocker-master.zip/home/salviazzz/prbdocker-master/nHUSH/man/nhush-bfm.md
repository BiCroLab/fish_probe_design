% NHUSH-BFM(1) nhush-bfm ABCDE
% Erik Wernersson
% January 2022

# NAME
nhush-bfm -- brute force matching of genomic sequences against a genome, using
Hamming distance.

# SYNOPSIS
**nhush-bfm** [*OPTIONS*]

# DESCRIPTION
**nhush-bfm** does linear brute force comparison of a sequence against a reference
genome. It is extremely slow and does not make any tricks and hence only
intended to be used as a last resort or for debugging other tools.

# OPTIONS

**-c**, **--colors**
: use colors in the output.

**-h**, **--help**
: Display a basic help

**-m f**, **--from f**
: Show matches with a distance of at least m, default: 0.

**-q query.fa**, **--query query.fa**
: set the file of sequences to query. Not to be used with -s.

**-r ref.fa**, **--ref ref.fa**
: Specify a fasta file containing the reference genome.

**-s str**, **--string str**
: set the string to query in the reference genome. Not to be used with -q.

**-t**, **--table**
: Show a summary table at the end.

**-v L**, **--verbose L**
: Set the verbosity level. 0: quite, 1: default, >1 extra.

**-y**, **--no-reverse**
: Don't scan the reverse complement.

**-M #**, **--to #**
: Specify the Hamming radius to use. Any matches <= # will be considered a
hit.

**-V**, **--version**
: show version information and quit.

**--threads t**
: Set the number of threads to use. If not specified the environmental
  variable `OMP_NUM_THREADS` will be used.

# EXAMPLES
**bfm -r chr10.fa -s ATTGAATCCGATA -M 0**
: See if ATTGAATCCGATA is present in chr10.fa

**bfm -r chr10.fa -s ATTGAATCCGATA -m 1 -M 5 --table**
: Make a summary of how often ATTGAATCCGATA is present in chr10.fa
up to Hamming radius 5 and ignore perfect matches.


# SEE ALSO
nhush, nhush-comb and nhush-fasplit


# WEB PAGE
[https://github.com/elgw/nHUSH](https://github.com/elgw/nHUSH)


# REPORTING BUGS
Please report bugs at
[https://github.com/elgw/nHUSH/issues/](https://github.com/elgw/nHUSH/issues/)


# COPYRIGHT
Copyright  ©  2022 Erik Wernersson.  License GPLv3+: GNU GPL version 3 or later
<https://gnu.org/licenses/gpl.html>.
This is free software: you are free to change and redistribute it.  There is NO WARRANTY, to the
extent permitted by law.

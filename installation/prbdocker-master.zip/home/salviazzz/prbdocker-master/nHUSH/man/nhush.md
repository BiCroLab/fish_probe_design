% NHUSH(1) nhush ABCDE
% Erik Wernersson
% January 2022-2023

# NAME
nhush -- filter out probes that are not unique enough to be used in FISH probe design.

# SYNOPSIS
For querying:
**nhush** [*COMMAND*]

# SEE ALSO
nhush-mindist nhush-bfm nhush-comb and nhush-fasplit

# WEB PAGE
[https://github.com/elgw/nHUSH](https://github.com/elgw/nHUSH)

# REPORTING BUGS
Please report bugs at
[https://github.com/elgw/nHUSH/issues/](https://github.com/elgw/nHUSH/issues/)

# COPYRIGHT
Copyright  ©  2022 Erik Wernersson.  License GPLv3+: GNU GPL version 3 or later
<https://gnu.org/licenses/gpl.html>.
This is free software: you are free to change and redistribute it.  There is NO WARRANTY, to the
extent permitted by law.

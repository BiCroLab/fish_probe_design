% NHUSH(1) nhush ABCDE
% Erik Wernersson
% January 2022

# NAME
nhush -- filter out probes that are not unique enough to be used in FISH probe design.

# SYNOPSIS
For querying:
**nhush** [*OPTIONS*]

For exporting sequences (if *--external* was used).
**nhush** dump-mindist query.fa mindist.uint8 LEN

Write all sequences (of length LEN) and their minimal distance found so
far in a tab
delimited format (tsv) to the standard output. Redirect to a file by
appending `> result.tsv` at the end.

# DESCRIPTION
**nhush** finds all matches up to a certain Hamming distance between a reference
genome and itself, or alternatively against some query sequences.

Since the number of ways to place m mismatches increases very quick with the
senquece length, it is probably best to split sequences that are longer than 60
by the program nhush-fasplit. For 60-mers all matches <= 7 mm can be found in
reasonable time.

# OPTIONS
**-e e.fa**, **--external e.fa**
: Instead of querying the input genome against itself, the sequences in e.fa
will be queried against the reference genome.

**-f ref.fa**, **--file ref.fa**
: Set the reference genome to be the sequences in ref.fa. This file can
be concatenated from several other files. See the examples below.

**-h**, **--help**
: Display basic help message.

**-n n**, **--nrounds n**
: set the number of rounds or iterations to use (at most). By default there is
no limit.

**-r**, **--no-srand**
: Don't use a random seed.

**-s**, **--sfp**
: Skip the first perfect match. This will only work together with --external.
When --sfp is enabled, the first perfect match will be ignored. This is useful
when the sequences in the external file are also present on the reference
genome. E.g., when querying probes that are present on the genome, it is
expected that there is one perfect match.

**--until mm**, **-u mm**
: Run until all hits <= mm mismatches are found.

**-v**, **--verbose**
: set the verbosity level. 0=quiet, 1=normal, >1 extra information.

**-x file**, **--external file*
: To match the reference genome against an external list of probes, specify
a fasta file.

**-D d**, **--discard d**
: specify a Hamming radius for quick discarding of sequences. Any sequences
that has a match <= d will not be further investigated. As a consequence any
reported distance <= d might not be the smallest distance.

**-E file**, **--embraced file**
: Export embraced/kept sequences to file.

**--H h**, **--hash h**
: set the initial number of bases that should be used for hashing the genome.
4^h buckets will be used. The value of h can at most be 16.

**-L l**, **--length l**
: set the length of the oligos. All oligos need to have the same length.

**-T t**, **--threads t**
: Set the max number of computational threads to use.

**-V**, **--version**
Show version information

# EXAMPLES

**cat chr\*.fa > hg19.fa**
: Concatenate all chromosomes to one file.

**nhush --length 21 --file hg19.fa --threads 16**
: Determine the shortest distance from all 21-mers on hg19.fa to all
21-mers on hg19.fa

**nhush --length 21 --file hg19.fa --threads 16 --external probe-candidates.fa --sfp**
: Determine the shortest distance between all the probes of length 21 in
probe-candidates.fa to the sequences on gh19.fa


# SEE ALSO
nhush-bfm nhush-comb and nhush-fasplit

# WEB PAGE
[https://github.com/elgw/nHUSH](https://github.com/elgw/nHUSH)

# REPORTING BUGS
Please report bugs at
[https://github.com/elgw/nHUSH/issues/](https://github.com/elgw/nHUSH/issues/)

# COPYRIGHT
Copyright  ©  2022 Erik Wernersson.  License GPLv3+: GNU GPL version 3 or later
<https://gnu.org/licenses/gpl.html>.
This is free software: you are free to change and redistribute it.  There is NO WARRANTY, to the
extent permitted by law.

#!/bin/bash

rm -rf genome-wide
rm -rf sequences-of-interest

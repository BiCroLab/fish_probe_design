-- same syntax as gmask, see gmask.lua.

-- Example script
-- Will say that the only region of interest is on chromosomes 7
mask_all()
unmask_region("chromosome 7,", 2000000, 2500000)

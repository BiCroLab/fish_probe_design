set -e

# Number of basepairs
genome_size=10000000


nhush=../bin/nhush

if [ -z "$nhush" ]; then
    nhush=`which nhush`
fi

if [ -z "$nhush" ]; then
    echo "Cound not find nhush -- please compile first!"
    exit 1
fi
echo "Found nhush at: $nhush"


echo "Genome size = ${genome_size}"
echo "Generating genome.fa"
$nhush genrand -l ${genome_size} -n 1 -s 0 > genome.fa

echo "Pick out a sequence at random of length 40"
seq=`$nhush readrand genome.fa 40`
echo "Picked '$seq'"
echo "Generating query.fa"
$nhush genmm -f 0 -t 11 -s $seq > query.fa

echo "Done"

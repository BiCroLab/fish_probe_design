set -e
# Accumulated probability of binding (apb)

genome=genome.fa
length=40
qfile=q${length}.fa
genome_size=1000

## Find hush
nhush=../bin/nhush

if [ -z "$nhush" ]; then
    nhush=`which nhush`
fi

if [ -z "$nhush" ]; then
    echo "Cound not find nhush -- please compile first!"
    exit 1
fi
echo "Found nhush at: $nhush"

## Eq classes

$nhush genrand -l ${genome_size} -n 1 -s 0 > genome.fa

if [ ! -f "genome.fa.L40.eqc" ] ; then
$nhush eq_classes --file $genome --length $length
fi

## Find apb for some seqeuences
if [ ! -f "q40.fa" ] ; then
$nhush genrand -l ${length} -n 1000 > ${qfile}
fi

## Run!
rm -rf q40.fa.*
$nhush --probb --until 5 --file ${genome} --external $qfile

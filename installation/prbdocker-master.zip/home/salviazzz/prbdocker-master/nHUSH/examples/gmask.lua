-- Available commands:
-- mask_all() -- hides everything
-- unmask_all() -- unhides everything
-- mask_region(name, from, to) -- mask part of a chromosomes
-- unmask_region(name, from, to) -- unmask part of a chromosomes

-- Important:
-- for mask_region() and unmask_region(), the name string has to
-- uniquely match a substring of the chromosome names as specified in
-- the fasta file.
--
-- if the genome contains (among other):
-- ->NC_060925.1 Homo sapiens isolate CHM13 chromosome 1, alternate assembly T2T-CHM13v2.0
-- >NC_060934.1 Homo sapiens isolate CHM13 chromosome 10, alternate assembly T2T-CHM13v2.0
-- >NC_060947.1 Homo sapiens isolate CHM13 chromosome X, alternate assembly T2T-CHM13v2.0
--
-- then "ome 1," would be a perfectly fine identifies for the first record
-- while "chromosome 1" could match also chromosomes 10, 11, ...

--- Example script
unask_all()
mask_region("chr X,", 0, 100000)

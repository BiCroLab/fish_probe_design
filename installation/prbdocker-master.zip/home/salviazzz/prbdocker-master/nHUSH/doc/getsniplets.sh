set -e
echo "Don't use"
exit 1
# Extract what is between M1 and M2 with
# sed -n '/^M1$/,/^M2$/p' hush.tex | sed '1d;$d' >
# For C: extract between '//M1' and `//M2' with
# sed -n '/^\/\/M1$/,/^\/\/M2$/p' file.c | sed '1d;$d' >> snip1.c
# use togehter with \inputminted{c}{snip1.c}


mkdir -p sniplets
sed -n '/^\/\/TAG-cmpfun$/,/^\/\/ETAG$/p' ../src/eq_classes.c | sed '1d;$d' > sniplets/cmpseq.c

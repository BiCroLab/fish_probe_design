# eq_classes_cli --file hg19.fa --length 40 --threshold 10 --out hg19.shitlist.L40.T10.fa
# awk 'BEGIN {sum=0; nclass=0} {if($2 > 0) {print $2; sum = sum + $2; nclass=nclass+1}} END0 {printf "sum=%d nclass=%d\n", sum, nclass}' hg19.shitlist.L80.T10.fa > hg19.L80.clustersize_from_10.csv

filename = "hg19.L80.clustersize_from_10.csv"

cl = []
with open(filename) as file:
   for l in file:
      cl.append(int(l))

import matplotlib.pyplot as plt
import numpy as np

ncl = np.array(cl)

#plt.hist(cl)
#plt.show()

>>> sum(np.logical_and(ncl>4,ncl <= 16))
#561981
>>> sum(np.logical_and(ncl>16,ncl <= 64))
#428444
>>> sum(np.logical_and(ncl>64,ncl <= 256))
#77367
>>> sum(np.logical_and(ncl>4**4,ncl <= 4**5))
#21413
>>> sum(np.logical_and(ncl>4**5,ncl <= 4**6))
#5233
>>> sum(np.logical_and(ncl>4**6,ncl <= 4**7))
#89


sum(ncl > 4**2)
#532547
sum(ncl > 4**3)
#104103
sum(ncl > 4**4)
#26736
sum(ncl > 4**5)
#5323
sum(ncl > 4**6)
#90
sum(ncl > 4**7) # (16384)
#1

$ nhush eq_classes --file chr22.fa \
  --length 40
## Export to fasta format, for each class it writes the multiplicity
## a numerical id of the class and the minimal form of the sequence.
$ nhush eq_classes --export chr22.fa.L40.eqc \
  --file chr22.fa \
  --length 40 \
  --low 125 # Only when multiplicity is >= 125
> 16409901 id0
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
> 745 id22951159
CTCGGCCTCCCAAAGTGCTGGGATTACAGGCGTGAGCCAC

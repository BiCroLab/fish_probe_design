$ query=~/probe_candidates.fa
$ nhush mindist \
  --ref genome.fa \
  --query $query \
  --length 40 \
  --until 5 # stop within this Hamming radius
# writes to $query.L40.mindist.uint8

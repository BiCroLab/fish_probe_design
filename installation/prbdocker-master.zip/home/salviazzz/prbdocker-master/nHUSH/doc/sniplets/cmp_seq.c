int cmp_seq(uint8_t * A, uint8_t * B, seqcmp_t * X)
{
    size_t L = X->L; // string length
    /* Quick return: no RCs needed */
    if(memcmp(A, B, L) == 0)
    { return 0; }

    /* Reverse complements into pre-allocated buffers */
    rcomp(A, X->rA, L);
    rcomp(B, X->rB, L);

    if(memcmp(A, X->rA, L) > 1)
    { A = X->rA; }

    if(memcmp(B, X->rB, L) > 1)
    { B = X->rB; }

    return memcmp(A, B, L);
}

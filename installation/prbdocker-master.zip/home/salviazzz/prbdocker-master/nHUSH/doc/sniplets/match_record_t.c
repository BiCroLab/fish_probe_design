typedef struct {
    uint32_t seq1_pointer; /* Query oligo */
    uint32_t seq2_pointer; /* Matching oligo */
    uint32_t seq2_multiplicity;
    uint32_t hamming_distance;
} match_record_t;

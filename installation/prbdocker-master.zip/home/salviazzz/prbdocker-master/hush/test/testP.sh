#!/bin/bash

echo "testP.sh

Purpose: test the parallel implementation of hush
How:
1/ A 'reference genome' is created (ref.fa)
2/ Sequences to find are created (q.fa)
3/ Subfolders are generated where the query is split into the number of cores
   to be used.
4/ Hush-P is run using 1, 4, 8, 16, 32, and, 64 cores.
5/ Results are compared. Note that they are just compared in-between, i.e., to
   see that the output is the same regardless of the number of cores used.

# Timings on a 4-cores/8-threads machine (fractal):
# threads, time(s), time(s) -x
#  1, 10.4, 19.3
#  2,  5.6, 10.1 
#  4,  3.2,  5.4 
#  8,  2.3,  3.6
# 16,  2.3,  3.6
# 32,  2.3,  3.6
#
# Timings on Orion
# threads, time(s), time(s) -x
#  1, 22.0, 40.8
#  2, 12.1, 21.8
#  4,  7.3, 13.1
#  8,  4.6,  7.6
# 16,  3.2,  4.6
# 32,  2.5,  3.4
"
create_test_data() {
echo " -> Creating/regenerating test data"

if [ ! -d "q1" ]; then
  mkdir q1
else
  rm -rf q1
  mkdir q1
fi
if [ ! -d "q2" ]; then
  mkdir q2
else
  rm -rf q2
  mkdir q2
fi
if [ ! -d "q4" ]; then
  mkdir q4
else
  rm -rf q4
  mkdir q4
fi
if [ ! -d "q8" ]; then
  mkdir q8
else
  rm -rf q8
  mkdir q8
fi
if [ ! -d "q16" ]; then
  mkdir q16
else
  rm -rf q16
  mkdir q16
fi
if [ ! -d "q32" ]; then
  mkdir q32
else
  rm -rf q32
  mkdir q32
fi
if [ ! -d "q64" ]; then
  mkdir q64
else
  rm -rf q64
  mkdir q64
fi

echo "Create random reference "genome" and query file, ref.fa and q.fa"
touch ref.fa.x
rm ref.fa.*
echo "250 M reference genome"
genrand -l 25000000 -c > ref.fa
echo "400k sequences of length 60"
genrand -l 60 -n 400000 > q.fa
readrand ref.fa 60 >> q.fa

# 1 core
# split q.fa into xaa, xab, xac, xad

echo "splitting"
cd q1
split -n l/1 ../q.fa
#split -l 800000 ../q.fa
cd ..

cd q2
split -n l/2 ../q.fa
# split -l 400000 ../q.fa
cd ..

cd q4
split -n l/4 ../q.fa
#split -l 200000 ../q.fa
cd ..

cd q8
split -n l/8 ../q.fa
#split -l 100000 ../q.fa
cd ..

cd q16
split -n l/16 ../q.fa
#split -l 50000 ../q.fa
cd ..

cd q32
split -n l/32 ../q.fa
#split -l 25000 ../q.fa
cd ..

cd q64
split -n l/64 ../q.fa
#split -l 12500 ../q.fa
cd ..

echo " -> Done creating test data"
}

set -e

# Add binaries to path
if ! [ -x "$(command -v hushp)" ]; then
  PATH=$PATH:../bin/
fi

if ! [ -x "$(command -v hushp)" ]; then
  echo 'Can not find hushp!'
  echo 'Did you compile it?'
  exit 1
fi

create_test_data

# 1 thread
# split q.fa into xaa, xab, xac, xad
#echo "============= 1 th old hush ====="
#dtime ./hush -r ref.fa -l 60 -m 5 -q q.fa -o qa.fa 

echo " -> Running hushp"
echo ""
echo "============= 1 th ============="
time hushp -r ref.fa -l 60 -m 9 -q q1 -t 1 
cat q1/*.out > q1/q.out

echo "============= 2 th ============="
time hushp -r ref.fa -l 60 -m 9 -q q2 -t 2 
cat q2/*.out > q2/q.out

echo "============= 4 th ============="
time hushp -r ref.fa -l 60 -m 9 -q q4 -t 4 
cat q4/*.out > q4/q.out

echo "============= 8 th ============="
time hushp -r ref.fa -l 60 -m 9 -q q8 -t 8 
cat q8/*.out > q8/q.out

echo "============= 16 th ============="
time hushp -r ref.fa -l 60 -m 9 -q q16 -t 16 
cat q16/*.out > q16/q.out

echo "============= 32 th ============="
time hushp -r ref.fa -l 60 -m 9 -q q32 -t 32
cat q32/*.out > q32/q.out

echo "============= 64 th ============="
time hushp -r ref.fa -l 60 -m 9 -q q64 -t 64
cat q64/*.out > q64/q.out


echo "============= validating ========="
echo "no errors if the next line says done"
#diff qa.fa q1/xaa.out
diff q1/q.out q2/q.out
diff q1/q.out q4/q.out
diff q1/q.out q8/q.out
diff q1/q.out q16/q.out
diff q1/q.out q32/q.out
diff q1/q.out q64/q.out
echo "done"

echo "Was anything detected? Yes if the number of characters are different in these files:"
wc q.fa
wc q1/q.out

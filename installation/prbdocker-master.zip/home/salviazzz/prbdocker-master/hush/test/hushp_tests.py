

# for python3

import subprocess
import os
import glob
from random import randint
import sys
import math


def hamming(s1, s2):
    h = 0
    for i in range(0, len(s1)):
        if s1[i] != s2[i]:
            h = h+1
    return h


def rand_seq(length):
    # Generate a random string of length letters
    s = ''
    ATCG = {0: 'A', 1: 'T', 2: 'C', 3: 'G'}  # TODO: use same as hush
    for i in range(0, length):
        s = s + ATCG[randint(0, 3)]
    # print(s)
    return s


def gen_mm(s, mm):
    # Generate a perturbated string so that
    # the hamming distance to s is mm

    ATCG = {0: 'A', 1: 'T', 2: 'C', 3: 'G'}  # TODO: use same as hush

    sl = list(s)
    while hamming(s, ''.join(sl)) != mm:
        sl[randint(0, len(s)-1)] = ATCG[randint(0, 3)]

    # print(''.join(sl))
    return ''.join(sl)


def isseq(string):
    if len(string) < 4:
        return False
    if string[0] == '>':
        return False
    return True


def nsequences(strings):
    """ Return the number of sequences in strings
    """
    strings = strings.split('\n')
    nseq = 0
    for s in strings:
        if isseq(s):
            nseq = nseq + 1

    return nseq


def test_find(stringLength=60, mismatches=5):
    """ Ensure that queries are found up to the number of specified
    mismatches
    """

    cleanup()

    teststr = (f'test_find(stringLength={stringLength}, '
               f'mismatches={mismatches})')

    refFile = 'ref.fa'
    cleanup()

    seq = rand_seq(stringLength)

    with open(refFile, 'w') as of:
        of.write(rand_seq(10000 + randint(0, 100000)))
        of.write(seq)
        of.write(rand_seq(10000 + randint(0, 100000)))

    with open('query/xaa', 'w') as of:
        of.write(f'> 0 mm\n')
        of.write(seq + '\n')
        for i in range(0, 1000):
            mm = randint(0, mismatches)
            of.write(f'> {mm} mm\n')
            of.write(gen_mm(seq, mm) + '\n')

    cmd, hout = run_hush(stringLength=stringLength, mode='-x',
                         fro=0, to=mismatches)

    with open('query/xaa.out', 'r') as inf:
        result = inf.read()

    # Test has passed if all sequences are filtered out
    passed = (nsequences(result) == 0)

    if not passed:
        print('TEST FAILED')
        print(f'{nsequences(result)} not found!')
        print(teststr)
        print(cmd)
        print(hout)
        exit(1)


def cleanup():
    files = glob.glob('./ref.fa.*')
    for f in files:
        os.remove(f)
        # print('rm ' + f)


def test_discard(stringLength=60, newline=True, keepPerfect=True):
    """
    Tests discard mode
    - If perfect=True, perfect matches are noticed and hence the
    output should be empty.
    - If newline=True the sequence is terminated with a '\n'
    otherwise not.
    """

    teststr = (f'test_discard(stringLength={stringLength}, '
               f'newline={newline}, keepPerfect={keepPerfect})')

    refFile = 'ref.fa'
    cleanup()

    seq = rand_seq(stringLength)

    with open(refFile, 'w') as of:
        of.write(seq)

    with open('query/xaa', 'w') as of:
        if newline:
            of.write(seq + '\n')
        else:
            of.write(seq)

    if keepPerfect:
        cmd, hout = run_hush(stringLength=stringLength, mode='-x', fro=1)
    else:
        cmd, hout = run_hush(stringLength=stringLength, mode='-x', fro=0)

    with open('query/xaa.out', 'r') as inf:
        result = inf.read()

    if keepPerfect:
        passed = (len(result) > 0)
    else:
        passed = (len(result) == 0)

    if not passed:
        print('TEST FAILED')
        print(teststr)
        print(cmd)
        print(hout)
        exit(1)


def test_hushp_unit_tests():
    # Run the few built in unit tests
    run_hush_args(['-u'], retcode=0)
    return


def test_return_values():
    # No arguments
    run_hush_args([], retcode=1)
    # Ask for help
    run_hush_args(['--help'], retcode=0)
    # Ask for version
    run_hush_args(['--version'], retcode=0)
    # Give non-used parameter
    run_hush_args(['--spagettimonster'], retcode=1)
    # Should also return error when files can't be found...
    return


def run_hush_args(hushArgs=[], retcode=0):
    cmd = hushArgs
    cmd.insert(0, 'hushp')
    process = subprocess.Popen(cmd,
                               stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE,
                               universal_newlines=True)
    stdout, stderr = process.communicate()

    if process.returncode != retcode:
        print(' '.join(cmd))
        print(f'Return code: {process.returncode} (expected {retcode})')
        print(stdout)
        print(stderr)
        exit(1)

    return ' '.join(cmd), stdout
    # print(stdout)


def run_hush(stringLength, refFile='ref.fa', queryFolder='query/',
             fro='1', to='5', mode='-x', nThreads=1, retcode=0):
    # retcode: expected return value
    hushArgs = (f'-l {stringLength} '
                f'-t {nThreads} -q {queryFolder} '
                f'-r {refFile} -f {fro} -m {to}')
    cmd = hushArgs.split(' ')
    cmd.insert(0, 'hushp')
    cmd.append(mode)
    process = subprocess.Popen(cmd,
                               stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE,
                               universal_newlines=True)
    stdout, stderr = process.communicate()

    if process.returncode != retcode:
        print(' '.join(cmd))
        print(f'Return code: {process.returncode} (expected {retcode})')
        print(stdout)
        print(stderr)
        exit(1)

    return ' '.join(cmd), stdout
    # print(stdout)


def reprint(s):
    sys.stdout.write('\r' + s)
    sys.stdout.flush()


if __name__ == '__main__':
    print("Testing hushp")

    # Things to do:
    # -- have way to reproduce tests
    # -- keep track of failed tests and go on...

    # Parallel vs single thread
    # Make sure that not too much is found
    # Count mode and exact count mode
    # Formatting of output ... let the tests define this

    print(' -> Built in unit tests')
    test_hushp_unit_tests()

    print(' -> Correct return values')
    test_return_values()

    print(' -> Finding query strings within hamming radius')
    for stringLength in range(15, 61):
        for mismatches in range(1, math.floor(stringLength/6)):
            reprint((f'   string length: {stringLength}, '
                     f'mismatches: {mismatches}'))
            test_find(stringLength=stringLength, mismatches=mismatches)
    print("")

    print(' -> Agnostic to newline at end of last query string')
    test_discard(15, newline=False, keepPerfect=True)
    test_discard(15, newline=False, keepPerfect=False)

    print(' -> Discard mode, keep/discard perfect match')
    for stringLength in range(15, 60):
        reprint(f'   string length: {stringLength}')
        test_discard(stringLength, newline=True, keepPerfect=True)
        test_discard(stringLength, newline=True, keepPerfect=False)
    print("")

    exit(0)

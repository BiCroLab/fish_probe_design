

genrand -l 1000 -c > test.fa
fafile=test.fa
rm test.fa.*
rm query/xaa.out

seq=$(readrand $fafile 40 123)
echo "Sequence:"
echo $seq
echo $seq > query/xaa
hushp -x -l 40 -m 0 -q query -t 1 -r test.fa -f 0 -C -p 1 -g 123:123 
echo "--> With ignore:"
cat query/xaa.out

hushp -x -l 40 -m 0 -q query -t 1 -r test.fa -f 0 -C -p 1 
echo "--> Without ignore:"
cat query/xaa.out



#!/bin/bash

echo "testP_count.sh

Purpose: test the match counting feature
"
create_test_data() {
echo " -> Creating/regenerating test data"

if [ ! -d "q2c" ]; then
  mkdir q2c
else
  rm -rf q2c
  mkdir q2c
fi

echo "Create random reference "genome" and query file, ref.fa and q.fa"
touch ref.fa.x
rm ref.fa.*

echo "2 M reference genome"
genrand -l 200000 -c > ref.fa
echo "1k sequences of length 40"
genrand -l 40 -n 1000 -c > q.fa

genmm -c -f 0 -t 10 -s ATAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA > q.fa
# self-match
cp q.fa ref.fa

echo "splitting"
cd q2c
# split -n l/2 ../q.fa
split -l 500 ../q.fa
cd ..

echo " -> Done creating test data"
}

set -e

# Add binaries to path
if ! [ -x "$(command -v hushp)" ]; then
  PATH=$PATH:../bin/
fi

if ! [ -x "$(command -v hushp)" ]; then
  echo 'Can not find hushp!'
  echo 'Did you compile it?'
  exit 1
fi

create_test_data

# 1 thread
# split q.fa into xaa, xab, xac, xad
#echo "============= 1 th old hush ====="
#dtime ./hush -r ref.fa -l 60 -m 5 -q q.fa -o qa.fa 

echo " -> Running hushp"
echo ""
echo ""

echo "============= 2 th ============="
# First run, should add a new column with counts
time hushp -r ref.fa -l 40 -m 5 -q q2c -t 2 -o qa.fa -c
# Second run, should increment the counts
cat q2c/*.out > q2c/q.out_1
cd q2c
# split -n l/2 ../q.fa
split -l 500 q.out_1
cd ..
time hushp -r ref.fa -l 40 -m 5 -q q2c -t 2 -o qa.fa -c
cat q2c/*.out > q2c/q.out_2

echo "Output stored in q2c/q.out_2"


echo "============= validating ========="
echo "TODO"

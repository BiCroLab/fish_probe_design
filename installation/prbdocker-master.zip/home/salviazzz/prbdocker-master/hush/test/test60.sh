#!/bin/bash
set -e


# Add binaries to path (temporarily)
if ! [ -x "$(command -v hushp)" ]; then
  PATH=$PATH:../bin/
fi

if ! [ -x "$(command -v hushp)" ]; then
  echo 'Can not find hushp!'
  echo 'Did you compile it?'
  exit 1
fi

# Create a directory for temporary data
if [ ! -d "data" ]; then
  mkdir data
fi

chrfile="/data/hg/Homo_sapiens.GRCh37.dna.chromosome.9.fa"
echo "Location of chr9: $chrfile
change if not correct
"

genmm -s TCTACAGTTTGAAAGCCACTATTTTATGAACCAAGTAGAACAAGATATTTGAAATGGAAA -f 0 -t 7 > data/few60
hush -l 60 -r $chrfile -q data/few60 -o temp -m 5 -p 1 

cat temp

genmm -s TCTACAGTTTGAAAGCCACTATTTTATGAACCAAGTAGAACAAGATATTTGAAATGGAAA -f 5 -t 5 -n 10000 -c > data/many60
wc -l data/many60
hush -l 60 -r $chrfile -q data/many60 -o temp -m 5 -p 1 
echo "output should be empty!"
wc -l temp

# Memory usage
#valgrind --tool=massif --pages-as-heap=yes --massif-out-file=massif.out  ./a.out -l 60 -r chr9.fa -q few60 -o temp -m 5 -v 1 

#grep mem_heap_B massif.out | sed -e 's/mem_heap_B=\(.*\)/\1/' | sort -g | tail -n 1


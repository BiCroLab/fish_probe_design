#!/bin/bash

# Example on brute force matching with hamming distance 5
# Edit $GEOMEDIR to point to a folder with .fa files
# Example usage: ./bfm.sh AGATTCGATAA

PATH=$PATH:../bin/

set -e  # abort on errors

GENOMEDIR=/data/hg/hg19/

for hgfile in $GENOMEDIR/*.fa ; do
  bfm $hgfile $1
done



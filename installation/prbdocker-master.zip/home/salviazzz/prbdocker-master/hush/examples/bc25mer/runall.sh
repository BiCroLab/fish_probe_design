#!/bin/bash

# Example file for how to run hush on some query sequences
# against the whole genome.

set -e  # abort on errors

mkdir query

nThreads=4

GENOMEDIR=../hg/GRCh37/
queryFile=bc25mer.240k.fasta
HCONF="-m 2 -l 25 -m 2 -x -t $nThreads -p 1"

echo "HUSH config: $HCONF"

cd query 
  split -n l/$nThreads ../$queryFile
cd ..

for hgfile in $GENOMEDIR/*.fa ; do
  hushp $HCONF -r $hgfile -q query 
  cd query
  cat *.out > query.out # join the output files
  split -n l/$nThreads query.out # split them again
  cd ..
done

# Output is in query/query.out
cleaner -f query/query.out -n > bc25mer.240k.Hamming2.fasta

exit 1

Examples on how to process the [25-mers](https://elledge.hms.harvard.edu/?page_id=638) from (https://doi.org/10.1073/pnas.0812506106)





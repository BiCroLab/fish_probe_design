#!/bin/bash

# Example file for how to run hush on some query sequences
# against the whole genome.

set -e  # abort on errors

nThreads=4

GENOMEDIR=../hg/GRCh37/
queryString=TTGGCTTTCAGGCTTTAAACTACCT
outFile=bc73451

touch $outFile
rm $outFile
touch $outFile

for hgfile in $GENOMEDIR/*.fa ; do
  echo $hgfile
  bfm -r $hgfile -s $queryString -m 2 -x >> $outFile
done

# cat $outFile

exit 1

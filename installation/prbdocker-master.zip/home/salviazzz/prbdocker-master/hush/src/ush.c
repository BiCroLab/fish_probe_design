#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>

// Suggests to do it by hand
// https://danluu.com/assembly-intrinsics/
// 
// however objdump -d a.out suggests that gcc is doing a good job with
// popcount today.

/*
 * Timings on mbp, 2.8 Ghz
 * For qL = 300000000 (300 M)
 * nQ
 *   1   1.5 s
 *   2   2.6 s
 *  10   9.2 s
 *  20  18.7 s
 * 100  89.6 s 
 *  t = .6 + .9*nQ
 *
 * For qL = 3000000000 (3 B)
 * nQ
 *   1   15.4 s
 *   2   26.5 s
 *  10   97.5 s
 *  t = 7.5 +  9*nQ
  *
 */


  static inline 
unsigned int hamming32(uint8_t * a, uint8_t * b)
{
  uint32_t * A = (uint32_t *) a;
  uint32_t * B = (uint32_t *) b;
  return __builtin_popcountl(A[0] & B[0]);
}

  static inline
unsigned int hamming64(uint8_t * a, uint8_t * b)
{
  uint64_t * A = (uint64_t *) a;
  uint64_t * B = (uint64_t *) b;
  return __builtin_popcountll(A[0] & B[0]);
}


void init(uint8_t * S, size_t nS)
{
  for(size_t kk = 0; kk<nS; kk++)
  {
    uint8_t n = rand() % 4;
    n = n+1;
    switch(n){
      case 1:
        S[kk] = 1;
        break;
      case 2:
        S[kk] = 2;
        break;
      case 3:
        S[kk] = 4;
        break;
      case 4: 
        S[kk] = 8;
        break;
    }
  }

  for(int kk = 0; kk<10; kk++)
    printf("%u ", S[kk]);

  printf("\n");
}

unsigned int match2(uint8_t * restrict S, const size_t nS, uint8_t ** restrict Q, const size_t nQ, const size_t lQ, size_t * restrict M)
{
  unsigned int s = 0;
  const int s_max = 54;
  for(size_t kk = 0; kk<nS; kk++)
  {
    for(size_t qq = 0; qq<nQ; qq++)
    {
    s = 0;
    for(int ll = 0; ll<60; ll++)
    {
      s = s + (S[kk+ll] == Q[qq][ll]);
    }
    if(s>s_max)
      M[qq]++;
  }
  }
  return s_max;
}

unsigned int match1(uint8_t * restrict S, const size_t nS, uint8_t ** restrict Q, const size_t nQ, const size_t lQ, size_t * restrict M)
{
  unsigned int s = 0;
  const int s_max = 54;
  for(size_t kk = 0; kk<nS; kk++)
  {
    for(int qq = 0; qq<nQ; qq++)
    {
    s = 0;
    s = s + hamming64(S+kk+0,  Q[qq]+0);
    s = s + hamming64(S+kk+8,  Q[qq]+8);
    s = s + hamming64(S+kk+16, Q[qq]+16);
    s = s + hamming64(S+kk+24, Q[qq]+24);
    s = s + hamming64(S+kk+32, Q[qq]+32);
    s = s + hamming64(S+kk+40, Q[qq]+40);
    s = s + hamming64(S+kk+48, Q[qq]+48);
    s = s + hamming32(S+kk+56, Q[qq]+56);
    if(s>s_max)
      M[qq]++;
    }
  }
  return s_max;
}


int main(int argc, char ** argv)
{

//  sranddev(); // Only on FreeBSD/OsX

  // Default settings
  size_t lS = 3000000000; // length of reference sequence                 
  size_t nQ = 1; // number of queries
  size_t lQ = 60; // length of each query

  // Parsing
  if(argc == 2)
    nQ = atol(argv[1]);



  size_t * M1 = malloc(nQ*sizeof(size_t));
  size_t * M2 = malloc(nQ*sizeof(size_t));
  for (int kk = 0; kk<nQ; kk++)
  {
    M1[kk] = 0;
    M2[kk] = 0;
  }

  printf("lS: %zu nQ: %zu lQ: %zu\n", lS, nQ, lQ);

  uint8_t * S = malloc(lS*sizeof(uint8_t));

  uint8_t ** Q = malloc(nQ*sizeof(uint8_t*));
  for(int kk = 0; kk<nQ; kk++)
  {
    Q[kk] = malloc(lQ*sizeof(uint8_t));
    init(Q[kk], lQ);
  }

  init(S,lS);

  size_t x = 0;
  match2(Q[0], lQ, Q, 1, lQ, &x);
  printf("x=%zu\n", x);
  assert(x == 1);

  printf("__builting_popcount\n");
  clock_t begin = clock();
  printf("%u\n", match1(S, lS, Q, nQ, lQ, M1)); 
  clock_t end = clock();
  printf("Took %f s\n",  (double)(end - begin) / CLOCKS_PER_SEC);

  printf("brutus\n");
  begin = clock();
  printf("%u\n", match2(S, lS, Q, nQ, lQ, M2));
  end = clock();
  printf("Took %f s\n",  (double)(end - begin) / CLOCKS_PER_SEC);

  if(0)
  {
  printf("   pop brute\n");
  for(int kk = 0; kk<nQ; kk++)
   printf("q%d, %zu, %zu\n", kk, M1[kk], M2[kk]);
  }
  return 0;
} 

#include <stdio.h>
#include <stdlib.h>

#define main
#include "hmatchSingleP.c"
#undef main

int main(int argc, char ** argv)
{

  char * S = "GAGTCAGATATATATATATGGAGAG";

  int L = 20;

  sparam * Q = sparam_init();
  sparam_set_ssl(Q, L);

  printf("sequence: %s\n", S);

  printf("%u\n", subs_hash_v0(S, Q));
  printf("# subs_hash_v1_3\n");
  for(int variation = -1; variation<3*L; variation++)
  {
    printf("%d %u\n", variation, subs_hash_v1_3(S, variation, Q));
  }

  printf("# subs_hash_v1\n");
  for(int variation = -1; variation<4*L; variation++)
  {
    printf("%d %u\n", variation, subs_hash_v1(S, variation, Q));
  }



  return(0);
}

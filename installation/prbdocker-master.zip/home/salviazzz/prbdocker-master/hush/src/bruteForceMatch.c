#define _GNU_SOURCE

#include <assert.h>
#include <math.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <getopt.h>

#define main
#include "hmatchSingleP.c"
#undef main

/*
 * Brute force matching of a single oligo vs a single chromosome.
 */

typedef struct{
    char * rfile; // Reference file
    char * qfile; // Query file
    char * string; // Query string
    int mmin; // Ignore matches < mmin
    int mmax;  // Max mismatches
    int reverse; // reverse complement or not
    int showTable;
    int quiet;
} bconf;

void bconf_show(bconf* C)
{
    printf("rfile=%s\n", C->rfile);
    printf("qfile=%s\n", C->qfile);
    printf("string=%s\n", C->string);
    printf("mmin=%d\n", C->mmin);
    printf("mmax=%d\n", C->mmax);
    printf("reverse=%d\n", C->reverse);
    printf("showTable=%d\n", C->showTable);
}

bconf * bconf_new()
{
    bconf * C = malloc(sizeof(bconf));
    C->rfile = NULL;;
    C->qfile = NULL;
    C->string = NULL;
    C->mmin = 0;
    C->mmax = 5;
    C->reverse = 1;
    C->showTable = 0;
    C->quiet = 0;
    return C;
}

void bconf_free(bconf * C)
{
    if(C->rfile != NULL)
    {
        free(C->rfile);
    }
    if(C->string != NULL)
        {
    free(C->string);
        }
    if(C->qfile != NULL)
    {
        free(C->qfile);
    }
    return;
}

void bfm_usage()
{
    printf("Usage:\n");
    printf(" bfm -r reference.fa -s string -v -m -x\n");
    printf(" OPTIONS:\n");
    printf(" -r [file]\n\t Specify reference file\n");
    printf(" -s [string]\n\t Specify query string\n");
    printf(" -q qfile\n\t Specify a fasta query file.\n");
    printf(" -M [number]\n\t Specify the Hamming radius "
           "(distance <=M is considered a hit)\n");
    printf(" -y \n\t Don't scan reverse complement\n");
    printf(" -h \n\t Show this help message\n");
    printf(" -v \n\t Show version\n");
    printf(" -t \n\t show summary table at the end\n");
    printf(" -Q \n\t quiet, don't print matches "
           "to be used with -t\n");
    printf("See man page for more info.\n");
    return;
}

int bfm_hamming(uint8_t * A, uint8_t * B, int N)
{
    int d = N;
    for(int kk = 0; kk<N; kk++)
    {
        d -= (A[kk] == B[kk]);
    }
    return d;
}


int bfm_qfile(bconf * C)
{
    // When a query file is used

    // Read the reference file
    sparam * Q = sparam_init();
    sprintf(Q->rFile, "%s", C->rfile);
    sparam_init_D(Q);

    FILE * fquery = fopen(C->qfile, "r");
    assert(fquery != NULL);

    size_t linecap = 1024;
    char * string = malloc(1024+2);
    size_t qread = 0;

    uint8_t * QS = malloc(1024);
    uint8_t * QSrc = malloc(1024);


    while( (qread = getline(&string, &linecap, fquery)) != -1)
    {
        // Remove '\n' from the end of R
        qread = char_trimnewline(string, qread);
        if(string[0] < 'A' || string[0] > 'T') // if comment or unrecognized
        {
            fprintf(stdout, "%s\n", string); // write unchanged
        }
        else // if sequence of length sl
        {
            int match = 0;
            int len = strlen(string);
            Q->sl = len;
            to_digital(QS, string, len);
            reverse_complement(Q, QSrc, QS);

            for(size_t kk = 0; kk < Q->nD-len; kk++)
            {
                int d = bfm_hamming(QS, Q->D+kk, len);
                if(d <= C->mmax)
                {
                    if(d > C->mmin)
                    {
                        match = 1;
                    }
                }
                d = bfm_hamming(QSrc, Q->D+kk, len);
                if(d <= C->mmax)
                {
                    if(d > C->mmin)
                    {
                        match = 1;
                    }
                }
                //if(match)
                //    break;
            }
            if(match == 0)
            {
                fprintf(stdout, "%s\n", string);
            }
        }
    }
    return 0;
}

void bf_argparsing(bconf * C, int argc, char ** argv)
{
    int gotr = 0; // reference
    int gots = 0; // string
    int gotq = 0; // query file

    struct option longopts[] = {
                                {"help", no_argument, NULL, 'h'},
                                {"ref", required_argument, NULL, 'r'},
                                {"from", required_argument, NULL, 'm'},
                                {"to", required_argument, NULL, 'M'},
                                {"to", required_argument, NULL, 'M'},
                                {"no-reverse", no_argument, NULL, 'y'},
                                {"version", no_argument, NULL, 'v'},
                                {"table", no_argument, NULL, 't'},
                                {"string", required_argument, NULL, 's'},
                                {"quiet", no_argument, NULL, 'Q'},
                                {NULL, 0, NULL, 0}};

    char ch;
    while((ch = getopt_long(argc, argv, "r:s:hvm:M:xtq:Q", longopts, NULL)) != -1)
    {
        switch(ch){
        case 'q':
            C->qfile = malloc(strlen(optarg)+2);
            sprintf(C->qfile, "%s", optarg);
            gotq = 1;
            break;
        case 'Q':
            C->quiet = 1;
            break;
        case 'h':
            bfm_usage();
            exit(1);;
            break;
        case 'v':
            hush_version();
            exit(1);
            break;
        case 'r':
            C->rfile = malloc(strlen(optarg)+2);
            strcpy(C->rfile, optarg);
            gotr = 1;
            break;
        case 's':
            C->string = malloc(strlen(optarg)+2);
            strcpy(C->string, optarg);
            gots = 1;
            break;
        case 'm':
            C->mmin = atoi(optarg);
            break;
        case 'M':
            C->mmax = atoi(optarg);
            break;
        case 'y':
            C->reverse = 0;
            break;
        case 't':
            C->showTable = 1;
            break;
        }
    }

    bconf_show(C);

    if(gotr == 0)
    {
        printf("No reference file given\n");
        exit(1);
    }

    if(gots == 0 && gotq == 0)
    {
        printf("No query string or query file specified\n");
        exit(1);
    }

    if(gots == 1 && gotq == 1)
    {
        printf("Both query string and query file specified\n");
        exit(1);
    }

}

void bfm_string(bconf * C)
{

    sparam * Q = sparam_init();
    sprintf(Q->rFile, "%s", C->rfile);

    size_t * M = malloc((C->mmax+1)*sizeof(size_t));
    for(size_t kk=0; kk < C->mmax+1; kk++)
        M[kk] = 0;

    Q->sl = strlen(C->string);
    char * R = C->string;
    uint8_t * Rv = malloc(1024*sizeof(char));
    to_digital(Rv, R, strlen(R));
    uint8_t * Rrcv = malloc(strlen(R)*sizeof(uint8_t));
    reverse_complement(Q, Rrcv, Rv);

    Q->verbose = 0;
    sparam_init_D(Q);
    Q->verbose = 2;

    int delta = 0;
    for(size_t pos = 0; pos<Q->nD-Q->sl; pos++)
    {
        if(C->reverse)
        {
            delta = hamming(Rrcv, Q->D+pos, Q);
            if( delta > C->mmin && delta <= C->mmax)
            {
                M[delta]++;
                // bamwrite ...
                if(C->quiet == 0)
                {
                    printf("\n%s, (%zu) RC\n", C->rfile, pos);
                    hamming_print(stdout, Q->D+pos, Rrcv, Q);
                }
            }
        }

        delta = hamming(Rv, Q->D+pos, Q);
        if( delta <= C->mmax)
        {
            M[delta]++;
            if(C->quiet == 0)
            {
                printf("\n%s (%zu):\n", C->rfile, pos);
                hamming_print(stdout, Q->D+pos, Rv, Q);
            }
        }
    }

    if(C->showTable)
    {
        printf("\n");
        printf("Hamming distance, number of hits\n");
        for(int kk = C->mmin; kk<= C->mmax; kk++)
        {
            printf("%3d, %zu\n", kk, M[kk]);
        }
        printf("\n");
    }
    sparam_free(Q);
}

int main(int argc, char ** argv)
{

    if(argc<3)
    {
        bfm_usage();
        return -1;
    }

    struct timespec ta, tb;
    clock_gettime(CLOCK_MONOTONIC, &ta);

    bconf * C = bconf_new();
    bf_argparsing(C, argc, argv);

    if(C->string != NULL)
    { // scan a single file
        bfm_string(C);
    }

    if(C->qfile != NULL)
    { // scan vs a fasta file
        bfm_qfile(C);
    }

    bconf_free(C);
    free(C);

    clock_gettime(CLOCK_MONOTONIC, &tb);
    printf("Took: %.1f s\n", clockdiff(&ta, &tb));
    return(0);
}

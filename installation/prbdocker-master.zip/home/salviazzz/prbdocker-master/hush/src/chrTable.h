/*
 * Small library for reading two-column tsv files.
 *
 * Used in hush to read information about concatenated
 * input files in order to be able to map indexes to specific
 * files and local coordinates.
 *
 * chrTable_init
 * Read a tsv file with rows like: <size>\t<name>, Example:
 
 $ head -n 3 /data/hg/GRCh37/GRCh37_all.fa.tsv
135534747	omo_sapiens.GRCh37.dna.chromosome.10.fa
135006516	Homo_sapiens.GRCh37.dna.chromosome.11.fa
133851895	Homo_sapiens.GRCh37.dna.chromosome.12.fa

Then later on
chrTable_get will retrieve filename and position from a global
index. I.e.
chrTable_get(135534746) > Homo_sapiens.GRCh37.dna.chromosome.10.fa:135534747
chrTable_get(135534747) > Homo_sapiens.GRCh37.dna.chromosome.11.fa:0
...

 *
 * for stand-alone debuggin, use:
 * use -DchrTableMain 
 */


#ifndef __chrTable_h__
#define __chrTable_h__

typedef struct{
  size_t * start;
  size_t * end;
  size_t nrows; // Number of used rows
  size_t  size; // max number of rows
  char ** names;
} cht;

// Load a tsv table with size, name
// returns NULL on failure
cht * chrTable_init(char * file);
// Free a cht object
void chrTable_free(cht * T);
// Return the position within a chromosome from the global position pos
int chrTable_get(cht *, size_t gpos, size_t * lpos, char ** name);
// Show the table
void chrTable_show(cht * T);


#endif

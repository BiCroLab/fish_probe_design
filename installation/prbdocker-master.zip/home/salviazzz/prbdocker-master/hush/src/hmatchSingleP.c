#define _GNU_SOURCE

#ifndef __APPLE__
#define _XOPEN_SOURCE 700 // Make getline visible on on linux but hides qsort_r on osx
#endif

#include <assert.h>
#include <math.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <getopt.h>
#include "chrTable.h"
#include "hmatchSingleP.h"
#include "hush.h"

#include "hush_server.h"
#include "hush_ssl_mm.c"

int read_D(char * rFilePreName, sparam * Q)
  // called by sparam_init_D, reads a .fa.D file
{
  FILE * rFilePre = fopen(rFilePreName, "r");
  struct stat st;
  int status = stat(rFilePreName, &st);
  if(status != 0)
  {
    fprintf(stderr, "Could not get info about %s\n", rFilePreName);
    exit(-1);
  }
  size_t fsize = st.st_size;
  Q->D = malloc(fsize);
  size_t nRead = fread(Q->D, sizeof(uint8_t), fsize, rFilePre);
  if(Q->verbose>0)
  {
    printf(" Fsize: %zu, Read %zu nt\n", fsize, nRead);
  }
  Q->nD = fsize;
  free(rFilePreName);
  fclose(rFilePre);
  return 0;
}


int sparam_init_D(sparam * Q)
{
  /* Load or create an '.aD' file
   where 'A', 'C' 'G' 'T' is encoded as
    '0' '1' '2' '3'.

   If it does not exist, create one from the input reference file.

   When creating a new 'D'-file, 'A','a', is converted to 0, 'C', 'c' to 1, 'G', 'g' to 2
   and 'T', 't' to 3. That means that complimentary letters can be found by 3-l.

   Note: 'n' and 'N' are translated to 'A'=0 not to cause gaps
   alternative strategy: translate 'n' to a random base.
   */

  char * rFilePreName = malloc(1024*sizeof(char));
  sprintf(rFilePreName, "%s.aD", Q->rFile);

  if(Q->verbose>0)
  {
    printf("Reading %s, pre checked reference file\n", rFilePreName);
  }

  FILE * rFilePre = fopen(rFilePreName, "r");

  if(rFilePre != NULL)
  {
    fclose(rFilePre);
    return read_D(rFilePreName, Q);
  }

  if(Q->verbose>0)
  {
    printf("  Didn't exist, generating...\n");
    printf("  Reading r-file %s\n", Q->rFile);
  }

  // Get file size
  struct stat st;
  int status = stat(Q->rFile, &st);
  if(status != 0)
  {
    printf("  ! Can not open rFile %s\n", Q->rFile);
    return(1);
  }

  size_t fsize = st.st_size;

  // Allocate enough memory, possibly more than needed when
  // non-nucleotide characters are filtered out like line endings
  Q->D = malloc(fsize);
  if(Q->D == NULL)
  {
    printf("  ! Memory allocation failed\n");
    return(2);
  }

  FILE * f = fopen(Q->rFile, "r");
  if(f == NULL)
  {
    printf("  ! Could not open %s\n", Q->rFile);
    return(3);
  }

  // read fsize bytes
  size_t bbRead =  fread(Q->D, fsize, 1, f);
  if(bbRead != 1)
  {
    printf("  ! Failed to read from %s\n", Q->rFile);
    return(4);
  }
  fclose(f);

  size_t readpos = 0;
  size_t writepos = 0;

  if(Q->verbose>0)
    printf("  Processing data\n");

  /* Two state parser: either inside comment or not
   * assuming comments start with '>' and end with '\n'
   * */
  int inComment = 0;

  while(readpos<fsize)
  {
    char symbol = Q->D[readpos++];

    if(inComment == 1)
    {
      if(symbol == '\n')
        inComment = 0;
    }
    else
    {
      switch(symbol) {
        case '>':
          inComment = 1;
          break;
        case 'A':
          Q->D[writepos++] = 0;
          break;
        case 'a':
          Q->D[writepos++] = 0;
          break;
        case 'T':
          Q->D[writepos++] = 3;
          break;
        case 't':
          Q->D[writepos++] = 3;
          break;
        case 'C':
          Q->D[writepos++] = 1;
          break;
        case 'c':
          Q->D[writepos++] = 1;
          break;
        case 'G':
          Q->D[writepos++] = 2;
          break;
        case 'g':
          Q->D[writepos++] = 2;
          break;
        case 'n':
          Q->D[writepos++] = 0;
          break;
        case 'N':
          Q->D[writepos++] = 0;
          break;
        default:
          // Discard anything that is not atcgnATCGN, ok if non-printable characters
          break;
      }
    }
  }

  Q->nD = writepos;

  if(Q->nD < Q->sl)
  {
    printf("  ! Reference database (%zu) smaller than the string length (%d)!\n", Q->nD, Q->sl);
    printf("  ! Is everything a comment?");
    return(6);
  }

  if(Q->verbose > 0)
  {
    printf("%zu nt : ", Q->nD);
    printf(" %.*s ...\n", Q->sl, Q->D);
  }

  if(Q->verbose>1)
  {
    printf("  Q->nD = %zu\n", Q->nD);
  }

  printf("  Writing %s\n", rFilePreName);
  rFilePre = fopen(rFilePreName, "w");

  size_t nWrite = fwrite(Q->D, Q->nD, sizeof(uint8_t), rFilePre);
  printf("  Wrote %zu segment with %zu bytes\n", nWrite, nWrite*Q->nD);

  free(rFilePreName);

  return 0;
}

int hamming(const uint8_t * restrict A,
    const uint8_t * restrict B,
    const sparam * restrict Q)
{
  // Hamming distance between A and B

  int h = 0;
  for(int kk = 0; kk<Q->sl; kk++) {
    if(A[kk] != B[kk]) {
      h++;
    }
  }

  return h;
}

int hamming_print(FILE * fd, const uint8_t * restrict A, const uint8_t * restrict B, const sparam * restrict Q)
{
  // Hamming distance which also prints the alignment to the terminal
  int h = 0;
  int score = hamming(A,B,Q);

  char * Ac = malloc(((unsigned int) Q->sl)*sizeof(uint8_t));
  char * Bc = malloc(((unsigned int) Q->sl)*sizeof(uint8_t));

  to_chars(Ac, A, Q->sl);
  to_chars(Bc, B, Q->sl);


  fprintf(fd, "%.*s\n", Q->sl, Ac);
  for(int kk = 0; kk<Q->sl; kk++)
  {
    if(Ac[kk] == Bc[kk])
    {
      fprintf(fd, "|");
    } else
    {
      fprintf(fd, " ");
      h++;
    }
  }
  fprintf(fd, " %d \n", score);
  fprintf(fd, "%.*s\n", Q->sl, Bc);
  assert(h==score);
  free(Bc);
  free(Ac);
  return h;
}

size_t getUnique_uint32_t(uint32_t * L, size_t n)
{
  // Figure out how many unique entries there are in L
  // L has be be sorted

  if(n==0)
    return 0;

  uint32_t last = L[0];
  size_t u = 1; // number of unique
  for(size_t kk = 1; kk<n; kk++)
  {
    if(L[kk] != last)
    {
      u++;
      last = L[kk];
    }
  }
  return u;
}

// qsort assumes different headers depending on the architecture
#ifdef __APPLE__
int uint32_t_cmp(void * PQ, const void * PA, const void * PB)
#else
int uint32_t_cmp(const void * PA, const void * PB,void * PQ)
#endif
{
  // SS: global parameter, substring
  uint32_t * A  = (uint32_t *) PA;
  uint32_t * B = (uint32_t *) PB;

  if( A[0] == B[0] )
    return 0;
  if(A[0]>B[0])
    return 1;
  return -1;

}

#ifdef __APPLE__
int str_cmp(void * PQ, const void * PA, const void * PB)
#else
int str_cmp(const void * PA, const void * PB,void * PQ)
#endif
{
  // substring comparison

  // SS: global parameter, substring
  uint32_t * A  = (uint32_t *) PA;
  uint32_t * B = (uint32_t *) PB;
  sparam * Q = (sparam *) PQ;

  //  printf("str_cmp, pos %u vs pos %u\n", A[0], B[0]);
  //  printf("Q->ssl: %d\n", Q->ssl);

  return memcmp((char *) Q->D + (size_t) A[0], (char *) Q->D + (size_t) B[0], Q->ssl);
}


uint32_t subs_hash_v0(const uint8_t * restrict S, const sparam * restrict Q)
{

  size_t h = 0;
  for(int kk = 0; kk<Q->ssl; kk++)
  {
    h*=4;
    h+=S[kk+Q->ssl*Q->css];
    assert(S[kk+Q->ssl*Q->css] < 4);
  }

  assert( h < powl(4, Q->ssl) );
  //  printf("%lu\n", h);
  return h;
}

char val2char(const uint8_t v)
{
  switch(v) {
    case 0:
      return 'A';
      break;
    case 1:
      return 'C';
      break;
    case 2:
      return 'G';
      break;
    case 3:
      return 'T';
      break;
    default:
      assert(1==0);
  }
  assert(0);
  return '\n';
}

uint8_t char2val(const char c)
{
  switch(c) {
    case 'a':
      return 0;
      break;
    case 'A':
      return(0);
      break;
    case 'c':
      return 1;
      break;
    case 'C':
      return(1);
      break;
    case 'g':
      return 2;
      break;
    case 'G':
      return(2);
      break;
    case 't':
      return 3;
      break;
    case 'T':
      return(3);
      break;
    default:
      assert(0); // invalid letter
      return(1);
  }
}

void to_digital(uint8_t * restrict y, const char * restrict x, const size_t n)
{
  for(size_t kk=0; kk<n; kk++)
  {
    //    printf("%c=%u ", x[kk], (uint8_t) x[kk]); fflush(stdout);
    y[kk] = char2val(x[kk]);
  }
  //  printf("\n");
  return;
}

void to_chars(char * C, const uint8_t * D, const size_t n)
{
  for(size_t kk = 0; kk < n; kk++)
  {
    C[kk] = val2char(D[kk]);
  }
  return;
}

void print_br(const uint8_t * restrict v, const size_t n)
{
  for(size_t kk = 0; kk<n; kk++)
  {
    printf("%c", val2char(v[kk]));
  }
  return;
}

uint32_t subs_hash_v1_3(const uint8_t * restrict S, const int variation, const sparam * restrict Q)
{

  // A substring of length N has N*3 substrings within a hamming
  // distance of 1. This is parameterized by the argument 'variation'
  // The hash for the unaltered substring is returned when
  // variation == -1


  if(variation==-1)
  {
    return subs_hash_v0(S,Q);
  }

  // Modify character at this position
  int vpos = floor(variation/3);
  // To this variation
  int vval = variation - vpos*3;

  //  printf("vpos: %d, vval: %d\n", vpos, vval);

  assert(vpos<Q->ssl);
  assert(vval<4);

  size_t h = 0;
  for(int kk = 0; kk<vpos; kk++)
  {
    h*=4;
    h += S[kk+Q->ssl*Q->css];
  }

  // at vpos
  h*=4;
  size_t val = S[vpos+Q->css*Q->ssl];
  //  printf(" val: %zu ", val);
  val = (vval+val+1) % 4;
  //  printf("modifed val: %zu\n", val);
  h += val;

  for(int kk = vpos+1; kk<Q->ssl; kk++)
  {
    h*=4;
    h += S[kk+Q->css*Q->ssl];
  }
  assert(h<powl(4, Q->ssl));
  return h;
}

uint32_t subs_hash(uint32_t P, sparam * Q)
{
  // substring hash value
  uint8_t * S = Q->D + (size_t) P;
  uint32_t h = 0;
  for(int kk = 0; kk<Q->ssl; kk++)
  {
    h *= 4;
    h += S[kk+Q->css*Q->ssl];
  }
  return h;
}


int sparam_init_B(sparam * Q)
{
  // populates Q->B and sets Q->nB
  // B is the data structure for the buckets, it is big as the number of
  // sequences that will be hashed.

  Q->nB = Q->nD-Q->ssl;

  if(Q->verbose > 2)
  {
    printf("Q->nB: %zu\n", Q->nB);
    fflush(stdout);
  }

  Q->B = malloc(Q->nB*sizeof(uint32_t)); // bucket index

  char * bname = malloc(1024*sizeof(char*));
  sprintf(bname, "%s.aB%d", Q->rFile, Q->ssl);

  if(Q->verbose>0)
    printf("Reading %s (buckets)\n", bname);

  FILE * bFile = fopen(bname, "r");

  if(bFile == NULL)
  { // create new if not stored on disk
    if(Q->verbose>0)
    {
      printf(" does not exist, creating...\n");
      fflush(stdout);
    }

    // Initialize B as a vector of pointers to the strings in R
    for (uint32_t bb = 0; bb < Q->nB; bb++)
      Q->B[bb] = bb;

    // Sort the indexes based on the strings that they point at
#ifdef __APPLE__
    qsort_r(Q->B, Q->nB, sizeof(uint32_t), (void *) Q, str_cmp);
#else
    qsort_r(Q->B, Q->nB, sizeof(uint32_t), str_cmp, (void *) Q);
#endif

    /*
    // What is the purpose?
    printf("Some strings:\n");
    for(size_t kk = 0; kk<1000; kk=kk+100)
    {
    printf("%9zu ", kk);
    print_br(Q->D + Q->B[kk], 40); printf(" = %zu\n", (size_t) subs_hash_v0(Q->D + Q->B[kk], Q));
    }
    */


    bFile = fopen(bname, "w");
    size_t nWrite = fwrite(Q->B, Q->nB, sizeof(uint32_t), bFile);
    if(Q->verbose>0)
      printf("  Wrote %zu values\n", nWrite);

  }
  else
  { // Load from disk if already exists
    size_t nRead = fread(Q->B, sizeof(uint32_t), Q->nB, bFile);
    if(Q->verbose > 1) {
      printf("Read %zu values\n", nRead);
    }
    //    assert((size_t) nRead == (size_t) powl(4, Q->ssl));
  }

  free(bname);
  fclose(bFile);
  return 0;
}

int sparam_init_H(sparam * Q)
{
  /* One index per possible hash value */

  assert(Q->nH>0);
  Q->H = malloc((Q->nH+1)*sizeof(uint32_t));
  assert(Q->H != NULL);

  if(Q->verbose > 0) {
    printf("  Q->nH = %zu\n", Q->nH);
  }

  if(Q->verbose>1) {
    printf(".");
    fflush(stdout);
  }

  char * bname = malloc(1024*sizeof(char*));
  sprintf(bname, "%s.aH%d", Q->rFile, Q->ssl);

  if(Q->verbose>0) {
    printf("Reading %s, HASH table\n", bname);
  }

  FILE * bFile = fopen(bname, "r");

  if(bFile == NULL)
  {
    if(Q->verbose>0)
      printf("  does not exist, creating...\n");

    for(size_t ll=0; ll<Q->nH+1; ll++)
      Q->H[ll] = (uint32_t) -1;

    for(size_t ll = 0; ll<Q->nB; ll++)
    {
      //      printf("%u\n", Q->B[ll]);
      // assert(Q->B[ll] < Q->nD);
      uint32_t h = subs_hash_v0(Q->D + Q->B[ll], Q);
      uint32_t h1 = subs_hash(Q->B[ll], Q);
      assert(h1 == h);

      if(h > Q->nH)
      {
        printf("h=%zu h1 = %zu\n", (size_t) h, (size_t) h1);
        assert(0);
      }

      // Since BI is sorted, we use the first one as the starting point of the bucket
      if(Q->H[h] == (uint32_t) -1)
        Q->H[h] = ll;
    }

    // set first and last element
    if(Q->H[0] == (uint32_t) -1)
      Q->H[0]=0;
    Q->H[Q->nH] = Q->nB-1; // remember, HI[kk] is bucket_size+1 long

    // Walk backwards and propagate the start position of the later
    // buckets.
    for(size_t ll = Q->nH-1; ll>0; ll--)
    {
      if(Q->H[ll] == (uint32_t) -1)
        Q->H[ll] = Q->H[ll+1];
    }

#ifndef NDEBUG
    if(Q->verbose > 2)
    {
      for(size_t ll = 1; ll < Q->nH; ll++)
      {
        if(Q->H[ll] < Q->H[ll-1])
        {
          printf("H[%zu] = %zu\n", (size_t) ll-1, (size_t) Q->H[ll-1]);
          printf("H[%zu] = %zu\n", (size_t) ll, (size_t) Q->H[ll]);
        }
      }
    }
#endif

    bFile = fopen(bname, "w");
    size_t nWrite = fwrite(Q->H, Q->nH+1, sizeof(uint32_t), bFile);
    if(Q->verbose>0)
      printf("  Wrote %zu values\n", nWrite);

  }
  else
  {
    size_t nRead = fread(Q->H, sizeof(uint32_t), Q->nH+1, bFile);
    if(Q->verbose>0)
      printf("  Read %zu values\n", nRead);
  }

  fclose(bFile);

  free(bname);
  return 0;
}

void sparam_show(sparam * Q)
{
  printf("### Settings\n");
  printf("# Sequence length: %d\n", Q->sl);
  printf("# Hamming radius: %d\n", Q->hr);
  printf("# Min hamming radius: %d\n", Q->mm_min);
  printf("# Sub string length: %d\n", Q->ssl);
  printf("# Number of substrings: %d\n", Q->nss);
  printf("# Mismatches per substring: %d (up to)\n", Q->mm);
  printf("# Theoretical gain vs brute force: %d\n", Q->gain);
  printf("# Reference file: %s\n", Q->rFile);
  printf("# Query file: %s\n", Q->qFile);
  //  printf("# Output file: %s\n", Q->oFile); // Not for parallel hush, will generate .out-files instead
  printf("# verbose level: %d\n", Q->verbose);

  printf("# Reverse complement: ");
  if(Q->rc == 1) { printf("Yes\n"); }
  else { printf("No\n"); }

  printf("# Mode: ");
  switch(Q->mode)
  {
    case MODE_DISCARD:
      printf("discard\n");
      break;
    case MODE_COUNT:
      printf("counting matches (inexact, might count duplicates)\n");
      break;
    case MODE_COUNT_EXACT:
      printf("counting matches (exact)\n");
      break;
    default:
      printf("UNKNOWN!\n");
  }

  if(Q->rIgnore == 1)
  {
    printf("# Will ignore [%zu, %zu] in the reference\n", Q->rIgnoreA, Q->rIgnoreB);
  }
  else
  {
    printf("# No region will be ignored (no -g parameter used)\n");
  }

  // String must be longer than the sum of it's substrings
  assert(Q->sl >= Q->ssl*Q->nss);
  assert(Q->nH > 0);
  assert(Q->nB > 0);

}

void sparam_set_ssl(sparam * Q, int ssl)
{
  Q->ssl = ssl;
  Q->nH = powl(4, Q->ssl);
}

sparam * sparam_init()
{
  sparam * Q = malloc(sizeof(sparam));

  Q->D = NULL;
  Q->nD = 0;
  Q->sl = 0;
  Q->hr = 0;
  Q->H = NULL;
  Q->B = NULL;
  Q->nH = 0;
  Q->mm_min = 1;
  Q->mm = 0;
  Q->css = 0;
  Q->nss = 0;
  Q->ssl = 0;
  Q->verbose = 1;
  Q->rc = 0;
  Q->mode = MODE_DISCARD;
  Q->nPosMax = 100000; // Largest number of unique sequences that can be found
  Q->nIgnore = 1000;
  Q->gain = -1;

  Q->nQueries = 0;

  Q->rIgnore = 0;
  Q->rIgnoreA = 0;
  Q->rIgnoreB = 0;

  Q->rFile = (char * ) malloc(1024*sizeof(char));
  sprintf(Q->rFile, "\n");
  Q->qFile = (char * ) malloc(1024*sizeof(char));
  sprintf(Q->qFile, "\n");
  Q->oFile = (char * ) malloc(1024*sizeof(char));
  sprintf(Q->oFile, "\n");

  Q->nThreads = 0;
  Q->thread = -1;
  Q->thread_done = 0;
  Q->server = 0;
  Q->Pos = NULL;

  if(Q->mode == MODE_COUNT_EXACT)
  {
    // Set up buffer for storing matches
    Q->Pos = malloc(Q->nPosMax*sizeof(uint32_t));
    Q->nPos = 0;
  }

  return Q;
}


void sparam_recalc(sparam * Q)
{
  // update ssl and mm based on hr and sl
  //  int setValues = 0;

  int L = Q->sl;
  int hr = Q->hr;
  int ssl = -1;
  int mm = -1;
  int nss = -1;
  int gain = hush_ssl_mm(L, hr, &ssl, &mm, &nss);

  if(gain < 1)
  {
    printf("Failed to find settings for sub string length and mismatches per substring for the given combination of string length and hamming radius\n");
    exit(1);
  }

  Q->nss = nss;
  sparam_set_ssl(Q, ssl);
  Q->mm = mm;
  Q->gain = gain;
  return;
}

void sparam_set_hr(sparam * Q, int hr)
{
  Q->hr = hr;
}

void sparam_set_sl(sparam * Q, int sl)
{
  Q->sl = sl;
}

void sparam_free(sparam * Q)
{
  if(Q->D != NULL)
    free(Q->D);
  if(Q->H != NULL)
    free(Q->H);
  if(Q->B != NULL)
    free(Q->B);
  free(Q->rFile);
  free(Q->qFile);
  free(Q->oFile);

  if(Q->mode == MODE_COUNT_EXACT)
  {
    if(Q->Pos != NULL)
    {
      free(Q->Pos);
    }
  }

  free(Q);
  Q = NULL;
}

void sparam_free_scopy(sparam * Q)
{
  // Do not free the common data, only the private allocations
  free(Q->rFile);
  free(Q->qFile);
  free(Q->oFile);
  if(Q->Pos != NULL)
  {
    free(Q->Pos);
  }

  free(Q);
  Q = NULL;
}


void usage(void)
{
  printf("Required arguments:\n");
  printf(" -r refFile.fa, --refFile refFile.fa\n\t Specify reference file \n");
  printf(" -l N, --stringLength N\n\t specify query sequence length \n");
  printf(" -f N, --minMM\n\t least number of mismatches, defaults to 1"
      "(i.e. ignores perfect matches). \n");
  printf(" -m N, --maxMM\n\t  number of mismatches (Hamming radius)\n");
  printf(" -q folder, --queryFolder folder\n\t where the query files are, "
      "processed with SPLIT(1)\n");
  printf(" -t N, --threads\n\t number of threads to use\n");
  //  printf(" -o output.fa : output file\n");
  printf("Optional arguments:\n");
  printf(" -p N, --verbose N\n\t verbose level, 0 = quiet, "
      "1 = normal, 2 = insane, defaults to 0\n");
  printf(" -x, --reverse\n\t also scan reverse complement\n");
  printf(" -u, --tests\n\t run some unit tests\n");
  printf(" -c, --count\n\t count: alignments\n"); // set mode to MODE_COUNT
  printf(" -C, --exact\n\t count alignments exact (slower than -c)\n"); // MODE_COUNT_EXACT
  printf(" -i, --ignore\n\t ignore sequences with more than this number of off-targets\n");
  printf(" -g A:B, --gap A:B\n\t ignore region A:B of the current reference "
      "genome. 0-indexed. Only one gap allowed.\n");
  printf(" -h, --help\n\t show this help and quit\n");
  printf(" --try\n\t See if a specific combination of string length and hamming radius "
      "is possible\n");
  printf("\n");
  printf("See `man hush` for full documentation\n");
}

int sparam_validate_arguments(sparam * Q)
{
  int valid = 1;
  if(strlen(Q->qFile) == 0)
  {
    printf("No query file given\n");
    valid = 0;
  }

  if(strlen(Q->rFile) == 0)
  {
    printf("No reference file given\n");
    valid = 0;
  }

  if(strlen(Q->oFile) == 0)
  {
    printf("No output file given\n");
    valid = 0;
  }

  if(Q->nThreads<1)
  {
    printf("Number of threads not specified!\n");
    valid = 0;
  }

  return(valid);
}

uint8_t reverse_letter_number(uint8_t n)
{
  return 3-n;
}

char reverse_letter(char C)
{
  switch(C)
  {
    case 'A':
      return 'T';
      break;
    case 'T':
      return 'A';
      break;
    case 'C':
      return 'G';
      break;
    case 'G':
      return 'C';
      break;
  }

  assert(0);
  return ' ';
}


void reverse_complement(sparam * Q, uint8_t * T, uint8_t * S)
{
  // set T as the reverse complement to S
  for(int kk = 0; kk< Q->sl; kk++)
    T[kk] = reverse_letter_number(S[Q->sl - kk-1]);
}

void * hush_run_thread(void * P)
{
  //  printf("hush_run_thread\n"); fflush(stdout);
  sparam * Q = (sparam *) P;
  hush_run(Q);
  Q->thread_done = 1;
  return NULL;
}

int stringIsSeq(sparam * Q, char * R, size_t nR, size_t * nHits)
{
  /* Determine if the string R is a sequence to be matched
   * or if not. nR is the number of characters (excluding '\0')
   * The string is supposed to only contain letters from the genomic alphabet.
   */

  // First the quick tests:
  if(nR < 2)
  {
    return 0;
  }

  if(R[0] == '>')
  {
    return 0;
  }

  if(Q->mode == MODE_DISCARD)
  {
    // Check length
    if( !(nR == Q->sl))
    {
      if(Q->verbose > 2)
      {
        printf("Not a sequence, wrong length\n");
      }
      return 0;
    }

    // Check first character
    // TODO: require 'A', 'T', 'C', or 'G'
    if( nR > 1)
      if(R[0] == '>')
      {
        if(Q->verbose > 2)
        {
          printf("First character is '>', i.e., a comment\n");
        }
        return 0;
      }
    return 1;
  }

  if(Q->mode == MODE_COUNT || Q->mode == MODE_COUNT_EXACT)
  {
    // Two cases:
    // A/ Only sequence. Example:
    // ATC...GAA
    // B/ Sequence and count. Example:
    // ATC...GAA, 92

    if( nR < Q->sl)
      return 0;

    if(nR == Q->sl)
    { // case A
      if(R[0] == '>')
      {
        return 0;
      }
      return 1;
    }
    // Case B:

    // Find ','
    size_t pos = Q->sl;
    assert(R[pos] == ',');

    nHits[0] = atol(R+(pos+1));

    if(nHits[0] > Q->nIgnore)
    {
      return 0;
    }

    if(Q->verbose > 2)
    {
      printf("(TODO) Initial hits: %zu\n", nHits[0]);
    }
    return(1);

  }

  // Should never get here
  assert(0);
  return -1;
}

int char_trimnewline(char * S, int N)
{
  /* Remove at most one instance of '\n' at the end of a string.
   * i.e., convert 'ATC\n\0' -> 'ATC\0\0' and return the new length.
   */

  assert(strlen(S) == N);
  assert(N>0);

  if(N>0)
  {
    if(S[N-1] == '\n')
    {
      S[N-1] = '\0';
      return N-1;
    }
  }

  return N;
}

int hush_run(sparam * Q)
{
  // printf("hush_run\n"); fflush(stdout);


  //  FILE * fquery = stdin;

  FILE * fquery = fopen(Q->qFile, "r");
  if(fquery == NULL)
  {
    printf(" ! Can not open qFile %s\n", Q->qFile);
    fflush(stdout);
    return(1);
  }

  //FILE * fout = stdout;

  FILE * fout = fopen(Q->oFile, "w");
  if(fout == NULL)
  {
    printf(" ! Can not open %s\n", Q->oFile);
    fflush(stdout);
    return(1);
  }

  //  printf("BUFSIZ: %d\n", BUFSIZ);
  //  Increase the buffer size, was 8192 by default
  //  4xBUFSIZ might yield 0-3% speed gain on the fractal
  char * fquery_buff = malloc(4*BUFSIZ*sizeof(char));
  setbuf(fquery, fquery_buff);
  char * fout_buff = malloc(4*BUFSIZ*sizeof(char));
  setbuf(fout, fout_buff);
  /*
   * Main loop. Read one line from the query file at a time
   * If comment, pass through to the output file.
   * If sequence, let it pass only if it does not match the database
   * Perfect matches are excepted.
   */

  // Strings for the current query sequence and it's reverse complement
  size_t linecap = 1024;
  char * R = malloc(linecap*sizeof(char));
  uint8_t * Rv = malloc(Q->sl*sizeof(uint8_t)); // Digital representation of R
  sprintf(R, "\n\n");
  char * RX = malloc(linecap*sizeof(char));
  uint8_t * RXv = malloc(Q->sl*sizeof(uint8_t)); // 'digital' representation of RX

  sprintf(RX, "\n\n");

  size_t qread = 0; // number of chars read
  while( (qread = getline(&R, &linecap, fquery)) != -1)
  {
    // R[qread-1] = '\b'; If reading from stdin

    // Remove '\n' from the end of R
    qread = char_trimnewline(R, qread);

    // Decide if it looks like a correct sequence
    size_t n_hits = 0;
    int isSeq = stringIsSeq(Q, R, qread, &n_hits);
    size_t n_hits0 = n_hits;


    if(!isSeq) // if comment or unrecognized
    {
      // printf("Non-seq: %s\n", R);
      fprintf(fout, "%s\n", R); // write unchanged
    }
    else // if sequence of length sl
    {
      Q->nPos = 0;
      //      printf("R: %.*s\n", Q->sl, R);

      to_digital(Rv, R, Q->sl);
      //    print_br(Rv, Q->sl); printf("\n");

      n_hits += hush_get_matches(Q, Rv);
      Q->nQueries++;
      if(Q->rc == 1)
      {
        reverse_complement(Q, RXv, Rv);
        //  printf("%s -> %s\n", R, RX);
        n_hits += hush_get_matches(Q, RXv);
      }

      if(Q->mode == MODE_DISCARD)
      {
        // only write the sequence back if it did not match anything
        // Perfects matches are ignored
        if(n_hits == 0)
          fprintf(fout, "%.*s\n", Q->sl, R);
      }

      if(Q->mode == MODE_COUNT)
      {
        fprintf(fout, "%.*s, %zu\n", Q->sl, R, n_hits);
      }

      if(Q->mode == MODE_COUNT_EXACT)
      {
#ifdef __APPLE__
        qsort_r(Q->Pos, Q->nPos, sizeof(uint32_t), NULL, uint32_t_cmp);
#else
        qsort_r(Q->Pos, Q->nPos, sizeof(uint32_t), uint32_t_cmp, NULL);
#endif

        n_hits = getUnique_uint32_t(Q->Pos, Q->nPos) + n_hits0;
        fprintf(fout, "%.*s, %zu\n", Q->sl, R, n_hits);
      }

      if(Q->verbose > 2 )
      {
        // printf("Investigated %zu candidates out of %zu sequences\n", n_candidates, Q->nD-Q->sl-1);
        printf("%zu hits where dist<=%d\n", n_hits, Q->mm);
      }

    } // if sequence
  } // while(getline)

  fclose(fout);
  fclose(fquery);
  free(fout_buff);
  free(fquery_buff);
  free(R);
  free(RX);
  free(Rv);
  free(RXv);

  return 0;
}

size_t hush_get_matches(sparam * restrict Q, const uint8_t * restrict R)
  /* Q: settings/data
   * R: sequence to match
   */
{
#ifndef NDEBUG
  if(Q->verbose>3)
  {
    printf("________________________________________________________________________\n");
    printf("hush_get_matches: %s\n", R);
  }
#endif

  int nVariants = 0;
  if(Q->mm == 1)
    nVariants = Q->ssl*3;

  size_t n_candidates = 0;
  size_t n_hits = 0;

  for(int kk = 0; kk<Q->nss; kk++) // Look up each sub string
  {

    Q->css = kk; // current substring
    // Change into something like while(sparam_get_ssHash(&h, R, ..., Q)==0)

#ifndef NDEBUG
    if(Q->verbose>3)
    {
      printf("            ______________________________________________Current Sub String:%d\n", Q->css);
    }
#endif

    for(int dd = -1; dd<nVariants; dd++) // search all perturbations of R
    {

      size_t h = subs_hash_v1_3(R, dd, Q);
      // Repeated A's give h=0 ...


#ifndef NDEBUG
      printf("Q->ssl=%d\n", Q->ssl);
      if(Q->verbose > 3)
        printf("h_%d(Q) = %lu\n", kk, h);
#endif

      assert(h < Q->nH);

      // Get range of indexes of B to use
      size_t pos = Q->H[h];
      size_t endpos = Q->H[h+1];
      assert(endpos >= pos);

      // TODO: -1 ?
      //if(endpos>0)
      //  endpos--;
#ifndef NDEBUG
      if(!(endpos < Q->nB))
      {
        sparam_show(Q);
        printf("dd: %d\n", dd);
        printf("nVariants: %d\n", nVariants);
        printf("h: %zu\n", h);
        printf("Q->ssl: %d\n", Q->ssl);
        printf("pos: %zu endpos: %zu Q->nH: %zu\n", pos, endpos, Q->nH);
        printf("Q->nB: %zu, Q->nH: %zu\n", Q->nB, Q->nH);
        printf("Theoretical gain vs brute force: %d\n", Q->gain);
        assert(0);
      }

      if(Q->verbose > 3)
        printf("\n--> searching in [%zu, %zu]\n\n", pos, endpos);
#endif

      while(pos<=endpos)
      {
        n_candidates++;
#ifndef NDEBUG
        if(Q->verbose > 3)
          printf("-> Potential candidate in hash table %d, pos %zu:\n", kk, pos);
#endif
        int hdist = Q->sl;

        assert(Q->B != NULL);
        assert(pos < Q->nB);

        size_t Dpos = Q->B[pos]- Q->ssl*Q->css;

        if(Dpos + Q->sl <= Q->nD)
        {
          if(Q->rIgnore == 0 || ( (Q->rIgnore == 1) & (Dpos < Q->rIgnoreA || Dpos > Q->rIgnoreB)))
          {
            if(Q->B[pos] >= Q->ssl*Q->css)
            {
              hdist = hamming(R, Q->D + Dpos, Q);
              // #ifndef NDEBUG
              if(Q->verbose>3)
              {
                print_br(R, Q->sl); printf(" vs \n");
                print_br(Q->D + Dpos, Q->sl); printf("\n");
                printf("hamming(R, Q[%zu]) = %d\n", Dpos, hdist);
              }
              // #endif
            }
          }
        }
        else {
          // Consider as mismatch if the position is in the region to be ignored
          hdist = Q->hr + 1;
        }

        if(hdist <= Q->hr) // MATCH
        {

          if(hdist < Q->mm_min)
          {
            // Useful for ignore perfect matches if Q->mm_min == 1
          }
          else
          {
#ifndef NDEBUG
            if(Q->verbose > 2)
            {
              printf("hdist: %d, %d\n", hdist, hamming(R, Q->D + (size_t) Q->B[pos]- Q->ssl*Q->css, Q));
              hamming_print(stdout, R, Q->D + (size_t) Q->B[pos]- Q->ssl*Q->css, Q);
            }
#endif

            n_hits++;
            if(Q->mode == MODE_DISCARD)  // Early abort
            {
              pos = endpos+1; // don't check any more sequences.
              kk = Q->nss + 1; // i.e. don't try with another bucket
              dd = nVariants + 1;
            }

            if(Q->mode == MODE_COUNT_EXACT)
            {
              // Add position to list if not already there
              // TODO: Switch to binary tree
              if(Q->nPos < (Q->nPosMax+1)) // TODO: Grow dynamically
              {
                Q->Pos[Q->nPos++] = Q->B[pos] - Q->ssl*Q->css;
              }
            }
          }
        }
        pos++;
      }

    }
  }
  return n_hits;
}

void sparam_scopy(sparam * T, sparam * S)
{ // shallow copy from source to target

  T->D = S->D;
  T->nD = S->nD;
  T->hr = S->hr;
  T->H = S->H;
  T->B = S->B;
  T->nB = S->nB;
  T->nH = S->nH;
  T->mm = S->mm;
  T->mm_min = S->mm_min;
  T->sl = S->sl;
  T->css = S->css;
  T->nss = S->nss;
  T->ssl = S->ssl;
  T->rc = S->rc;
  T->gain = S->gain;
  T->verbose = S->verbose;
  T->mode = S->mode;
  T->nPosMax = S->nPosMax;

  T->nQueries = S->nQueries;
  T->nIgnore = S->nIgnore;

  T->rIgnore = S->rIgnore;
  T->rIgnoreA = S->rIgnoreA;
  T->rIgnoreB = S->rIgnoreB;

  strcpy(T->oFile, S->oFile);
  strcpy(T->rFile, S->rFile);
  strcpy(T->qFile, S->qFile);

  if(T->mode == MODE_COUNT_EXACT)
  {
    T->Pos = malloc(T->nPosMax*sizeof(uint32_t));
    T->nPos = 0;
  }

  T->nThreads = S->nThreads;
return;
}

void split_print_name(char * S, char * folder, int kk)
{
  // Generate file names as those generated with the command split
  sprintf(S, "%s/x%c%c", folder, ((int) floor((kk/26)) % 26) + 'a', (kk%26) + 'a');
  assert(kk<676);
}

void unit_tests()
{
  // Does not contain a single test that can fail!
  printf(" --> split_print_name\n");
  char name[256];

  for(int kk = 0; kk<5; kk++)
  {
    split_print_name(name, "/folder", kk);
    printf("%d %s\n", kk, name);
  }
  for(int kk = 24; kk<26; kk++)
  {
    split_print_name(name, "/folder", kk);
    printf("%d %s\n", kk, name);
  }
  for(int kk = 670; kk<676; kk++)
  {
    split_print_name(name, "/folder", kk);
    printf("%d %s\n", kk, name);
  }

  sparam * Q = sparam_init();
  Q->sl = 12;

  printf(" --> reverse_complement\n");
  char seq[40];
  sprintf(seq, "ATCGAATTCCGG");
  uint8_t * seqv = malloc(12*sizeof(uint8_t));
  uint8_t * rseqv = malloc(12*sizeof(uint8_t));
  printf("seq:    %.40s\n", seq);
  to_digital(seqv, seq, 12);
  printf("from binary: ");
  print_br(seqv, 12);
  printf("\n"); fflush(stdout);

  reverse_complement(Q, rseqv, seqv);
  printf("R(seq): ");
  print_br(rseqv, 12);
  printf("\n");
  return;
}


void set_rIgnore(sparam * Q, char * s)
{
  /* Set region to ignore in reference */
  char * val = strtok(s, ":");
  if(val == NULL)
  {
    printf("Error: Invalid rIgnore string\n");
    exit(1);
  }
  Q->rIgnoreA = atol(val);
  val = strtok(NULL, ":");
  if(val == NULL)
  {
    printf("Error: Invalid rIgnore string\n");
    exit(1);
  }
  Q->rIgnoreB = atol(val);

  printf("Will ignore region [%zu, %zu]\n", Q->rIgnoreA, Q->rIgnoreB);

  if(Q->rIgnoreA > Q->rIgnoreB)
  {
    printf("Error: Invalid region\n");
    exit(1);
  }

  return;
}

static double clockdiff(struct timespec* start, struct timespec * finish)
{

  double elapsed = (finish->tv_sec - start->tv_sec);
  elapsed += (finish->tv_nsec - start->tv_nsec) / 1000000000.0;
  return elapsed;
}


int argparsing(int argc, char ** argv, sparam * Q)
{

  struct option longopts[] = {
    { "help",         no_argument,       NULL,   'h' },
    { "verbose",      required_argument, NULL,   'p' },
    { "version",      no_argument,       NULL,   'v' },
    { "nThreads",     required_argument, NULL,   't' },
    { "refFile",      required_argument, NULL,   'r' },
    { "stringLength", required_argument, NULL,   'l' },
    { "maxMM",        required_argument, NULL,   'm' },
    { "minMM",        required_argument, NULL,   'f' },
    { "queryFile",    required_argument, NULL,   'q' },
    { "ignore",       required_argument, NULL,   'i' },
    { "gap",          required_argument, NULL,   'g' },
    { "unitTests",    no_argument,       NULL,   'u' },
    { "reverse",      no_argument,       NULL,   'x' },
    { "tests",        no_argument,       NULL,   'u' },
    { "count",        no_argument,       NULL,   'c' },
    { "exact",        no_argument,       NULL,   'C' },
    { "try",          no_argument,       NULL,   'T' },
    {"server",        no_argument,       NULL,   's' },
    { NULL,           0,                 NULL,   0   }
  };

  int tryconfig = 0;

  int ch = 0;
  while((ch = getopt_long(argc, argv, "hr:l:m:q:o:vp:t:uxcCf:i:g:sT", longopts, NULL)) != -1)
  {
    switch(ch) {
      case 'r': // Reference file
        strcpy(Q->rFile, optarg);
        break;
      case 'l': // string Length
        sparam_set_sl(Q, atoi(optarg));
        break;
      case 'm': // number of Mismatches
        sparam_set_hr(Q, atoi(optarg));
        break;
      case 'f': // number of Mismatches
        Q->mm_min = atof(optarg);
        break;
      case 'q':
        strcpy(Q->qFile, optarg);
        break;
      case 'o':
        strcpy(Q->oFile, optarg);
        break;
      case 'i':
        Q->nIgnore = atol(optarg);
        break;
      case 'g':
        Q->rIgnore = 1;
        set_rIgnore(Q, optarg);
        break;
      case 'h':
        usage();
        exit(EXIT_SUCCESS);
        break;
      case '?':
        printf("Unknown command line option\n");
        usage();
        return(1);
      case 'p':
        Q->verbose = atoi(optarg);
        break;
      case 'v':
        hush_version();
        exit(EXIT_SUCCESS);
        break;
      case 'u':
        unit_tests();
        exit(EXIT_SUCCESS);
      case 't':
        Q->nThreads = atoi(optarg);
        break;
      case 'x':
        Q->rc = 1;
        break;
      case 'c':
        Q->mode = MODE_COUNT;
        break;
      case 'C':
        Q->mode = MODE_COUNT_EXACT;
        break;
      case 's':
        Q->server = 1;
        break;
      case 'T':
        tryconfig = 1;
        break;
      default:
        printf("Unused argument\n");
        break;
    }
  }

  if(argc==1)
  {
    usage();
    return(1);
  }

  if(tryconfig)
  {
    int ssl = 0;
    int mm = 0;
    int nss = 0;

  int gain = hush_ssl_mm(Q->sl, Q->hr, &ssl, &mm, &nss);

  printf("Input:\n");
  printf(" Query string length: %d\n Hamming radius: %d\n",
      Q->sl, Q->hr);
  if(gain>0)
  {
  printf("Configuration:\n");
  printf(" Number of substrings: %d\n", nss);
  printf(" Sub string length %d\n", ssl);
  printf(" Most mismatches per substring: %d\n", mm);
  printf(" Theoretical gain: %d (vs brute force)\n", gain);
  exit(0);
  } else {
    printf("\n! Sorry, HUSH can't figure out how use the combination \n  of string length"
        " and Hamming radius that you specified\n");
    exit(1);
  }

  }


  return 0;
}

void sparam_init_T(sparam * Q)
{
  char * tsvFile = malloc(1024*sizeof(char));
  sprintf(tsvFile, "%s.tsv", Q->rFile);
  printf("Looking for metadata in %s\n", tsvFile);
  Q->CHT = chrTable_init(tsvFile);
  if(Q->CHT == NULL)
  {
    printf(" Nothing could be loaded\n");
  }
  free(tsvFile);
  return;
}

#ifndef main
int main(int argc, char ** argv)
{
  time_t t0 = clock();

  sparam * Q = sparam_init();

  // Default parameters
  sparam_set_sl(Q, 40); // string length
  sparam_set_hr(Q, 5);
  Q->nThreads = -1;

  // Parse input
  int argstatus = argparsing(argc, argv, Q);
  if(argstatus != 0)
  {
    exit(argstatus);
  }

  // Check that the settings make sense
  sparam_recalc(Q);
  if(sparam_validate_arguments(Q) != 1)
    return(1);

  struct timespec ta, tb;
  clock_gettime(CLOCK_MONOTONIC, &ta);

  // If exists, read meta data
  // i.e. Q->CHT
  //sparam_init_T(Q);

  // load sequence into Q->D
  if(sparam_init_D(Q) != 0)
  {
    printf("Failed to run sparam_init_D, quiting\n");
    return(1);
  }
  clock_gettime(CLOCK_MONOTONIC, &tb);

  if(Q->verbose > 1)
  {
    printf("Timing init_D: %.1f s\n", clockdiff(&ta, &tb));
  }

  clock_gettime(CLOCK_MONOTONIC, &ta);
  // Create buckets
  if(sparam_init_B(Q) != 0)
  {
    printf("Failed to run sparam_init_B, quiting\n");
    return(1);
  }
  clock_gettime(CLOCK_MONOTONIC, &tb);
  if(Q->verbose > 1)
  {
    printf("Timing init_B: %.1f s\n", clockdiff(&ta, &tb));
  }

  clock_gettime(CLOCK_MONOTONIC, &ta);
  // Create Hash table
  if(sparam_init_H(Q) != 0)
  {
    printf("Failed to run sparam_init_H, quiting\n");
    return(1);
  }
  clock_gettime(CLOCK_MONOTONIC, &tb);
  if(Q->verbose > 1)
  {
    printf("Timing init_H: %.1f s\n", clockdiff(&ta, &tb));
  }

  time_t t1 = clock();

  struct timespec start, finish;

  clock_gettime(CLOCK_MONOTONIC, &start);

  if(Q->verbose > 0)
  {
    sparam_show(Q);
  }

  if(Q->server)
  {
    if(Q->mode == MODE_COUNT_EXACT)
    {
      if(Q->Pos == NULL)
      {
        Q->Pos = malloc(Q->nPosMax*sizeof(uint32_t));
        Q->nPos = 0;
      }
    }

    hush_server(Q);
    return 0;
  }

  // Prepare the data to give to the threads
  pthread_t * threads = malloc(Q->nThreads*sizeof(pthread_t));;
  sparam ** QQ = malloc(Q->nThreads*sizeof(sparam *));
  for(int kk = 0; kk<Q->nThreads; kk++)
  {
    QQ[kk] = sparam_init();
    QQ[kk]->thread = kk;
    sparam_scopy(QQ[kk], Q);
  }

  // hush_run(Q);
  fflush(stdout);
  for(int kk = 0; kk<Q->nThreads; kk++)
  {
    //    printf("Starting thread\n");
    split_print_name(QQ[kk]->qFile, Q->qFile, kk);
    sprintf(QQ[kk]->oFile, "%s.out", QQ[kk]->qFile);
    //  printf(" Will write to %s\n", QQ[kk]->oFile);
    // printf(" r, q files: %s, %s\n", QQ[kk]->rFile, QQ[kk]->qFile);
    // printf("QQ[kk]->rc = %d\n", QQ[kk]->rc);
    // fflush(stdout);
    int iret1 = pthread_create( &threads[kk], NULL, hush_run_thread, (void*) QQ[kk]);
    if(iret1 != 0)
    {
      printf("Thread creation failed\n");
      return(1);
    }
  }

  size_t nQueries = 0;
  if(Q->verbose > 0)
  {
      while(1)
      {
          usleep(10000);
          nQueries = 0;
          int allDone = 1;
          for(int kk = 0; kk < Q->nThreads; kk++)
          {
              nQueries += QQ[kk]->nQueries;
              allDone *= QQ[kk]->thread_done;
          }
          printf("\r %zu", nQueries);
          if(allDone)
              break;

      }
      printf("\r                 \n");
  }

  for(int kk = 0; kk<Q->nThreads; kk++)
    pthread_join(threads[kk], NULL);

  nQueries = 0;
  for(int kk = 0; kk<Q->nThreads; kk++)
  {
    nQueries += QQ[kk]->nQueries;
    sparam_free_scopy(QQ[kk]);
  }

  free(QQ);
  free(threads);

  double tLoad = (double) (t1-t0) / CLOCKS_PER_SEC;

  clock_gettime(CLOCK_MONOTONIC, &finish);
  double elapsed = clockdiff(&start, &finish);

  if(Q->verbose>0)
  {
    printf("Matched nq=%zu queries vs reference, nq/tm = %.0f\n",
        nQueries, (double) nQueries/ (double) elapsed);
    printf("Timings (s): Load: tl=%.3f, Match tm=%.3f, Total: tl+tm=%.3f\n",
        tLoad, elapsed,tLoad+elapsed);
  }

  sparam_free(Q);
  return 0;
}
#endif

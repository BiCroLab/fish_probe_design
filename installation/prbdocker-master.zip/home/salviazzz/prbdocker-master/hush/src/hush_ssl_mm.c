#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

/*
int hush_ssl_mm(int L, int hr, int * ssl, int * mm, int * nss);
int main( int argc, char ** argv)
{

  int L = atoi(argv[1]);
  int hr = atoi(argv[2]);

  int ssl = 0;
  int mm = 0;
  int nss = 0;

  int gain = hush_ssl_mm(L, hr, &ssl, &mm, &nss);

  printf("L:%d, hr:%d -> ssl:%d, mm:%d, nss:%d (%dx)\n", L, hr, ssl, mm, nss, gain);

  return 0;

}
*/


int hush_ssl_mm(int L, int hr, int * ssl, int * mm, int * nss)
  /*
   * Set the optimal sub string length and number of mismatches per substring
   * based on the sequence length L and the hamming radius hr
   */
{

  int optgain = -1;
  int optssl = -1;
  int optmm = 0;
  int optnss = 0;

  // 4**ssl <= 2^32 -> maxssl=16
  // However that requires a lot of memory
  // So I've reduced the max to
  int maxssl = 13;

  for(int ssl = 4; ssl <= maxssl; ssl++)
  {
    for(int mm = 0; mm< 2; mm++)
    {
      div_t d = div(L, ssl);
      int nss = d.quot;
      if(
          (mm == 0 && (nss > hr))
          || (mm == 1 && (nss*2 > hr))
        )
      {
        size_t nbuckets = powl(4, ssl);
        size_t nvariations = powl(nss*(3*ssl+1), mm);
        double gain = (double) nbuckets / (double) nvariations;
//        printf("ssl: %d, mm:%d g: %f\n", ssl, mm, gain);
        if(gain > optgain)
        {
          optgain = gain;
          optssl = ssl;
          optmm = mm;
          optnss = nss;
        }
      }
    }
  }

  ssl[0] = optssl;
  mm[0] = optmm;
  nss[0] = optnss;

  assert(optnss*optssl <= L);
  return optgain;
}




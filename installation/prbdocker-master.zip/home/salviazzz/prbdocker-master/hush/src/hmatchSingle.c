// https://github.com/elgw/unique_seq_hamming/

#define _XOPEN_SOURCE 700 // or any bigger number required for getline on linux
#define _GNU_SOURCE
// but defining this hides qsort_r on osx

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <math.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include "hmatchSingle.h"
#include "hush.h"

#include "hush_server.h"

/* 
 * Single = single hash table 
 *
 * To do:
 * - Enable more than 1 mismatch per substring, replace/rewrite
 *   subs_hash_v1()
 * - The function that maps -l and -m to Q->ssl and Q->mm, sparam_recalc() needs attention, 
 *   currently hard coded for -l 60 -m 5 and -l 40 -m 5
 *   At least good values for 30,40,60,80,100 and then something that is ok in between
 *
 * Ideas:
 * - Use #define for sl, ssl, etc... and build a whole set of binaries
 * instead of using variables. Branch free!
 *
 * */

void sparam_init_D(sparam * Q)
{
  // Load a clean file from disk with only atcgATCG
  // 'n' or 'N' is translated to 'a' not to cause gaps

  if(Q->verbose>0)
    printf("Reading %s\n", Q->rFile);

  // Get file size 
  struct stat st;
  int status = stat(Q->rFile, &st);
  if(status != 0)
  {
    printf("Can not open %s\n", Q->rFile);
    exit(-1);
  }

  size_t fsize = st.st_size;

  // Allocate enough memory, possibly more than needed when
  // non-nucleotide characters are filtered out like line endings
  Q->D = malloc(fsize);
  if(Q->D == NULL)
  {
    printf("Memory allocation failed\n");
    assert(Q->D != NULL);
  }

  FILE * f = fopen(Q->rFile, "r");
  if(f == NULL)
  {
    printf("Could not open %s\n", Q->rFile);
    exit(-1);
  }

  size_t bbRead =  fread(Q->D, fsize, 1, f);
  if(bbRead != 1)
  { 
    printf("Failed to read file\n"); 
    exit(1); 
  }

  size_t readpos = 0;
  size_t writepos = 0;

  if(Q->verbose>0)
    printf("Processing data\n");
  while(readpos<fsize)
  {
    switch(Q->D[readpos++]) {
      // aA
      case 97:
        Q->D[writepos++] = 'A';
        break;
      case 65:
        Q->D[writepos++] = 'A';
        break;
        // tT
      case 116:
        Q->D[writepos++] = 'T';
        break;
      case 84:
        Q->D[writepos++] = 'T';
        break;
        // cC
      case 99:
        Q->D[writepos++] = 'C';
        break;
      case 67:
        Q->D[writepos++] = 'C';
        break;
        // gG
      case 103:
        Q->D[writepos++] = 'G';
        break;
      case 71:
        Q->D[writepos++] = 'G';
        break;
        // n and N is replaced by 'A' to preserve the structure
      case 'n':
        Q->D[writepos++] = 'A';
        break;
      case 'N':
        Q->D[writepos++] = 'A';
        break;
      default:
        // Discard anything that is not atcgnATCGN
        break;
    }
  }

  fclose(f);

  Q->nD = writepos;
  assert(Q->nD >= Q->sl);
}

int hamming(const char * restrict A, const char * restrict B, sparam * Q)
{
  int h = 0;
  for(int kk = 0; kk<Q->sl; kk++)
    if(A[kk] != B[kk])
      h++;

  return h;
}

int hammingv(char * A, char * B, sparam * Q)
{
  int h = 0;
  int score = hamming(A,B,Q);
    printf("\n%.*s\n", Q->sl, A); 
  for(int kk = 0; kk<Q->sl; kk++)
  {
    if(A[kk] == B[kk])
    {
      if(Q->verbose>1)
        printf("|");
    } else
    {
      if(Q->verbose>1)
        printf(" ");
      h++;
    }
  }
    printf(" %d \n", score);
    printf("%.*s\n", Q->sl, B);
  assert(h==score);
  return h;
}

#ifdef __APPLE__
int str_cmp(void * PQ, const void * PA, const void * PB)
#else
int str_cmp(const void * PA, const void * PB,void * PQ)
#endif
{
  // substring comparison

  // SS: global parameter, substring
  uint32_t * A  = (uint32_t *) PA;
  uint32_t * B = (uint32_t *) PB;
  sparam * Q = (sparam *) PQ;

  //  printf("str_cmp, pos %u vs pos %u\n", A[0], B[0]);
  //  printf("Q->ssl: %d\n", Q->ssl);

  return strncmp(Q->D + (size_t) A[0], Q->D + (size_t) B[0], Q->ssl);
}

int subs_cmp(const void * PA, const void * PB, const void * PQ)
{
  // substring comparison

  // SS: global parameter, substring
  char ** A = (char **) PA;
  char ** B = (char **) PB;
  sparam * Q = (sparam *) PQ;

  //  printf("subs_cmp\n");
  //  printf("  %.10s\n", Q[0]+Q->SS*10);
  //  printf("    %.10s\n", S[0]+Q->SS*10);
  //  printf("     %d\n", strncmp(Q[0]+Q->SS*10, S[0]+Q->SS*10, nChar));
  return strncmp(A[0]+Q->css*Q->ssl, B[0]+Q->css*Q->ssl, Q->nD);
}

uint32_t subs_hash_v0(char * S, sparam * Q)
{

  size_t h = 0;
  for(int kk = 0; kk<Q->ssl; kk++)
  {
    h*=4;
    switch(S[kk+Q->ssl*Q->css])
    {
      case 'A':
        h+=0;
        break;        
      case 'C':
        h+=1;
        break;
      case 'G':
        h+=2;
        break;
      case 'T':
        h+=3;
        break;
      default:
        printf("-> subs_hash_v0\n");
        printf("? invalid letter: >%c<\n", S[kk+Q->css*Q->ssl]);
        assert(0);
        break;
    }
  }

  assert(h<powl(4, Q->ssl));
  return h;
}

uint32_t subs_hash_v1(char * S, int variation, sparam * Q)
{

  // A substring of length N has N*3 substrings within a hamming
  // distance of 1. This is parameterized by the argument 'variation'
  // The hash for the unaltered substring is returned when 
  // variation == -1
  //
  // This is more stupid than that, and generates N*4 hash values.
  //
  // In future version: supply the initial hash (radius 0) and just
  // flip two bits per variation. 

  if(variation==-1)
    return subs_hash_v0(S,Q);

  // Hashing with variation
  //  printf("subs_hash_v1: %.40s\n", S);

  int vpos = floor(variation/4);
  int vval = variation - vpos*4;

  assert(vpos<Q->ssl);
  assert(vval<4);

  size_t h = 0;
  for(int kk = 0; kk<vpos; kk++)
  {
    h*=4;
    switch(S[kk+Q->ssl*Q->css])
    {
      case 'A':
        h+=0;
        break;        
      case 'C':
        h+=1;
        break;
      case 'G':
        h+=2;
        break;
      case 'T':
        h+=3;
        break;
      default:
        printf("? invalid letter: >%c<\n", S[kk+Q->css*Q->ssl]);
        assert(0);
        break;
    }
  }

  // at vpos
  h*=4;
  h+=vval;

  for(int kk = vpos+1; kk<Q->ssl; kk++)
  {
    h*=4;
    switch(S[kk+Q->css*Q->ssl])
    {
      case 'A':
        h+=0;
        break;        
      case 'C':
        h+=1;
        break;
      case 'G':
        h+=2;
        break;
      case 'T':
        h+=3;
        break;
      default:
        printf("?? invalid letter: >%c<\n", S[kk+Q->css*Q->ssl]);
        assert(0);
        break;
    }

  }
  assert(h<powl(4, Q->ssl));
  return h;
}

uint32_t subs_hash(uint32_t P, sparam * Q)
{
  char * S = Q->D + (size_t) P;
  uint32_t h = 0;
  for(int kk = 0; kk<Q->ssl; kk++)
  {
    h*=4;
    switch(S[kk+Q->css*Q->ssl])
    {
      case 'A':
        h+=0;
        break;        
      case 'C':
        h+=1;
        break;
      case 'G':
        h+=2;
        break;
      case 'T':
        h+=3;
        break;
      default:
        printf("invalid letter: >%c<\n", S[kk+Q->css*Q->ssl]);
        assert(0);
        break;
    }
  }
  return h;
}


int sparam_init_B(sparam * Q)
{

  fflush(stdout);
  Q->B = malloc(Q->nD*sizeof(uint32_t)); // bucket index

  char * bname = malloc(1024*sizeof(char*));
  sprintf(bname, "%s.B%d", Q->rFile, Q->ssl);

  if(Q->verbose>0)
    printf("Reading %s\n", bname);

  FILE * bFile = fopen(bname, "r");

  if(bFile == NULL)
  {
    if(Q->verbose>0)
    {
      printf("Does not exist, creating...\n"); 

      printf("A");
      fflush(stdout);
    }

    for (uint32_t bb = 0; bb<Q->nD-Q->ssl; bb++)
      Q->B[bb] = bb;

    if(Q->verbose>0)
    {
      printf("Q");
      fflush(stdout);
    }

#ifdef __APPLE__
    qsort_r(Q->B, Q->nD-Q->ssl, sizeof(uint32_t), Q, str_cmp); 
#else
    qsort_r(Q->B, Q->nD-Q->ssl, sizeof(uint32_t), str_cmp, Q); 
#endif
    bFile = fopen(bname, "w");
    size_t nWrite = fwrite(Q->B, Q->nD-Q->ssl, sizeof(uint32_t), bFile);
    if(Q->verbose>0)
      printf("Wrote %zu values\n", nWrite);

  }
  else
  {
    size_t nRead = fread(Q->B, sizeof(uint32_t), Q->nD-Q->ssl, bFile);
    if(Q->verbose > 0) {
      printf("Read %zu values\n", nRead);
    }
  }

  fclose(bFile);
  return 0;
}

int sparam_init_H(sparam * Q)
{
  Q->H = malloc((Q->nB+1)*sizeof(uint32_t));
  assert(Q->H != NULL);

  if(Q->verbose>1)
  {
    printf(".");
    fflush(stdout);
  }

  char * bname = malloc(1024*sizeof(char*));
  sprintf(bname, "%s.H%d", Q->rFile, Q->ssl);

  if(Q->verbose>0)
    printf("Reading %s\n", bname);

  FILE * bFile = fopen(bname, "r");

  if(bFile == NULL)
  {
    if(Q->verbose>0)
      printf("Does not exist, creating...\n"); 


    for(size_t ll=0; ll<Q->nB; ll++)
      Q->H[ll] = (uint32_t) -1;

    for(size_t ll = 0; ll<Q->nD-Q->sl-1; ll++)
    {
      uint32_t h = subs_hash(Q->B[ll], Q);
      assert(h<Q->nB);

      // Since BI is sorted, we use the first one as the starting point of the bucket
      if(Q->H[h] == (uint32_t) -1) 
        Q->H[h] = ll;
    }

    // set first and last element
    if(Q->H[0] == (uint32_t) -1)
      Q->H[0]=0;
    Q->H[Q->nB] = Q->nD-Q->sl-1; // remember, HI[kk] is bucket_size+1 long

    // Walk backwards and propagate the start position of the later
    // buckets. 
    for(size_t ll = Q->nB-1; ll>0; ll--)
    {
      if(Q->H[ll] == (uint32_t) -1)
        Q->H[ll] = Q->H[ll+1];
    }

    bFile = fopen(bname, "w");
    size_t nWrite = fwrite(Q->H, Q->nB+1, sizeof(uint32_t), bFile);
    if(Q->verbose>0)
      printf("Wrote %zu values\n", nWrite);

  }
  else
  {
    size_t nRead = fread(Q->H, sizeof(uint32_t), Q->nB+1, bFile);
    if(Q->verbose>0)
      printf("Read %zu values\n", nRead);
  }

  fclose(bFile);
  if(Q->verbose>0) 
    printf("\n");
  return 0;
}

void sparam_show(sparam * Q)
{
  printf("### Settings\n");
  printf("# Sequence length: %d\n", Q->sl);
  printf("# Hamming radius: %d\n", Q->hr);
  printf("# Sub string length: %d\n", Q->ssl);
  printf("# Number of substrings: %d\n", Q->nss);
  printf("# Mismatches per substring: %d\n", Q->mm);
  printf("# Reference file: %s\n", Q->rFile);
  printf("# Query file: %s\n", Q->qFile);
  printf("# Output file: %s\n", Q->oFile);
  printf("# verbose level: %d\n", Q->verbose);

  // String must be longer than the sum of it's substrings
  assert(Q->sl >= Q->ssl*Q->nss);
  assert(Q->nB>0);
}

void sparam_set_ssl(sparam * Q, int ssl)
{
  Q->ssl = ssl; 
  Q->nB = powl(4, Q->ssl);
}


sparam * sparam_init()
{
  sparam * Q = malloc(sizeof(sparam));

  Q->D = NULL;
  Q->nD = 0;
  Q->sl = 0;
  Q->hr = 0; 
  Q->H = NULL;
  Q->B = NULL;
  Q->nB = 0;
  Q->mm = 0;
  Q->css = 0;
  Q->nss = 0;
  Q->ssl = 0;
  Q->verbose = 1;

  Q->rFile = (char * ) malloc(1024*sizeof(char));
  Q->rFile[0] = '\0';
  Q->qFile = (char * ) malloc(1024*sizeof(char));
  Q->qFile[0] = '\0';
  Q->oFile = (char * ) malloc(1024*sizeof(char));
  Q->oFile[0] =  '\0';
  return Q;
}

void sparam_recalc(sparam * Q)
{
  // update ssl and mm based on hr and sl
  //  int setValues = 0;

  if(Q->sl == 30)
    if(Q->hr == 5)
    {
      Q->nss = 3;
      sparam_set_ssl(Q, 10);
      Q->mm = 1;
    }

  if(Q->sl == 40)
    if(Q->hr == 5)
    {
      Q->nss = 3;
      sparam_set_ssl(Q, 13);
      Q->mm = 1;
    }

  if(Q->sl == 60)
    if(Q->hr == 5)
    {
      Q->nss = 6;
      sparam_set_ssl(Q, 10);
      Q->mm = 0;
    }

}

void sparam_set_hr(sparam * Q, int hr)
{
  Q->hr = hr;
  sparam_recalc(Q);
}

void sparam_set_sl(sparam * Q, int sl)
{
  Q->sl = sl;
  sparam_recalc(Q);
}

void sparam_free(sparam * Q)
{
  if(Q->D != NULL)
    free(Q->D);
  if(Q->H != NULL)
    free(Q->H);
  if(Q->B != NULL)
    free(Q->B);
  free(Q->rFile);
  free(Q->qFile);
  free(Q->oFile);

  free(Q);
  Q = NULL;
}

void usage(void)
{
  printf("Usage:\n");
  printf(" -h : help\n");
  printf("Required arguments:\n");
  printf(" -r refFile.fa : reference file \n");
  printf(" -l 60 : sequence length \n");
  printf(" -m 5 : number of mismatches \n");
  printf(" -q query.fa : query file\n");
  printf(" -o output.fa : output file\n");
  printf("Optional arguments:\n");
  printf(" -v 0 : verbose level, 0 = quite, 1=normal, 2 = insane\n");

}
  
int sparam_validate_arguments(sparam * Q)
{
  int valid = 1;
  if(strlen(Q->qFile) == 0)
  {
    printf("No query file given\n");
    valid = 0;
  }

  if(strlen(Q->rFile) == 0)
  {
    printf("No reference file given\n");
    valid = 0;
  }

  if(strlen(Q->oFile) == 0)
  {
    printf("No output file given\n");
    valid = 0;
  }


return(valid);
}

int main(int argc, char ** argv)
{
  time_t t0 = clock();

  // sparam * Q = malloc(sizeof(sparam));
  sparam * Q = sparam_init();

  // Default parameters
  sparam_set_sl(Q, 40); // string length
  sparam_set_hr(Q, 5);

  // Parse input
  int ch = 0;
  while((ch = getopt(argc, argv, "hr:l:m:q:o:vp:")) != -1)
  {
    switch(ch) {
      case 'r': // Reference file
        strcpy(Q->rFile, optarg);
        break;
      case 'l': // string Length
        sparam_set_sl(Q, atoi(optarg));
        break;
      case 'm': // number of Mismatches
        sparam_set_hr(Q, atoi(optarg));
        break;
      case 'q':
        strcpy(Q->qFile, optarg);
        break;
      case 'o':
        strcpy(Q->oFile, optarg);
        break;
      case 'h':
        usage();
        return(0);
        break;
      case '?':
        printf("Unknown command line option\n");
        usage();
        return(0);
      case 'p':
        Q->verbose = atoi(optarg);
        break;
      case 'v':
        hush_version();
        return(0);
      default:
        printf("Unused argument\n");
    }
  }

  if(argc==1)
  {
    usage();
    return(-1);
  }

  if(sparam_validate_arguments(Q) != 1)
    return(-1);

  // Show and verify parameters before starting
  if(Q->verbose > 1)
    sparam_show(Q);

  // Open the query file already here, so that it can exit fast if
  // there are errors
  FILE * fquery = fopen(Q->qFile, "r");
  if(fquery == NULL)
  {
    printf("Can not open %s\n", Q->qFile);
    return(-1);
  }

  sparam_init_D(Q); // load sequence into Q->D

  if(Q->verbose > 0)
  {
    printf("%zu nt : ", Q->nD);
    printf(" %.*s ...\n", Q->sl, Q->D);
  }

  if(Q->verbose>1)
    printf("Q->nD = %zu\n", Q->nD);

  sparam_init_B(Q);
  sparam_init_H(Q);

  time_t tstart = clock();

  FILE * fout = fopen(Q->oFile, "w");
  if(fout == NULL)
  {
    printf("Can not open %s\n", Q->oFile);
    return(-1);
  }

  size_t linecap = 1024;
  char * R = malloc(linecap*sizeof(char));

  /* 
   * Main loop. Read one line from the query file at a time
   * If comment, pass through to the output file.
   * If sequence, let it pass only if it does not match the database
   * Perfect matches are excepted. 
   */

  int nVariants = 0;
  if(Q->mm == 1)
    nVariants = Q->ssl*4; // TODO: should be Q->ssl*3 but subs_hash_v1 has to be rewritten
  printf("nVariants: %d\n", nVariants);

  size_t nQueries = 0; // count number of query strings
  size_t qread = 0; // number of chars read
  while( (qread = getline(&R, &linecap, fquery)) != -1)
  {
    int isSeq = 1;
    if( !(qread == Q->sl+1))
      isSeq = 0;
    if( qread > 1)
      if(R[0] == '>')
        isSeq = 0;

    if(!isSeq) // if comment or unrecognized
    {
      if(Q->verbose > 1)
      {
        fprintf(fout, "#");
        printf("::: %s", R);
      }
      fprintf(fout, "%s", R);

    }
    else // if sequence of length sl
    {
      nQueries++;
      size_t n_candidates = 0;
      size_t n_hits = 0;

      for(int kk = 0; kk<Q->nss; kk++) // Look in each hash table/bucket
      {
        Q->css = kk;
        // Change into something like while(sparam_get_ssHash(&h, R, ..., Q)==0)

        for(int dd = -1; dd<nVariants; dd++) // search all "adjacent" buckets
        {

          size_t h = subs_hash_v1(R, dd, Q); 

          if(Q->verbose > 2)
            printf("h_%d(Q) = %zu\n", kk, h);
          assert(h<Q->nB);

          size_t pos = Q->H[h];
          size_t endpos = Q->H[h+1];

          if(Q->verbose > 2)          
            printf("\n--> searching in [%zu, %zu]\n\n", pos, endpos);

          while(pos<endpos)
          {
            n_candidates++;
            if(Q->verbose > 2)
              printf("-> Potential candidate in hash table %d, pos %zu:\n", kk, pos);

            int hdist = Q->sl;
            if(Q->B[pos] >= Q->ssl*Q->css)
            {
              hdist = hamming(R, Q->D + (size_t) Q->B[pos]- Q->ssl*Q->css, Q);
              if(Q->verbose>2)
                printf("hamming(R, Q) = %d\n", hdist);
            }

            if(hdist <= Q->hr) // MATCH
            {

              if(hdist == 0)
              {
                // Ignore perfect matches
              }
              else
              {
              if(Q->verbose > 1)
              {
                printf("hdist: %d, %d\n", hdist, hamming(R, Q->D + (size_t) Q->B[pos]- Q->ssl*Q->css, Q));

                hammingv(R, Q->D + (size_t) Q->B[pos]- Q->ssl*Q->css, Q);
              }

                n_hits++;
                pos = endpos+1; // don't check any more sequences. 
                kk = Q->nss + 1; // i.e. don't try with another bucket
                dd = nVariants + 1;
              }
            }
            pos++;
          }

        }
      }

      // only write the sequence back if it did not match anything
      // Perfects matches are ignored

      if(n_hits == 0)
        fprintf(fout, "%.*s\n", Q->sl, R);

      if(Q->verbose > 1 )
      {
        printf("Investigated %zu candidates out of %zu sequences\n", n_candidates, Q->nD-Q->sl-1);
        printf("%zu hits where dist<6\n", n_hits);
      }

    } // if sequence
  } // while(getline)

  /* Clean up */
  fclose(fout);
  fclose(fquery);
  sparam_free(Q); 

  clock_t tend = clock();
  double tLoad = (double) (tstart-t0) / CLOCKS_PER_SEC;
  double tMatch = (double) (tend-tstart) / CLOCKS_PER_SEC;
  double tTot = tMatch+tLoad;

  if(Q->verbose>0)
  {
    printf("Compared %zu sequences against the reference sequence\n", nQueries);
    printf("%f seq per second\n", (double) nQueries / (double) tMatch);
    printf("%f seq per second (loading included)\n", (double) nQueries / (double) tTot);

    printf("\nTime: Load: %.4f, Match %.4f, Total: %.4f s\n", 
        tLoad, tMatch,tTot);
  }
  return 0;
} 

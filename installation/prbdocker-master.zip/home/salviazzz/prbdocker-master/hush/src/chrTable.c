#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

#include "chrTable.h"


cht * chrTable_init(char * file)
{
  cht * T = malloc(sizeof(cht));


  T->size = 100;
  T->nrows = 0;

  T->start = malloc(T->size*sizeof(size_t));
  T->end = malloc(T->size*sizeof(size_t));
  T->names = malloc(T->size*sizeof(char*));
  for(size_t kk = 0; kk<T->size; kk++)
  {
    T->names[kk] = NULL;
  }

  FILE * tsv = fopen(file, "r");

  if(tsv == NULL)
  { printf("chtTable: Failed to open %s\n", file); return NULL; }

  char buf[1024];
  size_t row = 0;
  while( fgets(buf, 1024, tsv) != NULL )
  {
    char * sizeStr = strtok(buf, "\t");
    if(sizeStr != NULL){
      char * nameStr = strtok(NULL, "\n");
      if(nameStr != NULL) {
        T->names[row] = malloc((strlen(nameStr)+1)*sizeof(char));
        sprintf(T->names[row], "%s", nameStr);
        T->start[row] = 0;
        T->end[row] = atol(sizeStr)-1;
        if(row>0)
        {
          T->start[row] = T->start[row] + T->end[row-1]+1;
          T->end[row] = T->end[row] + T->end[row-1]+1;
        }
        row++;
      }
    }
  }
  T->nrows = row;

  fclose(tsv);

  return T;
}

void chrTable_show(cht * T)
{
  printf("chrTable:\n");
  for(size_t kk = 0; kk<T->nrows; kk++)
  {
    printf("%zu: %zu, %zu, %s\n", kk, T->start[kk], T->end[kk], T->names[kk]);
  }
}

void chrTable_free(cht * T)
{
  free(T->start);
  free(T->end);
  for(size_t kk = 0; kk < T->nrows; kk++)
  {
    if(T->names[kk] != NULL)
    {
      free(T->names[kk]);
    }
  }
  free(T->names);
  free(T);
  return;
}

int chrTable_get(cht * T, size_t pos, size_t * lpos, char ** name)
{
  for(size_t kk = 0; kk<T->size; kk++)
  {
    if(pos >= T->start[kk] && pos <= T->end[kk])
    {
      lpos[0] = pos - T->start[kk];
      name[0] = T->names[kk];
      return 0;
    }
  }
  return 1;
}

#ifdef chrTableMain

int main(int argc, char ** argv)
{
  // For debugging/unit testing
  if(argc < 2)
  {
    printf("Usage: %s file.tsv\n", argv[0]);
    return 1;
  }

  cht * T = chrTable_init(argv[1]);
//  chrTable_show(T);

  for(size_t kk = 0; kk<12; kk++)
  {
    size_t pos = 0;
    char * name = NULL;
    if(chrTable_get(T, kk, &pos, &name) == 0)
    {
      printf("idx: %zu, File: %s, pos: %zu\n",
          kk, name, pos);
    }
  }

  chrTable_free(T);

  return 0;
}
#endif

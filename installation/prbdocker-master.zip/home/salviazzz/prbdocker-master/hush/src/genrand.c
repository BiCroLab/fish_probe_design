#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <time.h>
#include "hush.h"

void usage()
{
  printf("genrand: To create random sequences using the alphabet 'A', 'T', 'C', 'G'\n");
  printf("Usage:\n");
  printf("-c        : disable comment strings in output\n");
  printf("-l strlen : length of sequences\n");
  printf("-n nseq   : number of sequences to generate\n");
  printf("-s seed   : set a seed for the random number generator\n");
  printf("-h        : show this help\n");
  printf("-p level  : set level of verbosiveness\n");
  printf("-v        : show version\n");
}

char int2char(int n)
{
  switch(n)
  {
    case 0:
      return 'A';
    case 1:
      return 'T';
    case 2:
      return 'C';
    case 3:
      return 'G';
    default:
      assert(0);
      return 'A';
  }
}

void print_rand_seq(char *s , int n)
{
  for(int kk = 0; kk<n; kk++)
  {
    s[kk] = int2char(rand()%4);
  }
  s[n] = '\0';
  printf("%s\n", s);
}


int main(int argc, char ** argv)
{

  int comments = 1;
  size_t N = 1;
  size_t L = 60;
  int verbose = 0;
  unsigned int r_seed = time(NULL)*getpid();

  int ch;
  while((ch = getopt(argc, argv, "cl:n:s:hvp:")) != -1)
  {
    switch(ch) {
      case 'c':
        comments = 0;
        break;
      case 'l':
        L = atol(optarg);
        break;
      case 'n':
        N = atol(optarg);
        break;
      case 'h':
        usage();
        return(0);
      case 'p':
        verbose = 1;
        break;
      case 'v':
        hush_version();
        return(0);
      case 's':
          r_seed = atol(optarg);
        break;
      default:
        printf("Unknown option\n");
        return(0);        
    }
  }

  if(argc == 1)
  {
    usage();
    return(-1);
  }

  if(verbose==1)
  {
    printf("# N: %zu\n", N);
    printf("# L: %zu\n", L);
    printf("# r_seed: %u\n", r_seed);
  }
        
  srand(r_seed);
  char * s = malloc(L*sizeof(char)+1);
  sprintf(s, "\n");

  for(size_t nn = 0; nn<N; nn++)
  {
      if(comments)
        printf(">seq %zu\n", nn+1);      
      print_rand_seq(s, L);
    
  }

  return 0;
}

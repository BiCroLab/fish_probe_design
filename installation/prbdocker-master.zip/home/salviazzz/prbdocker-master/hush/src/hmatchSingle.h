
// 
typedef struct{
  char * D; // Reference D
  size_t nD; // size of D

  int sl; // string length
  int hr; // hamming radius = number of mismatches

  uint32_t * H; // hash table, pointing to B
  uint32_t * B; // sorted indexes for S
  size_t nB; // number of buckets
  
  int mm; // max number of mismatches
  int css; // current sub string
  int nss; // number of sub strings
  int ssl; // sub string length

  char * rFile;
  char * qFile;
  char * oFile;

  int verbose;

} sparam;

void sparam_init_D(sparam *);
void print_usage(void);

// hamming distance
//int hamming(char * , char *, sparam * );
// hamming distance, potentially verbosive
int hammingv(char * , char *, sparam *);
int subs_cmp(const void * , const void * , const void *);
uint32_t subs_hash(uint32_t , sparam *);

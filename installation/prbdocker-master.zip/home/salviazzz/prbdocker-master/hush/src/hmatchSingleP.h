#ifndef _hmatchSingleP_h_
#define _hmatchSingleP_h_

#define _GNU_SOURCE

#define MODE_DISCARD 0
#define MODE_COUNT 1
#define MODE_COUNT_EXACT 2

#include "chrTable.h"

// Main structure. Each thread will get a separate copy with unique qFile and oFile. 
typedef struct{
  uint8_t * D; // Reference "database"
  size_t nD; // size of D, i.e. number of letters in reference genome

  int sl; // string length
  int hr; // hamming radius = number of mismatches
  int rc; // scan reverse complement?

  uint32_t * H; // hash table, pointing to B
  size_t nH;

  uint32_t * B; // sorted indexes for S
  size_t nB; // number of buckets
  
  int mm; // max number of mismatches
  int mm_min;
  int css; // current sub string
  int nss; // number of sub strings
  int ssl; // sub string length
  int gain; // How much faster vs brute force

  char * rFile; // to be read into D
  char * qFile; // with query sequences, read on the fly
  char * oFile; // output file

  int verbose; // verbose level
  
  /* 
   * 1=early abort when first match is found
   * 0=count the number of alignments within mm mismatches
   */

  int mode; 

  /* For counting the number of UNIQUE matches */
  uint32_t * Pos;
  size_t nPos;
  size_t nPosMax;

  /* Keep track on the number of sequences that has been queried */
  size_t nQueries;
  /* Cap on the number of off targets 
   * sequences with more matches than this will not be scanned agatin
   * */
  size_t nIgnore;

  /* Ignore one region of the reference sequence? */  
  int rIgnore;
  size_t rIgnoreA; // From
  size_t rIgnoreB; // To

  int nThreads;
  int thread;
  int thread_done;

  int server;

  cht * CHT;

} sparam;


// Initialize a sparam struct with default values
sparam * sparam_init();
// Validate the settings in Q, 
// set mm based on sl, nss and hr
void sparam_recalc(sparam * Q);
// Parse command line arguments
int argparsing(int argc, char ** argv, sparam * Q);



// Create the buckets from D (or read from disk if cached)
int sparam_init_B(sparam *);

// Read the rFile into D. Returns 0 on success.
// D could stand for database
int sparam_init_D(sparam *);
// Read already cleaned fa-file
int read_D(char * , sparam * );

// Create hash table, H from B and D
int sparam_init_H(sparam *);
// Shallow copy of sparam
void sparam_scopy(sparam *, sparam *);
// Show the parameters of Q
void sparam_show(sparam * Q);
// Set substring length
void sparam_set_ssl(sparam * Q, int ssl);
// Set hamming radius
void sparam_set_hr(sparam * Q, int hr);
// Set string length
void sparam_set_sl(sparam * Q, int sl);
// Free allocated memory regions pointed to from Q as well as Q
void sparam_free(sparam * Q);

// Set a region to be ignored
void set_rIgnore(sparam * Q, char * s);

// delta time 
// static double clockdiff(struct timespec* start, struct timespec * finish);


// Show command line arguments
void usage(void);
// Validate input arguments
int sparam_validate_arguments(sparam * Q);
// Reverse base for binary representation
uint8_t reverse_letter_number(uint8_t n);
// Reverse base for character representation
char reverse_letter(char C);
// Reverse complement for binary string
void reverse_complement(sparam * Q, uint8_t * T, uint8_t * S);


// Write names as split does.
void split_print_name(char *, char *, int);
void unit_tests(void);

// hamming distance between A and B
int hamming(const uint8_t * restrict A, const uint8_t * restrict B, const sparam * restrict Q);
// Print the match
int hamming_print(FILE *, const uint8_t * , const uint8_t *, const sparam *);
int subs_cmp(const void * , const void * , const void *);
// substring hash value
uint32_t subs_hash(uint32_t , sparam *);
// Run HUSH
int hush_run(sparam * );
// Entry point for threads
void * hush_run_thread(void *);
void reverse_complement(sparam *, uint8_t *, uint8_t *);

// Find matches to a string
size_t hush_get_matches(sparam *, const uint8_t *);

// Figure out if the input string (from query file)
// is sequence or not
int stringIsSeq(sparam * Q, char * R, size_t nR, size_t * nHits);


void to_chars(char * , const uint8_t *, const size_t);
void to_digital(uint8_t * , const char *, const size_t);

// Count number of unique elements in sorted list.
size_t getUnique_uint32_t(uint32_t * L, size_t n);

// Comparator function to sort uint32_t numbers
#ifdef __APPLE__
int uint32_t_cmp(void * PQ, const void * PA, const void * PB);
#else
int uint32_t_cmp(const void * PA, const void * PB,void * PQ);
#endif

// Comparator function for strings encoded as uint8_t
#ifdef __APPLE__
int str_cmp(void * PQ, const void * PA, const void * PB);
#else
int str_cmp(const void * PA, const void * PB,void * PQ);
#endif

// Hash value for the uint8_t string pointed to by S
uint32_t subs_hash_v0(const uint8_t * restrict S, const sparam * restrict Q);
// Hash value for the uint8_t string pointed to by S.
// This function is idential to subs_hash_v0 when variation is set to -1
// Other than that, variation = 0,1,...ssl*3-1, is the hash values for the 
// sequences within a hamming distance of 1
uint32_t subs_hash_v1_3(const uint8_t * restrict S, const int variation, const sparam * restrict Q);


// Convert numeric valu to character, i.e., 'A'->0, 'C'->1 ...
char val2char(const uint8_t v);
// Inverse to val2char
uint8_t char2val(const char c);

// Convert string to sequence of numbers
void to_digital(uint8_t * restrict y, const char * restrict x, const size_t n);
// Convert sequence of integers to string
void to_chars(char * C, const uint8_t * D, const size_t n);

// Print binary representation of sequence as character representation
void print_br(const uint8_t * restrict v, const size_t n);



#endif

#define _XOPEN_SOURCE 700 // or any bigger number required for getline on linux
#define _GNU_SOURCE

#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <math.h>
#include <fcntl.h>
#include <assert.h>

#include "splitread.h"

static size_t min_size_t(size_t a, size_t b)
{
  if(a<b)
    return a;
  return b;
}

static size_t max_size_t(size_t a, size_t b)
{
  if(a>b)
    return a;
  return b;
}

splr_t * splr_init(void)
{
  splr_t * s = (splr_t *) malloc(sizeof(splr_t));
  s->starts = NULL;
  s->ends = NULL;
  s->N = 0;
  s->fsize = 0;

  s->fnameIn = NULL;
  s->fnameOut = NULL;
  s->fnameParts = NULL;

  return(s);
}

int splr_split(splr_t * splr, char * fnameIn, char * fnameOut, int N)
{
/* Tries to define boundaries for N regions, at line breaks,
 * so that each region ends with an EOL or a EOF.
 */

  FILE * f = fopen(fnameIn, "r");

  if(f==NULL)
  {
    printf("Could not read %s\n", fnameIn);
    splr->N = 0;
    return(-1);
  }

  struct stat st;
  int status = stat(fnameIn, &st);

  if(status != 0)
  {
    printf("Can not get size of %s\n", fnameIn);
    splr->N = 0;
    return(-1);
  }

  size_t fsize = st.st_size;  
  splr->fsize = fsize;

  if(fsize == 0)
  {
    printf("Empty file, can't be split!\n");
    splr->N = 0;
    return(-1);
  }

  /* File exists and is non-zero. Set up the struct.
  */
  splr->fnameIn = malloc(1024*sizeof(char));
  splr->fnameOut = malloc(1024*sizeof(char));
  sprintf(splr->fnameIn, "%s", fnameIn);
  sprintf(splr->fnameOut, "%s", fnameOut);

  /* Generate a name for the temporal file for this split.
   * Uses the same naming as 'split', i.e., xaa, xab, ...
   */
  splr->fnameParts = malloc(N*sizeof(char*));

  for(int kk = 0 ; kk<N; kk++)
  {
    splr->fnameParts[kk] = (char*) malloc(1024*sizeof(char));
    sprintf(splr->fnameParts[kk], "%s.part_x%d", splr->fnameOut, kk);
  }

  splr->starts = malloc(N*sizeof(size_t));
  splr->ends = malloc(N*sizeof(size_t));
  splr->N = N;

  /* Find the splits */

  for(int kk = 0; kk<N; kk++)
  {
    if(kk == 0)
    {
      splr->starts[0] = 0;
    }
    else {
      splr->starts[kk] = splr->ends[kk-1]+1;
    }

    if(kk+1 == N) // If the last segment asked for
    {
      splr->ends[kk] = fsize-1;
    } 
    else 
    {
      // Guess where the end position of this part could be.
      // (Anzats)
      splr->ends[kk] = min_size_t(fsize, 
          max_size_t((kk+1)*fsize/N - 1, splr->starts[kk]));

      size_t endpos = splr->ends[kk];

      if(endpos + 1 < fsize)
      {

        fseek(f, endpos, SEEK_SET);

        size_t fpos = ftell(f);

        while(fgetc(f) != '\n' && (endpos++)<fsize)
        {
          fpos++;
        }

        splr->ends[kk] = (size_t) fpos;

      } else {
        // Set this to the last interval
        splr->N = kk+1; 
        kk = N+1;
      }
    }
  }

  fclose(f);
  return(0);
}

void splr_free(splr_t ** splr)
{
  if(*splr == NULL)
    return;

  if((*splr)->fnameParts != NULL)
  {
    for(int kk = 0 ; kk<(*splr)->N; kk++)
      free((*splr)->fnameParts[kk]);
    free((*splr)->fnameParts);
  }

  if((*splr)->starts != NULL)
    free((*splr)->starts);
  if((*splr)->ends != NULL)
    free((*splr)->ends);

  free(*splr);
  *splr = NULL;
  return;
}

void splr_show(splr_t * splr)
{
  printf("-> splr_show, SUMMARY:\n");
  if(splr->N == 0)
  {
    printf(" Not initialized!\n");
    return;
  }
  printf(" input file: %s\n", splr->fnameIn);
  printf(" ouput file: %s\n", splr->fnameOut);
  printf(" fsize: %zu\n", splr->fsize);
  printf(" N segments: %zu\n", splr->N);
  for(int kk = 0; kk<splr->N; kk++)
  {
    printf(" [%10zu, %10zu] %s\n", splr->starts[kk], splr->ends[kk], splr->fnameParts[kk]);
  }
  return;
}

int splr_test(splr_t * splr, char * fname)
{
  printf("-> splr_test\n");
  if(splr->N == 0)
  {
    printf(" No splits\n");
    // TODO: test that file size is 0
    return(0);
  }

  FILE * f = fopen(fname, "r");

  size_t lastpos = splr->ends[splr->N -1]-1;

  for(int kk = 0; kk+1<splr->N; kk++)
  {
    printf(" Interval %d. Testing so that last character is '\\n'\n", kk+1);
    if(splr->ends[kk]+1 < lastpos)
    {
      fseek(f, splr->ends[kk], SEEK_SET);
      int c = fgetc(f);
      if(c != '\n')
      {
        printf(" last character: %c\n", c);        
        assert(c == '\n');
      }
    }
  }

  assert(ferror(f) == 0);
  printf(" Testing so that the last interval is inside the file\n");
  printf(" Lastpos: %zu\n", lastpos);
  fseek(f, lastpos, SEEK_SET);
  int c = fgetc(f);
  assert(c != EOF);
  if(c == '\n')
  {
    printf(" Last character: (%d) '\\n'\n", c);
  } else {
    printf(" Last character: (%d) '%c'\n", c, c);
  }

  fclose(f);
  return(0);
}

int splr_cat(splr_t * splr)
{
  /* For debugging/example. 
   * Shows how to read each part of the input 
   * file and write it to separate files 
   */

  if(splr->N == 0)
  {
    printf("splr_t object not initialized!\n");
    return(-1);
  }

  FILE * fin = fopen(splr->fnameIn, "r");

  size_t linecapp = 2048;
  char * rline = (char *) malloc(linecapp*sizeof(char));

  ssize_t linelen = 0;

  for(int ff = 0; ff< splr->N; ff++)
  {
    FILE * fout = fopen(splr->fnameParts[ff], "w");
    fseek(fin, splr->starts[ff], SEEK_SET);
    
    if(0) {
    /* Write character by character. */
    int c = fgetc(fin);
    size_t nWritten = 0;
    size_t nChars = splr->ends[ff] - splr->starts[ff];
    
       while(c != EOF && nWritten < nChars)
    {
      fputc(c, fout);
      nWritten++;
      c = fgetc(fin);
    }
    }

    /* Write line by line */
    size_t lastpos = splr->ends[ff];
    while((linelen = getline(&rline, &linecapp, fin)) != -1)
    {
      /* Do some processing of the line before writing back
       * myStringFun(rline);
       */

      fwrite(rline, linelen, 1, fout);

   if(ftell(fin)>lastpos)
   {
     printf("Reached end of segment\n");
     break;
   }

    }

    fclose(fout);
  }

  fclose(fin);

  free(rline);

  return(0);
}

int splr_join_files(splr_t * splr)
{
  if(splr->N == 0)
  {
    printf("splr_t object not initialized!\n");
    return(-1);
  }
  
  FILE * fout = fopen(splr->fnameOut, "w");
  for(int kk = 0; kk<splr->N; kk++)
  {
    FILE * fin = fopen(splr->fnameParts[kk], "r");
    int c = fgetc(fin);
    size_t nWritten = 0;
    while (c != EOF){ // unnecessary comparison since the file size is known
      fputc(c, fout);
      nWritten++;
      c = fgetc(fin);
    }
    assert(nWritten == splr->ends[kk] - splr->starts[kk]);
    fclose(fin);
  }

  /* Remove the temporary files */
  for(int kk = 0; kk<splr->N; kk++)
    remove(splr->fnameParts[kk]);

  return(0);
}

typedef struct{
  int threadid;
  splr_t * splr;
} tdata;

static void * threadfun(void * da)
{
  tdata * data = (tdata *) da;
  splr_t * splr = data->splr;
  int ff = data->threadid;

  FILE * fin = fopen(splr->fnameIn, "r");

  size_t linecapp = 2048;
  char * rline = (char *) malloc(linecapp*sizeof(char));

    FILE * fout = fopen(splr->fnameParts[ff], "w");
    fseek(fin, splr->starts[ff], SEEK_SET);
 
    /* Write line by line */
    size_t lastpos = splr->ends[ff];
    size_t linelen = 0;
    while((linelen = getline(&rline, &linecapp, fin)) != -1)    {
      // Do some processing of the line before writing back
      // myStringFun(rline);
      fwrite(rline, linelen, 1, fout);

   if(ftell(fin)>lastpos) /*      <<<< ---- Notice! ---- <<<<      */
     break;
    }

    fclose(fout);

  fclose(fin);
  free(rline);
  return(NULL);
}

#ifndef main
int main(int argc, char ** argv)
{
  if(argc < 3)
  {
    fprintf(stderr, "ERROR: no input and output file names given\n");
    return(-1);
  }

  int N = 4; // Number of splits to use

  if(argc > 3)
  {
    N = atoi(argv[3]);
  }
  else
  {
    printf("Number of splits not specified, using %d\n", N);
  }

  splr_t * splr = splr_init();

  /* Figure out where the boundaries are */
  splr_split(splr, argv[1], argv[2], N);
  
  splr_show(splr);
  splr_test(splr, argv[1]);

  int nthreads = splr->N;

  pthread_t * threads = malloc(nthreads*sizeof(pthread_t));
  tdata * D = malloc(nthreads*sizeof(tdata));
  for(int kk = 0; kk<nthreads; kk++)
  {
    D[kk].threadid = kk;
    D[kk].splr = splr;
  }

  for(int kk = 0; kk<nthreads; kk++)
    pthread_create(&threads[kk], NULL, threadfun, (void*) &D[kk]);

  for(int kk = 0; kk<nthreads; kk++)
    pthread_join(threads[kk], NULL);

//  splr_cat(splr); // non-threaded version of the lines above

  splr_join_files(splr); // join the parts to argv[2] and remove parts from disk
  splr_free(&splr);
  return(0);
}
#endif

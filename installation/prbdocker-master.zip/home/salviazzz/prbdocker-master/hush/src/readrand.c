#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>

/* 
 * Might fail to produce a string of full length if it hits EOF
 * before all characters have been read.
 *
 * Does not warn if N is outside of the file.
 */

void readrand_usage()
{
  printf("reads N characters 'A'--'z' in a file, starting at a random position\n");
  printf("Usage:\n");
  printf("$ readrand file N\n");
  printf("There is no guarantees that N characters can be found\n");
  printf("Returns 1 on failure\n");
}

int main(int argc, char ** argv)
{

  if(argc < 3)
  {
    readrand_usage();
    exit(1);
  }

  size_t nchars = atol(argv[2]);

  FILE * f = fopen(argv[1], "r");

  if(f == NULL)
  {
    fprintf(stderr, "Failed to open %s\n", argv[1]);
    return 1;
  }

  size_t pos = 0;
  int gen_randpos = 1;

  if(argc>3)
  {
    gen_randpos = 0;
    pos = atol(argv[3]);
  }

  fseek(f, 0L, SEEK_END);
  size_t fsize = ftell(f);

  srand(time(NULL)*getpid());

  if(nchars>fsize)
  {
    fprintf(stderr, "Can't extract %zu characters from a file of %zu bytes\n", nchars, fsize);
    exit(1);
  }

  size_t maxpos = 0;

  if(gen_randpos)
  {
    if(fsize > nchars)
    {
      maxpos = fsize-nchars;
      pos = rand() % (maxpos+1);
    }
  }

  fseek(f, pos, SEEK_SET);

  if(errno != 0)
  {
    fprintf(stderr, "errno=%d\n", errno);
    return 1;
  }

  size_t nprinted = 0;

  int ch = 0;

  while( (ch = fgetc(f)) != EOF  && nprinted < nchars)
  {
    if( ((ch >= (int) 'A') && (ch <= (int) 'Z'))
        || ((ch >= (int) 'a') && (ch <= (int) 'z')) )
    {
      printf("%c", ch);
      nprinted++;
    }
  } 

  if(nprinted > 0)
  {
    printf("\n");
  }

  fclose(f);

  if(nprinted != nchars)
  {
    fprintf(stderr, "Error: Didn't read the wanted number of characters\n");
    return 1;
  }

  return 0; 
}

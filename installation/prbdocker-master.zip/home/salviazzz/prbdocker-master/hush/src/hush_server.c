#define _GNU_SOURCE

#ifndef __APPLE__
#define _XOPEN_SOURCE 700 // Make getline visible on on linux but hides qsort_r on osx
#endif


#include <stdio.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include "hmatchSingleP.h"
#include "hush_server.h"
#include <assert.h>
// #include <error.h> // Only GNU, not needed
#include <errno.h>


void match_string(sparam * Q, FILE * sd, char * S)
{

  size_t nshow_max = 15; // Max number of hits to show

  printf("Input: %s\n", S); 

  // Set up line buffer
  size_t lbSize = 1024;
  char * lb = malloc(lbSize*sizeof(char));

  if(strlen(S) != Q->sl)
  {
    fprintf(sd, "String is %zu characters, should by %d\n", strlen(S), Q->sl);

    free(lb);
    return;
  }

  uint8_t * Sv = malloc(Q->sl * sizeof(uint8_t));
  uint8_t * Svx = malloc(Q->sl * sizeof(uint8_t));
  to_digital(Sv, S, Q->sl);
  reverse_complement(Q, Svx, Sv);

  printf("Looking for matches\n"); fflush(stdout);

  // TOOD: either redirect stdout to sd or supply a FILE * to hammingv ...
  // pipe in <unistd.h> could do the trick?

  Q->nPos = 0;
  if(Q->Pos == NULL)
  {
    printf("Can't proceed Q->Pos == NULL\n");
    return;
  }

  size_t hits = hush_get_matches(Q, Sv);
  size_t hitsx = hush_get_matches(Q, Svx);

  if(hits+hitsx == 1) {
    fprintf(sd, "%zu match\n", hits+hitsx);
  } else {
    fprintf(sd, "%zu matches\n", hits+hitsx);
  }

#ifdef __APPLE__
  qsort_r(Q->Pos, Q->nPos, sizeof(uint32_t), NULL, uint32_t_cmp);
#else
  qsort_r(Q->Pos, Q->nPos, sizeof(uint32_t), uint32_t_cmp, NULL);
#endif

  size_t n_hits = getUnique_uint32_t(Q->Pos, Q->nPos);
  if(n_hits < Q->nPosMax)
  {
    fprintf(sd, "%zu unique\n", n_hits);
  } else {
    fprintf(sd, "more than %zu are unique\n", Q->nPosMax);
  }

  size_t hit_last = (size_t) -1;
  size_t nshow = Q->nPos;

  if(nshow > nshow_max)
  {
    nshow = nshow_max;
    fprintf(sd, "NOTE: Only showing the first %zu hits\n", nshow);
  }


  size_t shown = 0;
  for(size_t idx = 0; idx < Q->nPos; idx++)
  {
    if(Q->Pos[idx] != hit_last)
    {
      fprintf(sd, "\n");
      hit_last = Q->Pos[idx];
      size_t pos = Q->Pos[idx];

      // Get coordinates of match
      size_t localPos = 0;
      char * fileName = NULL;
      if(Q->CHT != NULL)
      {
        if(chrTable_get(Q->CHT, Q->Pos[idx], &localPos, &fileName) == 0)
          ;
      }

      if(hamming(Sv, Q->D+pos, Q) < hamming(Svx, Q->D+pos, Q))
      {

        fprintf(sd, "Match at pos %zu ", (size_t) Q->Pos[idx]);
        if(fileName != NULL)
        {
          fprintf(sd, "%s:%zu\n", fileName, localPos);
        } else { fprintf(sd, "\n"); }

        hamming_print(sd, Sv, Q->D+pos, Q);
      } else {        
        fprintf(sd, "Reverse complement match at pos %zu ", (size_t) Q->Pos[idx]);
        if(fileName != NULL)
        {
          fprintf(sd, "%s:%zu\n", fileName, localPos);
        } else { fprintf(sd, "\n"); }

        hamming_print(sd, Svx, Q->D+pos, Q);
      }
      shown++;
    }
    if(shown >= nshow)
    {
      idx = Q->nPos;
    }
  }

  return;
}

void hush_server(sparam * Q)
{
  int newsockfd;
  unsigned int clilen;
  int portno = 9876;
  int sWait = 5;

  printf("Starting server at port: %d\n", portno);

  char buffer[256];
  struct sockaddr_in serv_addr, cli_addr;
  int n;

  int sockfd = -1;
  while(sockfd == -1)
  {
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if(sockfd == -1)
    {
      printf("ERROR opening socket: %s\n", strerror(errno));
      printf("Will retry in %d s\n", sWait);
      sleep(sWait);
    }
  }
  printf("Socket open.\n");

  bzero((char *) &serv_addr, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = INADDR_ANY;
  serv_addr.sin_port = htons(portno);

  while( (bind(sockfd, (struct sockaddr *) &serv_addr,
          sizeof(serv_addr))) <0 ) 
  {
    printf("ERROR on binding : %s", strerror(errno));
    printf("ERROR opening socket, will retry in %d s\n", sWait);
    sleep(sWait);
  }

  listen(sockfd,5);
  clilen = sizeof(cli_addr);

  while (1) {
    printf("Waiting for connection\n");
    newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
    if (newsockfd < 0) 
    {
      fprintf(stderr, "ERROR on accept");
      exit(1);
    }
    bzero(buffer,256);

    // Read query string from the socket
    n = read(newsockfd,buffer,255);
    if (n < 0) 
    {
      fprintf(stderr, "ERROR reading from socket");
      exit(1);
    }

    // Use a buffered stream
    FILE * sd = fdopen(newsockfd, "a+");

    printf("Got %zu : \"%s\"\n", strlen(buffer), buffer);

    match_string(Q, sd, buffer);
    //  printf("Here is the message: %s\n",buffer);

    // n = write(newsockfd,"I got your message",18);

    fflush(sd);
    fclose(sd); // ALso closes newsockfd
  }

  return; 
}

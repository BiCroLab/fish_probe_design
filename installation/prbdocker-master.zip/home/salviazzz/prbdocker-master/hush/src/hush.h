#ifndef __hush_h_
#define __hush_h_

#define HUSH_VERSION_MAJOR "0"
#define HUSH_VERSION_MINOR "0"
#define HUSH_VERSION_PATCH "2"

#define HUSH_VERSION HUSH_VERSION_MAJOR "."               \
    HUSH_VERSION_MINOR "."                          \
    HUSH_VERSION_PATCH

#ifndef GIT_VERSION
#define GIT_VERSION "unknown"
#endif

/* For hush_cgi.c and hush_server.c */

#define PORT_NUMBER 9876;

void hush_version()
{
  printf("HUSH, version %s\n", HUSH_VERSION);
  printf("GIT HASH: %s\n", GIT_VERSION);
  printf("Bienko Crosetto Labs 2018-2019\n");
}

#endif

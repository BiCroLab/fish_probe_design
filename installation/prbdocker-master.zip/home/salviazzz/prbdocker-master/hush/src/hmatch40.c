// https://github.com/elgw/unique_seq_hamming/

#define _XOPEN_SOURCE 700 // or any bigger number required for getline on linux
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <math.h>
#include <string.h>
#include <sys/stat.h>
#include "hmatch40.h"

/*
Strategies for 5 mm for strings of length 40:
a) 3 hash tables, check sequences withing radius 1
string length 10:
1048000 bins

For each sequences:
40x3xNS/2^20 = 28k

string length 11 -> 8k

string length 12 -> 2k

string length 13 -> .5k
each hash table 2^26 elements x 8 bit
-> 550 Mb

b) 6 hash tables, radius 0
6 characters for indexing -> 4096 bins.
For each sequences, 
    6 bins x NS/4096 sequences to be checked 
    with NS = 250x10^6 -> 366 000
*/

/* glob_SS affects the string comparison and the hash generating
 * function, i.e. it is a state
*/

int glob_SS; // substring number, 0, .., 9

#define glob_nChar 13 // gives 2^26 sized buckets

char * glob_S; // sequence to match in

size_t sequence_load(char * filename)
{
  // Load a clean file from disk with only atcgATCG
  // 'n' or 'N' is translated to 'a' not to cause gaps

  int verbose = 0;
  if(verbose)
    printf("Reading %s\n", filename);

  // Get file size 
  struct stat st;
  int status = stat(filename, &st);
  assert(status == 0);

  size_t fsize = st.st_size;

  // Allocate enough memory, possibly more than needed when
  // non-nucleotide characters are filtered out like line endings
  glob_S = malloc(fsize);

  FILE * f = fopen(filename, "r");

  size_t bbRead =  fread(glob_S, fsize, 1, f);
  if(bbRead != 1)
  { 
    printf("Failed to read file\n"); 
    exit(1); 
  }

  size_t readpos = 0;
  size_t writepos = 0;

  if(verbose>0)
    printf("Processing data\n");
  while(readpos<fsize)
  {
    switch(glob_S[readpos++]) {
      // aA
      case 97:
        glob_S[writepos++] = 'A';
        break;
      case 65:
        glob_S[writepos++] = 'A';
        break;
        // tT
      case 116:
        glob_S[writepos++] = 'T';
        break;
      case 84:
        glob_S[writepos++] = 'T';
        break;
        // cC
      case 99:
        glob_S[writepos++] = 'C';
        break;
      case 67:
        glob_S[writepos++] = 'C';
        break;
        // gG
      case 103:
        glob_S[writepos++] = 'G';
        break;
      case 71:
        glob_S[writepos++] = 'G';
        break;
        // n and N is replaced by 'A' to preserve the structure
      case 'n':
        glob_S[writepos++] = 'A';
        break;
      case 'N':
        glob_S[writepos++] = 'A';
        break;
      default:
        // Discard anything that is not atcgnATCGN
        break;
    }
  }

  fclose(f);

  return(writepos);
}

int hamming40(char * A, char * B)
{
  int h = 0;
  for(int kk = 0; kk<40; kk++)
    if(A[kk] != B[kk])
      h++;
  
  return h;
}

int hamming40v(char * A, char * B)
{
  const int verbose = 1;
  int h = 0;
  int score = hamming40(A,B);
  if(verbose)
    printf("\n%.40s\n", A);
  for(int kk = 0; kk<40; kk++)
  {
    if(A[kk] == B[kk])
    {
      if(verbose)
        printf("|");
    } else
    {
      if(verbose)
        printf(" ");
      h++;
    }
  }
  if(verbose)
  {
    printf(" %d \n", score);
    printf("%.40s\n", B);
  }
  assert(h==score);
  return h;
}

int subs_cmp(const void * A, const void * B)
{
  // substring comparison

  // SS: global parameter, substring
  char ** Q = (char **) A;
  char ** S = (char **) B;

  //  printf("subs_cmp\n");
  //  printf("  %.10s\n", Q[0]+glob_SS*10);
  //  printf("    %.10s\n", S[0]+glob_SS*10);
  //  printf("     %d\n", strncmp(Q[0]+glob_SS*10, S[0]+glob_SS*10, nChar));
  return strncmp(Q[0]+glob_SS*13, S[0]+glob_SS*13, glob_nChar);
}

size_t subs_hash_v1(const char * restrict S, int variation)
{
  int vpos = variation/4;
  int vval = variation - vpos*4;

  assert(vpos<13);
  assert(vval<4);

  size_t h = 0;
  for(int kk = 0; kk<vpos; kk++)
  {
    h*=4;
    switch(S[kk+13*glob_SS])
    {
      case 'A':
        h+=0;
        break;        
      case 'C':
        h+=1;
        break;
      case 'G':
        h+=2;
        break;
      case 'T':
        h+=3;
        break;
      default:
        printf("invalid letter: >%c<\n", S[kk+10*glob_SS]);
        assert(0);
        break;
    }
  }

  // at vpos
  h*=4;
  h+=vval;

  for(int kk = vpos+1; kk<13; kk++)
  {
  h*=4;
    switch(S[kk+13*glob_SS])
    {
      case 'A':
        h+=0;
        break;        
      case 'C':
        h+=1;
        break;
      case 'G':
        h+=2;
        break;
      case 'T':
        h+=3;
        break;
      default:
        printf("invalid letter: >%c<\n", S[kk+10*glob_SS]);
        assert(0);
        break;
    }


  }
  assert(h<powl(4, 13));
  return h;
}

size_t subs_hash(const char * restrict S)
{
  size_t h = 0;
  for(int kk = 0; kk<13; kk++)
  {
    h*=4;
    switch(S[kk+13*glob_SS])
    {
      case 'A':
        h+=0;
        break;        
      case 'C':
        h+=1;
        break;
      case 'G':
        h+=2;
        break;
      case 'T':
        h+=3;
        break;
      default:
        printf("invalid letter: >%c<\n", S[kk+10*glob_SS]);
        assert(0);
        break;
    }
  }
  return h;
}


int main(int argc, char ** argv)
{
  if(argc < 4)
  {
    printf("Wrong number of input arguments\n");
    printf("Usage: \n");
    printf("%s db.fa query.fa out.fa\n", argv[0]);
    printf("Optional arguments (at the end): -verbose, -debug, -show\n");
    return 0;
  }

  int showMatch = 0;
  int verbose = 0;
  int debug = 0;

  if(argc > 4)
  {
    for(int kk = 4; kk<argc; kk++)
    {
    if(strcmp(argv[kk], "-verbose") == 0)
        verbose = 1;
    if(strcmp(argv[kk], "-debug") == 0)
        debug = 1;
    if(strcmp(argv[kk], "-show") == 0)
        showMatch = 1;
        }
  }

  time_t t0 = clock();

  // Open the query file already here, so that it can exit fast if
  // there are errors
  FILE * fquery = fopen(argv[2], "r");
  assert(fquery != NULL);

  printf("Loading sequence ... ");
  fflush(stdout);
  size_t lS = sequence_load(argv[1]); // load sequence into glob_S
  assert(lS>0);
  assert(lS>39);
  printf(" %.40s ...\n", glob_S);

  if(debug)
    printf("lS = %zu\n", lS);

  glob_SS = 0; // substring state
  const int nB = 3; // number of buckets
  const size_t bucket_size = powl(4, 13);

  printf("Creating %d buckets: ", nB);
  fflush(stdout);
  char *** BI = malloc(nB*sizeof(char*)); // bucket index
  for(int kk = 0; kk<nB; kk++)
  {
    printf("<");
    fflush(stdout);
    glob_SS = kk; // set corresponding substring
    BI[kk] = (char **) malloc(lS*sizeof(char*));
    for (size_t bb = 0; bb<lS-39; bb++)
      BI[kk][bb] = (char*) glob_S + bb;
    printf("|");
    fflush(stdout);

    qsort(BI[kk], lS-39, sizeof(char*), subs_cmp); 
    printf("> ");
    fflush(stdout);


  }
  printf("\n");

  printf("Creating hash indexes: ");
  fflush(stdout);
  size_t ** HI = malloc(nB*sizeof(char *));
  assert(HI != NULL);

  for(int kk = 0; kk<nB; kk++)
  {
    printf(".");
    fflush(stdout);
    glob_SS = kk;

    // The extra element to use when calculating the size of the hash bins
    HI[kk] = malloc((bucket_size+1)*sizeof(char*)); 
    assert(HI[kk] != NULL); 

    for(size_t ll=0; ll<bucket_size; ll++)
      HI[kk][ll] = (size_t) -1;

    for(size_t ll = 0; ll<lS-39; ll++)
    {
      size_t h = subs_hash(BI[kk][ll]);
      assert(h<bucket_size);
        
      // Since BI is sorted, we use the first one as the starting point of the bucket
      if(HI[kk][h] == (uint64_t) -1) 
        HI[kk][h] = ll;
    }

    // set first and last element
    if(HI[kk][0] == (uint64_t) -1)
      HI[kk][0]=0;
    HI[kk][bucket_size] = lS-39; // remember, HI[kk] is bucket_size+1 long

    // Walk backwards and propagate the start position of the later
    // buckets. 
    for(size_t ll = bucket_size-1; ll>0; ll--)
    {
      if(HI[kk][ll] == (uint64_t) -1)
        HI[kk][ll] = HI[kk][ll+1];
    }
    
    if(debug)
    {
    for(size_t ll = 0; ll<bucket_size-1; ll++)
      assert(HI[kk][ll]<=HI[kk][ll+1]);
    }
  }
  printf("\n");

  printf("Aligning... \n");
  time_t tstart = clock();

  FILE * fout = fopen(argv[3], "w");
  assert(fout != NULL);

  size_t linecap = 1024;
  char * Q = malloc(linecap*sizeof(char));

  /* 
   * Main loop. Read one line from the query file at a time
   * If comment, pass through to the output file.
   * If sequence, let it pass only if it does not match the database
   * Perfect matches are excepted. 
   */

  size_t qread = 0;
  while( (qread = getline(&Q, &linecap, fquery)) != -1)
  {
    int isSeq = 1;
    if( !(qread == 41))
      isSeq = 0;
    if( qread > 1)
      if(Q[0] == '>')
        isSeq = 0;

    if(!isSeq) // if comment or unrecognized
    {
      if(debug)
      {
        fprintf(fout, "#");
        printf("::: %s", Q);
      }
      fprintf(fout, "%s", Q);
      
    }
    else // if sequence of length 40
    {
      size_t n_candidates = 0;
      size_t n_hits = 0;

      for(int kk = 0; kk<nB; kk++) // Look in each hash table/bucket
      {
        glob_SS = kk;
        for(int dd = 0; dd<13*4; dd++) // search all "adjacent" buckets
        {
        size_t h = subs_hash_v1(Q, dd); 
        if(debug)
          printf("h_%d(Q) = %zu\n", kk, h);

        size_t pos = HI[kk][h];
        size_t endpos = HI[kk][h+1];
        if(debug)
          printf("\n--> searching in [%zu, %zu]\n\n", pos, endpos);
        //for(size_t tt = h-10; tt<h+10; tt++)
        //  printf("HI[0][%zu] =  %zu\n", tt, HI[kk][tt]);
        while(pos<endpos)
        {
          n_candidates++;
          if(0*debug)
            printf("-> Potential candidate in hash table %d, pos %zu:\n", kk, pos);

          int hdist = hamming40(Q, BI[kk][pos]);
          if(verbose)
            printf("H(Q, S) = %d\n", hdist);

          if(hdist<6) // MATCH
          {
            if(showMatch == 1)
            {
              // show the alignment on std out
              hamming40v(Q, BI[kk][pos]);
            }

            if(hdist == 0)
            {
              // Ignore perfect matches
            }
            else
            {
              n_hits++;
              pos = endpos+1; // don't check any more sequences. 
              kk = 100; // i.e. don't try with another bucket
              dd = 1000;
            }
          }
          pos++;
        }

        }
      }

      // only write the sequence back if it did not match anything
      // Perfects matches are ignored
      
      if(n_hits == 0)
        fprintf(fout, "%.40s\n", Q);

      if(debug)
      {
        printf("Investigated %zu candidates out of %zu sequences\n", n_candidates, lS-59);
        printf("%zu hits where dist<6\n", n_hits);
      }

    } // if sequence
  } // while(getline)

  clock_t tend = clock();

  printf("Time: loading: %f s, matching %f s\n", 
      (double) (tstart-t0) / CLOCKS_PER_SEC,
      (double) (tend-tstart) / CLOCKS_PER_SEC);

  fclose(fout);
  fclose(fquery);

  return 0;
} 

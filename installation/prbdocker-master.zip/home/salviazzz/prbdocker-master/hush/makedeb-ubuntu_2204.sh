#!/bin/bash
set -e

NAME="Erik Wernersson"
EMAIL="https://github.com/elgw/hush/issues"

set -e # exit on error

if [ $EUID = 0 ]; then
    echo "WARNING: You are running as root, please abort!"
    echo "Sleeping for 10 s"
    sleep 10
fi

savedir="$(pwd)"
builddir=$(mktemp -d)
cd $builddir
pkgdir=$(mktemp -d)/hush
echo "pkgdir=$pkgdir"

ver_major=`sed -rn 's/^#define.*HUSH_VERSION_MAJOR.*([0-9]+).*$/\1/p' < $savedir/src/hush.h`
ver_minor=`sed -rn 's/^#define.*HUSH_VERSION_MINOR.*([0-9]+).*$/\1/p' < $savedir/src/hush.h`
ver_patch=`sed -rn 's/^#define.*HUSH_VERSION_PATCH.*([0-9]+).*$/\1/p' < $savedir/src/hush.h`
pkgver="${ver_major}.${ver_minor}.${ver_patch}"
echo "pkgver=$pkgver"
arch=$(dpkg --print-architecture)
echo "arch=$arch"

echo "Preparing files"
# Copy files to the correct places
# binaries
mkdir -p $pkgdir/usr/local/bin
cp $savedir/bin/hushp $pkgdir/usr/local/bin/

# man pages
mkdir -p $pkgdir/usr/share/man/man1/
cp $savedir/man/man1/hush.1 $pkgdir/usr/share/man/man1/

cd $pkgdir
size=$(du -k usr | tail -n1 | sed 's/usr//')

mkdir $pkgdir/DEBIAN/
cat > $pkgdir/DEBIAN/control << END
Package: hush
Version: $pkgver
Architecture: $arch
Depends:
Conflicts:
Maintainer: $NAME <$EMAIL>
Installed-Size: $size
Section: custom
Priority: optional
Homepage: https://github.com/elgw/hush/
Description: HUSH
END

cd $pkgdir/../
dpkg-deb --build hush hush_${pkgver}_${arch}.deb
mv hush_${pkgver}_${arch}.deb "$savedir"

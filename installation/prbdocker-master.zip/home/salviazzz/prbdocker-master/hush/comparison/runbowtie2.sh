bowtie-build -f ../hg/GRCh37_all.fsa ../hg_bowtie/hg_bowtie

# -e/--maqerr <int>  max sum of mismatch quals across alignment for -n (def: 70)
# -k <int>           report up to <int> good alignments per read (default: 1)
# --nofw/--norc      do not align to forward/reverse-complement reference strand
# -n/--seedmms <int> max mismatches in seed (can be 0-3, default: -n 2)
# --ntoa                  convert Ns in reference to As
#-x <bt2-idx>      
#
# The basename of the index for the reference genome. The basename is the name of any of the index files up 
# to but not including the final .1.bt2 / .rev.1.bt2 / etc. bowtie2 looks for the specified index first in
# the current directory, then in the directory specified in the BOWTIE2_INDEXES environment variable.
time bowtie -k 2 -e 5 -norc -q ../k60_n100 -x ../hg_bowtie/ 2>> out_bowtie

#!/bin/bash

### building docker container using the provided Dockerfile
docker build -t prbdocker .

### converting docker container to singularity image
docker run -v /var/run/docker.sock:/var/run/docker.sock -v ".":/output \
 --privileged -t --rm singularityware/docker2singularity:v2.6 prbdocker

### moving singularity image to the target location
### rsync --partial --progress -e ssh ${CONTAINER} ${USER}@${SSH_DOMAIN}:${TARGET_LOCATION}

$ nhush eq_classes --file hg19.fa --length 40
$ nhush eq_classes --export hg19.fa.L40.eqc \
  --length 40 --low 1000 --file hg19.fa \
    | grep -B 1 TGGAATGGAATGGAATGGAATGGAATGGAATGGAATGGA
> 1476 id2556795582
TGGAATGGAATGGAATGGAATGGAATGGAATGGAATGGAA
$ nhush bfm -r hg19.fa -M 0 \
  -s TGGAATGGAATGGAATGGAATGGAATGGAATGGAATGGAA \
    | grep match \
    | wc
1476    4428   91512

import itertools
import numpy as np

def hdist(a, b):
    return np.sum(np.array(list(a)) != np.array(list(b)))

def printmm(s, alpha, mm):
    # all positions in the string
    stringpos = list(range(0,len(s)))
    for c in itertools.combinations(stringpos, mm):
        # c is are the locations to permute
        e = list(s)
        # original values at pos c
        org = list(map(e.__getitem__, c))
        for p in itertools.permutations(alpha, mm):
            # p: replacement letters
            for i,pos in enumerate(c):
                e[pos] = p[i]
            sout = ''.join(e)
            if hdist(sout, s) == mm:
                print(''.join(e) + ' ' , end='')
        print('')


# base string
s = 'ATCG'
# Alphabet
alpha = 'ATCG'

#printmm(s, alpha, mm=1)
printmm(s, alpha, mm=2)
#printmm(s, alpha, mm=3)

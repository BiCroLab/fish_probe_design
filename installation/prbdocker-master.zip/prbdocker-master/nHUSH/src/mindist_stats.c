#include "mindist_stats.h"


uint8_t * md_read(const char * file, size_t * fsize)
{
    FILE * fid = fopen(file, "r");
    if(fid == NULL)
    {
        fprintf(stderr, "Unable to open %s\n", file);
        exit(EXIT_FAILURE);
    }

    size_t size = 0;
    fseek(fid, 0, SEEK_END);
    size = ftell(fid);
    rewind(fid);

    uint8_t * md = malloc(size*sizeof(size_t));
    size_t nread = fread(md, 1, size, fid);

    if(nread != size)
    {
        fprintf(stderr, "Unable to read %s\n", file);
        fprintf(stderr, "File should be %zu bytes, but read %zu bytes\n",
                size, nread);
        exit(EXIT_FAILURE);
    }
    fclose(fid);
    *fsize = size;
    return md;
}

int mindists_stats(int argc, char ** argv)
{
    char * mdfile = NULL;
    if(argc == 2)
    {
        mdfile = strdup(argv[1]);
    } else {
        fprintf(stderr, "No mindist file specified\n");
        exit(EXIT_FAILURE);
    }

    size_t md_size = 0;
    uint8_t * md = md_read(mdfile, &md_size);

    size_t * H = calloc(256, sizeof(size_t));

    for(size_t kk = 0 ; kk < md_size ; kk++)
    {
        H[md[kk]]++;
    }
    free(md);

    for(size_t kk = 0 ; kk < 256 ; kk++)
    {
        if(H[kk] > 0)
        {
            printf("d=%zu %zu\n", kk, H[kk]);
        }
    }

    free(H);
    free(mdfile);
    return EXIT_SUCCESS;
}

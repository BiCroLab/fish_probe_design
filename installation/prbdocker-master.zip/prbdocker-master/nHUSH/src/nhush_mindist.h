#ifndef nhush_mindist_h_
#define nhush_mindist_h_

int nhush_mindist(int argc, char ** argv);

#endif

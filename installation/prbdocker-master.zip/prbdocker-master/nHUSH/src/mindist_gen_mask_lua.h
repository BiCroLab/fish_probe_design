#pragma once

#define _GNU_SOURCE

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>
#include <readline/readline.h>
#include <readline/history.h>

#include "readfa.h"

uint8_t *
mindist_gen_mask_lua(FILE * outfile,
                     const char * script_file,
                     fasta_records_t * records,
                     size_t genome_size);

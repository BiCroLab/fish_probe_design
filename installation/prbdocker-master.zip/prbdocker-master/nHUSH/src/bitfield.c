#include "bitfield.h"

bitfield_t*
bitfield_new_false(size_t N)
{
#if bitfield_h_assert_
    assert(N>0);
#endif

    bitfield_t * F = calloc(1, sizeof(bitfield_t));
    F->N = N;
    F->data = calloc(N/8 + 1, 1);
    return F;
}


bitfield_t*
bitfield_new_true(size_t N)
{
#if bitfield_h_assert_
    assert(N>0);
#endif

    bitfield_t * F = bitfield_new_false(N);
    memset(F->data, 0b11111111, N/8 + 1);
    return F;
}


void
bitfield_free(bitfield_t * F)
{
#if bitfield_h_assert_
    assert(F != NULL);
#endif

    free(F->data);
    free(F);
    return;
}


void
bitfield_set_true(bitfield_t * F, size_t N)
{
#if bitfield_h_assert_
    assert(F != NULL);
    assert(F->data != NULL);
    assert(N < F->N);
#endif

    size_t idx = N/8;
    size_t sub = N-idx*8;
    uint8_t mask = 1 << sub;
    F->data[idx] = F->data[idx] | mask;
}


void
bitfield_set_false(bitfield_t * F, size_t N)
{
#if bitfield_h_assert_
    assert(F != NULL);
    assert(F->data != NULL);
    assert(N < F->N);
#endif

    size_t idx = N/8;
    size_t sub = N-idx*8;
    uint8_t mask = 255 - (1 << sub);
    F->data[idx] = F->data[idx] & mask;
}



int
bitfield_get(const bitfield_t * F, size_t N)
{
#if bitfield_h_assert_
    assert(F != NULL);
    assert(F->data != NULL);
    assert(N < F->N);
#endif

    size_t idx = N/8;
    size_t sub = N-idx*8;
    uint8_t mask = 1 << sub;
    return (int) ((F->data[idx] & mask) > 0);
}


/* The methods below were much slower, so we don't use them :) */
#if 0
int bitfield_getB(bitfield_t * F, size_t N)
{
    assert(F != NULL);
    assert(F->data != NULL);
    assert(N < F->N);

    size_t idx = N/8;
    size_t sub = N-idx*8;
    int v = 0;

    switch(sub)
    {
    case 0:
        // binary constants are a C2X feature or GCC extension
        v = F->data[idx] & 0b00000001;
        break;
    case 1:
        v = F->data[idx] & 0b00000010;
        break;
    case 2:
        v = F->data[idx] & 0b00000100;
        break;
    case 3:
        v = F->data[idx] & 0b00001000;
        break;
    case 4:
        v = F->data[idx] & 0b00010000;
        break;
    case 5:
        v = F->data[idx] & 0b00100000;
        break;
    case 6:
        v = F->data[idx] & 0b01000000;
        break;
    case 7:
        v = F->data[idx] & 0b10000000;
        break;
    }

    if(v > 0)
    {
        return 1;
    }
    return 0;
}

void
bitfield_set_falseB(bitfield_t * F, size_t N)
{
    assert(F != NULL);
    assert(F->data != NULL);
    assert(N < F->N);

    size_t idx = N/8;
    size_t sub = N-idx*8;
    //printf("N=%zu, idx=%zu, sub=%zu\n", N, idx, sub);
    //printf("%u ", F->data[idx]);
    switch(sub)
    {
    case 0:
        // binary constants are a C2X feature or GCC extension
        F->data[idx] = F->data[idx] & 0b11111110;
        break;
    case 1:
        F->data[idx] = F->data[idx] & 0b11111101;
        break;
    case 2:
        F->data[idx] = F->data[idx] & 0b11111011;
        break;
    case 3:
        F->data[idx] = F->data[idx] & 0b11110111;
        break;
    case 4:
        F->data[idx] = F->data[idx] & 0b11101111;
        break;
    case 5:
        F->data[idx] = F->data[idx] & 0b11011111;
        break;
    case 6:
        F->data[idx] = F->data[idx] & 0b10111111;
        break;
    case 7:
        F->data[idx] = F->data[idx] & 0b01111111;
        break;
    }

    return;
}

void
bitfield_set_trueB(bitfield_t * F, size_t N)
{
    assert(F != NULL);
    assert(F->data != NULL);
    assert(N < F->N);

    size_t idx = N/8;
    size_t sub = N-idx*8;
    switch(sub)
    {
    case 0:
        // binary constants are a C2X feature or GCC extension
        F->data[idx] = F->data[idx] | 0b00000001;
        break;
    case 1:
        F->data[idx] = F->data[idx] | 0b00000010;
        break;
    case 2:
        F->data[idx] = F->data[idx] | 0b00000100;
        break;
    case 3:
        F->data[idx] = F->data[idx] | 0b00001000;
        break;
    case 4:
        F->data[idx] = F->data[idx] | 0b00010000;
        break;
    case 5:
        F->data[idx] = F->data[idx] | 0b00100000;
        break;
    case 6:
        F->data[idx] = F->data[idx] | 0b01000000;
        break;
    case 7:
        F->data[idx] = F->data[idx] | 0b10000000;
        break;
    }
}
#endif

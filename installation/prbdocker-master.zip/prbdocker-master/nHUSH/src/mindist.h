#ifndef mindist_h__
#define mindist_h__

#define _GNU_SOURCE

#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <math.h>
#include <malloc.h> // memalign
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifndef __APPLE__
#include <sys/mman.h> // madvise
#include <sys/types.h>
#include <sys/sysinfo.h>
#endif
#include <time.h>
#include <unistd.h>
#include <omp.h>

#include "util.h"
#include "comb.h"
#include "pbar.h"
#include "readfa.h"
#include "atcg.h"
#include "eq_classes.h"
#include "mindist_gen_mask_lua.h"

#ifndef ANSI_COLOR_RED
#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_YELLOW  "\x1b[33m"
#define ANSI_COLOR_BLUE    "\x1b[34m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_CYAN    "\x1b[36m"
#define ANSI_COLOR_RESET   "\x1b[0m"
#endif

// TODO:
// Programatically from
// sysconf (_SC_LEVEL1_DCACHE_LINESIZE)
// or at compile time with
// $ getconf LEVEL1_DCACHE_LINESIZE
// Shouldn't be a problem if it is set to high
#define CACHE_LINESIZE 64

/* The type to store reference to the genome,
 * has to be uint64_t if the genome is larger than 2^32
 * Might be possible in a future version
 * WARNING: This feature is not completed.
 * #define PROPROBE64
 */
#ifdef PROPROBE64
#define uintG_t uint64_t
#else
#define uintG_t uint32_t
#endif

#define MODE_DISCARD 1
#define MODE_FULL 0
#define MODE_PROBB 2

#define QUERY_GENOME 2 /* Scan genome vs itself */
#define QUERY_EXTERNAL 3 /* Scan query sequences vs genome */

/* Shared between all threads, no changes
   can be done in a threaded setting. */
typedef struct { /* conf_t */

    /* Reference genome */
    char * fname;
    uint8_t * G; /* buffer for the genome */
    size_t nG; /* genome length */
    size_t nseq; /* number of sequences */
    fasta_records_t * G_records;

    /* Optional list of query sequences */
    char * qfname;
    uint8_t * Q; /* Genomic data for the query sequences */
    size_t nseq_query; /* Number of sequences to query */
    int skip_first_perfect; /* Don't care about the first perfect match */

    /* Discard/don't investigate further
     * sequences where dhamming <= d_discard */
    int d_discard;
    int mode; /* MODE_DISCARD or MODE_FULL */
    int query_mode; /* QUERY_GENOME or QUERY_EXTERNAL */

    /* List of sequences to use in the hash tables.
     * should be one representative per equivalence class
     * both ulist and multiplicity is read from the eqc file generated
     * by nhush eq-classes
     */
    uint8_t * ulist;

    uint32_t * multiplicity;
    double min_pb; // Minimal pb of use ...
    char * fasta_out;

    /* accumulated probability of binding for each query sequence
    *  */
    double * abp;
    /* Sequences having an abp above this are not investigated any further */
    double abp_max;

    size_t h; /* hash length, max 16, updated along the way */
    size_t nbuckets; /* Conseqence of h */
    size_t L; /* sequence length, constant once set */

    int verbose;
    int ask; /* ask to continue in some places */

    char * outname; /*  for writing distances */
    char * fname_embraced; /* For exporting embraced sequences */

    char * fname_log;
    FILE * log;

    char * fname_comb;
    comb_t * comb;

    int n_rounds;
    /* Run until all sequences with mismatches <= until_mm are found */
    int until_mm;

    int nthreads;
    int srand; /* call srand(time(NULL))? */

    int dump_bin_sizes;
/* Masking  */
    uint8_t * genome_mask; // binary
    char * genome_mask_script; // Name of lua script
    uint8_t * query_mask;
    char * query_mask_script;
} conf_t;

typedef struct {
    uint32_t seq_id;
    uint32_t target_id;
    double pb;
} match_record_t;


conf_t * conf_new();
void conf_free(conf_t ** conf);
void conf_show(FILE *, conf_t * conf);

/* Generate binary mask of length h where h
   elements are set to 1. This piece of code
   deserves attention. Knowing the history of
   previous hash filters it should be possible
   to give bounds on what is filtered out and calculate
   probabilities for mismatches of certain radii to
   be undetected etc. Also it might be possible to
   device optimal strategies using the Pigeonhole principle */
static uint8_t *  gen_hash_filter(size_t L, size_t h);
// For debugging, first h set to 1
uint8_t * gen_hash_filter_debug(size_t L, size_t h);

/* Generate a comb from a mask
*  For example, if f = [0 1 0 1 1 1] (L=6, h=4)
*  then it returns
*  [0 64 0 16 4 1 ]
*  We could have reversed the weights, starting from 1 ...
*/
uint32_t * chash_gen_comb(const uint8_t * f, size_t L, int h);


/* Generate random genome with 0,1,2,3 */
uint8_t * genome_random(size_t genome_size);

/* Combed hash, S: sequence, C: weights
 * I.e. C is a permutation of [1, 4, 16, ... 4^h, 0, 0, 0, ...] */
uint32_t chash(const uint8_t * SEQ, const uint32_t * COMB, size_t LENGTH);


uintG_t * chash_hash_genome(const uint8_t * genome, const size_t genome_size,
                             const uintG_t * hash_comb, const size_t L,
                             size_t *nchashes);

/* Count number of elements per bucket */
uintG_t * get_bucket_sizes(conf_t *,
                           const uint32_t * restrict chashes,
                           size_t nchashes);

/* Integrate B so that B[i] says where bucket i starts */
void cumsum_inplace(uintG_t * B, size_t n);


void nfree(void * p);

void nhush(conf_t * conf, uint8_t * mindist);


void comb_write(conf_t * conf);

/* Write uint8_t data to disk */
int write_uint8(char * fname, uint8_t * D, size_t N);

// Load existing or create new
uint8_t * mindist_get(conf_t * conf);
int mindist_write(conf_t * conf, uint8_t * mindist);

/* list of sequences to Use, i.e. still consider */
/* Create new ulist */
void ulist_init_ones(conf_t * conf);

/* load ulist from disk */
int ulist_get(conf_t * conf);
/* write ulist to disk */
int ulist_write(conf_t * conf);

/* Print some stats and return the number of embraced sequences */
size_t showstats(const conf_t * conf, const uint8_t * mindist);

/* Update mindist[kk] by querying _seq against the genome
 Can only scan in one direction at a time, so call first
 with reverse_complement = 0 and then again, set to 1
*/
void query_seq_bucket(conf_t * conf,
                      const uint8_t * _seq, uint32_t seq_id,
               uint8_t * buffer, // will be changed
               const uint32_t * restrict hash_comb,
               const uint32_t * restrict B,
               const uint32_t * restrict B_genome,
               uint8_t * mindist,
               const size_t kk,
                      const int reverse_complement,
    FILE * pb_result_file);



/* Asserts also with DNDEBUG */
#define xassert(a) _xassert(a, __LINE__, __FILE__)
void _xassert(int t, int line, char * file);


typedef struct {
    conf_t * conf;
    uint8_t * mindist;
    uint32_t * hash_comb;
    uintG_t * B;
    uintG_t * B_genome;
    size_t thread;
    char pad_[16];
} q_threaddata_t;

typedef struct {
    int thread;
    conf_t * conf;
    char pad_[64-16];
} filter_matches_t;

void query_genome_threads(conf_t * conf,
                          uint8_t * mindist, uint32_t * hash_comb,
                          uintG_t * B, uintG_t * B_genome);

/* Query sequences thread:nthreads:nseq */
void query_genome_thread(conf_t * conf,
                         uint8_t * mindist, uint32_t * hash_comb,
                         uintG_t * B, uintG_t * B_genome,
                         size_t thread);

void * query_genome_pthread(void * threaddata);

void hash_filter_fprint(FILE *, const uint8_t * v, int n);

/* Print time, message */
void print_time(FILE * f, char * msg);

int nhush_mindist(int argc, char ** argv);

#endif

#include "find_abundant.h"

static void
abd_usage()
{
    printf("Usage: \n");
    printf("nhush find-abundant [OPTIONS]\n");
    printf("\n");
    printf("Required arguments:\n");
    printf("--file genome.fa\n\t specify fasta file to read\n");
    printf("--length seq_len\n\t specify the sequence length of interest\n");
    printf("--threshold t\n\t"
           "min number of copies before a sequence is printed out\n");
    printf("--out file.fa\n\t"
           "specify a file to write to\n");
    printf("\n");
    return;
}


static abd_conf_t *
abd_conf_new(int argc, char ** argv)
{

    struct option longopts[] = {
        { "file",         required_argument, NULL,   'F' },
        { "length",       required_argument, NULL,   'L' },
        { "out",          required_argument, NULL,   'O' },
        { "threshold",    required_argument, NULL,   'T' },
        { "verbose",      required_argument, NULL,   'V' },
        { NULL,           0,                 NULL,   0   }
    };


    abd_conf_t * conf = calloc(1, sizeof(abd_conf_t));
    conf->verbose = 1;

    int ch;
    while((ch = getopt_long(argc, argv,
                            "F:L:O:T:V:",
                            longopts, NULL)) != -1)
    {
        switch(ch)
        {
        case 'F':
            conf->fname = strdup(optarg);
            break;
        case 'L':
            conf->seq_len = atoi(optarg);
            break;
        case 'O':
            conf->oname = strdup(optarg);
            break;
        case 'T':
            conf->threshold = atoi(optarg);
            break;
        case 'V':
            conf->verbose = atoi(optarg);
            break;
        }

    }

    if(conf->fname == NULL)
    {
        fprintf(stderr, "--file not specified\n");
        goto fail;
    }

    if(conf->oname == NULL)
    {
        fprintf(stderr, "--out not specified\n");
        goto fail;
    }

    if(conf->seq_len == 0)
    {
        fprintf(stderr, "--length not specified\n");
        goto fail;
    }

    if(conf->threshold <= 0)
    {
        fprintf(stderr, "--threshold not specified or invalid\n");
        goto fail;
    }


    {
        FILE * fid = fopen(conf->oname, "r");
        if(fid != NULL)
        {
            fprintf(stderr, "%s already exists\n", conf->oname);
            exit(EXIT_FAILURE);
        }
    }

    conf->logname = malloc(strlen(conf->oname) + 16);
    sprintf(conf->logname, "%s.log.txt", conf->oname);

    conf->logfile = fopen(conf->logname, "w");
    if(conf->logfile == NULL)
    {
        fprintf(stderr, "Unable to open %s for writing\n", conf->logname);
    }

    conf->outfile = fopen(conf->oname, "w");
    if(conf->outfile == NULL)
    {
        fprintf(stderr, "Unable to open %s for writing\n", conf->oname);
        exit(EXIT_FAILURE);
    }

    return conf;

    fail:
    abd_usage();
    exit(EXIT_FAILURE);
}


static void
abd_conf_free(abd_conf_t * conf)
{
    fclose(conf->logfile);
    fclose(conf->outfile);
    assert(conf != NULL);
    free(conf->fname);
    free(conf);
}

typedef struct {
    size_t L; /* String length */
    uint8_t * G; /* Pointer to genome */
} seqcmp_t;

static int
cmp_seq(const void * _s1, const void *_s2, void * _d)
{
    uint32_t * s1 = (uint32_t *) _s1;
    uint32_t * s2 = (uint32_t *) _s2;
    seqcmp_t * d = (seqcmp_t*) _d;
    uint8_t * G = (uint8_t *) d->G;
    return memcmp(G+ *s1, G+ *s2, d->L);
}

static void
abd_conf_show(FILE * fid, abd_conf_t * conf)
{
    fprintf(fid, "Reading genome from %s\n", conf->fname);
    fprintf(fid, "Will write to %s\n", conf->oname);
    fprintf(fid, "Sequence length: %zu\n", conf->seq_len);
    fprintf(fid, "Threshold:       %zu\n", conf->threshold);
    fprintf(fid, "Verbosity level: %d\n", conf->verbose);
}

int
find_abundant(int argc, char ** argv)
{
    abd_conf_t * conf = abd_conf_new(argc, argv);

    if(conf->verbose > 1)
    {
        abd_conf_show(stdout, conf);
    }

    abd_conf_show(conf->logfile, conf);


    conf->G = readfa(conf->fname, &conf->nG, &conf->G_records);
    if(conf->G == NULL)
    {
        fprintf(stderr, "Something went wrong when reading %s\n", conf->fname);
        fprintf(stderr, "Unable to continue\n");
        exit(EXIT_FAILURE);
    }

    /* Extract pointers to sequences */
    size_t nseq_alloc = conf->nG;

    uint32_t * GP = calloc(nseq_alloc, sizeof(uint32_t));

    size_t writepos = 0;
    for(size_t kk = 0; kk < conf->nG - conf->seq_len; kk++)
    {
        /* TODO: handle boundaries and strange symbols */
        GP[writepos++] = kk;
    }

    size_t nseq = writepos;

    /* Sort sequences */
    seqcmp_t seqcmp;
    seqcmp.L = conf->seq_len;
    seqcmp.G = conf->G;

    printf("Sorting\n");
    qsort_r(GP, nseq,
            sizeof(uint32_t),
            cmp_seq, (void*) &seqcmp);


    printf("Identifying unique and writing to %s\n", conf->oname);
    /* Identify repeating
       and put into heap ... or similar
     */
    size_t neq = 0;
    char * last_seq = NULL;
    char * seq = (char*) conf->G + GP[0];

    for(size_t kk = 1; kk<nseq; kk++)
    {
        last_seq = seq;
        seq = (char*) conf->G + GP[kk];
        if(memcmp(seq, last_seq, conf->seq_len) == 0)
        {
            neq++;
        } else {
            /* how many neq ? */
            if(neq >= conf->threshold)
            {
                fprintf(conf->outfile, "> %zu\n", neq);
                fprint_seq(conf->outfile, (uint8_t*) last_seq, conf->seq_len);
                fprintf(conf->outfile, "\n");
            }

            neq = 0;
        }
    }


    /* Output to stdout */
    // TODO pop heap / sort and read from list

    abd_conf_free(conf);

    return EXIT_SUCCESS;
}

#ifndef __nhush_version_h__
#define __nhush_version_h__

#define NHUSH_VERSION_MAJOR "0"
#define NHUSH_VERSION_MINOR "1"
#define NHUSH_VERSION_PATCH "0"
#define NHUSH_VERSION NHUSH_VERSION_MAJOR "." \
    NHUSH_VERSION_MINOR "." \
    NHUSH_VERSION_PATCH

#endif

#ifndef eq_classes_h_
#define eq_classes_h_

#define _GNU_SOURCE
#include <stdlib.h>
#include <getopt.h>

#include "util.h"
#include "readfa.h"
#include "pbar.h"
#include "bitfield.h"


typedef struct{
    char * fname; /* Input name */
    char * oname; /* Output name */
    char * eqc_name; /* Binary file name */
    char * logname;

    FILE * outfile;
    FILE * logfile;

    int export;
    char * export_name;
    size_t export_th_low;
    size_t export_th_high;

    uint8_t * G;
    /* A "binary" mask used in some situations to filter
    * things to use (1) or discard (0)
    */
    uint8_t * genome_selection;

    size_t nG; /* genome length */
    size_t nseq; /* number of sequences */
    size_t seq_len;
    size_t threshold; /* Show sequences with this number of repeats or more */
    int verbose;
    int overwrite;
    fasta_records_t * G_records;
    int interactive;
}
eqc_conf_t;

typedef struct {
    uint32_t class_id;
    uint32_t class_multiplicity;
} seq_info_t;


eqc_conf_t *
eqc_conf_new(int argc, char ** argv);
void
eqc_conf_free(eqc_conf_t * conf);

/* Read into array, set number of items in *N */
seq_info_t *
read_eqc(const char * fname, size_t *N);

/* Generate a binary array where there is one
 * element per equivalence class set to 1,
 * remaining set to 0.
 * output/input size is N */

uint8_t *
eqc_gen_ulist(const seq_info_t * eqc, size_t N);

int
eq_classes(int argc, char ** argv);

#endif

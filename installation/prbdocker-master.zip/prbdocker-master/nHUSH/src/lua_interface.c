#include "lua_interface.h"

#define MAX_THREADS 1

// Reverse complement
static void
set_rc(uint8_t * r, const uint8_t * f, const size_t L)
{
    for(size_t k = 0; k < L; k++)
    {
        r[L-k-1] = 3-f[k];
    }
    return;
}


typedef struct {
    uint8_t * G;
    uint32_t L;
    uint8_t * buff;
} arg_t;


static int
rcmpfun(const void * _A, const void * _B, void * _arg)
{

    uint32_t * A = (uint32_t*) _A;
    uint32_t * B = (uint32_t*) _B;

    arg_t * arg = (arg_t*) _arg;
    const size_t L = arg->L;
    uint8_t * s1 = arg->G + *A;
    uint8_t * s2 = arg->G + *B;

    //printf("pos %u vs %u L=%zu\n", *A, *B, L); fflush(stdout);


    /* Quick return without rcomp if possible */
    if(memcmp(s1, s2, L) == 0)
    { return 0; }

    /* Find a buffer region that this thread is allowed to use */
    int thread = omp_get_thread_num();
    if(thread < 0)
    {
        thread = 0;
    }
    //printf("thread = %d, MAX_THREADS = %d\n", thread, MAX_THREADS);
    assert(thread < MAX_THREADS);

    uint8_t * r1 = arg->buff + L*2*thread;
    uint8_t * r2 = arg->buff + L*2*thread + L;

    set_rc(r1, s1, L);
    set_rc(r2, s2, L);
    uint8_t * a = s1;
    uint8_t * b = s2;
    if(memcmp(r1, s1, L) < 0)
    {
        a = r1;
    }
    if(memcmp(r2, s2, L) < 0)
    {
        b = r2;
    }
    return memcmp(a, b, L);
}


int luacb_set_sequence_length(lua_State * L)
{
    lua_getglobal(L, "eq_classes_conf");
    eqc_conf_t * conf = (eqc_conf_t *) lua_touserdata(L, -1);

    const char * str = lua_tostring(L, 1);
    if(str == NULL)
    {
        printf("Missing argument\n");
        return 0;
    }

    conf->seq_len = atoi(str);
    printf("Sequence length set to %ld\n", conf->seq_len);
    return 0;
}

int luacb_load_mindist(lua_State * L)
{
    lua_getglobal(L, "eq_classes_conf");
    eqc_conf_t * conf = (eqc_conf_t *) lua_touserdata(L, -1);

    if(conf->G == NULL)
        {
            printf("No genome loaded\n");
            return 0;
        }

    if(conf->seq_len < 1)
    {
        printf("sequence length not set\n");
        return 0;
    }

    const char * mindist_file = lua_tostring(L, 1);
    if(mindist_file == NULL)
    {
        printf("No file provided\n");
        return 0;
    }
    int select_from = 1;
    int select_to = 254;

    const char * from_str = lua_tostring(L, 2);
    if(from_str != NULL)
    {
        select_from = atoi(from_str);
    }

    const char * to_str = lua_tostring(L, 2);
    if(to_str != NULL)
    {
        select_to = atoi(to_str);
    }

    printf("Will load %s\n", mindist_file);
    printf("Will select all positions where %d <= mindist <= %d\n",
           select_from, select_to);

    free(conf->genome_selection);

    FILE * fid = fopen(mindist_file, "r");
    if(fid == NULL)
    {
        printf("Failed to read %s\n", mindist_file);
        return 0;
    }
    conf->genome_selection = calloc(conf->nG, 1);
    assert(conf->genome_selection != NULL);
    size_t nexpected = conf->nG - conf->seq_len + 1;
    size_t nread = fread(conf->genome_selection, 1, nexpected, fid);
    fclose(fid);
    if(nread != nexpected)
    {
        fprintf(stderr, "Failed reading ... got %zu, expected %zu\n", nread, nexpected);
        fprintf(stderr, "I.e. genome size - sequence length + 1 (%zu + %zu -1)\n", conf->nG, conf->seq_len);
        return 0;
    }

    for(size_t kk = 0; kk < conf->nG; kk++)
    {
        if( (conf->genome_selection[kk] >= select_from) && (conf->genome_selection[kk] <= select_to))
        {
            conf->genome_selection[kk] = 1;
        } else {
            conf->genome_selection[kk] = 0;
        }
    }
    printf("mindist file loaded\n");
    return 0;
}

int luacb_load_genome(lua_State * L)
{
    lua_getglobal(L, "eq_classes_conf");
    eqc_conf_t * conf = (eqc_conf_t *) lua_touserdata(L, -1);

    const char * genome_file = lua_tostring(L, 1);
    if(genome_file == NULL)
    {
        printf("No file provided\n");
        return 0;
    }

    free(conf->fname);
    conf->fname = strdup(genome_file);

    printf("Loading %s ... ", genome_file);
    fflush(stdout);
    free(conf->G);

    conf->G = readfa(conf->fname, &conf->nG, &conf->G_records);
    if(conf->G == NULL)
    {
        printf("Failed to load %s\n", conf->fname);
    } else {
        printf("done\n");
    }
    return 0; // Number of results pushed
}

int luacb_show_genome_records(lua_State * L)
{
    lua_getglobal(L, "eq_classes_conf");
    eqc_conf_t * conf = (eqc_conf_t *) lua_touserdata(L, -1);
    if(conf->G == NULL)
    {
        printf("No genome loaded\n");
        return 0;
    }

    if(conf->G_records == NULL)
    {
        printf("No records loaded for %s\n", conf->fname);
    }

    fasta_records_show(conf->G_records, conf->G);


    return 0;
}

int luacb_find_selected_in_all_chr(lua_State * L);
int luacb_help(lua_State * L);
int luacb_select_region(lua_State * L);
int luacb_unselect_all(lua_State * L);
int luacb_test(lua_State * L);

typedef struct {
    char * command;
    char * args;
    int (*callback)(lua_State * L);
    char * help;
} lua_interface;

lua_interface interface[] = {
    {"load_genome", "file",
     luacb_load_genome,
     "load a fasta file specifed by its file name"},

    {"load_mindist", "file, min=1, max=254",
     luacb_load_mindist,
     "load mindist file as mask, any number [min, max] will be set selected."},

    {"show_genome_records", "",
     luacb_show_genome_records,
     "Show the records in the loaded fasta file"},

    {"unselect_all", "",
     luacb_unselect_all,
     "Mark all positions to be ignored"},

    {"select_region", "chr, start, end",
     luacb_select_region,
     "Select a range in a record to be used"},

    {"set_sequence_length", "L",
     luacb_set_sequence_length,
     "Define the sequence length of interest, L"},

    {"find_selected_in_n_chr", "n, outfile",
     luacb_find_selected_in_all_chr,
     "Find sequences in selected regions that are present in >= n chromosomes. Outfile is optional."},

    {"test", "variable", luacb_test, "just for testing"},

    {"dofile", "file", NULL, "load a script and run it (built in Lua function)"},

    {"help", "",
     luacb_help,
     "show the help message"},

    {NULL, NULL, NULL, NULL},
};

int luacb_test(lua_State * L)
{
    const char * first = lua_tostring(L, 1);
    printf("first=%s\n", first);
    lua_pushnil(L); return 1;
}

int luacb_help(lua_State * L)
{
    if(lua_isstring(L, 1))
    {
        const char * cmd = lua_tostring(L, 1);
        printf("No detailed help available for '%s'\n", cmd);
        return 0;
    }

    printf("Available commands:\n");
    for(int kk = 0; interface[kk].command != NULL; kk++)
    {
        printf("%s(%s)\n\t%s\n", interface[kk].command, interface[kk].args, interface[kk].help);
    }

    return 0;
}

int luacb_unselect_all(lua_State * L)
{
    lua_getglobal(L, "eq_classes_conf");
    eqc_conf_t * conf = (eqc_conf_t *) lua_touserdata(L, -1);
    assert(conf != NULL);
    if(conf->G == NULL)
    {
        printf("Please load a genome first\n");
        return 0;
    }
    free(conf->genome_selection);
    conf->genome_selection = calloc(conf->nG, 1);
    assert(conf->genome_selection != NULL);
    printf("All positions unselected\n");
    return 0;
}

int luacb_select_region(lua_State * L)
{
    lua_getglobal(L, "eq_classes_conf");
    eqc_conf_t * conf = (eqc_conf_t *) lua_touserdata(L, -1);
    assert(conf != NULL);
    if(conf->G == NULL)
    {
        printf("Please load a genome first\n");
        return 0;
    }
    if(conf->genome_selection == NULL)
    {
        printf("Please initiate a selection first (unselect_all)\n");
        return 0;
    }
    const char * record = lua_tostring(L, 1);
    if(record == NULL)
    {
        printf("chromosome/record specified\n");
        return 0;
    }

    const char * startpos_str = lua_tostring(L, 2);
    if(startpos_str == NULL)
    {
        printf("start position not specified\n");
        return 0;
    }

    const char * endpos_str = lua_tostring(L, 3);
    if(endpos_str == NULL)
    {
        printf("start position not specified\n");
        return 0;
    }

    long int startpos = atol(startpos_str);
    long int endpos = atol(endpos_str);

    if(startpos > endpos)
    {
        printf("The start position can not be after then end position\n");
        return 0;
    }

    if(startpos < 0)
    {
        printf("The start position has to be positive\n");
        return 0;
    }

    printf("Selecting %s [%ld -- %ld] \n", record, startpos, endpos);

    // Find ONE matching record or fail
    int match = -1;
    int nmatch = 0;
    for(size_t kk = 0; kk<conf->G_records->n; kk++)
    {
        if(strcasestr( conf->G_records->name[kk], record))
        {
            match = kk;
            nmatch++;
        }
    }

    if(nmatch < 1)
    {
        printf("Could not find any record that match '%s'\n", record);
        return 0;
    }

    if(nmatch > 1)
    {
        printf("Found %d matches for '%s', please be more specific!\n", nmatch, record);
        return 0;
    }

    printf("Matching record: '%s'\n", conf->G_records->name[match]);

    if((size_t) endpos >= conf->G_records->len[match])
    {
        printf("The end pos (%ld) >= the size of the chromosome (%ld)\n",
               endpos, conf->G_records->len[match]);
        return 0;
    }

    size_t global_first = conf->G_records->pos[match] + startpos;
    size_t global_end = global_first + endpos - startpos;
    printf("Will set pos [%zu, %zu] to 1\n", global_first, global_end);
    for(size_t kk = global_first; kk <= global_end; kk++)
    {
        conf->genome_selection[kk] = 1;
    }
    printf("done\n");
    return 0;
}

/* Convert global linear index to fasta record index. Slow for
 * anything large. Example usage: human genome where there are only a
 * few records */
int pos_to_chr_id(eqc_conf_t * conf, uint32_t idx)
{
    for(size_t kk = 0; kk < conf->G_records->n; kk++)
    {
        if(idx >= conf->G_records->pos[kk])
        {
            if(idx - conf->G_records->pos[kk] < conf->G_records->len[kk])
            {
                return kk;
            }
        }
    }
    return -1;
}

int luacb_find_selected_in_all_chr(lua_State * L)
{
    lua_getglobal(L, "eq_classes_conf");
    eqc_conf_t * conf = (eqc_conf_t *) lua_touserdata(L, -1);
    assert(conf != NULL);
    if(conf->G == NULL)
    {
        printf("Please load a genome first\n");
        return 0;
    }

    if(conf->genome_selection == NULL)
    {
        printf("No selection performed\n");
        return 0;
    }

    if(!conf->seq_len)
    {
        printf("Please specify the sequence length first\n");
        return 0;
    }

    int min_nchr = 24;
    if( lua_isnumber(L, 1) )
    {
        min_nchr = lua_tonumber(L, 1);
    }
    printf("Looking for sequences in at least %d chromosomes\n", min_nchr);

    FILE * fid = stdout;
    if( lua_isstring(L,2) )
    {
        const char * outfile = lua_tostring(L,2);
        if(outfile != NULL)
        {
            printf("Will write to %s\n", outfile);
            fid = fopen(outfile, "w");
            if(fid == NULL)
            {
                printf("Unable to open %s\n", outfile);
                return 0;
            }
        }
    }

    // gen a list of start positions
    size_t npos = 0;
    for(size_t kk = 0; kk + conf->seq_len < conf->nG; kk++)
    {
        npos+=conf->genome_selection[kk] > 0;
    }

    printf("npos = %zu\n", npos);

    if(conf->nG > UINT32_MAX)
    {
        printf("The reference genome can not be represented by 32-bit pointers\n");
        // TODO: move to an earlier position
        exit(EXIT_FAILURE);
    }

    uint32_t * selected_positions = calloc(npos+10, sizeof(uint32_t));
    assert(selected_positions != NULL);
    printf("Generating list of starting positions\n");
    {
        size_t writepos = 0;
        for(size_t kk = 0; kk + conf->seq_len < conf->nG; kk++)
        {
            if(conf->genome_selection[kk])
            {
                selected_positions[writepos++] = kk;
            }

        }
        assert(writepos == npos);
    }

    for(size_t kk = 0; kk<npos; kk++)
    {
        if(selected_positions[kk]+conf->seq_len >= conf->nG)
        {
            printf("Something is wrong with the start positions\n");
            assert(0);
        }
    }

    arg_t cs_arg;
    cs_arg.L = conf->seq_len;
    cs_arg.G = conf->G;
    assert(MAX_THREADS > 0);
    cs_arg.buff = (uint8_t *) malloc(MAX_THREADS*cs_arg.L*2);
    assert(cs_arg.buff != NULL);

    // sort the list of start positions by the rcmpfun function
    printf("Sorting start positions of %zu sequences of length %ld\n",
           npos, conf->seq_len);

    for(size_t kk = 0; kk<npos; kk++)
    {
        rcmpfun(selected_positions, selected_positions+kk, &cs_arg);
    }
    printf("With qsort ...\n");

    qsort_r(selected_positions, npos, sizeof(uint32_t),
            rcmpfun, &cs_arg);

    // Go through the list and for each class of sequences, see how
    // many chromosomes it falls into
    printf("Qsort done\n");

    uint32_t max_neq = 0;
    uint32_t first = 0;
    uint32_t n_individual = 0;
    uint8_t * chromosomes = calloc(32, 1);
    assert(chromosomes != NULL);

    for(size_t kk = 1; kk<npos; kk++)
    {
        if(rcmpfun( &selected_positions[first],
                    &selected_positions[kk],
                    &cs_arg) == 0)
        {
            n_individual++;

            // same as previous
        } else {
            int nchr = 0;
            for(int kk = 0; kk<24; kk++)
            {
                nchr += chromosomes[kk];
            }
            if(nchr >= min_nchr)
            {
                fprintf(fid, "nchr=%d ", nchr);
                fprint_seq(fid, conf->G + selected_positions[first], conf->seq_len);
                fprintf(fid, "\n");
            }
            memset(chromosomes, 0, 32);
            first = kk;
        }
        int chr = pos_to_chr_id(conf, selected_positions[kk]);
        if(chr > -1)
        {
            chromosomes[chr]=1;
        }
    }
    if(fid != stdout)
    {
        fclose(fid);
    }
    printf("Largest multiplicity: %u\n", max_neq);
    printf("n_individual: %u\n", n_individual);
    free(selected_positions);
    return 0;
}


/***
 *
 * Would be nice: tab completion for standard commands
 *
 * This started with the configuration settings of eq_classes. Should
 * eventually have its own set of relevant configs.
 */
int nhush_lua_repl(int argc, char ** argv)
{
    if(argc > 1)
    {
        printf("%s does not use any command line arguments\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    eqc_conf_t * conf = calloc(1, sizeof(eqc_conf_t));
    conf->verbose = 1;

    conf->logname = malloc(128);
    sprintf(conf->logname, "chromflock_interactive.log.txt");

    conf->logfile = fopen(conf->logname, "a");
    if(conf->logfile == NULL)
    {
        fprintf(stderr, "Unable to open %s for writing\n", conf->logname);
    }

    assert(conf != NULL);

    lua_State * L = luaL_newstate();
    luaL_checkversion(L);

    luaL_openlibs(L); // might not be needed, performance penalty?

    lua_pushlightuserdata(L, conf);
    lua_setglobal(L, "eq_classes_conf");

    printf("Welcome to nHUSH/eq_classes\n");
    printf("type `help` for a list of available commands\n\n");

    for(int kk = 0; interface[kk].command != NULL; kk++)
    {
        if(interface[kk].callback != NULL)
        {
            lua_register(L, interface[kk].command, interface[kk].callback);
        }
    }

    using_history();
    rl_bind_key('\t', rl_complete); // Enable file name completion

    /* Read-Eval-Print Loop (REPL) */
    char * cmd = NULL;
    while( (cmd = readline("HUSH> ")))
    {
        if (strncmp (cmd, "quit", 4) == 0) {
            free(cmd);
            break;
        }

        if (strcmp (cmd, "help") == 0) {
            if(luaL_dostring(L, "help()"))
            {
                printf("internal error %s : %d\n", __FILE__, __LINE__);
            }
            continue;
        }

        if( luaL_dostring(L, cmd) != LUA_OK)
        {
            printf("Error: '%s' is not defined, no such variable or function!\n",
                   cmd);
        }
        add_history(cmd);
        free(cmd);
    }

    lua_close(L);

    eqc_conf_free(conf);
    return EXIT_SUCCESS;
}

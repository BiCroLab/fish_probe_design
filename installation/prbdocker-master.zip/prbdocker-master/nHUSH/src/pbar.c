#include <assert.h>
#include <math.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include "pbar.h"

struct pbar {
    volatile size_t * current;
    const size_t * total;
    volatile int active;
    pthread_t thread;
    double time;
    size_t usleep;
};

static double
timespec_diff(struct timespec* end, struct timespec * start)
{
    double elapsed = (end->tv_sec - start->tv_sec);
    elapsed += (end->tv_nsec - start->tv_nsec) / 1000000000.0;
    return elapsed;
}

/* convert time (s) to a string and append the result to etastr
 * using tmpstr as a buffer */
static void
print_time(char * etastr, const double time0, char * tmpstr)
{
    double time = round(time0);
    /* casting rounds to lower */

    int hours = (int) (time / 3600.0);
    time -= 3600.0*hours;
    int minutes =  (int) floor(time / 60.0) % 60;
    time -= 60.0*minutes;
    int seconds = (int) round(time);

    if(time0 >= 3600)
    {
        sprintf(tmpstr, " %d h", hours);
        strcat(etastr, tmpstr);
    }
    if(minutes > 0 && hours < 5)
    {
        sprintf(tmpstr, " %d min", minutes);
        strcat(etastr, tmpstr);
    }

    if(time0 < 180)
    {
        sprintf(tmpstr, " %d s", seconds);
        strcat(etastr, tmpstr);
    }
    return;
}

static void*
pbar_thread(void *arg)
{
    pbar_t * p = (pbar_t * ) arg;
    int eta_delay = 5; /* show the eta after eta_delay seconds */

    struct timespec tstart, tnow;
    clock_gettime(CLOCK_REALTIME, &tstart);
    p->time = 0;

    size_t last = 0;
    double eta = 0;
    size_t ticks = 0;

    size_t lastlen = 0; // Length of previous message
    size_t maxlen = 0;
    char * etastr = malloc(200);
    etastr[0] = '\0';
    char * outstr = malloc(200);
    outstr[0] = '\0';
    char * tmpstr = malloc(256);
    tmpstr[0] = '\0';

    while(p->active)
    {
        ticks++;
        /* Get current status of number of jobs completed and the
           total number of jobs */
        size_t current = *p->current+1;
        size_t total = *p->total+1;

        /* Update total time */
        clock_gettime(CLOCK_REALTIME, &tnow);
        double t = timespec_diff(&tnow, &tstart);
        p->time = t;

        /* Update ETA at most once per second */
        if(current - last > 1.0)
        {
            double q = (double) current / (double) total;
            eta = t * (1.0 - q) / q;
        }

        /* Prepare the output, the progress is updated
         * more often than the ETA */
        sprintf(etastr, " ");
        if(t > eta_delay)
        {
            if(current <= total)
            {
                sprintf(etastr, ", eta");
                print_time(etastr, eta, tmpstr);
            } else {
                sprintf(etastr, ", ?");
            }
        }
        sprintf(outstr, "%zu / %zu, %.2f%%",
                current, total, 100*((double) current / (double) total));

        /* Make sure to overwrite any previous characters on the output line */
        size_t len = strlen(outstr)+strlen(etastr)+2;
        if(len > maxlen)
            maxlen = len;
        while(strlen(outstr)+strlen(etastr) < lastlen)
        {
            strcat(etastr, " ");
        }
        lastlen = len;

        /* Display */
        printf("\r  %s%s\r", outstr, etastr);
        fflush(stdout);
        usleep(p->usleep);
    }

    /* Last message when active != 1 */

    if(*p->current == *p->total)
    {
        sprintf(outstr, "\r%zu sequences took",
                *p->total+1);
    } else {
        sprintf(outstr, "\r%zu/%zu sequences took",
                *p->current, *p->total+1);
    }
    print_time(outstr, p->time, tmpstr);

    /* ' '-pad to overwrite old output */
    while(strlen(outstr) < maxlen+2)
    {
        strcat(outstr, " ");
    }
    printf("%s\n", outstr);

    /* Done */
    free(etastr);
    free(outstr);
    free(tmpstr);
    return NULL;
}

int
pbar_start(pbar_t * p)
{
    p->active = 1;
    return pthread_create(&p->thread, NULL, &pbar_thread, p);
}

int
pbar_stop(pbar_t * p)
{
    assert(p!=NULL);
    if(p->active)
    {
        p->active = 0;
        return pthread_join(p->thread, NULL);
    }
    return EXIT_SUCCESS;
}

pbar_t*
pbar_new(const size_t * total, volatile size_t * current)
{
    pbar_t * p = calloc(1, sizeof(pbar_t));
    p->current = current;
    p->total = total;
    p->usleep = 500000; /* microseconds */
    return p;
}

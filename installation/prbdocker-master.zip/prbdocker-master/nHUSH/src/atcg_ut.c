#include "atcg.h"

int main()
{
    return atcg_ut();
}

function bino_scheme()

N = 12390;
L = 20;
h = 14;
C = zeros(N, L);
H = [ones(1,h), zeros(1,L-h)];

fprintf('Random test data with N=%d, L=%d, h=%d\n', N, L, h);
for kk = 1:N
    C(kk,:) = H(randperm(L));
end

mm = 0;
while 1
    fprintf('Testing if %d mismatches will be captured\n', mm)
    if check_c(C, mm)
        mm = mm + 1;
    else
        fprintf("no\n");
        break;
    end    
end
end

function B = bino_next(B, N)
B
    n = numel(B);
    if n == 1
        B = B+1;
    end
    pos = n;
    if(B(n) == N)        
        pos = pos -1;
        while(B(pos) < pos)
            pos = pos+1;
        end
    end
    B(pos) = B(pos)+1;
    for kk = pos+1:n        
        B(kk) = B(kk-1) + 1;
    end
end

function B = binos(N, k) 
k = 2;
B = zeros(nchoosek(N,k), k); 
B(1, :) = 1:k;
for kk = 2:size(B,1)
    B(kk, :) = bino_next(B(kk-1, :), N);
end

end

function B = c_to_binos(C, mm)

B = [];
for kk = 1:size(C,1)
    pos = find(C(kk,:) == 0);
    b = nchoosek(pos, mm);
    B = cat(1, B, b);
end

end

function y = check_c(C, mm)
if mm == 0
    if size(C,1) > 0
        y = 1;
    else
        y = 0;
    end
    return;
end

P = nchoosek(1:size(C,2), mm);
%P = binos(size(C, 2), mm);
B = c_to_binos(C, mm);

if sum(ismember(P, B, 'rows')) == size(P,1)    
    y = 1;
else    
    fprintf('Coverage: %d / %d\n', sum(ismember(P, B, 'rows')), size(P, 1));
    y = 0;
end

end
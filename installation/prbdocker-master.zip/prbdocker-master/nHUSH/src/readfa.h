#pragma once

/* For reading fasta-files, buddy with atcg.h
 */

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include "atcg.h"

/* Structure for the names of the structures in the
 * the fasta file */

/* Defined in atcg.h */
struct sym_table;
typedef struct sym_table sym_table_t;

typedef struct _fasta_records_t {
    /* Array of all record names */
    char ** name;
    /* Length of each record */
    size_t * len;
    /* Start position in the genome */
    size_t * pos;
    /* Number of records */
    size_t n;
    /* Number of records allocated */
    size_t nalloc;
} fasta_records_t;

typedef struct {
    /* Genomic data converted to numeric representation */
    uint8_t * data;
    /* Number of basepairs */
    size_t data_size;
    fasta_records_t * records;
    // Possibly we should copy the symbol table here
    // sym_table_t * sym_table;
} fasta_data_t;


/** @brief Read a fasta file.
 *
 * @param fname fasta file to read.
 * @param fourbase If set all symbols are converted to
 * ACGT.
 * @param T The sym_table_t is defined in atcg.h and contains a Lookup
 * table for Nucleic Acid Codes. The non-unique are mapped to a single
 * alternative For example N is mapped to A but could be mapped to T,
 * C or G. M is mapped to A (or could be to C) ...  Unknown letters
 * are left untouched
 * @param verbose The verbosity level.
 * @return A fasta_data_t object.
 */

fasta_data_t * readfa_sym(const char * fname,
                          const sym_table_t * T,
                          int fourbase,
                          int verbose);


/** @brief Simpler interface to readfa_sym
 *
 *  with no substitution
 *   Read fa and return *gsize bytes.
 *  fr will be set.
 * @param fname fasta file to read.
 * @param[out] gsize the size of the genome, i.e. number of basepairs
*/
uint8_t * readfa(const char * fname,
                 size_t * gsize, fasta_records_t ** fr);


/* Print the content of fr in tab delimited format.
 * suitable for direct writing to a tsv file */
void fasta_records_fprint(FILE * fid, fasta_records_t * fr);

/* Just print the fasta records to stdout */
void fasta_records_show(fasta_records_t * fr, uint8_t * G);

/* free */
void fasta_records_free(fasta_records_t ** _fr);

void fasta_data_free(fasta_data_t * fa);


/** Command line interface for unit tests */
void
readfa_ut(int argc, char ** argv);

// TODO:


// 80 char wide
// readfa_write(fasta_data_t * )

// rename to fasta_io or similar

% NHUSH-FASPLIT(1) nhush-fasplit ABCDE
% Erik Wernersson
% January 2022

# NAME
nhush-fasplit -- split fa sequences into sub sequences

# SYNOPSIS
**nhush-fasplit** [*OPTIONS*]

# DESCRIPTION
**nhush-fasplit** extracts sequences from fasta files and writes out sub sequences.
If the input sequences are of length L and the sub string length is l, then
**nhush-fasplit** will write out L-l+1 sub sequences per input sequences.

**nhush-fasplit** is intended to be used together with **nhush**.

# OPTIONS

**-f file.fa**, **--file file.fa**
: specify the input fasta file

**-h**, **--help**
: Display a basic help

**--l**, **--sub-length**
: Set the length of the sub strings

**-o file.fa**, **--out file.fa**
: Set the output file.

**--L**, **--length**
: set the string length.

# EXAMPLES
**nhush-fasplit -L 80 -l 21 --file probes.fa**
: split all sequences of length 80 in probes.fa into 21-mers. By default
the output file will be called probes.fa.21mers

# SEE ALSO
nhush nhush-bfm and nhush-comb

# WEB PAGE
[https://github.com/elgw/nHUSH](https://github.com/elgw/nHUSH)

# REPORTING BUGS
Please report bugs at
[https://github.com/elgw/nHUSH/issues/](https://github.com/elgw/nHUSH/issues/)

# COPYRIGHT
Copyright  ©  2022 Erik Wernersson.  License GPLv3+: GNU GPL version 3 or
later <https://gnu.org/licenses/gpl.html>.
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.

# Example usage
This folder contains a few small test scripts to show how nHUSH can be
used. Please run

``` shell
./gen-testdata.sh
```
to generate some test data to play with.


## Genome Wide
See the bash script `run-genome-wide.sh` for a concrete example.

The general procedure consists of:
- Get a copy of a genome of interest
- Merge all fasta files to one (`cat *.fa > all.fa`)
- Determine how long sequences you are interested in (the _-L_ parameter)
- Set the number of threads to use (_-T_)
- Provide a stop criterion (`--until n`) to make nHUSH
stop when all alignments with a Hamming distance <= n
are found.
- Self-matches are ignored so the  `--sfp` option is not needed (ignored).
- Possibly specify `--hash h` to set the initial hash length.

### Output
For the example, the following files are generated:

The output is split into several files

- `commands` shows all commands that were run by the example script

- `genome.fa.nh.L26.log.txt`

A log, containing the command line and progress for nHUSH.

- `genome.fa.bh.L26.mindist.uint8`

Here comes the real output, encoded as unsigned 8-bit unsigned integers.

- `genome.fa.out.L26.ulist`

For book keeping. Flags sequences (by the start positions) to be indexed or
not. Initially nHUSH might scan for duplicate sequences and exclude them for
further indexing.

- `genome.fa.nh.L26.comb`

For book keeping/resuming aborted jobs. The combs/hash functions used so far.
The next hash function can be deducted from this. Not expected to be used
except for debugging, can be inspected with
```
nhush-comb --show genome.fa.nh.L26.comb
```

## Sequences of interest
See the bash script `run-sequences-of-interest`
for a concrete example.

- Get a copy of a genome of interest
- Merge all fasta files to one (`cat *.fa > all.fa`)
- Get sequences of interest and place in a separate file (to be
handed to nHUSH with the `--external file.fa` argument).
- Determine how long sequences you are interested in (the _-L_ parameter)
- Set the number of threads to use (_-T_)
- Provide a stop criterion (`--until n`) to make nHUSH
stop when all alignments with a Hamming distance <= n
are found.
- Use `--sfp` option to skip the first perfect match. If the
sequences of exist on the reference genome we expect one perfect
match, i.e., the self match.
- Possibly specify `--hash h` to set the initial hash length.

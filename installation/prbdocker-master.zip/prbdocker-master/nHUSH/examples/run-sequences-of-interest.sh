#!/bin/bash
set -e

until=4
folder=sequences-of-interest
length=40
file=../genome.fa
qfile=query.fa

echo "This script demonstrates how to run nHUSH for sequences of interest"
echo ""
echo "Settings:"
echo "Folder to run in: ${folder}"
echo "Genome file: ${file}"
echo "Query file: ${qfile}"
echo "Sequence length: ${length}"
echo "Run until all matches <= ${until} are found"
echo "Expected run time: < 1 min"

confirm () {
    read -r -p "Are you sure? [y/N] " response
    response=${response,,}    # tolower
    if [[ "$response" =~ ^(yes|y)$ ]]
    then
        return 1
    else
        return 0
    fi
}

echo "This will delete the folder '${folder}' if it already exist"
if confirm == 0
then
    exit 0
fi

rm -rf ${folder}
mkdir ${folder}

echo "Entering '${folder}'"
cd ${folder}

echo "Making a link to ../${qfile}"
ln ../${qfile} ${qfile}

echo "---"
echo "Running nHUSH until everything with a match within a Hamming"
echo "distance of $until is found"
echo "---"

cmd="nhush --file ${file} --length ${length} --sfp --until ${until} --hash 6 --external ${qfile}"
echo $cmd >> commands
eval "$cmd"


echo "---"
echo "Dumping the result, left column: sequence, right column: shortest"
echo "Hamming to any location of the reference genome found so far"
echo "Since we used --until $until you can trust that values <= $unil"
echo "are exact."
echo "For values, v > $until the true value can fall anywhere"
echo "in [$until+1, v]"
echo "A high value is expected for the first sequence"
echo "since we used --sfp, i.e. skip first perfect, and that sequence"
echo "exists on the reference genome"
echo "---"

cmd="nhush dump-mindist ${qfile} ${qfile}.nh.L${length}.mindist.uint8 ${length} > result.tsv"
echo "${cmd}" >> commands
eval "${cmd}"

echo "---"
echo "Showing sequences that has a Hamming distance <= ${until}"
echo "---"

cmd="awk '{if (\$2 <= ${until} ){ print \$0 }}' result.tsv"
echo "${cmd}" >> commands
eval "${cmd}"

echo "---"
echo "Done"
echo "See the folder ${folder} for more details"

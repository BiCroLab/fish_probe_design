## Development status

For the latest bugs see [issue tracking](https://github.com/elgw/nHUSH/issues).

## Todo
- [ ] By translating the comb several scans could be run without
re-indexing/sorting the reference genome. This is done already
in HUSH.
- [ ] Paralellize **place_in_buckets**. Should be possible to
processing chunk per thread and then merging the results
afterwards.
- [ ] Use something smarter for the initial hash length (if
not provided as an argument).
- [ ] A general cleanup of the code base wouldn't hurt.


## Maybe
- [ ] Create project file/folder where md5 sums etc are stored.
Also only write output files to that folder.
- [ ] Compile separate binaries for 32-bit indexing and 64-bit
indexing (i.e.,
have a special version for large genomes).
- [ ] read multiple fa-files?
- [ ] Use _ulist_ to filter out boundaries between chromosomes, i.e., before
each `> chr ...` _L-1_ elements should be excluded.
- [ ] Can we create an optimal sequence of combs? Probably not without
brute force. This is similar or equivalent to generating _constant
weight codes_
- [ ] Get number of available cores on mac, i.e. set conf->nthreads
- [ ] get peek memory on mac
- [ ] Could it be rewritten to look for length of continuous
perfect off-target matches? It won't be compatible with the current
comb strategy so it might be better included as a separate (post)
filter.
- [ ] Same as above, but for binding energy ...

- [ ] Support for querying specific regions or every Nth sequence etc
without the need of an `--external` fasta file.
- [ ] Automatic date for the man pages.
- [ ] Care a little about low level performance, [https://www.agner.org/optimize/#asmlib]

## Done
- [x] Support all standard genomic characters as defined on [https://en.wikipedia.org/wiki/Nucleic_acid_notation]
- [x] Paralellization of **nhush-bfm**
- [x] create index for multi-seq fa-file.
- [x] Load and save combs.
- [x] Introduce milestones:
- milestone 0: exclude everything within a
hamming radius 0, i.e. perfect matches
- milestone k: exclude everything within a
hamming radius of k.
The combs will determine what milestones have been reached and
which is next.
- [x] Have a list of sequences not to add to the hash table, _ulist_. This list should mask
out repeated patterns like 'AAA ... AA' (but importantly keep the first occurance).
No impact on performance for `chr17`...
- [x] multi-threading for the querying.
- [x] decreasing h as querying time goes down with fewer sequences
- [x] reverse complement
- [x] Load and save ulist not to redo it each time.
- [x] Improve the speed and memory usage for the comb_get_v3
algorithm. For example no need to explicitly generate all
_N choose k_ into an array.

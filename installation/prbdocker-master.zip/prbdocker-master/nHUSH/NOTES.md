# Notes

## Using Huge Pages
nHUSH uses 2 Mb page size by default.

Check that huge tables are enabled

``` SHELL
grep HUGETLB /boot/config-$(uname -r)
CONFIG_CGROUP_HUGETLB=y
CONFIG_ARCH_WANT_GENERAL_HUGETLB=y
CONFIG_HUGETLBFS=y
CONFIG_HUGETLB_PAGE=y                         # what we look for
CONFIG_HUGETLB_PAGE_FREE_VMEMMAP=y
# CONFIG_HUGETLB_PAGE_FREE_VMEMMAP_DEFAULT_ON is not set
```

Enable support for huge pages via madvice (if not already enabled).
``` SHELL
echo madvise >/sys/kernel/mm/transparent_hugepage/enabled
```

How to see that they are in use when nHUSH is running:

``` SHELL
$ grep "Huge" /proc/meminfo
Hugepagesize:       2048 k
AnonHugePages:   3022848 kB # There is where the memory goes ..
```

### References
 - [https://mazzo.li/posts/check-huge-page.html]
 - [https://www.kernel.org/doc/html/latest/admin-guide/mm/transhuge.html]

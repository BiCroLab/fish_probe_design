#!/bin/env python

def rc(seq):
    return seq.strip()[::-1].translate(
        str.maketrans(
            {'A' : 'T',
             'a' : 't',
             'T' : 'A',
             't' : 'a',
             'C' : 'G',
             'c' : 'g',
             'G' : 'C',
             'g' : 'c'}))

if __name__ == '__main__':
    import sys

    for line in sys.stdin:
        if line[0] == '>':
            print(line.rstrip())
        else:
            print(rc(line))

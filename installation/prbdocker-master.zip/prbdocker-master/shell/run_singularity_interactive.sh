# upon module load singularity
singularity run -H "$(pwd)" /group/bienko/containers/prb.sif
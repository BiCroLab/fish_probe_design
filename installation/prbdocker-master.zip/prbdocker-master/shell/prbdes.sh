source ~/shell/interactive.sh -m 4 -c 32
module load singularity
singularity run -H "$(pwd)" /group/bienko/containers/prb.sif


prbdes get_oligos DNA 1
prbdes run_nHUSH -d DNA -L 40 -l 21 -m 3 -t 40 -i 14
prbdes reform_hush_combined DNA 80 21 3
prbdes melt_secs_parallel
prbdes generate_blacklist -L 40 -c 100
prbdes build-db_BL -f q_bl -m 32 -i 6 -L 80 -c 100 -d 8 -T 72
prbdes cycling_query -s DNA -L 80 -m 8 -c 100 -t 40 -greedy
prbdes summarize-probes-final
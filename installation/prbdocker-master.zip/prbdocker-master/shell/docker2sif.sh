inter4
module load singularity
cd /group/bienko/containers
rm -f prb.sif
singularity build prb.sif docker-archive://prbdocker.tar
% ESCAFISH(1) escafish ABCDE | escafish documentation
% Erik Wernersson
% 2023

# NAME
**escafish** is a small tool to create FISH probes from oligo databases.

# SYNOPSIS

**escafish** [*OPTIONS*]

# OPTIONS
**\--db** _file.tsv_
: Specify the oligo database file to use, see EXPECTED INPUT below.

**\--mingap**
: Set the minimal distance between adjacent oligos.

**\--help**
: Show a short help message and quit. This should include default
  values for most parameters.

**\--noligos** _n_
: Specify the number of oligos per probe.

**\--out** _outfile_
: specify the file to write the probe to. If this is set, a log file
  called outfile.log.txt will also be created. If outfile is not
  specified the result will be written to the screen (stdout).

**\--pw** _v_
: set the weight for pairwise distances. Increase to get smaller
  probes, decrease to get better oligos.

**\--plot** _filename.svg_
: Plot to  _filename.svg_.

**\--greedy**
: Turn off exact search. When speed is more important than quality.

**\--verbose** _v_
: set the verbose level. 0=quit, 1=normal, >1 high.

# EXPECTED INPUT
A TSV file with the following required columns:

 - **start**, start position of the oligo
 - **end**, end position of the oligo
 - **oligo_cost**, how much does it cost to include this oligo.

it is fine if the TSV file has more columns and the column order does
not matter. The data needs to be sorted by the **start** column. Note
that **escafish** assumes that all oligos are on the same chromosome.

# OUTPUT
Writes the lines in the database the corresponds to the probe to the
screen or to the file specified by **--out**. If **--out** is
specified a log file will also be created with the extension .log.txt.

# WEB PAGE
[https://github.com/elgw/escafish/](https://github.com/elgw/escafish/)

# REPORTING BUGS
Please report bugs at
[https://github.com/elgw/escafish/issues/](https://github.com/elgw/escafish/issues/)

# COPYRIGHT
Copyright © 2022 Erik Wernersson.  License GPLv3+: GNU GPL version 3 or later
<https://gnu.org/licenses/gpl.html>.
This is free software: you are free to change and redistribute it.  There is NO WARRANTY, to the
extent permitted by law.

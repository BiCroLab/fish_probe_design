#ifndef apply_blacklist_h_
#define apply_blacklist_h_


#define _GNU_SOURCE
#include <assert.h>
#include <getopt.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include "version.h"
#include "read_db.h"
#include "readfa.h"
#include "atcg.h"


int
apply_blacklist(int argc, char ** argv);

#endif

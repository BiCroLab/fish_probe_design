#ifndef FIND_PROBE_SIMPLE_H
#define FIND_PROBE_SIMPLE_H

#include "escafish.h"

/* Simplest possible heuristics */
probe_t * find_probe_simple(pconf_t * );

#endif

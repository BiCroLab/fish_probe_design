#include "util.h"


#define NOTNULL(x) {                                            \
        if(x == NULL)                                           \
        {                                                       \
            fprintf(stderr,                                     \
                    "Got unexpected NULL pointer in %s%d\n",    \
                    __FILE__, __LINE__);                        \
            fprintf(stderr,                                     \
                    "This is a bug, please report it!\n");      \
            exit(EXIT_FAILURE);                                 \
        }}                                                      \



double clockdiff(struct timespec* end, struct timespec * start)
{
    double elapsed = (end->tv_sec - start->tv_sec);
    elapsed += (end->tv_nsec - start->tv_nsec) / 1000000000.0;
    return elapsed;
}

size_t get_peakMemoryKB(void)
{
    char * statfile = malloc(100*sizeof(char));
    NOTNULL(statfile);
    sprintf(statfile, "/proc/%d/status", getpid());
    FILE * sf = fopen(statfile, "r");
    if(sf == NULL)
    {
        fprintf(stderr, "Failed to open %s\n", statfile);
        free(statfile);
        return 0;
    }

    char * peakline = NULL;

    char * line = NULL;
    size_t len = 0;

    while( getline(&line, &len, sf) > 0)
    {
        if(strlen(line) > 6)
        {
            if(strncmp(line, "VmPeak", 6) == 0)
            {
                peakline = strdup(line);
                NOTNULL(peakline);
            }
        }
    }
    free(line);
    fclose(sf);
    free(statfile);

    // Parse the line starting with "VmPeak"
    // Seems like it is always in kB
    // (reference: fs/proc/task_mmu.c)
    // actually in kiB i.e., 1024 bytes
    // since the last three characters are ' kb' we can skip them and parse in between
    size_t peakMemoryKB = 0;
    //  printf("peakline: '%s'\n", peakline);
    NOTNULL(peakline);
    if(strlen(peakline) > 11)
    {
        peakline[strlen(peakline) -4] = '\0';

        //    printf("peakline: '%s'\n", peakline+7);
        peakMemoryKB = (size_t) atol(peakline+7);
    }

    free(peakline);
    return peakMemoryKB;
}


void show_time(FILE * f)
{
    f == NULL ? f = stdout : 0;
    int buf_len = 256;
    char buf[256];

    time_t now = time(NULL);
    struct tm * ptm = localtime(&now);
    strftime(buf, buf_len, "%FT%T", ptm);

    fprintf(f, "%s\n", buf);
    return;
}

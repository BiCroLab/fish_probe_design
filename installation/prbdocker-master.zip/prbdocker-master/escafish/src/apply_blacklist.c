#include "apply_blacklist.h"

#define NOTNULL(x) {                                            \
        if(x == NULL)                                           \
        {                                                       \
            fprintf(stderr,                                     \
                    "Got unexpected NULL pointer in %s%d\n",    \
                    __FILE__, __LINE__);                        \
            fprintf(stderr,                                     \
                    "This is a bug, please report it!\n");      \
            exit(EXIT_FAILURE);                                 \
        }}                                                      \


typedef struct {
    char * dbfile; /* File to check */
    char * blfile; /* "black list" */
    char * outfile; /* Where to write to */
    int verbose;

} bl_conf_t;

static void
bl_conf_free(bl_conf_t * conf)
{
    assert(conf != NULL);
    free(conf->dbfile);
    free(conf->blfile);
    free(conf);
    return;
}

static void
bl_usage()
{
    printf("USAGE\n");
    printf("escafish apply_blacklist --db d.tsv --bl b.fa --out file.tsv\n");
    printf("\n");
    printf("--db d.tsv\n\t"
           "The database to use, in TSV format\n");
    printf("--bl bl.fa\n\t"
           "A fasta file with sequences of high multiplicity\n");
    printf("--out file.tsv\n\t"
           "Optional output name\n");
    printf("\n");
    printf("The program will check the shortest distance from each sequence in "
           "the input database vs all sequences in the blacklist, using the ");
    printf("Hamming distance. The reverse complement of the sequence will also be used."
           "Finally a column 'bl_dist' will be appended to the input database and ");
    printf("everything will be written out the output file.");
    printf("\n");
    return;
}

static bl_conf_t *
bl_conf_new(int argc, char ** argv)
{
    bl_conf_t * conf = calloc(1, sizeof(bl_conf_t));
    NOTNULL(conf);
    conf->verbose = 1;

    struct option longopts[] = {
        { "bl",     required_argument, NULL, 'b' },
        { "db",     required_argument, NULL, 'd' },
        { "help",   no_argument, NULL, 'h' },
        { "out",    required_argument, NULL, 'o'},
        { "verbose", required_argument, NULL, 'v'},
        { "overwrite", no_argument, NULL, 'w'},
        { NULL, 0, NULL, 0 }
    };
    int ch;

    while((ch = getopt_long(argc, argv, "b:d:ho:v:w", longopts, NULL)) != -1)
    {
        switch(ch) {
        case 'b':
            conf->blfile = strndup(optarg, 1024);
            break;
        case 'd':
            conf->dbfile = strndup(optarg, 1024);
            break;
        case 'h':
            bl_usage();
            goto fail;
        case 'o':
            conf->outfile = strdup(optarg);
            break;
        case 'v':
            conf->verbose = atoi(optarg);
            break;
        }
    }

    if(!conf->dbfile)
    {
        fprintf(stderr, "No --db file specified\n");
        goto fail;
    }

    if(!conf->blfile)
    {
        fprintf(stderr, "No --bl file specified\n");
        goto fail;
    }

    if(!conf->outfile)
    {
        conf->outfile = malloc(strlen(conf->dbfile) + 128);
        NOTNULL(conf->outfile);
        sprintf(conf->outfile, "%s.bl_filtered.fa", conf->dbfile);
    }

    FILE * fid = fopen(conf->outfile, "r");
    if(fid != NULL)
    {
        printf("Error: The outfile %s does already exist\n", conf->outfile);
        goto fail;
    }

    return conf;

 fail:
    bl_conf_free(conf);
    return NULL;
}

static int hamming_distance(const char * A, const char * B, const int len)
{
    int hd = 0;
    for(int kk = 0; kk<len; kk++)
    {
        hd+=(A[kk] != B[kk]);
    }
    return hd;
}

int find_mindist(char * seq,
                 uint8_t * data,
                 fasta_records_t * rec)
{

    size_t len = strlen(seq);
    int mindist = (int) len;

    uint8_t * nseq = malloc(len);
    NOTNULL(nseq);
    uint8_t * rnseq = malloc(len);
    NOTNULL(rnseq);
    for(size_t kk = 0; kk<len; kk++)
    {
        switch(seq[kk]){
        case 'a':
        case 'A':
            nseq[kk] = numA;
            rnseq[len-kk-1] = 3 - numA;
            break;
        case 't':
        case 'T':
            nseq[kk] = numT;
            rnseq[len-kk-1] = 3 - numT;
            break;
        case 'c':
        case 'C':
            nseq[kk] = numC;
            rnseq[len-kk-1] = 3 - numC;
            break;
        case 'g':
        case 'G':
            nseq[kk] = numG;
            rnseq[len-kk-1] = 3 - numG;
            break;
        }
    }

    for(size_t kk =0 ; kk < rec->n; kk++)
    {
        assert(len == rec->len[kk]);
        int hd = hamming_distance((char*) nseq, (char*) data+rec->pos[kk], len);
        hd < mindist ? mindist = hd : 0;
        hd = hamming_distance((char*) rnseq, (char*) data+rec->pos[kk], len);
        hd < mindist ? mindist = hd : 0;
    }

    free(rnseq);
    free(nseq);
    return mindist;
}

void
append_mindist(bl_conf_t * conf, int * mindist, size_t N)
{
    FILE * in = fopen(conf->dbfile, "r");
    FILE * out = fopen(conf->outfile, "w");

    size_t n = 0;
    char * line = NULL;
    size_t len = 0;
    ssize_t read = 0;
    while ((read = getline(&line, &len, in)) != -1)
    {
        int ln = strlen(line);
        if(line[ln-1] == '\n')
        {
            line[ln-1] = '\0';
        }

        if(n>N)
        {
            break;
        }

        if(n == 0)
        {
            fprintf(out, "%s\tbl_dist\n", line);
        } else {
            fprintf(out, "%s\t%d\n", line, mindist[n-1]);
        }
        n++;

    }


    fclose(in);
    fclose(out);
    return;
}

int
apply_blacklist(int argc, char ** argv)
{
    bl_conf_t * conf = bl_conf_new(argc, argv);
    if(!conf)
        return EXIT_FAILURE;

    if(conf->verbose > 0)
    {
        printf("Will filter your sequences in %s against the sequences in %s\n",
               conf->dbfile, conf->blfile);
        printf("The result will be written to %s\n", conf->outfile);
    }

    /* Read db file */
    read_db_config rconf = {};
    rconf.log = stdout;
    rconf.tsvfile = conf->dbfile;
    rconf.verbose = conf->verbose;
    rconf.read_seq = 1;
    rconf.ignore_cost = 1;
    oligodb_t * db = read_db(rconf);
    if(db == NULL)
    {
        printf("Could not read %s\n", conf->dbfile);
        return EXIT_FAILURE;
    }

    if(db->noligos < 1)
    {
        printf("Found no oligos in %s\n", conf->dbfile);
        return EXIT_FAILURE;
    }

    if(conf->verbose > 0)
    {
        printf("Found %zu sequences of length %d\n", db->noligos, db->oligolen);
    }

    if(conf->verbose > 1)
    {
        printf("Got these sequences in the database\n");
        for(size_t kk = 0; kk<db->noligos; kk++)
        {
            printf("%zu: %s\n", kk, db->seq[kk]);
        }
    }


    printf("Reading %s\n", conf->blfile);
    size_t bl_data_size = 0;
    fasta_records_t * bl_records;
    uint8_t * bl_data = readfa(conf->blfile, &bl_data_size, &bl_records);
    if(bl_data == NULL)
    {
        printf("Failed to read from %s\n", conf->blfile);
        return EXIT_FAILURE;
    }

    size_t failed_length = 0;
    for(size_t kk = 0; kk < bl_records->n; kk++)
    {
        if(bl_records->len[kk] != (size_t) db->oligolen)
        {
            failed_length++;
            printf("%zu vs %d\n", bl_records->len[kk], db->oligolen);
        }
    }

    if(failed_length)
    {
        printf("%zu oligos were not of length %d\n", failed_length, db->oligolen);
        return(EXIT_FAILURE);
    }

    printf("Filtering (Brute force, 2 x %zu x %zu = %zu (%e)\n",
           db->noligos,
           bl_records->n,
           2*db->noligos*bl_records->n,
           (double) 2*db->noligos*bl_records->n);

    int * mindist = calloc(db->noligos, sizeof(int));
    NOTNULL(mindist);

#pragma omp parallel for
    for(size_t kk = 0; kk < db->noligos; kk++)
    {
        mindist[kk] = find_mindist(db->seq[kk], bl_data, bl_records);
    }

    /* Append result to input file */
    append_mindist(conf, mindist, db->noligos);

    free(mindist);
    oligodb_free(db);
    free(bl_data);
    fasta_records_free(&bl_records);
    bl_conf_free(conf);
    return EXIT_SUCCESS;
}

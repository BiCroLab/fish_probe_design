# Create a database (once)
# Example at https://www.ncbi.nlm.nih.gov/books/NBK279680/
# cd hg
# cat Homo_sapiens.GRCh37.dna.chromosome.*.fa > GRCh37_all.fsa
# cd ..
# makeblastdb -in hg/GRCh37_all.fsa -dbtype nucl -parse_seqids -out hg_blast/nt.fa
# cd comparison

echo "Running blast with k=40, n=100"
time blastn -dust no -strand plus -word_size 7 -num_descriptions 5 -num_alignments 10000 -db ../hg_blast/nt -query ../k40_n100 -out out_blast
# 67 s

echo "Running blast with k=40, n=1000"
time blastn -dust no -strand plus -word_size 7 -num_descriptions 5 -num_alignments 10000 -db ../hg_blast/nt -query ../k40_n1000 -out out_blast
#  777 s 

# -> 900/(710) = 1.3 seq/s

echo "Running blast with k=60, n=100"
time blastn -dust no -strand plus -word_size 7 -num_descriptions 5 -num_alignments 10000 -db ../hg_blast/nt -query ../k60_n100 -out out_blast
# 106 s

echo "Running blast with k=60, n=1000"
time blastn -dust no -strand plus -word_size 7 -num_descriptions 5 -num_alignments 10000 -db ../hg_blast/nt -query ../k60_n1000 -out out_blast
#
# from /proc/PID/status:
# VmPeak:	 1268268 kB
# 1192 s

# -> 900/(1192-106) = 0.83 sequences/second


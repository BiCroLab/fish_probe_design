#!/bin/bash
set -e

cd ..
./genrand -l 30 -n 100  > k30_n100
./genrand -l 30 -n 1000 > k30_n1000

./genrand -l 40 -n 100  > k40_n100
./genrand -l 40 -n 1000 > k40_n1000

./genrand -l 60 -n 100  > k60_n100
./genrand -l 60 -n 1000 > k60_n1000


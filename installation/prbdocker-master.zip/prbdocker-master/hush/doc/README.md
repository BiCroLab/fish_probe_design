# Documentation for HUSH

Generate `hush.pdf` with

```
make
```


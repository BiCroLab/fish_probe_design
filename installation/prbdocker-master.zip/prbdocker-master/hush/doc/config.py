
class config:
    ssl = 0
    nss = 0
    mm = 0
    sl = 0

    def __init__(self, sl, ssl, nss, mm):
        self.sl = sl
        self.ssl = ssl
        self.nss = nss
        self.mm = mm


C = []

class bestConf:

    L = 0  # string length
    hr = 0  # hamming radius

    l = 0  # substring length
    nl = 0  # number of substrings
    mm = 0  # mismatches per substring
    gain = 0
    lmax = 13

    def __str__(self):
        if(self.gain>0):
            return(F"(L {self.L} hr {self.hr}) -> l {self.l} nl {self.nl}\
 mm {self.mm} gain {self.gain}")
        else:
            return(F"(L {self.L} hr {self.hr}) -> NA")

    def __init__(self, L, hr):
        self.L = L
        self.hr = hr
        self.optimize()

    def getgain(self, mm, l, nl):
        assert(mm <= 1)
        assert(l*nl <= self.L)
        assert(self.hr < nl*(mm+1))

        nbuckets = 4**l
        nvariations = nl*(3*l+1)**mm
        g = nbuckets/nvariations

        if(l > self.lmax):
            g = 0

        if g > self.gain:
            self.gain = g
            self.l = l
            self.mm = mm
            self.nl = nl
        return(g)

    def optimize(self):
        """
        Find:
            mm : mismatches per substring
            ssl : sub string length
            nss: number of sub strings
        based on:
            sl: string length
            hr: hamming radius

        Best if the gain is optimal
        And that probably means that 0 mm
        """

        for mm in range(0, 2):
            #  Implies nl is at least self.hr+1
            for mm in range(0,2):
                if mm == 0:
                    nl_min = self.hr+1
                if mm == 1:
                    nl_min = self.hr//2+1;
                for nl in range(nl_min, nl_min+10):
                    for l in range(5, self.L//nl+1):
                        g = self.getgain(mm, l, nl)


for L in range(60,61):
    for hr in range(3, 10):
        print(bestConf(L, hr))


C.append(config(60, 10, 6, 0))
C.append(config(40, 13, 3, 0))
C.append(config(40, 13, 3, 1))
C.append(config(30, 10, 3, 1))

for conf in C:
    c = 4**(-conf.ssl)*conf.nss*(3*conf.ssl+1)**conf.mm
    g = 1/c
    print(F"sl: {conf.sl} ssl: {conf.ssl} nss: {conf.nss} mm: {conf.mm} gain: {g}")



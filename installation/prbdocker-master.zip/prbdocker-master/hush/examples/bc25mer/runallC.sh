#!/bin/bash

# Example file for how to run hush on some query sequences
# against the whole genome.

set -e  # abort on errors

nThreads=4

GENOMEDIR=../hg/GRCh37/
queryFile=bc25mer.240k.fasta
HCONF="-m 2 -l 25 -m 2 -x -t $nThreads -p 1 -C"
folder=queryC

echo "HUSH config: $HCONF"

cd $folder
  split -n l/$nThreads ../$queryFile
cd ..

for hgfile in $GENOMEDIR/*.fa ; do
  hushp $HCONF -r $hgfile -q $folder
  cd $folder
  cat *.out > query.out # join the output files
  split -n l/$nThreads query.out # split them again
  cd ..
done

# Output is in query/query.out
# cleaner -f query/query.out -n > bc25mer.240k.Hamming2.fasta

awk '$2>0 {print $0}' $folder/query.out

# Or with the comment lines:
awk '$2>10 {print l; print $0}  {l = $0}' $folder/query.out 

# >bc25mer_73451
# TTGGCTTTCAGGCTTTAAACTACCT, 158
#

exit 1

#!/bin/bash

# Example file for how to run hush on some query sequences
# against the whole genome.

set -e  # abort on errors

mkdir query

#
#cat /data/hg/GRCh37/Homo_sapiens.GRCh37.dna.chromosome.21.fa | tr -d '\n' | fold -w40 > query/query1.fa
#grep -Eiv 'N' < query/query1.fa > query/query.fa
genrand -l 40 -n 1000000 > query/query.fa


GENOMEDIR=/data/hg/GRCh37/
queryFile=query.fa
HCONF="-l 40 -m 2 -x -t 8"

cd query 
  split -n l/8 ../$queryFile
cd ..

for hgfile in $GENOMEDIR/*.fa ; do
  hushp $HCONF -r $hgfile -q query 
  cd query
  cat *.out > query.out # join the output files
  split -n l/8 query.out # split them again
  cd ..
done

diff query/query.in query/query.out
exit 1


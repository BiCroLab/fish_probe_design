
set -e


# Generate a random "chromosome"
if [ -f ref.fa ]; 
then 
  echo "! Removing ref.*"
  rm ref.*
fi
genrand -l 1000000 -n 1 > ref.fa

# Generate a set of sequences to scan
genrand -l 40 -n 5 > query.fa

if [ -d query ]; 
then 
  echo "! removing folder query"
  rm -Rf query
fi

mkdir query

cd query
split -n l/4 ../query.fa
cd ..

hushp -l 40 -t 4 -m 5 -r ref.fa -q query -p 2 -o test.fa

cd query
cat *.out > ../query.fa.out.DISCARD
cd ..

hushp -l 40 -t 4 -m 5 -r ref.fa -q query -p 2 -o test.fa -c

cd query
cat *.out > ../query.fa.out.COUNT
cd ..




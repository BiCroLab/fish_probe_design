#!/bin/bash
set -e

function drawLine()
{

  for i in $(seq 1 20)
  do
    printf '\u2500'
  done


  tLen=${#1}
  if [ "$tLen" -gt "0" ]
  then
    printf "$1"
  fi

  lastLen=$((20-$tLen))
  if [ "$lastLen" -le "0" ]
  then
    lastLen=0
  fi

  for i in $(seq 1 $lastLen)
  do
    printf '\u2500'
  done

  printf '\n'
  echo $tLen
}

## Settings
# fasta file to use
fafile=randref.fa
#../src/a.out $fafile 40 > query/xaa
len=60
mmTo=9

echo ""
echo "This script will read a random sequence of length $len from"
echo "fa file: ${fafile}"
echo "That sequence will then be permuted"
echo "then it will use hushp and see if it hush finds it"
echo "hush will look within a Hamming radius of 0 to $mmTo"
echo ""
read -n 1 -s -r -p "Press any key to continue"
echo ""
drawLine "Generating ${fafile}"
touch ${fafile}.x
rm randref.fa.*
genrand -l 10000000 > $fafile

drawLine "Running hush"

# get a random string of length 40
seq=$(readrand $fafile $len)
# generate also some similar sequances
genmm -f 0 -t 21 -n 1 -s $seq > query/xaa
# run throught hush
hushp -x -l $len -m $mmTo -q query -t 1 -r $fafile -f 0 -C -p 1
# see if it was found
drawLine "Done"
cat query/xaa.out


#!/bin/bash

set -e

remkdir () {
  # Create a new empty folder
  # or empty the folder if it exists
  if [ ! -d $1 ]; then
    mkdir $1
  else
    rm -rf $1
    mkdir $1
  fi
}

smallref () {
  echo "Reference sequence same length as query sequence"
  # Reference sequence has the same length as the query sequence
  # That tests so that sequences close to end and beginning of reference
  # file are found.
  seqLength=$1
  rm ref.*
  genrand -l $seqLength > ref.fa
  remkdir q1
  cp ref.fa q1/xaa

  hushp -t 1 -q q1 -r ref.fa -m 5 -l $seqLength -p 0 -f 0 -C
  cat q1/xaa.out
  nfound=$(tail -n 1 q1/xaa.out | awk '{print $2}')
  if (($nfound != 1)) ; then
    echo "Error at line $LINENO : expected one match"
    exit 1
  fi

  # Try doing the same thing again,
  # The second time it is run there is the difference that
  # The .B and .H file will be read from disk, and not generated 
  # directly in memory.

  rm q1/xaa.out
  hushp -t 1 -q q1 -r ref.fa -m 5 -l $seqLength -p 0 -f 0 -C
  cat q1/xaa.out
  nfound=$(tail -n 1 q1/xaa.out | awk '{print $2}')
  if (($nfound != 1)) ; then
    echo "Error at line $LINENO : expected one match"
    exit 1
  fi

  # Non-unique counting
  # if '-m 0' we expect one match per sub sequence.
  rm q1/xaa.out
  hushp -t 1 -q q1 -r ref.fa -m 0 -l $seqLength -p 0 -f 0 -c
  nfound=$(tail -n 1 q1/xaa.out | awk '{print $2}')
  echo "Fount $nfound with -c"
  if (($seqLength == 30)) ; then
    if (($nfound != 3)) ; then
      echo "Error at $LINENO"
      exit 1
    fi
  fi
  if (($seqLength == 40)) ; then
    if (($nfound != 3)) ; then
      echo "Error at $LINENO"
      exit 1
    fi
  fi
  if (($seqLength == 60)) ; then
    if (($nfound != 6)) ; then
      echo "Error at $LINENO"
      exit 1
    fi
  fi

  # Filter mode -x
  rm q1/xaa.out
  hushp -t 1 -q q1 -r ref.fa -m 0 -l $seqLength -p 0 -f 0 -x
  nlines=$(wc -l q1/xaa.out)
  if (($nlines > 1)) ; then
      echo "Error at $LINENO"
      exit 1
    fi
}

smallref 30
smallref 40
smallref 60

echo "All tests passed"

#!/bin/bash

set -e

# Add binaries to path (temporarily)
if ! [ -x "$(command -v hushp)" ]; then
  PATH=$PATH:../bin/
fi

echo $PATH

if ! [ -x "$(command -v hushp)" ]; then
  echo 'Can not find hushp!'
  echo 'Did you compile it?'
  exit 1
fi

if [ ! -d "data" ]; then
  mkdir data
fi

echo "Generating mismatches from a input sequence known to be in chr9
The exact input sequence is there as well as permutations with 1 to 7 mismatches"

chrfile="/data/hg/GRCh37/Homo_sapiens.GRCh37.dna.chromosome.9.fa"
echo "Location of chr9: $chrfile
change if not correct
"


genmm -s ATTTTATGAACCAAGTAGAACAAGATATTTGAAATGGAAA -f 0 -t 7 > data/few40
echo "Running hush"

hush -l 40 -r $chrfile -q data/few40 -o data/temp -m 5 -p 1 

echo "Running parallel hush"
cd data
split -l 8 few40
cd ..

hushp -l 40 -t 2 -r $chrfile -q data -o data/temp.p1 -m 5 -p 1 

cat data/temp
cat data/xaa.out
cat data/xab.out

echo "Same again but now with many mismatches"
genmm -s ATTTTATGAACCAAGTAGAACAAGATATTTGAAATGGAAA -f 5 -t 5 -n 10000 -c > data/many40
wc -l data/many40
hush -l 40 -r $chrfile -q data/many40 -o data/temp -m 5 -p 1 
echo "output should be empty!
That means that no matches were found"
wc -l data/temp

cd data
# split -l 5000 many40
split -n l/2 many40
cd ..

hushp -l 40 -t 2 -r $chrfile -q data -o data/temp.p1 -m 5 -p 1 
wc -l data/xaa.out
wc -l  data/xab.out



#valgrind --tool=massif --pages-as-heap=yes --massif-out-file=massif.out ./a.out -l 40 -r chr9.fa -q few40 -o temp -m 5 -v 1 
#grep mem_heap_B massif.out | sed -e 's/mem_heap_B=\(.*\)/\1/' | sort -g | tail -n 1
# 987430912

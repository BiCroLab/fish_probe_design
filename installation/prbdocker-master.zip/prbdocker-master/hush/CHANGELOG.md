## 0.0.2
- Added `makedeb-ubuntu_2204.sh` to create a debian package. The deb
  package does only contain the binary `hushp` since the other tools
  are considered obsolete (and should use the counterparts in nHUSH).
- Changed how the software version is written in `src/hush.h`

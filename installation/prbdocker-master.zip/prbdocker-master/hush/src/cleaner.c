#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include "hush.h"

#ifndef _POSIX_C_SOURCE
#define  _POSIX_C_SOURCE >= 200809L
#endif

void printline_nonunique(char * A, char * B)
{

  if(A[0] == '>')
    if(!(B[0] == 'A' || B[0] == 'T' || B[0] == 'C' || B[0] == 'G'))
      printf("%s", A);
}

void printline(char * A, char * B)
{

  if(A[0] == '>')
    if(B[0] == 'A' || B[0] == 'T' || B[0] == 'C' || B[0] == 'G')
      printf("%s%s", A, B);
}

void usage(char * name)
{
    printf("Usage: %s -f file -n -h\n", name);
    printf(" -n  only non-unique, otherwise only the unique are shown\n");
    printf(" -h  show this help\n");
    printf(" -v  show version info\n");
    printf("See the man page for more information.\n");
}

int main(int argc, char ** argv)
{

  char * file = malloc(1024*sizeof(char));
  file[0] = '\0';
  int mode = 0;

  int ch;
  while((ch = getopt(argc, argv, "f:nhv")) != -1)
  {
    switch(ch) {
      case 'n':
        mode = 1;
        break;
      case 'f':
        strcpy(file, optarg);
        break;
      case 'h':
        usage(argv[0]);
        return 0;
      case 'v':
        hush_version();
        return(0);
      default:
        usage(argv[0]);
        return -1;
    }
  }
 
  if(strlen(file) == 0)
    {
      printf("No file name given\n");
      return -1;
    }


  // Run
  FILE * fin = fopen(file, "r");
  if(fin == NULL)
  {
    printf("Can not open %s\n", file);
    return -1;
  }

  size_t linecap = 1024;

  char * A = malloc(linecap*sizeof(char));
  char * B = malloc(linecap*sizeof(char));

  size_t qread = 0;

  qread = getline(&A, &linecap, fin);
  if(qread == -1)
    return 1;

  while(1)
  {
    qread = getline(&B, &linecap, fin);
    if(qread == -1)
      return 0;

    if(mode == 0)
      printline(A, B);
    if(mode == 1)
      printline_nonunique(A,B);

    qread = getline(&A, &linecap, fin);
    if(qread == -1)
      return 0;

    if(mode == 0)
      printline(B, A);
    if(mode == 1)
      printline_nonunique(B,A);

  }

  return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <string.h>
#include <strings.h>
#include <unistd.h> // for read/write
#include "../hush.h"

/* CGI "script" that can communicate with hushp when run with the `-s` flag.
 * Communication is done over a tcp socket (a unix domain socket would probably be as fine).
 *
 * The port number is hard coded in hush.h
 *
 * Answers the GET request "version"
 * Sends "POST" requests to hushp if running.
 *
 */

void error(char *msg)
{
  perror(msg);
  exit(0);
}

void client_send_get(char * msg)
{
  //  printf("Trying to send %s\n", msg);

  size_t MAXLEN_ANS = 100000;

  int portno = PORT_NUMBER;

  int sockfd, n;

  struct sockaddr_in serv_addr;
  struct hostent *server;

  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd < 0) 
  {
    printf("Error opening socket\n");
    error("ERROR opening socket");
  }

  server = gethostbyname("localhost");
  if (server == NULL) {
    printf("ERROR, no such host\n");
    exit(0);
  }

  bzero((char *) &serv_addr, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  bcopy((char *)server->h_addr, 
      (char *)&serv_addr.sin_addr.s_addr,
      server->h_length);
  serv_addr.sin_port = htons(portno);

  if (connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) < 0) 
  {
    printf("Error connecting\n");
    error("ERROR connecting");
  }

  n = write(sockfd,msg,strlen(msg));
  if (n < 0) 
  {
    printf("Error writing to socket\n");
    error("ERROR writing to socket");
  }

  char * ans = malloc(MAXLEN_ANS*sizeof(char));

  n = read(sockfd, ans , MAXLEN_ANS);
  if (n < 0) 
  {
    error("ERROR reading from socket");
    printf("Error reading from socket\n");
  }
  //printf("GOT %d from HUSH: \"%.*s\"\n", n, n, ans);

  printf("%.*s", n, ans);
  return;
}

int main(int argc, char ** argv, char ** envp) {

  int debug = 0;

  printf("Content-Type: text/plain;charset=us-ascii\n\n");

  if(debug) 
  { // Show command line arguments
    printf("argc: %d\n", argc);
    for(int kk = 0; kk<argc; kk++)
    {
      printf("argv[%d] = %s\n", kk, argv[kk]);
    }
  }

  if(debug)
  { // show environmental variables
    for (char **env = envp; *env != 0; env++)
    {
      char *thisEnv = *env;
      printf("%s\n", thisEnv);    
    }
  }


  /* For METHOD = "GET"
   * Data is stored in the environmental variable "QUERY_STRING"
   */

  char * data = getenv("QUERY_STRING");

  if(data != NULL)
  {
  if(debug){
    printf("QUERY_STRING = \"%s\"\n", data);
  }

    if(strcmp(data, "version") == 0)
    {
      hush_version();
      return 0;
    }
  }

  /* For METHOD = "POST"
   * Data is passed to STDIN, size of the request can be
   * read from the CONTENT_LENGTH environmental variable.
   */
  char * lenStr = getenv("CONTENT_LENGTH");
  if(lenStr == NULL)
  {
    printf("No \"POST\" message and no known \"GET\" request.\n");
  } else {
    size_t len = atol(lenStr);
    if(len>1000000)
    {
      printf("Message is too long\n");
      return 0;
    }
    size_t extra = 20;
    char * input = malloc((len+extra)*sizeof(char));
    char * gotIt = fgets(input, len+extra, stdin);
    if(gotIt == NULL)
    {
      printf("Failed reading from stdin\n");
    } else {
      if(debug)
      {
        printf("%s\n", input);
      }
    }

    char delim[] = "=";
    char *ptr = strtok(input, delim);
    // printf("0: %s\n", ptr);

    char * field = malloc(1024*sizeof(char));
    sprintf(field, "data");

    while(ptr != NULL)
    {
      if(strncmp(ptr, field, 4) == 0)
      {        
        ptr = strtok(NULL, delim);
        if(ptr != NULL) {
          if(debug){ printf("Sending: %s\n", ptr); }
          client_send_get(ptr);
        }
      }
      ptr = strtok(NULL, delim);
    }
  }

  return 0;
}

#ifndef __hush_server_h__
#define __hush_server_h__


void hush_server(sparam * Q);


#endif

# Hamming distance with popcnt
It is possible to compare sequences extremely fast using the special instruction `popcnt` found on modern 64-bit processors. In order to do so the characters need to represented by a unique bit each, for example:

For example:
```
Letter  Binary Decimal
  A      0001     1
  T      0010     2
  C      0100     4
  G      1000     8 
 *N      1111    15

*N = any nucleotide. There can not be N in the query string, only
allowed in the target sequences.

Then, for example
A & A = 0001
A & B = 0000
```

There are suggestions on the net to code the Hamming distance using
the `popcnt` instruction by hand. On this page it is shown to
outperform gcc:
[https://danluu.com/assembly-intrinsics/]().
However, `objdump -d ush` suggests that gcc is doing a good job with
 popcount today. Could it be done with one instruction less per
popcnt?


```
$ objdump -d ush
...
 ac2:   f3 48 0f b8 c9          popcnt %rcx,%rcx
 ac7:   01 c8                   add    %ecx,%eax
 ac9:   48 8b 4a 28             mov    0x28(%rdx),%rcx
 acd:   4c 21 c9                and    %r9,%rcx
 ad0:   f3 48 0f b8 c9          popcnt %rcx,%rcx
 ad5:   01 c8                   add    %ecx,%eax
 ad7:   48 8b 4a 30             mov    0x30(%rdx),%rcx
 adb:   4c 21 c1                and    %r8,%rcx
 ade:   f3 48 0f b8 c9          popcnt %rcx,%rcx
 ae3:   01 c8                   add    %ecx,%eax
 ae5:   89 f9                   mov    %edi,%ecx
 ae7:   23 4a 38                and    0x38(%rdx),%ecx
 aea:   f3 48 0f b8 c9          popcnt %rcx,%rcx
...

$ gcc --version
gcc (Ubuntu 7.2.0-8ubuntu3) 7.2.0
```

